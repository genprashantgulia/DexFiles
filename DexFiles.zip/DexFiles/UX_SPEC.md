# DexFiles UX spec (v1 draft, for approval)

Goal: every control has ONE home, every view has a reason to exist, and the same app feels native on phone, tablet and DeX.

## 1. Where things live (one job per place)

| Question the user has | Where it is answered | Notes |
|---|---|---|
| Where am I? | Top bar: back / forward / up, **title + path pill** (each segment tappable, long-press = sibling menu) | Samsung-style pill breadcrumb under the title on tablet/DeX; title only on phone |
| How is this ordered? | **Sort strip** directly above the files: `Name ↑ ▾` on the left, item count + view icon on the right | Exactly like Samsung My Files. Tap = choose key, arrow = flip direction. Details view also sorts by tapping column headers |
| How does it look? | **⋮ menu → View** (Icons, List, Details, Columns) and, on wide windows, a view button in the top bar | Sort is NOT in this menu (my earlier design duplicated it) |
| What can I do with the selection? | **Floating action pill at the bottom** (phone/tablet) or top action bar (DeX): Share, Copy, **Move**, Delete, More | Samsung pattern. Appears only in selection mode |
| What can I do here (no selection)? | **⋮ menu**: Select, New folder, New file, Paste, View, Show hidden, Settings | Also in right-click on empty space |
| What can I do with this item? | Long-press (touch) / right-click (mouse) context menu; keyboard shortcuts | Same list as selection actions, plus Open with, Properties, Rename |
| Find something | Search pill (expands to a full search screen with recent searches and type filters) | |
| Other places / tabs | Sidebar (drawer on phone/small tablet, permanent on wide); tabs strip only on wide windows | Tabs move into the top bar area like iPad; "+" always visible |

### Selection mode
- Enter by: long-press, tapping the **Select** pill, Ctrl/Shift-click, or dragging a rubber band (mouse).
- Top: `✕  N selected`  + select-all checkbox. Rows show check circles. Bottom pill: **Share · Copy · Move · Delete · ⋯**.
- **Move / Copy open a destination sheet** (Samsung "Move to"): storage list, recent folders, "New folder", then a Move here button. Also supported: cut/paste, drag between panes or windows, Ctrl+X/V.
- Delete = Trash with an **Undo** snackbar (no scary dialog unless permanent).

## 2. Views: why each exists

| View | It exists for | Best for | Shown on |
|---|---|---|---|
| **Icons** | Recognising things by sight | Photos, videos, screenshots, design assets, folders you know by look. Real-aspect thumbnails, pinch to resize | All sizes |
| **List** | Fast scanning with big, calm touch targets: name + `date · size` | Daily driver: Downloads, Documents, anything text-heavy. Default on phone | All sizes |
| **Details** | Auditing: compare size/date/type, clean up, work on several levels at once | Large folders, "what is eating my storage", sorting by Size/Date. **Tree rows**: chevron expands a folder inline (indented), so you can select across folders without navigating. Columns (Kind, Size, Date modified/created, …) are **resizable, reorderable, hideable** | Tablet and DeX (hidden under ~600 dp) |
| **Columns** | Exploring deep trees without losing context | Android/data, project trees, moving files up/down levels. Each click opens the next column; selected file previews on the right; arrow keys walk the tree | Wide windows only |
| *Gallery (later)* | Triage a photo folder: big preview + filmstrip | Camera roll, screenshots | Wide + categories Images/Videos |

Rules that make views feel smart:
1. **Remembered per folder**, with sensible defaults by content: mostly images → Icons; Downloads/Documents → List; storage root → List; Details/Columns only when chosen.
2. Switching view keeps selection and scroll position; the change cross-fades (200 ms).
3. Home, categories, search results and Trash all use the SAME views (no special screens).
4. Phone never offers a view that cannot fit (Details/Columns hidden when narrow).

## 3. Behaviour rules
- **Tap** opens (single-tap setting); **long-press** enters selection; **double-click** opens on mouse; **right-click** context menu; **Space** Quick Look; **Enter** open; **F2** rename.
- **Back** = go back in history; **Up** = parent folder. Neither auto-selects anything.
- **Rename**: inline in the row/tile (iPad), name selected without extension, Enter confirms, Esc cancels.
- **New folder**: appears in the list already in rename mode.
- **Progress**: jobs show in a bottom sheet/strip with cancel; Undo for delete/move.
- **Zoom**: pinch / Ctrl+scroll changes icon size in Icons view and row density in List/Details.
- **Errors** are human sentences with an action ("Not enough space. Free up space").

## 4. Visual system (so everything is in proportion)
- **Font**: Inter (optional "System font" setting later). Scale: Large title 28/34 semibold · Title 20/26 semibold · Body 16/22 · Secondary 13/18 · Caption 12/16. Never more than 3 sizes on one screen region.
- **Spacing grid**: 4, 8, 12, 16, 24, 32. Screen gutters 16 (phone) / 24 (tablet) / 24 (DeX).
- **Radii**: rows & chips 12, cards 16, sheets/dialogs 24, pills full.
- **Touch target** min 48 dp; row heights: List 64, Details 52 (Compact 40 with mouse), Columns 52.
- **Colour**: iPad-neutral surfaces, one accent (blue), yellow folders, tonal elevation (no heavy shadows), hairline dividers inset past the icon.
- **Motion**: 200 ms standard ease for view switch, sheet in/out, selection circle pop; no decorative animation.
- **Icons**: one family, 24 dp, 1.5 dp visual weight; file-type tiles use the same rounded-square shape and a small set of hues.

## 5. Build order (each is one chunk / one build)
1. **Design tokens** (Dimens.kt, type scale applied everywhere).
2. **Top bar + path pill + sort strip + ⋮ menu restructure.**
3. **Views rework**: Icons, List, Details-as-tree with resizable/reorderable columns, Columns; per-folder memory.
4. **Selection mode**: top count bar, floating action pill, **Move/Copy destination sheet**, Undo.
5. **Inline rename + context menus** polish.
6. **Tabs** redone (iPad pill tabs near top bar), **sidebar** polish (dotted dividers, storage card).
7. **Settings** as grouped-card screen.
8. **Viewers**: image (swipe, zoom), text, PDF, video/audio; PDF/doc thumbnails.
9. Pinch-zoom everywhere; dual pane last (two app windows already work in DeX).

## Open decisions (my recommendation first)
- Sort strip on every view, including phone? **Yes** (Samsung does).
- Tabs: top-bar pills, hidden on phone until a 2nd tab exists? **Yes.**
- Move/Copy via destination sheet AND cut/paste? **Both.**
