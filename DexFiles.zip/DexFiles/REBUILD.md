# DexFiles rebuild plan
Engine stays (core/, data/, state/). UI rewritten in `ui2/`, tokens first, one stage per build.

## Design system (ui2/design)
- Grid: 4dp base; spacing 4/8/12/16/24/32. Radii: 12 control, 20 card, 28 sheet, pill. Touch target 48, bar 56.
- Surfaces (AMOLED): canvas #000, card #0E0E10, raised #1A1A1D, overlay #242428. No borders; separation by tone only.
- Type: Inter, tight scale: Title 28/34 semibold, Heading 20/26 semibold, Body 16/22, Label 14/18 medium, Caption 12/16.
- Icons: Material Rounded family only, 24dp, one weight.
- Motion: springs (press, expand), 280ms emphasized for page. Every state change animates; nothing pops.
- Folders: customizable colour + glyph + badge (FolderStyle, stored per path).

## Layout principles
Top: breadcrumb + tabs only. Bottom floating dock (thumb zone): contextual — browse / select / search.
Search expands inside the dock with scope chip. Sidebar = places only. Home = Recent only.

## Stages
1. Design system + components (this build)  2. Browse screen (list/wide/grid/gallery/columns)  3. Dock, selection, search, switch MainActivity
4. Folder customization  5. Viewers  6. Settings/Edit home  7. Tags, network, dual pane
