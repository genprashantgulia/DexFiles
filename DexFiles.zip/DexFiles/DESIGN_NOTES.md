# Design reference notes (from user's screenshots, 2026-10-29)
Read this before touching UI. Inspirations to use ONLY: iPadOS Files and Samsung One UI 9 My Files (tablet, dark).

## One UI 9 My Files (tablet) - what to copy
- Sidebar: top row = menu icon (left) + settings gear (right). Items: Recent files, dotted divider, Downloads, Documents, Images, Audio files, Videos, Installation files (each a thin LINE icon in its own colour: teal, orange, pink, indigo, purple, green "APK"), dotted divider, then Storage: "Internal storage" as a rounded card showing "114.1 GB / 128 GB" with an expand chevron (expands to the folder tree), then Storage Share ("1 device available"), Google Drive / OneDrive ("Not signed in"). Big text, generous row height, 2-line items with grey subtitle. Selected item = dark rounded rectangle.
- Header: large CENTERED title (e.g. "Internal storage") with a grey subtitle underneath (free space / total size, e.g. "13.82 GB free", "5.38 GB"). Selection mode changes it to "2 selected" + total size.
- Pill breadcrumb bar: full-width rounded pill; ancestors grey separated by ">", current folder in accent blue. Right of it: panel/columns toggle, search, overflow (3 dots).
- Under it: "All v" filter dropdown (left) and sort "Type | up-arrow" (right).
- List rows: yellow folder icon (camera glyph for DCIM, download arrow for Download, zipper dots on zip files), name, grey date line, right-aligned "9 items" or file size; inset hairline separator starting at the text. Pinned system folders first, then a full-width rule, then the rest.
- Column (Miller) view via the panel toggle: columns side by side, selected row = rounded highlight.
- Category pages (Downloads): chips row filtering by source app (All = filled blue, others outlined pills: Claude, My Files, YTDLnis...), "File view v" dropdown, dense grid of square thumbnails edge to edge with filename overlaid on a bottom gradient.
- Selection mode: "All" check-circle top-left, "Cancel" top-right, blue check circles left of each row, floating rounded bottom action pill with icon+label: Move, Copy, Share, Delete, More. "More" popup: Copy to clipboard, Details, Rename, Extract, Extract to another folder, Extract to current folder, Add to favourites, Open with, Add to Home screen, Move to Secure Folder.
- Search: full screen; back arrow; "Filters" collapsible with toggle "Search by name only"; "Recent searches" card with removable chips and "Clear all"; search pill with mic + overflow near the bottom (above keyboard).
- Settings: rounded floating panel with grouped rounded cards: Cloud accounts; File management (toggles: show hidden system files, show cloud files in categories); "Edit home"; Advanced (toggles); Privacy.

## iPadOS Files - what to copy (from first screenshot, iPadOS 26-style promo)
- Sidebar: Recents, Shared; collapsible sections Favorites, Locations, Tags (coloured dots); selected item = soft rounded highlight.
- Toolbar: back/forward pill + folder title; right pill group (view options, new folder, grid, search).
- Icons view: airy grid; thumbnails keep REAL aspect ratio on a light card; below: name (2 lines), date, "Modified by", size; folders = yellow/coloured folder icon with "N items".
- (More iPad screenshots pending from user: list view, tab bar, long-press menu.)

## Decisions
- Keep our adaptive shell (Shell.kt). Add: centred large title + subtitle on wide screens, pill breadcrumb, source-app chips, floating bottom action pill for selection (all sizes), grouped-card Settings sheet, dotted dividers in sidebar, storage card with usage.
- Font: Inter (bundled). Folder icon: flat rich yellow, rounded, tab; per-folder glyph overlay (camera/download/etc.).
- Views to build: Icons (iPad), List (Samsung rows: icon, name, date, trailing items/size), Columns (Samsung Miller), Gallery/Grid (Samsung edge-to-edge tiles with name overlay). Details-with-column-headers only as optional desktop mode.
