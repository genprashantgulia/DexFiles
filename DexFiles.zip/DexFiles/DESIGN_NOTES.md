# Design reference notes (from user's screenshots, 2026-10-29)
Read this before touching UI. Inspirations to use ONLY: iPadOS Files and Samsung One UI 9 My Files (tablet, dark).

## One UI 9 My Files (tablet) - what to copy
- Sidebar: top row = menu icon (left) + settings gear (right). Items: Recent files, dotted divider, Downloads, Documents, Images, Audio files, Videos, Installation files (each a thin LINE icon in its own colour: teal, orange, pink, indigo, purple, green "APK"), dotted divider, then Storage: "Internal storage" as a rounded card showing "114.1 GB / 128 GB" with an expand chevron (expands to the folder tree), then Storage Share ("1 device available"), Google Drive / OneDrive ("Not signed in"). Big text, generous row height, 2-line items with grey subtitle. Selected item = dark rounded rectangle.
- Header: large CENTERED title (e.g. "Internal storage") with a grey subtitle underneath (free space / total size, e.g. "13.82 GB free", "5.38 GB"). Selection mode changes it to "2 selected" + total size.
- Pill breadcrumb bar: full-width rounded pill; ancestors grey separated by ">", current folder in accent blue. Right of it: panel/columns toggle, search, overflow (3 dots).
- Under it: "All v" filter dropdown (left) and sort "Type | up-arrow" (right).
- List rows: yellow folder icon (camera glyph for DCIM, download arrow for Download, zipper dots on zip files), name, grey date line, right-aligned "9 items" or file size; inset hairline separator starting at the text. Pinned system folders first, then a full-width rule, then the rest.
- Column (Miller) view via the panel toggle: columns side by side, selected row = rounded highlight.
- Category pages (Downloads): chips row filtering by source app (All = filled blue, others outlined pills: Claude, My Files, YTDLnis...), "File view v" dropdown, dense grid of square thumbnails edge to edge with filename overlaid on a bottom gradient.
- Selection mode: "All" check-circle top-left, "Cancel" top-right, blue check circles left of each row, floating rounded bottom action pill with icon+label: Move, Copy, Share, Delete, More. "More" popup: Copy to clipboard, Details, Rename, Extract, Extract to another folder, Extract to current folder, Add to favourites, Open with, Add to Home screen, Move to Secure Folder.
- Search: full screen; back arrow; "Filters" collapsible with toggle "Search by name only"; "Recent searches" card with removable chips and "Clear all"; search pill with mic + overflow near the bottom (above keyboard).
- Settings: rounded floating panel with grouped rounded cards: Cloud accounts; File management (toggles: show hidden system files, show cloud files in categories); "Edit home"; Advanced (toggles); Privacy.

## iPadOS Files - what to copy (from first screenshot, iPadOS 26-style promo)
- Sidebar: Recents, Shared; collapsible sections Favorites, Locations, Tags (coloured dots); selected item = soft rounded highlight.
- Toolbar: back/forward pill + folder title; right pill group (view options, new folder, grid, search).
- Icons view: airy grid; thumbnails keep REAL aspect ratio on a light card; below: name (2 lines), date, "Modified by", size; folders = yellow/coloured folder icon with "N items".
- (More iPad screenshots pending from user: list view, tab bar, long-press menu.)

## Decisions
- Keep our adaptive shell (Shell.kt). Add: centred large title + subtitle on wide screens, pill breadcrumb, source-app chips, floating bottom action pill for selection (all sizes), grouped-card Settings sheet, dotted dividers in sidebar, storage card with usage.
- Font: Inter (bundled). Folder icon: flat rich yellow, rounded, tab; per-folder glyph overlay (camera/download/etc.).
- Views to build: Icons (iPad), List (Samsung rows: icon, name, date, trailing items/size), Columns (Samsung Miller), Gallery/Grid (Samsung edge-to-edge tiles with name overlay). Details-with-column-headers only as optional desktop mode.

## iPadOS 27 Files - from user's video stills (2026-10-30, batch 1)
- Window chrome: "..." pill at top-left, then a back/forward pill, then CENTRED folder title with a small chevron (tap = menu of ancestors/actions). Right side: "Select" pill, view-list icon, search icon (or "..." menu).
- "..." / view menu: Select, New Folder, Scan Documents, Connect to Server | Icons / List (tick) | sort: Name, Kind, Date (shows "Newest to Oldest" under it), Size, Tags | View Options.
- Compact windows: sidebar replaced by a FLOATING PILL TAB BAR at the bottom: Recents, Shared, Browse (selected = soft rounded highlight).
- List rows: small real thumbnail or folder icon, name, grey "date - size" subtitle (folders: "date - N items"), expand chevron ">" on the left for folders (inline tree expand), cloud/status icon right, inset hairline separators. Row highlight on press = soft rounded rectangle.
- Details/columns list: header row "Name | Date Modified | ..." (blue labels, column menu "..."), large "Recents" title above it.
- Selection mode: "Select All" pill (left), "N Items" centred, filled blue check button (Done) right; hollow circles left of rows, blue filled check when selected, selected rows tinted; bottom floating pill with share, duplicate, move-to-folder, trash, and a separate round "..." button.
- Search: inline search field with mic at top of list; search page has scope switch (Recents | current folder), a suggestion row 'Name Contains "x"', results show location under the name.
- Sidebar: Recents, Shared; collapsible Favorites / Locations (On My iPad, OneDrive, iCloud Drive, Recently Deleted) / Tags (coloured dots). Soft highlight for selected.
- Quick Look: X close (left), file title with chevron, extra actions, share (right); video scrubber bar with times at bottom.
- Photos app (same family): big left-aligned title "Recently Saved" + "68 Items" under it; grid with ~3px gaps, thumbnails keep real aspect ratio.
- NOTE: iPadOS folders are BLUE (custom ones purple/red). User wants YELLOW folders; consider optional folder colours later.

## iPadOS 27 Files – batch 2 (video stills, wide/tablet layout)
- Window: floating rounded sidebar panel (… menu + sidebar-toggle icon at top; … menu = Scan Documents, Connect to Server, Edit Sidebar). Content has pill [back|forward] + title with chevron (path menu) + right pills: Select, New Folder icon, view/sort icon, search.
- Sidebar: Recents, Shared; collapsible Favorites / Locations / Tags (coloured dots). Edit Sidebar = red minus, drag handles, toggles per location.
- DETAILS (iPad "List"): column header row in blue (Name ▲ | Kind | Size | Date Modified | Tags | … column picker). Columns resizable by dragging header dividers; header … menu toggles Date Modified/Created/Last Opened/Added, Kind, Size, Tags, cloud status. Rows: left expand chevron (inline tree expansion with indent), folder icon, name, cloud icon, "folder", "7 items", date, tag dot. Footer "N items" centred. Recents rows: thumbnail + name + grey source line; group headings (Documents / Images) when Group By Kind.
- ICONS: spacious grid, folder icon top, tag dot + name + cloud, "N items" below; real thumbnails.
- COLUMNS: Mac-style Miller, rows with trailing chevron, selected row highlighted accent, "N items" footer.
- View menu: Icons / List / Columns (checkmark) | sort Name(Ascending)/Kind/Date/Size/Tags | View Options.
- View Options sheet: Sort By, Group By (None/Kind/Date/Size/Shared by), Icon and List Size (Compact/Default), Advanced: Show All Filename Extensions toggle.
- Context menu: top row Copy/Move/Share (icons+label), then Remove/Keep Download (cloud only), Quick Look, Open With >, Open in New Window, Get Info, Rename, Compress, Duplicate, New Folder with Item, Show in Enclosing Folder, Tags…/Customize Folder & Tags…, Add To > Favorites/Dock, Delete (red). Grouped by hairline separators.
- Get Info popover: big preview, name, kind-size, Open button, Information table (Kind, Always Open With, Size, Created, Modified, Last Opened, Where as breadcrumb link).
- New folder: inline rename row, name selected, keyboard. Customize Folder: tag colour + emoji/symbol picker (folder tinted by tag colour) -> idea: per-folder colour+glyph later (default stays yellow).
- Tags popover: radio list with colour dot per tag + Add New Tag.
- Folders iPad = blue/tinted by tag; ours = yellow default.
