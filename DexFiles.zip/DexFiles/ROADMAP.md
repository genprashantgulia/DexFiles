# DexFiles roadmap

## A. Must-work basics (do these first; nothing else until all tick)
1. Open folders/files; back/forward/up; breadcrumb jump.
2. Select (tap-hold, checkboxes, Ctrl/Shift click, Select All).
3. Right-click / long-press context menu for file, folder and empty space.
4. Rename (F2 / menu), New folder, New file.
5. Copy, Cut, Paste, Duplicate, Move to; conflict prompt (replace/keep both/skip).
6. Delete -> Trash, Restore, Empty Trash, confirm dialogs.
7. Properties / Get Info.
8. Share, Open With.
9. Sort (name/date/size/type, asc/desc) + folders-first; Show hidden.
10. Search in folder; search everywhere.
11. View modes all work on EVERY screen incl. Home; remembered per folder.
12. Tabs: obvious +, close, switch, "open in new tab"; sensible placement.
13. Settings screen (theme, font, view defaults, hidden files, confirmations, about).
14. Zip / Unzip.
15. Image / video / PDF / text viewer with swipe between items, no clipped arrows.
16. Dual pane: both panes interactive; drag between panes.
17. Pinch-to-zoom + Ctrl+scroll size; no crashes; progress + cancel for long jobs.

## B. iPadOS Files - features to include eventually
- Floating rounded sidebar; collapsible Favorites / Locations / Tags; Edit Sidebar (reorder, hide, remove).
- Recents, Shared, Recently Deleted.
- Back/forward pill + title with path menu; Select, New Folder, view, search pills.
- Icons / List / Columns; List with resizable, reorderable, toggleable columns (Kind, Size, Date Modified/Created/Last Opened/Added, Tags); inline folder expansion (tree) in List.
- Sort + Group By (Kind, Date, Size); Icon and List size Compact/Default; show all extensions.
- Real-aspect thumbnails; folder item counts; footer "N items".
- Context menu: Copy/Move/Share top row, Quick Look, Open With, Open in New Window, Get Info, Rename, Compress, Duplicate, New Folder with Item, Show in Enclosing Folder, Tags, Favorite/Add To, Delete.
- Quick Look preview (space bar) with swipe through files, markup later.
- Get Info popover (preview, kind, size, created, modified, last opened, where).
- Tags: colours, add/rename, filter by tag, tag dots in lists.
- Customise folder: colour + emoji/symbol.
- Inline rename; drag and drop (multi-item, spring-loaded folders), multi-window.
- Search with scope + suggestions; Scan documents; Connect to server (SMB/FTP/WebDAV) later.
- Select mode: Select All, "N items", Done, bottom action pill.
- Keyboard shortcuts; trackpad hover; stage-manager-like windows.

## C. Samsung My Files (One UI 9) - features to include eventually
- Sidebar: Home, categories (Images, Videos, Audio, Documents, Installation files), storage with usage bar, pinned folders, storage analysis, Trash; dotted dividers; storage card.
- Home: Recent files, categories, storage cards, "clean up" suggestions (large files, duplicates, unused apps, trash).
- Centred title + subtitle (count/size); pill breadcrumb; source-app chips (Downloads by app).
- List / Grid / Columns (Miller); gallery-style edge-to-edge tiles for media.
- Long-press multi-select with floating bottom action pill (Share, Copy, Move, Delete, More).
- Sort sheet + view-type sheet; Show hidden; per-folder sort memory.
- Search with filters (type, date) and recent searches.
- Storage analysis: large files, duplicates, unused, recycle bin; free-up-space.
- Safe-folder-like protected folders (later), cloud drives (later), network storage (later), FTP/SMB (later).
- Compress/Extract with password option; APK install; rename with extension protection.
- Drag and drop; DeX: right-click menus, hover, Ctrl shortcuts, multi-window.
- Settings: theme, font size, show hidden, trash on/off, auto-empty days, file extensions, analyse storage.

## D. Desktop power features (Windows / macOS / third-party)
- Details columns resizable, reorderable, sortable; group by; column picker.
- Address bar editable; breadcrumb menu of siblings; Ctrl+L.
- Tabs with drag-to-reorder, duplicate, reopen closed tab; dual pane; split view.
- Batch rename, bulk operations with queue + pause/resume; undo (Ctrl+Z).
- Preview pane; Quick Look; checksum; folder size; open terminal-like "path copy".
- Favourites/bookmarks; recent folders; type-ahead find; filters; saved searches.
- Archive browsing without extracting; image/video/PDF/text viewers; media gallery; EXIF.
- Themes; accent colour; density; font choice (Inter / system).
