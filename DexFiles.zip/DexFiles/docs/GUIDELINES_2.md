# Guideline pillars from the user (2026-11-05) — advisory only, NOT overriding the design spec
Source pasted prompt was cut off after pillar 31 (Technical foundation, Dual-pane, UI hierarchy, start of Tactile physics).
Take-what-helps notes:
- USE: all I/O on Dispatchers.IO; state survives resize/process death; java.io.File default, SAF only for SD/OTG; FileChannel.transferTo for copies; LRU thumbnail cache; FileProvider for sharing; FileObserver auto-refresh; Ctrl/Shift click multi-select; 4/8dp grid; thin visible scrollbars that widen on hover; breadcrumb truncation with an ellipsis dropdown; tabular (fixed-width) digits for sizes/dates (Inter tnum, not a monospace font); muted metadata; press scale 0.97.
- LATER: density modes (compact 32 / standard 40 / comfortable 48); dual-pane + Tab-key pane switch + synced navigation (dual pane postponed by user); window snap persistence; cross-window drag IPC.
- DIFFERS from approved mockup (keep mockup): monospace font for numbers; selection ring (mockup uses tint only); inner-shadow on press.
