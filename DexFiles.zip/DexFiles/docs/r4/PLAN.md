# Round 4 mocks (2026-11-09) - resume from here
User asked: (a) mocks for search-results restyle + other planned work, (b) 10 unique complete-overhaul themes, shared base architecture.
Rules: no pastel/Catppuccin/Everforest/mocha. Each theme = type, colour, icons, file+folder style, panels, menus, motion, radius/spacing.
Themes (10): 1 Studio 95 (retro windows, dither blue), 2 Phosphor (CRT, green/amber/white/ice), 3 Outrun (synthwave),
4 Blueprint, 5 Broadsheet (newsprint, light), 6 Neo-Brutal, 7 Aero Gel (glossy Y2K), 8 Rams (analog hardware), 9 Lacquer (black lacquer+gold+vermilion), 10 Cockpit (cassette futurism).
Boards planned: Overview, Engine (architecture), Search, Viewer, Analyze, then 10 theme boards.
Mock artifact: Design type. Generator script: docs/r4/gen.py (writes .dc.html boards). Status below.
## Status
- [x] artifact created; all 15 boards published; awaiting user feedback
