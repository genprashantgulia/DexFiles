# Layout contract

One table. Every screen reads its width and follows the row for it; nothing else is allowed to change with size.

| Width (dp) | Under 600 | 600 – 900 | Over 900 |
|---|---|---|---|
| Sidebar | none; the menu button opens a drawer over the page | icon rail (68 dp); the menu button opens the full list over the page | full sidebar (252 dp), folds to the rail by the toggle |
| Inspector / preview | sheet | sheet | docked panel on demand (Quick Look, board 08) |
| Settings | full-screen page | panel over the page | docked panel when the page keeps 480 dp, else over the page |
| Category groups (Columns view) | pills above the list | pills above the list | side column from 600 dp of pane width |
| Split view | off (use tabs) | optional | optional |

**Never changes with width:** the tab strip, the path pill and title behaviour, the sort strip, row anatomy, the selection pill, every menu, the search field. They only stretch or truncate.

## Rules

1. **Classes** come from `windowClassFor` in `ui/Shell.kt` and nowhere else. Phone = `Compact`, rail = `Medium`, full sidebar = `Expanded`.
2. **Slack.** `rememberWindowClass` keeps the current class until the width is 24 dp past the line, so dragging a window edge across a breakpoint never flickers.
3. **Crossing glides.** The sidebar, the rail and "none" are one box whose width animates (`App.kt`), so a resized window moves like cloth, not a jump.
4. **Pane-level decisions read the pane's own width** (`BoxWithConstraints` in `Pane.kt`): Details columns from 760 dp, Columns side groups from 600 dp. The window class only decides window-level things.
5. **Touch targets** are never below 44 dp: small round buttons use `minimumInteractiveComponentSize()` so the visual stays small and the hit area grows. Known exception: tab-strip close buttons, inside a 34 dp pill.
6. **Text follows the text-size setting; layout never does.**
7. A new feature names which row of this table it uses. If it needs a row that is not here, the table changes first.
