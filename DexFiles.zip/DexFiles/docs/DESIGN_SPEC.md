# DexFiles design spec (from the approved mockup, 2026-11-05)

Mockup canvas: claude.ai artifact VoKiT729JTXdv7G57noBmF (boards 1-12). This file holds the exact values so the app copies numbers, not impressions.
Target: 11-inch tablet (about 1280x800 dp landscape) and Samsung DeX. Font: Inter 400/500/600/700.

## Colour (True Black theme)
- background #000000; raised card #0C0C0E; control/pill #121214; field/chip #17171A; hover/selected neutral #26262B
- popup menu #26262C (ring #34343A); dialog #1E1E22 (ring #2C2C32); settings card #1A1A1E
- hairline row divider #1C1C20; dotted date line #2A2A30
- text #F2F2F4; dim #8E8E96; secondary #B4B4BC / #D4D4DA; size/value emphasis #CFCFD6
- accent amber #FFC93C; accent text #FFD257; text on accent #1A1200; selected row tint rgba(255,201,60,0.13); selected sidebar item rgba(255,201,60,0.16)
- danger #FF8A80 (button text #FF9E94 on rgba(255,138,128,0.16))
- file tiles: PDF #C8472F, DOC #2E62B8, XLS/CSV #238A55, MP3 #2F9B6B, MP4 #6A4FD0, images use real thumbnails

## Shape (Radius tokens in code: xs 8, s 12, m 16, l 20, xl 28)
- controls and bars: full pill (height/2); content card 28; menus 20; dialogs 28; settings card 32; tiles/thumbnails 12-16; file type tile 12

## Layout
- Tab row 44 (tab pill height 34, +circle 34, 8 gap); top bar row 56 (circle buttons 44, path pill height 44, 10 gap)
- Sidebar 264 wide: item height 46 (pill), sub-item 42 indented 44, section captions 12/600 dim; Settings at the bottom with Trash and Analyze storage
- Content card: margin 0 12 12 0, radius 28, bg #0C0C0E; centred page title 34/600
- List row 68 high: tile 48, name 16/500 on top, date 13 dim left, size 13/600 right, divider starts after the icon
- Icons grid: 6 columns, gap 12, thumbnail 148 radius 16, name 13/500, date 12 dim; folder icon 104
- Select mode: header shows tick + "N selected" 20/600 with the close button on the RIGHT; floating action bar (Move, Copy, Share, Delete, More) radius 36, bottom 28
- Header has Back AND Forward (forward dimmed to 38% when no forward history); no Up button

## Folders
- Style C "papers peeking out" is chosen. Has files: papers visible, full colour. Empty: no papers, 50% opacity.
- Colours (back/front): amber #D9A200/#FFC93C, blue #2F6FD0/#5B9BFF, green #1F9D5A/#43C980, red #D0453A/#FF7A6B, purple #7A4FD0/#A98BFF, graphite #5A5A64/#8A8A96
- Folder style is part of the theme (True Black = C; later Glass = D, Desktop = E outline, Material You = F pillowy). Default folder colour is a setting; per-folder colour and glyph stay.
- Empty check runs in the background per visible folder; icon flips after it resolves.

## Menus
- Right-click (desktop): 40px rows, text left, shortcut hint right (12 dim), danger last. Touch menus (more, selection) use icons and 46px rows.
- View menu: List (with nested "Details columns" switch only while List is active), Icons, Gallery, Columns; Show hidden files; Preview panel.
- Sort menu: Name, Date modified, Size, Type; Ascending/Descending segmented; Folders first switch.
- Forward/back mouse buttons and Alt+Left/Right navigate history.

- Update 2026-11-05: the ⋮ menu no longer lists Trash or Analyze storage (they live in the sidebar). Details columns: user proposed a small "Simple | Detailed" segmented control beside List in the View menu (option 1 on board 13; options 2-4 shown for comparison). Tapping Detailed also switches to List.
- Settings: main list = Appearance (sub-page), Browsing, Files, Feel, More. Appearance holds Theme, Accent colour, Folder style, Font; each shows "Default" plus empty dashed placeholders (Theme 1.., Colour 1.., Style 1.., Font 1..) to fill in during the appearance phase.

- Stepped slider (Obsidian-style) for text size: whole-point steps 12..20 (default 16); reset button FIRST in the row (dim at default, amber when changed), then label with value ("18 · default is 16"), then slider with tick dots. While dragging: thumb grows with a soft ring and a value bubble sits above it; bubble hides ~800 ms after release. Haptic tick per step. Reuse for any bounded numeric setting (e.g. default thumbnail size).

## Search
- Search replaces the top bar: back button, amber-outlined pill with magnifier, query, scope chip (This folder / Everywhere), clear button. Matches highlighted amber/bold in names; results ease in staggered (22 ms apart, first 12).

## Copy rules
- Sentence case, active verbs, same word for an action everywhere (Move to Trash -> "Moved ..." toast with Undo). Errors say what happened and what to do.

## Motion (numbers shared by every animation; Compose spring(dampingRatio, stiffness))
Basis: Material 3 Expressive spring tokens and Apple fluid-interface principles (interruptible, velocity-preserving), from knowledge; web research pages did not load.
- Spatial (position/size): fast 1400, default 700, slow 300, damping 0.9
- Effects (fade/colour): fast 3800, default 1600, slow 800, damping 1.0 (never bounces)
- Bounce only for thrown things: tick pop damping 0.55 / stiffness 800; drag lift/drop damping 0.6 / stiffness 400
- Size sets speed: ticks and menus fast; sidebar and page changes default; full-screen changes slow
- Origin: menus scale 0.88->1 from their button (+6px slide), sidebar from its edge, pages: old slides 16px back, new arrives from 28px
- Press: scale 0.97 immediately (spatial fast) + light haptic on commit
- Search expand: width spatial default; text fades after 50%, scope chip after 70%
- Lay out once: content is composed at final size and slid/clipped; never re-flow mid-animation
- Reduced motion: replace movement with a 150 ms fade
- Lists: items animate placement on sort/delete/rename only when column count is stable
- Live demos: mockup board 12 "Motion lab" (same spring maths as Compose).

## Screens designed (boards): 1 List, 2 Icons, 3 Selecting, 4 Folder options, 5 Folder states/themes, Header, Sidebar, 6 Search, 7 Menus, 8 Dialogs + inline rename, 9 Settings card, 10 Empty/loading/error, 11 Preview/drag/toast/progress, 12 Motion lab.

## Build order
1. Header (tabs, bar with Back+Forward), Sidebar, folder icons in two states, sidebar/preview open-close rebuilt (lay out once)
2. List rows, sort strip, page title
3. Icons and Gallery
4. Selection bar, menus, dialogs
5. Search screen, Settings card, states
6. Then master-prompt features: tags, network/cloud, smart folders, analyzer cleaners, 7z/RAR, theme engine, shortcut cheatsheet, pointer icons
