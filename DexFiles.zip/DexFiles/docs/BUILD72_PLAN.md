# Build 72: the whole unified design in one go (progress log)
Order: A shape sweep, B phone tab box + sheet, C sibling dropdown, D Tray, E mosaic folders, F final pass.
Deferred (say so): dual-pane Compare layout, palette merged into search, Columns preview (already has Preview pane).
Done so far: build 71 command bar.
Done: A shape sweep, B phone tab box + TabSheet (ui/Tray.kt), C sibling menu (PathPill.kt), D Tray (VM tray/addToTray/dropTray, TrayBar, action "Add to tray").
Left: E mosaic folders, F final pass + zip.
Done: E FolderCover mosaic (FileIcons.kt, Icons grid). Build 72 zipped.
Build 73: mock-vs-screenshot pass: grey sidebar selection + rounded rows, chip bar rounded, card radius 16, search field in tab row (wide), folder icon in breadcrumb, status line.
Build 74: breadcrumb chevron semantics, editor cancel, search field right-aligned, headings parked (Dimens.showHeadings), palette sections + '>' in search, Compare panes dialog, radius sweep.
Build 75: phone breadcrumb without folder icon; wide search is the tab-row field (grow overlay only on phone/dual); dual panes get their own path bar + transfer rail (copy to other pane); search scope is one "in: folder" chip; remaining pills swept to Radius tokens.
Build 76: search field grows with animation + cross closes search; Appearance inline in flat Settings (Theme chips, Density Comfortable/Compact, sliders); date headings without dots; rail without dots; edge-swipe drawer at 84% width; Detailed greyed when pane < 760dp; search path as plain text + results count in filter row; resting bar (New folder, Paste, Select all); Open/Rename on bar when wide; transfer arrows give feedback.
Build 77: tick circle on tiles is a 44dp toggle (S Pen/mouse), command bar cells 52dp centred, Density moved into View menu (compact 0.74), Columns preview column.
Build 78: five-entry view menu (List, Details, Icons, Gallery, Columns), Details greyed when pane < 760dp.
- Build 79 (foundation): widths sidebar 220, preview 270, settings 330, drawer 250; selection bar cells/chip 48dp; palette, chips, buttons, rows from checklist section 0.
- Build 80 (screens, part 1): Sort + View icons on the path row (wide) / strip end (phone), strip shows count only, Home count wording.
- Build 81 (screens, part 2): F10 one flat action list (Open/Look; Move to/Copy to/Tray; Rename..Properties; Select; Move to Trash last in red) for right-click, long-press and More.
- Build 82 (screens, part 3): F9 inspector rows (label/value), header sub-line, Share/Move/Properties.
- Build 83: Settings sliders two-line, density removed, search recents menu full field width, shape variety back (tabs pill, round buttons circular, search field pill, rest rounded squares).
- Build 84: base = original mock 01 (calm). Pill command bar without counter (count + Clear in the strip), strip shows 'Date modified' sort label again, Sort icon removed from path row, ghost round buttons, sidebar selection amber plate+edge, idle bar removed.
- Build 85: sidebar selected = real amber (plate, 55% edge, amber icon); Recent type chips replaced by a quiet 'All ▾' in the strip; Columns source column 196dp, quieter, amber when chosen; selection pill cells uniform (More no longer boxed), bar raised above status line.
- Build 86: F1 is the base from here (not Ember tightened). Sidebar width 256, grey selection (amber only for chosen files), F1 wide command bar (amber count + icon/label cells, rounded rect), bar floats above the tray, strip removed on wide (status line shows N items), Sort+View icons back on path row, rounded-rect tabs, filled rounded-square round buttons, menu rows 40dp.
- Build 87: Ctrl K keycap on wide breadcrumb. F4/F5/Properties already matched the mocks on review (search filters, inspector rows, Properties sections).
- Build 88 (flows): tray strip amber-tinted with 'from folders', opened tray grouped FROM <folder> with thumbs and hint, progress card with cross and % in sub-line, dual-pane bar says Copy/Move to other pane, picker RECENT chips.
- build 89: search header quiet pill, Type/Date/Size chips, HOME groups by date, dual bar Move→/Copy→/Delete, inspector dedupe+humanised location, toast check, progress eta right, short context menu
- build 90: empty-tap clears focus, middle-ellipsis names, count only in status line (phone: no free space), no tree arrow on phone
- build 91: conflict dialog shows existing vs incoming (size/date, newer flagged); typed search filters + batch rename + failure dialog already existed
- Build 92: Density setting (Auto/Comfortable/Compact). Compact = 30dp details rows, 22dp thumbs, shorter header and sidebar rows; Auto switches on a mouse in windows 840dp+ (phones never). Comfortable unchanged.
- Build 93: two modes (Comfortable/Desktop; Desktop default at 840dp+): Details table forced in Desktop, 13sp names, tighter dividers/header; phone Icons view 3 per row (4 smallest, 2 largest); phone View button now in Recents/categories/search; Dual pane greyed on phone and turned off when narrow.
- Build 94: desktop mode removed (back to build 91 behaviour; parked until the app is at 100%). Kept: phone View button in Recents/categories, Dual pane greyed on phone. Phone Icons view: icon size picks 3/2/1 per row (never more than 3), text size can only reduce it. Columns metadata clipping gone with the row-scale revert.
- Build 95: cleanup. Removed ~50 unused functions/classes (old TopBar/AddressBar/SearchField/CommandBar, HomeScreen, CollapsingTitle, IdleBar, selectRing, DexDock, unused tokens, density pref) and 300+ unused imports; ⋮ menu keeps every row and greys what cannot work (New folder/Paste in virtual tabs, Compare without dual, Preview when narrow, Select all when empty).
- Build 95b: restored BatchRename.problems and FileEntry.toFile (used by CoreTest).
- Build 96: phone icon-size steps are now 3/2/1 per row (pinch, Ctrl+wheel and Settings slider all use them; zoom-out past 3 is blocked). Dropped from the backlog as low value: did-you-mean, progress Retry row, tray alignment, media scrubber.
- Build 97: selection count chip no longer clears the selection (wide: display-only; phone: removed, count is in the status line); menus have even padding (Material's own 8dp top/bottom no longer doubled); unselected row circles are outlined, not grey-filled.
- Build 98: Tray on phones = 'Tray · N' chip above the thumb zone (above the selection bar when selecting) opening a bottom sheet (grouped list with ×, Clear, Copy here, Move N here; greyed where nothing can be dropped); wide keeps the strip. Icons: Tray basket, Quick look eye, Duplicate and Extract get their own. Quick look footer shows 'n of m' and key hints.
- Build 99: F-board audit round 2. Retry for failed copy/move (F6), Quick look header Share/Open buttons + side arrows + Enter opens (F9), phone Recents category grid (F3), auto day headers in photo-heavy folders sorted by date (A4), copy tweaks (Nothing matches). Not built: wide Recents storage panel, did-you-mean.
