# Master guideline prompt (from the user, 2026-11-04) — use as a checklist, not a rewrite

Universal Android file manager (phones, foldables, tablets, DeX/ChromeOS). Best-of-class synthesis:
- iPadOS Files: drag shadows with badge counts; colour tags + sidebar filter; Quick Look (Space/tap) for images, audio, video, PDF, code, Markdown.
- Samsung My Files: storage analyzer + cleaners (duplicates, large files, unused APKs, trash); network/cloud hub (SMB, FTP/SFTP, cloud); archive extract (ZIP/7z/RAR/TAR) with progress cards.
- macOS Finder: Miller columns; smart folders / saved searches as sidebar shortcuts; quick-actions bar in inspector.
- Windows Explorer: tabs (drag to reorder, Ctrl+T), split view, breadcrumbs (copy path, Ctrl+L edit), Details view with sortable/resizable headers (Name, Date, Type, Size, Permissions).
Theme engine (hot-swappable): Material You dynamic colour; Frosted glass (RenderEffect blur); Mica/desktop minimal (hairline 1dp borders); True Black OLED (#000).
Input parity: PointerIcon switching, right-click menus, Ctrl/Shift click, Ctrl+drag copy; Ctrl+C/X/V/A/F/N/T, F2, Delete, Space; focus rings; Ctrl+/ shortcut cheatsheet; 48dp touch targets on compact, denser on expanded; pinch zoom, long-press select, swipe-dismiss preview.
Adaptive: Compact / Medium / Expanded (3-pane: nav | files/split | preview inspector); free-form windows; cross-window drag-and-drop.
Guardrails: instant async loading (10k+ items), UDF + immutable state, clean fs/UI separation, modular code for agent-friendly extension.
