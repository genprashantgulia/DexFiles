# Foundations: themes and other storages

## Themes (ready)
- Colour: `ui2/design/Palette.kt` (one Palette per mode). Non-colour sizes: `ThemeSpec`. A whole look = `DexThemeDef(spec, dark, light)`.
- `DexTheme(mode, textSize, theme = EmberTheme)` provides `LocalPalette`, `LocalSpec` and the Material scheme. A new theme is one more DexThemeDef; add a list and a Settings picker when the first one exists.
- Still outside the palette (move in when a theme needs to change them): file-kind colours (FileIcons.kt), Compare glyph colours, folder icon colours (Glyphs.kt).

## Other storages (not done, deliberately)
- Everything reads and writes through `java.io.File` (28 files). Volumes (`data/Volumes.kt`) is the only list of "places".
- Plan, in order: (1) one `Storage` interface in core (list, stat, open stream, mkdir, rename, delete, copy) with `LocalStorage` over File; (2) move FileOps, Listing, Search, Archives, TrashStore behind it one at a time, tests first (CoreTest already covers FileOps); (3) a `Volume` gets a scheme/id so paths stop being bare strings; (4) SAF (Drive etc.) as the first second implementation, SMB/SFTP after.
- Do this as its own build once the current one compiles; it touches paths everywhere and cannot be checked blind in a small change.
