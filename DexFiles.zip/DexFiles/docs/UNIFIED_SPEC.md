# DexFiles unified spec (touch first)

One source of truth for the app. It replaces opening the mocks. Every row is a decision from boards 01–15 of the unified mocks, with what the app does today (read from the code, file and line) and which build closes it.

**How it was made.** Rows come from the decision tables of the unified mocks (canvas version of 25 Nov 2026). The app column comes from reading the source of Build 111, updated for Build 112 from its diff. Nothing was run or compiled. A row is marked *Matches* only when a line of code proves it; anything not yet read is *Unverified*, not Matches. "Built, unseen" means Build 111 or 112 changed it but nobody has seen it on a device.

**Scope tags.** T = touch or shared by both. M = both inputs, only the touch half is audited. D = desktop only, parked until after touch parity (listed in the last part).

## Status

| Status | Rows |
|---|---|
| Missing | 17 |
| Differs | 27 |
| Unverified | 13 |
| Built, unseen | 22 |
| Matches | 24 |
| Parked | 9 |
| **Total** | **112** |

Touch parity is **not** reached: 44 rows differ or are missing, 13 are unverified. No claim of 100% until about twelve named screenshots have been compared against the boards after Build C.

## Build plan (touch first, three builds)

**Build A (Build 112): foundations everyone sees.** Sizes and tokens (48 dp hit areas, rows 56 on touch, menu rows 48/radius 16, toast 48 and 8 s with Undo), the selection bar (count chip, 56 high, Move amber), Sort once and Folders first only in the Sort popup, greyed-not-hidden actions and the shorter touch More list, Settings entry points, long-press on empty space, rows that grow with text, the 300 ms motion cap. Built, uncompiled and unseen: B01.3, B01.4, B01.5, B01.6, B02.1, B02.2, B02.6, B02.7, B04.4, B04.5, B05.3, B05.4, B05.5, B06.6, B13.6, B14.4, B15.1. B02.3 turned out to match already (Build 99). Four of those are partial (B01.3, B13.6, B14.4, B15.1; see their rows). Moved to Build C: B01.1 (tablet frame), B13.3 (needs a decision), the rest of B13.6 and B14.4. Not done: B14.7, B15.5 (reduced motion).

**Build 113 (between A and B, from your feedback of 27 Nov).** The count chip moved out of the bar into the sort strip (phone bar too crowded); the hold menu and More went back to the old split (hold = short with the four bar actions, More = the full list); greyed rows lose their phrase; Rename works for several items with a pattern built from pieces; Select similar; the Settings footer shows the build. Rows: B04.5, B05.3, B05.5, B05.7, B13.3. B13.3 is now a deliberate two-route design, not a gap.

**Build B: Settings, Info and viewers.** Settings as categories (phone list then page, tablet master and detail) with all eighteen content rows; one Info sheet (tablet side sheet 380, phone tall sheet) shared with Properties; the viewer chrome for all five viewers (bottom pill Share / Info / Delete, top back / name / ⋮, 48 dp targets, "3 of 12", Fit chip only when zoomed, failure states). Rows closed: B08.2, B08.3, B08.5, B08.6, B08.7, B10.1, B10.2, B10.5, B10.6, B10.c2, B10.c3, B10.c5, B10.c6, B10.c7, B10.c8, B10.c9, B10.c11, B10.c12, B10.c13, B10.c14, B10.c15, B10.c16, B10.c17, B10.c18.

**Build C: pages and the rest.** Trash days left, Storage page, Operations list, search (scope per tab, Clear filters, empty search with Jump to), dual pane at 720 dp with the transfer rail and Compare as a mode, states and banners, picker/progress leftovers, accessibility semantics, viewer container transform, plus every Unverified row once it has been read. Rows closed: B01.1, B06.3, B06.5, B07.2, B07.3, B07.5, B09.1, B09.3, B09.4, B11.3, B11.4, B11.5, B12.3, B12.4, B12.5, B12.6, B14.6, B15.2. To read first: B03.2, B03.3, B03.4, B03.5, B03.6, B06.4, B07.4, B07.6, B08.4, B13.1, B13.4, B14.3, B15.4.

Each build message will list the rows it closed and the rows still open. Desktop mode follows only after Build C is seen and compared.

## Part 1: tokens and metrics (the same everywhere)

### Tokens

| Token | Role | Dark | Light |
|---|---|---|---|
| cv | Window canvas | #000 | #F2F2F5 |
| cd | Card, panel | #0C0C0E | #FFFFFF |
| rs | Raised | #17171B | #ECECF0 |
| ov | Menu, overlay | #1C1C21 | #FFFFFF |
| hi | Hover, pressed | #26262C | #E9E9EE |
| tx | Text primary | #F2F2F4 | #1A1A1F |
| sec | Text secondary | #C9C9D1 | #3C3C44 |
| dm | Text dim | #8E8E96 | #6A6A74 |
| fa | Text faint | #85858F | #5E626B |
| am | Amber fill | #FFC93C | #D99A00 |
| amf | Focus ring | #FFC93C | #B07A00 |
| amt | Amber text | #FFD257 | #8F6200 |
| on | Text on amber | #1A1200 | #1A1200 |
| pl | Selection plate | #29200A | #FFF3CC |
| se | Selection edge (1 px, uniform) | #7A5A14 | #B07A00 |
| dg | Danger | #FF6B5E | #C0322A |
| dgb | Danger tint | #2A1717 | #FBE4E4 |
| ok | Success | #4CD08A | #1F7A44 |
| st | Strong stroke | #3A3A42 | #C9C9D2 |
| hr | Hairline | rgba(255,255,255,.08) | rgba(0,0,0,.08) |

Contrast rule: every text pair 4.5:1, every focus ring or selection edge 3:1, in both themes.

### Metrics

| Metric | Touch | Desktop (parked) |
|---|---|---|
| List row | 56 (text 14 / 12, two lines) | 32 |
| Icon button | 48 dp hit area, 40 dp plate | 32 (28 in menus) |
| Gap between targets | neighbouring hit areas may touch; free-standing controls 8 dp | 4 |
| Menu row | 48 | 36 |
| Menu | padding 6, group hairline 5, radius 16 | same |
| Top bar | 56 (crumb field 40, buttons 48 hit / 40 plate) | tabs 36, address 44 |
| Floating selection bar | 56, width max 600 | command bar 40 at window level |
| Toast | 48 high, 4 s (8 s with Undo) | same |
| Sidebar | 252; tablet rail 68; phone drawer 300 (84% of width, max 300) | 252 |
| Dialog | centred card 440–520; phone: full width minus 12 each side; 55% scrim | same |
| Radii | 8, 12, 16, 20, 28 only | same |
| Dual pane | from 720 dp content width | same |
| Slider thumb | 20 dp, hit 48 | 14 |
| Motion | phone 120–280 ms, tablet 120–260 ms, cap 300; reduced motion = 80 ms fade | 80–180 |

## Part 2: rows by board (touch half)

Row format: **ID · element** [scope] · status · size · build. Then *Spec*, *App now* and *Change*. Rows that match or are parked take one line.

### 01 · Frame and navigation

- *Desktop (parked):* Everything is visible at once: tab row, address row, command bar, sidebar. Hover shows shortcut tooltips after 400 ms. Mouse back and forward buttons walk history.
- *Tablet:* Sidebar collapses to a 68 rail. Tabs are one button with a count that opens the switcher. Width 900 and up swaps the rail for the full sidebar; nothing else changes.
- *Phone:* One column. ☰ opens the drawer, the crumb field replaces the page heading, tabs open as a list sheet. No bottom navigation, no floating button: the bottom belongs to the selection bar.

**B01.1 · Navigation frame** [M] · Differs · size M · build C
*Spec:* Tabs row, one toolbar, sidebar. Under 900 the sidebar becomes a rail; under 600 a drawer.  
*App now:* Shell.kt:75-80 breakpoints 600/900; App.kt:159 rail 68 / sidebar 252; App.kt:127 TabStrip on every non-phone window; Shell.kt NavBar puts Back, Forward, Sort and View as 40 dp buttons on 600+  
*Change:* Tablet by finger should have the phone top bar (crumb field, one tabs button with count, search, ⋮) and the strip carries count, sort and view. Needs an "input is touch" flag (Mods.mouse/keyboard) to choose between touch and desktop frames. Moved to Build C: it needs the touch/mouse input flag that also drives the desktop frame.

**B01.2 · Command bar** [D] · Parked (desktop only)

**B01.3 · Address bar** [M] · Built, unseen · size S · build A
*Spec:* Breadcrumb with sibling chevrons, no chevron after the last name, Ctrl L edits, Esc returns.  
*App now:* PathPill.kt: long-press on the pill or on a crumb copies the path and toasts "Path copied" (not for virtual or search locations); chevron box is 48 wide x 40 high. PARTIAL: the hit area is 40 high (the pill height), not 48 square. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot; decide whether 40 high is enough inside a 40 dp field.

**B01.4 · Settings entry** [M] · Built, unseen · size S · build A
*Spec:* Gear in the tab row (desktop), bottom of the rail (tablet), last drawer row (phone). Never pinned inside the sidebar list.  
*App now:* Sidebar.kt: Settings is the last row of the phone drawer; SidebarRail has Settings at its bottom; the ⋮ entry stays. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B01.5 · New / create** [M] · Built, unseen · size S · build A
*Spec:* Desktop: New in the command bar. Touch: first rows of ⋮ and long-press on empty space. No floating button.  
*App now:* Pane.kt: long-press on empty space opens the New menu (only where the folder is writable). Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B01.6 · Row size** [M] · Built, unseen · size S · build A
*Spec:* Desktop 32 · touch 56. Text identical in both (14 / 12).  
*App now:* Dimens.kt: rowHeight() = 56 dp x text scale (capped 1.6), on every window; rowInset 3. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B01.7 · Status line** [D] · Parked (desktop only)

### 02 · Lists, sort and grouping

- *Desktop (parked):* Details is the home view: a 28 high header (click sorts, drag edge resizes, right-click picks columns), 32 high rows, group headers fold with a click or arrow keys.
- *Tablet:* From 600 up the List shows a trailing date so the width is used; Details is available but optional. Sort and group open as a popup under the strip.
- *Phone:* Two-line List only. Details is greyed with the reason "needs a wider window". Same sort popup, same order, 48 high rows.

**B02.1 · Default view** [M] · Built, unseen · size S · build A
*Spec:* Desktop: Details. Touch: List. Details greyed on phone (needs 600), never hidden.  
*App now:* Shell.kt ViewOptionsMenu: Details enabled from 600 dp per pane, otherwise greyed at 45% with "needs a wider window"; Pane.kt and PathPill.kt SortStrip use the same 600. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B02.2 · Sort control** [M] · Built, unseen · size S · build A
*Spec:* Desktop: Sort in the command bar plus a click on any column header. Touch: one label in the strip ("Name ↑"). Same popup, with order and group inside.  
*App now:* Shell.kt NavBar: top-bar Sort button removed; the strip carries Sort. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B02.3 · Grouping** [M] · Matches — Group by None / Date / Type lives in the Sort popup. Photo folders default to Date. Headers fold on desktop.  
*Evidence:* Group by None / Type / Date modified / Size in the Sort popup (PathPill.kt); photo folders default to Date: Models.kt:152 groupShown + ExplorerViewModel.kt:352 autoDate (12+ items, 70% media, sorted by date). Size is an extra option.

**B02.4 · Columns** [D] · Parked (desktop only)

**B02.5 · Header text** [D] · Parked (desktop only)

**B02.6 · Folders first** [T] · Built, unseen · size S · build A
*Spec:* On by default, toggle in the sort popup, not in Settings.  
*App now:* SettingsCard.kt: Folders first removed; it lives only in the Sort popup. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B02.7 · Row targets** [M] · Built, unseen · size S · build A
*Spec:* Desktop rows 32 · touch rows 56 · menu rows 36 desktop, 48 touch.  
*App now:* DexMenu.kt: touch rows 48, padding 6, 5 dp hairline (MenuDivider), default radius 16; the Material menu imports that bypassed the wrapper were removed from FileActions, SearchFilters and Viewers; menu rows are 40 when a mouse is in use (spec 36, desktop part parked). Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

### 03 · Views

- *Desktop (parked):* Icons: 124 tiles, 8 across at 1280. Gallery: masonry, real aspect ratios, day headers. Columns: Miller columns with a preview as the last column, no side panel.
- *Tablet:* Icons: 5 across. Gallery: 3 columns. Columns: two lists and a thin preview; the first column becomes the second when you go deeper.
- *Phone:* Icons: 3 across (your cap), pinch steps 3 / 2 / 1. Gallery: 2 columns. Columns reflow into breadcrumb pills above one list, because a phone cannot hold a second list.

**B03.1 · View menu** [M] · Matches — Five views (List, Details, Icons, Gallery, Columns), then one Size slider that exists only while Icons or Gallery is on, then Preview pane (Alt P) on desktop.  
*Evidence:* Shell.kt:389-430 five views as flat list, slider only for Icons/Gallery, Preview pane lives in ⋮ (desktop only)

**B03.2 · Icons** [T] · Unverified · size ? · build C
*Spec:* iPad-style: large icon over a centred multi-line name, selection plate behind the whole tile, no ring.  
*App now:* Tile look (large icon, centred multi-line name, plate behind whole tile) not read yet  
*Change:* Read Pane.kt tile code and compare.

**B03.3 · Gallery** [T] · Unverified · size ? · build C
*Spec:* Masonry with true ratios; folders in a full-width row on top; hover shows name, tick circle on hover/pen.  
*App now:* Gallery masonry exists; folder row on top, tick circle (Pane.kt:1008-1037) not compared with the board  
*Change:* Compare.

**B03.4 · Gallery layout** [T] · Unverified · size ? · build C
*Spec:* Computed deterministically from ratios, so the same folder always lays out the same way and keeps the top photo when you zoom.  
*App now:* Deterministic layout and top-photo anchoring (Build 110 notes) not re-read  
*Change:* Compare.

**B03.5 · Columns** [M] · Unverified · size ? · build C
*Spec:* Desktop: Miller columns + preview. Tablet: two columns. Phone: pills + list.  
*App now:* ViewMode.COLUMNS exists (TopBar.kt:30); two-column tablet and phone pills version not read  
*Change:* Compare.

**B03.6 · Pinch / Ctrl-scroll** [T] · Unverified · size ? · build C
*Spec:* Stepped levels with blending, same levels on every device: phone 3/2/1, tablet 5…2, desktop 10…3.  
*App now:* ExplorerViewModel.kt:56-58 GRID_LEVELS 6 steps, PHONE_GRID_LEVELS 3 steps (148/188/240 px); columns per device (spec phone 3/2/1, tablet 5..2) not computed  
*Change:* Compute columns per level.

### 04 · Selection, command bar and tray

- *Desktop (parked):* Selection works on the desktop idiom: click, Ctrl-click, Shift-click, rubber band, Ctrl A. The count lives in the status bar. The command bar never moves, so the pointer finds every action where it was last time.
- *Tablet:* Long-press selects, circles appear on every row, the bar floats at the bottom, the tray is a quiet strip under it. Bar width capped at 600 so thumbs reach both ends.
- *Phone:* Same, narrower: bar uses vertical cells, the tray collapses to a small chip above the bar. The tray never needs more than one tap to open.

**B04.1 · Bar placement** [M] · Matches — Touch: floating bar at the bottom. Desktop: command bar at window level, under the address row.  
*Evidence:* Tray.kt:89-131 PaneDock floats the bar at the bottom; capped 560 (spec 600)

**B04.2 · Desktop command bar** [D] · Parked (desktop only)

**B04.3 · Selection look** [M] · Built, unseen · size  · build A
*Spec:* Amber plate and a uniform 1 px edge in a darker amber (3:1 against the card). Touch also shows a check circle; keyboard focus is a separate 2 px ring.  
*App now:* Sel.kt plate + 1 px edge; Dimens.kt:14 plate inset 3 dp touch; tick circle on tiles Pane.kt:1008 (rows unverified). Built in 111, uncompiled and unseen  
*Change:* Look at a screenshot.

**B04.4 · Bar content** [T] · Built, unseen · size S · build A
*Spec:* Move first and amber, Copy, Share, Delete in danger red, More. Rename, Compress, Properties, Add to tray inside More.  
*App now:* Selection.kt: bar 56 high, cells 48, Move amber; labels hide above 115% text size. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B04.5 · Count chip** [M] · Built, unseen · size S · build A
*Spec:* Touch: amber chip with the number and ✕; tapping clears. Desktop: the count is in the status bar; Esc or a click on empty space clears.  
*App now:* The count is an amber "3 selected ✕" chip at the left of the sort strip (PathPill.kt SortStripRow, Selection.kt CountChip); tapping clears. It is not in the bar: the phone bar was too crowded with it (user, 17 and 27 Nov). DEVIATION from the board, which draws it in the bar. The status line now shows only the size of the selected files. Built in 113, uncompiled and unseen  
*Change:* Redraw the chip in the strip on boards 01/04; look at a screenshot.

**B04.6 · Tray = one place** [M] · Matches — Phone: small chip above the bar. Tablet: neutral strip under the bar. Desktop: band above the status bar, full window width. Open: list grouped by source folder.  
*Evidence:* Tray.kt:89-131 phone chip above bar (TrayChip), tablet neutral strip (TrayStrip), open card grouped by source (TrayList)

**B04.7 · Copy here / Move here** [T] · Matches — Two buttons, Move is primary. Greyed with a reason in Trash, search and virtual folders.  
*Evidence:* Tray.kt:187-199 Copy here + Move N here primary, disabled and explained "Open a folder to drop these into it."

**B04.8 · Clipboard** [D] · Parked (desktop only)

### 05 · Menus

- *Desktop (parked):* Right-click opens a popup at the cursor, ordered exactly like the touch More list, with an icon row on top for the six everyday verbs. Every row shows its shortcut; right-clicking a non-selected row selects it first.
- *Tablet:* No right-click: ⋮ in the bar opens the same list as a popup above it, anchored to the bar so the thumb does not travel. S Pen button and mouse right-click behave like desktop.
- *Phone:* Long-press selects and shows the bar; More (or a second long-press on the selected item) opens a bottom sheet with a file header. The list order is identical.

**B05.1 · One list** [T] · Matches — File actions have one order everywhere: Open, Look, Move / Copy / Tray, Compress / Path / Properties; Trash last and red.  
*Evidence:* FileActions.kt:34-100 one action list feeds context menu and More; order Open, Move/Copy/Tray, Rename..., Select, Trash last

**B05.2 · Icon row** [D] · Parked (desktop only)

**B05.3 · Touch More** [T] · Built, unseen · size S · build A
*Spec:* Contains only what the bar cannot: Quick look, Open with, Add to tray, Rename, Compress, Copy path, Properties.  
*App now:* Decided with the user: More is the full list (Open, Quick look, Open with…, Show in folder, Add to tray, Rename, Duplicate, Compress, Extract…, Share, Cut, Copy to clipboard, Paste into folder, sidebar pin, Customize folder, Copy path, Properties, Select all, Invert, Select similar) with the four bar actions left out. The hold menu is short and keeps the four bar actions (phone sheet: big Move / Copy / Share / Trash targets, then Open, Quick look, Add to tray, Rename, Compress, Extract…, Properties), because the bar is out of reach when you hold. Both come from one list. DEVIATION from the board, which shows a 7 row More. Built in 113, uncompiled and unseen  
*Change:* Redraw board 05 with this split.

**B05.4 · Menu rows** [M] · Built, unseen · size S · build A
*Spec:* Desktop 36 high, touch 48; 6 px menu padding, 5 px hairlines between groups, radius 16.  
*App now:* DexMenu.kt: 48 / padding 6 / hairline 5 / radius 16 on every menu that goes through the wrapper. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

**B05.5 · Greyed not hidden** [T] · Built, unseen · size M · build A
*Spec:* "Paste" and "Dual pane" stay visible with 45% opacity and a phrase when they cannot work.  
*App now:* FileActions.kt: Quick look, Open with… and Rename are always in the list; they grey out (45%) when they cannot apply, with no phrase for the obvious cases (user, 27 Nov). Menus elsewhere keep a phrase only where the reason is not obvious (Paste "nothing to paste", Details "needs a wider window"). Built in 113, uncompiled and unseen  
*Change:* Look at a screenshot.

**B05.6 · Danger** [T] · Matches — Only Trash is red. Delete forever appears only inside Trash and always asks.  
*Evidence:* FileActions.kt:56-60 Delete danger; Delete forever only in Trash (FileActions.kt:44-46)

**B05.7 · Rename several** [T] · Built, unseen · size M · build A
*Spec:* Rename works on any selection. One item renames in place; several open one dialog where the name is built from pieces ({date}, {name}, {n}, {parent}) or a pattern used before, so little is typed. Every new name is checked before Rename is allowed. Select similar picks files whose names differ only in numbers.  
*App now:* Rename works on any selection (FileActions.kt). Several items open BatchRenameDialog (Dialogs.kt): a pattern field with one-tap pieces {name} {date} {n} {parent} {today}, patterns remembered after a rename and shown as chips (ExplorerViewModel.nameRules, up to 12; "Forget this pattern"), find / replace / before / after / numbers under "More options", preview with clashes first, Rename only when every name is valid and free. Select similar (More → Select) picks files whose names differ only in numbers (NameShape). Engine and tests in core/BatchRename.kt and CoreTest. FOUNDATION: the user's own naming convention is not wired in yet; it needs example names. Built in 113, uncompiled and unseen  
*Change:* Get example file names from the user; make their convention the first saved pattern (and a "not following the convention" selector).

### 06 · Dialogs, picker and feedback

- *Desktop (parked):* Dialogs are centred cards 440–520 wide on a 55% scrim. Enter confirms, Esc cancels, Tab cycles; the primary button is amber and focused. Opens at the file's own folder.
- *Tablet:* Identical card, 480 wide. Dialogs are never sheets: sheets are for choosing from a list (More, tabs), dialogs are for deciding.
- *Phone:* Card takes the full width minus 12 on each side so buttons never wrap (your Build 108 fix); text 14 sp; list rows 48.

**B06.1 · Dialog vs sheet** [T] · Matches — Decision = centred dialog at every width. List of actions = menu (desktop/tablet) or sheet (phone).  
*Evidence:* DexDialog.kt:99-112 centred card, 12 dp gutter on phone; Dialogs.kt:101 phone action list is a bottom sheet (list = sheet, matches)

**B06.2 · Footer** [T] · Matches — One row, never wraps. Order: ghost action left, then Cancel, then the primary. Primary is amber, danger is red-filled.  
*Evidence:* DexDialog.kt:116-117 one Row end-aligned; Selection.kt:174-178 ghost left, Cancel, primary; DexBtn.Danger exists

**B06.3 · Move/Copy picker** [M] · Differs · size S · build C
*Spec:* Opens in the file's own folder, recent-destination chips, New folder inline, folders only, greyed source.  
*App now:* Selection.kt:154-158 opens in file folder, 187-191 recent chips (match); New folder opens a second dialog (Selection.kt:174), files shown dimmed (Selection.kt:210)  
*Change:* New folder inline; folders only with source greyed.

**B06.4 · Conflict** [T] · Unverified · size ? · build C
*Spec:* Side-by-side comparison, "do for all" checkbox, Replace is primary only when the incoming is newer.  
*App now:* Dialogs.kt:409 ConflictDialog and "do for all" exist; side-by-side comparison and Replace-primary-if-newer not read  
*Change:* Read and compare.

**B06.5 · Progress** [T] · Differs · size S · build C
*Spec:* Floating card that collapses; no modal progress; cancel always available.  
*App now:* App.kt:268-307 floating JobCard (340 wide, appears after 350 ms, cancel button 36 dp at line 298); no collapse  
*Change:* Collapsible card, cancel 48.

**B06.6 · Undo** [T] · Built, unseen · size S · build A
*Spec:* Toast with Undo for Move, Copy, Rename, Trash; Delete forever has no Undo, so it asks first.  
*App now:* App.kt: toast shows 4 s, 8 s when it has an action (Undo); DexDialog.kt: toast min height 48, Undo target 48 high. Built in 112, uncompiled and unseen  
*Change:* Look at a screenshot.

### 07 · Search

- *Desktop (parked):* Search takes over the toolbar, not the page. The file panel stays, so Sort/View and the status line still work, and Esc puts the breadcrumb back exactly where you left it. Typing with nothing focused starts a search (type to find).
- *Tablet:* Back arrow, one field, filter chips under it. Results show a second line with the path, so you can tell Invoice Oct from Invoice Sep without opening either. 56 dp rows.
- *Phone:* Same layout, 14 sp, the keyboard stays up while results scroll; tapping a result hides the keyboard first. Chips scroll sideways, never wrap.

**B07.1 · One field** [M] · Matches — The search field expands in place of the breadcrumb (desktop) or the top bar (touch). It never opens a separate page.  
*Evidence:* Shell.kt:219 field grows over the top bar; SearchPill Shell.kt:299; tablet field in tab row

**B07.2 · Scope** [T] · Differs · size S · build C
*Spec:* This folder / Everything switch inside the field; remembered per tab.  
*App now:* SearchFilters.kt:63-66 one scope chip in:<folder>/Everywhere (equivalent); vm.searchCurrentOnly is one global flag, not per tab  
*Change:* Per-tab scope.

**B07.3 · Filters** [T] · Differs · size S · build C
*Spec:* Chips with checklist menus: Type, Modified, Size. Active chip is the amber plate; Clear filters appears only when one is active.  
*App now:* SearchFilters.kt:73-87 Type/Modified/Size chips with menus (match); no "Clear filters" chip  
*Change:* Clear filters when active.

**B07.4 · Result row** [M] · Unverified · size ? · build C
*Spec:* Desktop: Location column. Touch: path as second line. Match highlighted in amber text.  
*App now:* Second-line path and amber match highlight on result rows not read  
*Change:* Read Pane.kt result rows.

**B07.5 · Quick jump** [M] · Differs · size M · build C
*Spec:* Ctrl K (also Ctrl P) on desktop: folders first, actions after ">". Touch: empty search shows Recent + Jump to.  
*App now:* Shell.kt:358-375 empty search shows Recent searches only; no Jump to; palette reachable via ">" (Shell.kt:322)  
*Change:* Empty search = Recent + Jump to.

**B07.6 · No results / searching** [T] · Unverified · size ? · build C
*Spec:* Always an explanation and a next step; streaming results; Stop keeps partial results.  
*App now:* Pane.kt:515 "Searching… n found so far" exists; Stop control and no-results explanation not found  
*Change:* Read, then add.

### 08 · Viewers and Info

- *Desktop (parked):* Information stays beside the work: the inspector is docked, quick look is one key, viewers keep the sidebar so you never lose your place. Everything is reachable from the keyboard and no control hides.
- *Tablet:* Immersive by default. Chrome floats over the content and hides on tap. Properties slide in from the right and leave the list visible behind the scrim.
- *Phone:* Same pattern at 390: pills are shorter, the name truncates at 190 dp, Properties is a tall sheet. Actions live in the bottom pill (thumb zone), identity at the top.

**B08.1 · Chrome** [M] · Matches — Desktop: solid 44 dp toolbar, always visible. Touch: floating pills that hide on tap.  
*Evidence:* Viewers.kt:141-176 floating pills fade with a tap (Viewers.kt ReaderViewer detectTapGestures toggles chrome)

**B08.2 · Where actions live** [M] · Differs · size M · build B
*Spec:* Desktop: top right (Open with, Share, Info, More). Touch: bottom pill (Share, Info, Delete), top only has back, name and More.  
*App now:* Viewers.kt:152-163 actions live in the top ⋮ (Share, Open with, Properties, Trash); Viewer.kt:109-114 bottom pill is Zoom out, Fit, Zoom in, n/N; targets 32 dp (Viewers.kt:127)  
*Change:* Bottom pill Share, Info, Delete; top back, name, ⋮; 48 dp targets, all viewers.

**B08.3 · Info** [M] · Missing · size L · build B
*Spec:* Desktop: docked preview pane (Alt P, remembered). Tablet: side sheet 380. Phone: tall sheet.  
*App now:* Info is the centred Properties dialog (Viewer.kt:78, Viewers.kt MoreMenu "Properties", Dialogs.kt:276)  
*Change:* Tablet side sheet 380, phone tall sheet; same sheet for Properties from lists.

**B08.4 · Quick look** [M] · Unverified · size ? · build B
*Spec:* Desktop: Space. Touch: Preview in long-press menu opens a peek card.  
*App now:* QuickLook exists (Preview.kt:166, FileActions.kt Quick look); peek-card look not compared  
*Change:* Compare.

**B08.5 · Moving between files** [M] · Differs · size S · build B
*Spec:* Desktop: ← → and filmstrip. Touch: swipe sideways (your Build 110). Position shown as "3 of 12" everywhere.  
*App now:* Viewer.kt:84 and Viewers.kt pager swipe (match); position "n / N" only in the image pill  
*Change:* "3 of 12" in every viewer.

**B08.6 · Zoom** [M] · Differs · size S · build B
*Spec:* Desktop: buttons + keys + Ctrl wheel; touch: pinch + double tap, a Fit chip appears only when zoomed.  
*App now:* Viewer.kt:109-114 Fit chip always shown; spec: only while zoomed; PDF zoom not read  
*Change:* Fit chip only when zoomed.

**B08.7 · Failure** [T] · Missing · size M · build B
*Spec:* Unsupported and damaged states always give a next step (Open with, Show readable pages).  
*App now:* No unsupported or damaged state found in Viewers.kt, Viewer.kt or Preview.kt  
*Change:* Failure states with Open with / next step.

### 09 · Dual pane and Compare

- *Desktop (parked):* Two equal panes with a centre rail of the four transfer actions (copy, move, swap, same folder). The rail is for the mouse; F5/F6/Ctrl U are the same actions for keys. Left and right keep their own sort, view and tabs.
- *Tablet:* Side by side when the content is ≥ 720 dp wide (860 dp tablet, minus the 68 rail = 792). Each pane is a touch list, the rail buttons are 48 dp, and the floating bar acts on the active pane with arrows in the labels.
- *Phone:* No true side by side at 390: panes stack top and bottom with a 48 dp transfer strip between them. Opt-in from View › Split. The normal way to move between folders on a phone is still the tray and the Move picker.
- *Compare desktop (parked):* Compare is a mode of dual pane, not a second tool. Aligned rows, tags for newer / only here / differs, filter control in a compare row under the command bar, and a summary bar that carries the two bulk actions with their direction arrows.
- *Compare tablet:* Same layout, short tags. The floating bar holds one amber action; choose a direction by tapping the arrow buttons in the rail for single files.
- *Compare phone:* A phone cannot align two columns, so Compare becomes a list of differences, one row each with an arrow showing which way a copy would go. Rows you tick are copied; the rest are left alone.

**B09.1 · Dual pane threshold** [M] · Differs · size M · build C
*Spec:* Real side by side from 720 dp of content width (tablet 860 yes, most phones no). Below it: stacked split (opt-in) or tray.  
*App now:* Shell.kt:467 Dual pane enabled from 600; Shell.kt:389 Details at 760; App.kt:167 dual allowed when not phone; App.kt:122 forces dual off on phone, so the stacked split (top and bottom, 48 dp transfer strip) does not exist  
*Change:* One 720 dp content-width rule; add the opt-in stacked split on phone.

**B09.2 · Active pane** [M] · Matches — 2 dp amber top edge + faintly raised header. Command bar, shortcuts and floating bar act on it.  
*Evidence:* Pane.kt:155 2 dp strip, amber when active; raised header not checked

**B09.3 · Transfer** [M] · Missing · size M · build C
*Spec:* Centre rail with copy, move, swap, same folder; keys F5, F6, Ctrl U, Ctrl =. Drag between panes also works (board 13).  
*App now:* No centre rail; transferToOtherPane + F5/F6 (ExplorerViewModel.kt:1588-1589) and "Copy →" labels in the bar (Selection.kt:77-79)  
*Change:* Rail with copy, move, swap, same folder (48 dp).

**B09.4 · Compare** [M] · Differs · size L · build C
*Spec:* A mode on top of dual pane; aligned rows, tags, filter and a summary bar. Phone shows a difference list.  
*App now:* Compare is a dialog (Compare.kt:67, Shell.kt MoreMenu vm.dialog = Compare) with diff glyphs and a filter  
*Change:* Mode on top of dual pane with aligned rows, tags and summary bar.

**B09.5 · Safety** [T] · Matches — Bulk copy shows what will be replaced; nothing is ever deleted by Compare.  
*Evidence:* Compare.kt:38 and :68 nothing is deleted; copies use the normal path

### 10 · Settings

- *Desktop (parked):* Left list, right content capped at 640 dp so rows never stretch across 1000 px. Search settings at the top. Keyboard category exists only here; Tab and arrows move through rows, Space toggles.
- *Tablet:* Master and detail at 860: 260 dp category list, content beside it. Rows are 56 dp, the whole row is the target, back arrow returns to the folder you left.
- *Phone:* Two levels: category list with current values, then one page. 64 dp category rows, 56 dp setting rows. The Keyboard category is replaced by Touch and gestures.

**B10.1 · Container** [M] · Differs · size L · build B
*Spec:* Desktop: a Settings tab. Tablet: full screen, master and detail. Phone: list, then page.  
*App now:* Phone: full page slide-in (SettingsPanel.kt:37-47); tablet: 330/400 dp panel docked or over the page (App.kt:148-150, SettingsPanel.kt:60-72)  
*Change:* Tablet full screen master/detail 260 + content; phone list then page.

**B10.2 · Categories** [M] · Differs · size L · build B
*Spec:* Appearance, Files, Keyboard and mouse (desktop) / Touch and gestures (touch), Safety and Trash, Storage and access, About.  
*App now:* SettingsCard.kt:100-118 captions Appearance, Browsing, Layout, Operations; one sub-page (Appearance)  
*Change:* Appearance, Files, Touch and gestures, Safety and Trash, Storage and access, About.

**B10.3 · Changes apply at once** [T] · Matches — No Save or Apply anywhere; the status line says so.  
*Evidence:* SettingsCard.kt:100-118 every switch writes straight to vm; no Save button

**B10.4 · Icon size** [T] · Matches — Lives only in the View menu as one slider.  
*Evidence:* Icon size only in the View menu (Shell.kt:416-421); Settings has Text size and Theme only (SettingsCard.kt:180-190)

**B10.5 · Row anatomy** [T] · Differs · size S · build B
*Spec:* Title, optional one-line description, value or control on the right; whole row is the hit area on touch.  
*App now:* SettingsCard.kt:147 Item(title, hint, icon, trailing) rows 58 high with leading icons; spec 56, no leading icon  
*Change:* Row 56, title / one-line hint / value right.

**B10.6 · Danger** [T] · Missing · size S · build B
*Spec:* Only Reset is red, always behind a confirm dialog.  
*App now:* No Reset in Settings (SettingsCard.kt has only per-slider reset chips)  
*Change:* Reset behind a confirm dialog, red.

**Settings content (what each category holds)**

**B10.c1 · Appearance › Theme** · Matches  
*Spec:* System / Light / Dark segmented; wired  
*App now:* Theme (Light, Dark, System) exists: SettingsCard.kt:182

**B10.c2 · Appearance › Pure black** · Missing · build B  
*Spec:* Toggle "AMOLED backgrounds in dark theme; greys when off"  
*App now:* No pref (Prefs.kt has no pureBlack); dark background is always Color.Black  
*Change:* Pref + dark palette with a grey background when off

**B10.c3 · Appearance › Text size** · Differs · build B  
*Spec:* Slider with live preview row, 100%  
*App now:* SteppedSlider text size 12-20 (SettingsCard.kt:185); no live preview row  
*Change:* Add the preview row ("Vision ten ideas.pdf / 2.4 MB · Today")

**B10.c4 · Files › Show hidden files** · Matches  
*Spec:* Toggle, "Names that start with a dot"  
*App now:* Exists (SettingsCard.kt:107)

**B10.c5 · Files › Show file extensions** · Missing · build B  
*Spec:* Toggle  
*App now:* No pref; extensions always shown (EntryName.kt)  
*Change:* Pref + EntryName option

**B10.c6 · Files › Default view** · Differs · build B  
*Spec:* Choice, "For folders you have not set yourself"  
*App now:* Prefs.viewMode exists; not in Settings; "Remember view per folder" switch instead  
*Change:* Choice row that sets the default view; keep per-folder memory as the rule

**B10.c7 · Files › Default sort** · Differs · build B  
*Spec:* Choice, e.g. Name, A to Z  
*App now:* Prefs.sortKey/sortAscending exist; not in Settings  
*Change:* Choice row

**B10.c8 · Files › Dates** · Missing · build B  
*Spec:* Segmented Relative / Exact  
*App now:* No pref; Format uses one style  
*Change:* Pref + Format switch

**B10.c9 · Touch and gestures** · Differs · build B  
*Spec:* Read-only guide: Tap, Long press, Drag across circles, Press-hold-drag, Pinch, Swipe in a viewer, Swipe from the edge; plus "Open items with" single/double click  
*App now:* Only "Single tap to open" switch exists (SettingsCard.kt:109)  
*Change:* Guide page + keep the open-with choice

**B10.c10 · Safety and Trash › Move to Trash instead of deleting** · Matches  
*Spec:* Toggle  
*App now:* Exists as "Use Trash" (SettingsCard.kt:116)

**B10.c11 · Safety and Trash › Keep Trash for** · Missing · build B  
*Spec:* Choice, 30 days default; "Items older than this are removed"  
*App now:* Fixed at 30 days (TrashStore.kt:118), no pref  
*Change:* Pref (7/14/30/60 days) wired to purgeOlderThan

**B10.c12 · Safety and Trash › When a name already exists** · Differs · build B  
*Spec:* Choice: Ask me / Keep both  
*App now:* "Confirm before replacing" switch exists (SettingsCard.kt:115)  
*Change:* Relabel as the choice row

**B10.c13 · Safety and Trash › Delete forever** · Missing · build B  
*Spec:* Info row "Always asks first"  
*App now:* Behaviour exists; no row  
*Change:* Info row

**B10.c14 · Storage and access › All files access** · Missing · build B  
*Spec:* Status row Granted / Needs access  
*App now:* No status row  
*Change:* Status from Environment.isExternalStorageManager

**B10.c15 · Storage and access › SD card** · Missing · build B  
*Spec:* Status row with name and size  
*App now:* No row  
*Change:* Status from Volumes

**B10.c16 · Storage and access › Analyze storage** · Differs · build B  
*Spec:* Link to the Storage page  
*App now:* Exists in the sidebar (Sidebar.kt), not in Settings  
*Change:* Link row

**B10.c17 · Storage and access › Clear cache** · Missing · build B  
*Spec:* Action "Thumbnails and previews, 24 MB" + Clear  
*App now:* No row  
*Change:* Coil cache size + clear

**B10.c18 · About** · Missing · build B  
*Spec:* Version and build, Open source licences, Send feedback (includes version and device, no files), Reset all settings (red, confirm)  
*App now:* Only a footer text "DexFiles 1.0 · Onest font" (SettingsCard.kt:119)  
*Change:* About page with those rows

### 11 · Pages: Home, Trash, Storage, Operations

**B11.1 · Home screen** [T] · Matches — Recent, grouped by day. Touch: category chips. Desktop: Type menu in the command bar, categories in the sidebar. No dashboard, no FAB, no bottom nav.  
*Evidence:* Home.kt ChipBar + Pane.kt:858-861 category chips; Sidebar.kt:82 Recent first; no dashboard, FAB or bottom nav

**B11.2 · Where Home lives** [M] · Matches — Desktop: first sidebar item (Ctrl 1). Touch: the default tab and the drawer’s first item.  
*Evidence:* Sidebar.kt:82 Recent files is the first item; default tab is Recent (App.kt back handler lands on Loc.HOME)

**B11.3 · Trash** [T] · Differs · size M · build C
*Spec:* Same list component, Restore as primary, days left per row, red under 7 days.  
*App now:* Pane.kt:503-505 one banner "stay here for 30 days"; rows have no days left; deletedAt exists (TrashStore.kt:18), purge at 30 days (TrashStore.kt:118); Restore is primary (FileActions.kt:46)  
*Change:* Days left per row, red under 7.

**B11.4 · Storage** [T] · Differs · size L · build C
*Spec:* Segmented bar, category list, four reviewed clean-up actions, largest folders.  
*App now:* Screens.kt:73-89 AnalyzeScreen is a scan tool (Scan usage, Find duplicates, Empty folders, Installers); Largest files exists (Screens.kt:119); no segmented bar or category list  
*Change:* Segmented bar, categories, four reviewed clean-ups, largest folders.

**B11.5 · Operations** [M] · Differs · size M · build C
*Spec:* A list, newest first, with Cancel, Retry, Undo, Show; desktop keeps the column to 760 wide.  
*App now:* HistoryScreen.kt:96-115 newest-first list with Undo and Clear only  
*Change:* Cancel, Retry, Undo, Show per row.

### 12 · States: empty, permission, errors, loading, banners

**B12.1 · Empty is a state to design** [T] · Matches — Icon tile, one sentence of cause, at most two actions; actions show shortcuts on desktop only.  
*Evidence:* Pane.kt:563-571 StateCard icon + sentence + at most one action

**B12.2 · Permission** [T] · Matches — First run shows what and why before the system dialog; one amber button.  
*Evidence:* App.kt:311-340 what and why before the system dialog, one button (Material Button, not DexButton)

**B12.3 · Errors** [T] · Differs · size S · build C
*Spec:* Name the thing, the cause, the next step: “Can’t open Trip, moved or no permission, Go up / Retry”.  
*App now:* Pane.kt:559 "Can't open this folder" + cause + Go back only; no Retry; viewer errors absent  
*Change:* Name, cause, next step everywhere incl. viewers.

**B12.4 · Loading** [T] · Differs · size S · build C
*Spec:* Skeleton rows in the exact row height plus a status line with Stop; the list never jumps when real rows arrive.  
*App now:* Pane.kt:463-467 2 dp progress after 700 ms; Pane.kt:577 LoadingRows skeleton; no status line with Stop  
*Change:* Skeleton rows at exact height, Stop in status line.

**B12.5 · Banners** [T] · Missing · size M · build C
*Spec:* In-panel strips for conditions; stack at most three; each has one verb.  
*App now:* Only TrashBanner (Pane.kt:470, 503); no banner system  
*Change:* Banner component, max 3, one verb each.

**B12.6 · Feedback ladder** [T] · Differs · size S · build C
*Spec:* Inline, toast, banner, dialog; pick the lightest that is honest.  
*App now:* Toast and dialog exist; banner tier missing (see B12.5)  
*Change:* Covered by B12.5.

### 13 · Input

- *Desktop (parked):* Pick up with the pointer. The ghost stack shows up to three names and a count; cursor changes to copy with Ctrl, no-drop over invalid targets. Hovering a tab for 600 ms opens it so you can drop deeper.
- *Tablet:* Long press lifts the first row (scale 1.03, shadow, haptic tick); every selected row follows. Row under the finger gets the dashed amber outline. An edge band scrolls the list while you hold in it.
- *Phone:* Same lift. A tray drop zone appears above the system gesture area, so dragging to Tray is possible but the usual route is the bar’s Cut and Copy. The ghost sits above the finger so the target stays visible.

**B13.1 · Verb parity** [T] · Unverified · size ? · build C
*Spec:* Every action has one visible touch route and at least one pointer route and one key route.  
*App now:* Needs a verb x input table (touch route, pointer route, key route)  
*Change:* Build table from FileActions.

**B13.2 · Select on touch** [T] · Matches — Long press selects; tap adds; drag across circles ranges.  
*Evidence:* Pane.kt:676-680 long-press selects (not mouse); vm.onEntryClick adds while selecting; drag across circles to range not read

**B13.3 · Menu on touch** [T] · Matches — More button, not long press.  
*Evidence:* Deliberate: long-press on an unselected item selects; hold on a selected item lifts the stack and opens the actions menu beside it (a right-click that works wherever the fingers are); More on the bar is the second, visible route. Samsung has both (user, 27 Nov). Both draw from one action list (FileActions.kt).

**B13.4 · Drag and drop** [M] · Unverified · size ? · build C
*Spec:* Same “lift, carry, drop on a named target” on both; the target label names the verb.  
*App now:* Dnd.kt hold stack exists; ghost of up to 3 names + count, dashed amber outline not compared  
*Change:* Compare.

**B13.5 · Hover** [D] · Parked (desktop only)

**B13.6 · Targets** [M] · Built, unseen · size M · build C
*Spec:* 32 px desktop, 48 dp touch, 8 dp gaps.  
*App now:* 48 dp hit areas applied: RoundBtn, TabCountButton, tray remove, job cancel, toast Undo, viewer PillIcon and pill, strip view button, strip type/sort labels, selection cells. PARTIAL, still open: select circle 44 dp (Pane.kt tile/row circle), DexChip 30 dp, rail item 46 dp, sidebar rows 46/40. Built in 112, uncompiled and unseen  
*Change:* Close the four leftovers in Build C with the Sidebar and chips pass.

### 14 · Light theme and accessibility

- *Desktop (parked):* Light desktop: white panel on a cool grey window, menus on white with a soft long shadow (no black scrim glow). Hover is a 4% tint.
- *Tablet:* Same tokens. Floating bar is white with a 1 px ring; pressed state is a 10% overlay.
- *Phone:* Same tokens. Status-bar and nav-bar icons flip to dark automatically; AMOLED black does not apply.

**B14.1 · Contrast** [T] · Built, unseen · size  · build A
*Spec:* Every text pair ≥ 4.5:1, every non-text state ≥ 3:1, in both themes.  
*App now:* Light faint/danger/ok and amberUi tokens changed in Build 111 (Palette.kt, Theme.kt); not on device  

**B14.2 · Selection** [T] · Built, unseen · size  · build A
*Spec:* Plate + a uniform 1 px edge in a darker amber (3.1:1 dark, 3.7:1 light) + a check circle on touch. No one-sided bar.  
*App now:* Plate + uniform 1 px edge, edge token 3:1, no left bar (Build 111)  

**B14.3 · Light theme** [T] · Unverified · size ? · build C
*Spec:* First-class: same layouts, white card on cool grey, darker amber for text and rings.  
*App now:* Light theme exists; every board in light not compared  
*Change:* Compare screenshots.

**B14.4 · Text size** [T] · Built, unseen · size M · build C
*Spec:* Rows grow with text, nothing truncates names, bars collapse to icons at 115%.  
*App now:* Dimens.kt rowHeight grows with the text scale (system x app setting); selection bar drops its labels above 115%. PARTIAL: names do not yet wrap to two lines and the top bar does not collapse to icons. Built in 112, uncompiled and unseen  
*Change:* Name wrapping to two lines in rows; check at 130% and 160% with a screenshot.

**B14.5 · Keyboard focus** [M] · Built, unseen · size  · build A
*Spec:* 2 px amber ring, visible only after keyboard input; Tab order = visual order.  
*App now:* Mods.keyboard + Sel.focusRing (Build 111)  

**B14.6 · Screen readers** [T] · Missing · size M · build C
*Spec:* Rows read name, kind, size, date, state, hint; gestures have custom actions.  
*App now:* No custom accessibility actions and no row-level semantics found in ui/  
*Change:* Rows read name, kind, size, date, state; gestures get custom actions.

**B14.7 · Reduced motion** [T] · Missing · size S · build A
*Spec:* Fades only, 80 ms; haptics unchanged.  
*App now:* No reduced-motion check found anywhere  
*Change:* One helper in Motion.kt: duration 80 ms fade when the system animation scale is 0.

### 15 · Motion

**B15.1 · Durations by form** [M] · Built, unseen · size S · build A
*Spec:* Desktop 80–180 ms, tablet 120–260 ms, phone 120–280 ms, hard cap 300 ms.  
*App now:* Motion.kt glide(ms) clamps every duration to 120–300 ms (all glide users and raw tweens are at or under 300 except a 900 ms infinite pulse). PARTIAL: the phone 120–280 / tablet 120–260 split is not enforced. Built in 112, uncompiled and unseen  
*Change:* Look at motion on device.

**B15.2 · Origin follows input** [M] · Differs · size M · build C
*Spec:* Menus grow from the cursor or button; sheets rise from the edge; viewers grow from the thumbnail.  
*App now:* Viewer cross-fades 200 ms (App.kt:236); menus use DropdownMenu default; spec: viewers grow from the thumbnail  
*Change:* Container transform for viewers on touch.

**B15.3 · Desktop frame is still** [M] · Parked (desktop only)

**B15.4 · Layout never animates under a finger** [M] · Unverified · size ? · build C
*Spec:* Pinch and drag move content directly; reflow happens after release.  
*App now:* Pinch/drag reflow after release not re-read (Build 110 gallery fix exists)  
*Change:* Read.

**B15.5 · Reduced motion** [M] · Missing · size S · build A
*Spec:* 80 ms fade replaces everything; haptics stay.  
*App now:* Same as B14.7  
*Change:* Covered by B14.7.

## Part 3: motion timelines (touch, from board 15)

| Flow | Steps (start ms, length ms) |
|---|---|
| Drag to folder · phone | lift 0–120, carry 120–880, drop settles 880–1060, card in 1060–1280, run 1280–1660, toast + Undo 1660–1880 |
| Delete · phone | ripple 0–160, dialog in 160–360, wait for you 360–760, rows out 760–960, toast + Undo 960–1180 |

## Part 4: rules for mixed input (touch half)

- Width decides layout, input decides density. A small window with a mouse still wants compact rows; a large tablet with fingers still wants big targets.
- Gestures are shortcuts, never the only route: pinch, drag and swipe each duplicate a visible button.
- One vocabulary: the same verbs in the same order on every form (Open, Move, Copy, Share, Delete).

## Part 5: desktop-only rows (parked until touch parity)

| ID | Element |
|---|---|
| B01.2 | Command bar |
| B01.7 | Status line |
| B02.4 | Columns |
| B02.5 | Header text |
| B04.2 | Desktop command bar |
| B04.8 | Clipboard |
| B05.2 | Icon row |
| B13.5 | Hover |
| B15.3 | Desktop frame is still |

Also parked: Ctrl C/X/V to the tray, desktop command bar, tab strip, address row with Ctrl L, column header and resizing, hover, shortcut tooltips, Keyboard and mouse settings, preview pane (Alt P), desktop motion.

## Part 6: corrections made to the mocks while writing this spec

- Touch top bars drew 44, 40 and 36 dp buttons against the 48 dp rule. They now draw a 40 dp plate inside a 48 dp hit area, in the 56 dp bar, on phone and tablet (boards 01, 09, 10, 13, 16 text updated).
- Board 10 listed "Folders first" in Settings while board 02 puts it in the Sort popup. Removed from Settings.
- Board 09 had the open question 720 vs 600 dp; settled at 720.
