# DexFiles progress (read this first, don't re-explore)

## Done
- Full app written: Kotlin + Compose, ~5,700 lines (core logic, ViewModel, UI, drag-and-drop, preview, sidebar, tabs, dual pane, trash, search, zip, batch rename).
- Core logic (`app/src/main/java/app/dexfiles/core/`) is plain Kotlin: compiled and **26/26 unit tests pass** (checked 2026-10-28).
- GitHub Actions workflow builds an APK (`.github/workflows/build.yml`).

## Not verified
- The Android/UI layer (state/, ui/, data/, MainActivity) has NEVER been compiled; no Android SDK in the sandbox.

## Next chunks (do ONE per session, tick when done)
- [ ] 1. Push to GitHub, run the "Build APK" workflow, paste the first error log back.
- [ ] 2. Fix compile errors from the log (small, file by file).
- [ ] 3. Install APK on DeX, grant "All files access", report what breaks.
- [ ] 4. Fix runtime bugs found in step 3.
- [ ] 5. Polish: shortcuts, drag-and-drop feel, themes.
