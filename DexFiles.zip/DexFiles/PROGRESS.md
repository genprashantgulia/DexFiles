# DexFiles progress (read this first, don't re-explore)

## Done
- Full app written: Kotlin + Compose, ~5,700 lines (core logic, ViewModel, UI, drag-and-drop, preview, sidebar, tabs, dual pane, trash, search, zip, batch rename).
- Core logic (`app/src/main/java/app/dexfiles/core/`) is plain Kotlin: compiled and **26/26 unit tests pass** (checked 2026-10-28).
- GitHub Actions workflow builds an APK (`.github/workflows/build.yml`).

## Not verified
- The Android/UI layer (state/, ui/, data/, MainActivity) has NEVER been compiled; no Android SDK in the sandbox.

## Next chunks (do ONE per session, tick when done)
- [x] 1. Uploaded zip to GitHub; build runs via workflow that unzips DexFiles.zip.
- [x] 2a. First build error: MainActivity needed DexFilesApp + PermissionScreen -> written in ui/App.kt (2026-10-28).
- [x] 2b-1. JVM name clash on 9 VM setters fixed with @JvmName (2026-10-28).
- [x] 2b. Build is GREEN (2026-10-28), APK produced.
- [ ] 2c. STILL MISSING UI: dialogs host (DialogState: Rename, NewItem, ConfirmDelete, Conflicts, Properties, BatchRenameDlg, Compress, Archive, Message, EmptyTrash, Settings, Shortcuts) and right-click context menu (vm.menu / CtxMenu). VM already sets them; nothing draws them yet.
- [ ] 3. Install APK on DeX, grant "All files access", report what breaks.
- [ ] 4. Fix runtime bugs found in step 3.
- [ ] 5. Polish: shortcuts, drag-and-drop feel, themes.

## Notes from first install (2026-10-28)
- APK installs and opens; permission screen works. After granting access the app FORCE-CLOSES on the file view and on every icon tap.
- Added CrashLog (DexApp.kt) + CrashScreen (ui/App.kt): next launch shows the stack trace with a Copy button. NEXT: get that trace, fix crash.
- User feedback: UI feels too "desktop only"; wants a real blend of touch + keyboard/mouse (bigger touch targets, long-press menus, swipe, adaptive layout). Do after crash + dialogs.
