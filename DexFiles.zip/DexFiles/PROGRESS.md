# DexFiles progress (read this first, don't re-explore)

## Done
- Full app written: Kotlin + Compose, ~5,700 lines (core logic, ViewModel, UI, drag-and-drop, preview, sidebar, tabs, dual pane, trash, search, zip, batch rename).
- Core logic (`app/src/main/java/app/dexfiles/core/`) is plain Kotlin: compiled and **26/26 unit tests pass** (checked 2026-10-28).
- GitHub Actions workflow builds an APK (`.github/workflows/build.yml`).

## Not verified
- The Android/UI layer (state/, ui/, data/, MainActivity) has NEVER been compiled; no Android SDK in the sandbox.

## Next chunks (do ONE per session, tick when done)
- [x] 1. Uploaded zip to GitHub; build runs via workflow that unzips DexFiles.zip.
- [x] 2a. First build error: MainActivity needed DexFilesApp + PermissionScreen -> written in ui/App.kt (2026-10-28).
- [x] 2b-1. JVM name clash on 9 VM setters fixed with @JvmName (2026-10-28).
- [x] 2b. Build is GREEN (2026-10-28), APK produced.
- [ ] 2c. STILL MISSING UI: dialogs host (DialogState: Rename, NewItem, ConfirmDelete, Conflicts, Properties, BatchRenameDlg, Compress, Archive, Message, EmptyTrash, Settings, Shortcuts) and right-click context menu (vm.menu / CtxMenu). VM already sets them; nothing draws them yet.
- [ ] 3. Install APK on DeX, grant "All files access", report what breaks.
- [ ] 4. Fix runtime bugs found in step 3.
- [ ] 5. Polish: shortcuts, drag-and-drop feel, themes.

## Notes from first install (2026-10-28)
- APK installs and opens; permission screen works. After granting access the app FORCE-CLOSES on the file view and on every icon tap.
- Added CrashLog (DexApp.kt) + CrashScreen (ui/App.kt): next launch shows the stack trace with a Copy button. NEXT: get that trace, fix crash.
- User feedback: UI feels too "desktop only"; wants a real blend of touch + keyboard/mouse (bigger touch targets, long-press menus, swipe, adaptive layout). Do after crash + dialogs.
- [x] CRASH 1 FIXED (2026-10-28): "ExplorerViewModel not provided" -> DexFilesApp now provides LocalVm + LocalHostActivity (ui/App.kt). Waiting on user to retest; any new crash shows in the on-screen crash report.

## Build 3 feedback (2026-10-28) - APP WORKS, browsing OK
- [x] Dark-mode invisible text: DexTheme now wraps content in Surface (Theme.kt).
- Design problems to fix, ONE CHUNK PER SESSION, in this order:
  - [x] D1 (done by an earlier session that hit the usage limit; reviewed, all referenced symbols exist; needs a build to confirm).  Remove duplication: Home screen repeats sidebar (Favorites, Library, Storage). Decide: sidebar = places only; Home = recents/storage summary, or drop Home tab.
  - [ ] D2. Adaptive layout: touch-first on narrow/phone (bottom bar, bigger targets, long-press select + menus), desktop-first with mouse/keyboard on DeX (compact rows, hover, right-click). Detect by window width + pointer presence.
  - [ ] D3. Pinch-to-zoom for grid/thumbnail size (vm.gridSize exists, 72..240) + Ctrl+scroll on mouse.
  - [ ] D4. Declutter toolbar (too many icons: keep few, rest in a menu; bigger touch targets).
  - [ ] D5. Draw the missing dialogs + context menu (2c above).
  - [ ] D6. Test deeper: copy/paste, delete/trash, rename, zip, search, dual pane, drag-drop.

## iPad-style redesign (requested 2026-10-29) - one chunk per session
- [x] U1. Theme.kt: fixed iPad-like palettes (light #F2F2F7 canvas/white cards, dark pure black/charcoal), no wallpaper dynamic colour, larger type. FileIcons.kt: drawn yellow FolderIcon (replaces flat Material folder). Needs build + visual check.
- [ ] U2. Grid/icon view like iPad: spacious tiles, whole-image thumbnails (ContentScale.Fit), name + date/size below, selection circle, folder item counts.
- [ ] U3. All view types: Icons (grid), List, Details/columns, Gallery (large thumbs), Column view (Mac-style) -> view picker menu. Currently: Details, Grid, Compact list (check vm.ViewMode).
- [ ] U4. Toolbar/title bar iPad style: back/forward, breadcrumb title, rounded pill buttons, tabs as top pills.
- [ ] U5. Pinch-to-zoom + Ctrl+scroll tile size; size slider.
- [ ] U6. Menus/dialogs (2c): context menu, rename, new folder, delete confirm, properties, Settings.
- [ ] U7. Bugs: dual pane second pane not interactive; image viewer swipe; half-hidden arrows in full-screen viewer.

## Structural redesign (user feedback 2026-10-29 14:20: "rudimentary, scaled-down desktop, not native on tablet")
- [x] S1. Adaptive shell wired (2026-10-29): ui/Shell.kt (written by earlier session, reviewed, imports checked) = AdaptiveTopBar (one row, pill groups, 44dp targets, title+item count, path editor, search pill, view/sort menu, more menu), SelectionBar, BottomActionBar (phone). ui/App.kt now uses windowClassFor(width): Compact <600 (drawer sidebar, bottom action bar, no dual/preview), Medium <840 (drawer sidebar), Expanded (permanent sidebar, preview, dual). Pane.kt hides tab strip when only 1 tab. TopBar.kt is now unused (can delete later). NEEDS BUILD + visual check.
- [x] S2. Folder icon redesigned (2026-10-30): prototyped as SVG, rendered with Chromium at 200/110/64/32px on light/dark, then ported to Canvas in ui/FileIcons.kt FolderIcon (amber back+tab, cream paper strip, yellow->gold front, gloss). NEEDS BUILD + user opinion. Later: per-folder glyph overlay (camera for DCIM, arrow for Download).
- [ ] S3. Grid tiles iPad-style: thumbnails in ORIGINAL aspect ratio (Fit, not square crop), spacing, name + date/size below, selection circle.
- [ ] S4. Diagnose "view modes work randomly in some folders" (read Pane.kt ListingBody / vm.setViewMode / virtual folders).
- [ ] S5. Tabs look (iPad pill tabs), pinch-zoom, menus/dialogs (2c), bugs (dual pane focus, viewer swipe, arrows).
- [x] FONT (2026-10-29): Inter (OFL) bundled in res/font + licence in assets/licenses; Theme.kt applies it to all text styles. Samsung's own font is proprietary and can't be bundled; idea for later: Settings option "Use system font".
- User asked (14:53) for screenshots-based design: waiting for One UI 9 My Files (sidebar, grid, list, selection) and iPad Files (icons, list, tab bar, sidebar, long-press menu) screenshots before the "Views" chunk. Video links can't be watched.
- [x] One UI 9 screenshots received (2026-10-29) and distilled into DESIGN_NOTES.md (READ IT before any UI work). iPad screenshots still pending.
- NEXT chunk "Views": folder icon, real-aspect thumbnails (Fit), iPad-style Icons + List views (no column headers), Home must respect view mode, visible "new tab" button.

## Working agreement (user 2026-10-30)
- Free plan: usage limit resets mid-task. SAVE continuously: update PROGRESS.md after every chunk, ship a zip after every chunk, record durable decisions in memory. Project lives at /home/claude/DexFiles; if missing, unzip the latest DexFiles.zip attachment and copy PROGRESS.md + DESIGN_NOTES.md back in.

## Views chunk (2026-10-30) - written, NOT yet built
- [x] FileThumb: crop=false keeps real aspect ratio, icon hidden once image loaded.
- [x] Pane.kt: GridView = iPad-style (bigger cells, bold name 2 lines, "date · N items/size", selection circle); new PlainList (LIST mode: 64dp rows, 44dp thumb, subtitle, chevron on folders, inset hairlines). Columns view still uses old CompactList (TODO Samsung Miller look).
- [x] Tab strip always shown on width>=600dp so the "+" new-tab button is visible.
- [x] Home honours LIST/DETAILS (list rows) else grid.
- TODO next: build check, Miller columns, gallery, centred title/pill breadcrumb, selection pill, Settings, dialogs, context menu (see DESIGN_NOTES batch 2), pinch zoom, dual-pane, viewer swipe.

## Build 4 feedback (2026-10-30 14:48) - build GREEN, Views visible
- User: Home only had Icons+List; Home thumbs square; Details/Columns UI too small; overall not polished like iPad/Samsung. "Absolutely beautiful; fonts, sizes, UI and UX in proportion and synergy; should flow."
- [x] Home: all non-GRID modes -> rows; thumbs crop=false.
- [x] Details: rows 54dp, 36dp thumbs, bodyLarge, wider columns, accent-coloured 44dp header. Columns: 52dp rows, 280dp parent column, chevrons.
- NEXT (polish pass): define ONE spacing/radius/type scale (Dimens.kt) and apply across Shell, Sidebar, Pane; centred title, pill breadcrumb, floating selection pill, Settings sheet, menus/dialogs, motion (animateContentSize, crossfade view switch).

## Menus/dialogs chunk (2026-10-30) - written, NOT yet built
- [x] ui/Dialogs.kt: ContextMenuHost (file/folder/empty/trash), DialogHost (Rename, NewItem, Compress, ConfirmDelete, EmptyTrash, Conflicts, Properties, BatchRename, Archive, Message), SettingsDialog (grouped cards: theme, icon size, hidden, folders first, trash, single tap, sidebar/preview/dual), ShortcutsDialog. Wired in App.kt after QuickLook.
- ROADMAP.md created: A = absolute basics (tick these first), B = iPadOS features, C = Samsung features, D = desktop extras.
- User notes: tabs strip "unnaturally placed" (redesign later: iPad-like pill tabs near top bar); Details columns resize/reorder + pinch zoom later.

## Build 6 feedback (2026-10-30 15:09) - user was likely running build 5 (no dialogs yet)
- [x] Home now loads Recent entries through loadEntries and uses the SAME ListingBody as every folder (all 4 views identical code path). HomeScreen no longer used.
- [x] Columns view: parent column only when pane >=560dp wide AND parent readable (was blank 280dp column on roots/virtual and overflowed in dual pane -> "random little icons"); width = min(280dp, 36%).
- [x] Size text padding in Columns rows.
- Still to verify on device: Rename/Settings (Dialogs.kt) - needs Build 6/7 APK.
- Build 7 compile fix: restored rememberSubtitle/SelectCircle (accidentally cut), captured maxWidth. Rename 'not possible' on build 6: need exact symptom.

## Build 7 feedback (2026-10-31 00:16): build green; Home views OK; Columns OK
- [x] Rename/Compress now in context menu for real files in category/virtual views (only Trash excluded).
- [x] Rename/New name box: popover near top, name selected without extension, keyboard auto-opens, Enter confirms.
- [x] Back/Up no longer auto-select the folder you came from.
- TODO: true inline rename (editing in the row, iPad style); tabs placement; dual pane re-test.

## UX SPEC (2026-10-31) - READ UX_SPEC.md BEFORE ANY UI WORK
- User corrections: Samsung keeps VIEWS in the 3-dot menu and SORT in a strip above the files (key + direction arrow). Needs a real Move (destination sheet). Views must each have a purpose (iPad List = tree rows with chevrons that expand folders inline). Dual pane postponed (two app windows work). Priority: UI polish + well-reasoned UX.
- Build order in UX_SPEC.md section 5 (tokens -> top bar/path pill/sort strip -> views -> selection+Move sheet -> inline rename -> tabs/sidebar -> settings -> viewers -> pinch).

## Design bible (Docs artifact) - SAVED STATE 2026-10-31
Doc: https://claude.ai/artifact/R1hfYTY1DrbC69iVa2CCei  (project id c2746363-e201-47e4-a6c8-0c9d3f9542ff, body node 17b7a002-4d2d, session prefix mjf5xw1grbw)
Decision: Samsung My Files is the DEFAULT skeleton; iPad Files features grafted inside Samsung places.
Filled: s1 (two apps compared), s2 (Samsung keep), s3 (iPad graft), s4 (merge table), s5 (screens by window size), s6 (menus exactly).
STILL PENDING blocks (fill one per update, replace pending id with "## N. heading" + markdown; ids are mjf5xw1grbw.285 .. .290):
 s7 .285 Views/sorting/Details tree | s8 .286 Tabs (single + circle -> pill tabs, phone tab switcher) | s9 .287 Touch/mouse/keyboard
 s10 .288 Feature inventory + phases | s11 .289 Android limits/open questions | s12 .290 Sources
Then: user says "go" -> build per UX_SPEC.md order (tokens, top bar/path pill/sort strip, views, selection pill + Move sheet, inline rename, tabs, settings, viewers).

## Design bible - ALL 12 SECTIONS FILLED (2026-10-31)
Doc: https://claude.ai/artifact/R1hfYTY1DrbC69iVa2CCei. Awaiting user review / "go". Next: build per UX_SPEC.md order, phases in doc section 10.

## Build 9 (Phase 1-2 started, 2026-10-31)
Added ui/Dimens.kt (tokens), ui/PathPill.kt (PathPill + SortStrip). Shell.kt: real folders show PathPill instead of title dropdown; ⋮ view menu no longer has sort (strip owns it). Pane.kt: SortStrip above ListingBody.
TODO next: long-press crumb = sibling menu; "All" filter on strip; centred title+subtitle on Home/virtual; then Phase 3 views (Details tree, resizable columns), Phase 4 selection pill + Move sheet.

## Build 10 (UI consistency pass, 2026-10-31) - user feedback on Build 9
User: top-bar pills inconsistent (3 styles/heights), selection only tinted (wants check circle), sort menu missing options, Folders first still in view menu; "fix whole app, UI first".
Done: Modifier.barPill() (48dp, surface fill, hairline border) used by PillGroup, PathPill, search, path editor; select circles in Details + Columns lists; sort strip menu = keys + asc/desc + Folders first (removed from view menu); pill tab chips + single circled +; sidebar: coloured category icons, 48dp rows, storage card "used / total".
NOT yet: real Home (recent strip, category buttons, storage cards), Details tree/resizable columns, selection pill + Move sheet, inline rename, centred titles, viewers.

## Build 11 (layered overhaul, 2026-10-31)
Layers: canvas (background) > floating rounded cards (sidebar 264dp, each pane's listing, preview) with 12dp gaps; tab strip + top bar sit on canvas. Menus: all DropdownMenus rounded 20dp + surfaceContainerHigh; theme Shapes 12/16/20/24/28. Hairline row dividers (rowDivider) in Details + Columns lists. Close (X) right-aligned in selection bar.
Ideas pending: zebra rows option (macOS), real Home, Details tree/resizable cols, selection pill + Move sheet, inline rename, centred titles.

## Build 12 (2026-10-31): scroll perf + Home + selection pill + Move/Copy sheet
Perf: EntryBox no longer writes state on every scroll frame (coordsRef array, not mutableState) - was recomposing every visible row each frame; folder-count SubtitleCache; contentType on lazy lists; Coil rgb565 + disk cache.
UI: ui/Home.kt HomeTop (round category buttons, storage cards, pinned chips, "Recent files"); ui/Selection.kt SelectionPill (Move/Copy/Share/Delete/More floating bottom pill, all sizes) + DestinationSheet; SelectionBar = All circle, "N selected" + size, X on right. vm.transferSelectionTo(dest, move).
Remaining for "finished UI": inline rename, Details tree + resizable/reorderable columns, centred header titles, Settings screen as grouped cards, viewers, long-press crumb sibling menu, "All" filter on strip.

## Build 13 (2026-10-31): de-duplicate Home/sidebar, Samsung Recent files
User: Home repeated sidebar content; wanted Samsung/iPad polish. Done: Home = "Recent files" page (PageTitle big centred title, HomeChips filter pill All/Images/Videos/Audio/Documents/Other via vm.homeFilter, date group headers Today/Yesterday... with dotted rule in PlainList); all virtual pages use PageTitle (no sort strip); top bar shows no title on virtual pages; sidebar = Samsung layout (Recent files, dotted dividers, outlined coloured category icons, APK text, expandable 2-line Internal storage with top-level folder tree, pinned (minus Download/Documents), Trash, Analyze storage); neutral selected highlight; tab strip only when 2+ tabs, single-tab "+" lives in top-bar right pill.
Next: inline rename, Details tree + resizable columns, Settings grouped cards, viewers, long-press crumb menu.

## Build 14 (2026-10-31): Samsung columns, tree lists, collapsing titles, search icon
Columns: one column per ancestor (320dp each), horizontal scroll, last column = open folder, auto-scrolls to the end. List + Details: chevron expands folders inline (ui/Tree.kt rememberTree; vm.treeEntries lets expanded rows be selected/copied/deleted). Page titles collapse while scrolling (CollapsingTitle + nested scroll in Home.kt). Search = icon in right pill that expands over the path pill. Sidebar footer (gear + keyboard) removed; Settings/Shortcuts live only in the top-right menu.

## Build 15 (2026-10-31): feel + gestures
Tab strip ALWAYS visible (pill per tab + circled + right after the last pill; single tab not closable); + removed from top bar. Up button removed (Back/Forward only; Alt+Up still works). Touch: tap only opens (no selection), LONG-PRESS selects (haptic) - context menu on touch removed (More in pill instead); mouse unchanged. AMOLED dark: bg #000, card #0F0F11, pills #19191B. Page titles float on canvas above the card; sidebar on canvas (no card). Animations: sidebar expand/shrink, drawer slide+scrim, search/path crossfade, tab pills grow-in, selection pill slide-up, list animateItem. Samsung "All v" kind filter (vm.setKindFilter, tab.kindFilter) left of the sort strip.
Perf note for user: debug APK is JIT-only (first scroll janky); a release build (R8, debug-signed) would be smoother.

## Build 16 TODO (user feedback after Build 15)
1 Samsung search screen (Filters: current-folder-only toggle; recent searches chips+Clear all; bottom floating search pill with scope chip) - search scope bug: only searched current folder.
2 System back retraces history, then goes to Recent files, then exits.
3 Columns view must not auto-open preview pane.
4 Smooth transitions: folder nav slide/fade, selection (row colour + circle expand), top bar crossfade to selection bar, view switch crossfade.
5 Samsung polish: filled pills no border, bigger type, tinted rounded file tiles, no divider under sort strip.
Then continue design-bible feature list one by one: inline rename, Settings cards, viewers, Edit home, tags...

## Build 16 (done, awaiting compile)
- Samsung search screen (ui/SearchScreen.kt): Filters (current folder only / hidden), recent searches chips, bottom floating search pill with scope chip.
- Back retraces: quickLook > search > selection > drawer > history > Home > exit.
- Columns no longer auto-opens preview.
- Transitions: nav slide/fade, row colour anim, select-circle expand, top bar crossfade, view crossfade.
- Polish: filled borderless pills, barHeight 52, larger type, tinted file tiles, no divider under sort strip.

## REBUILD (started 2026-11-01) — see REBUILD.md
Decision: keep engine (core/, data/, state/) — it works. Rewrite UI layer as package app.dexfiles.ui2 stage by stage; old ui/ stays compiling until MainActivity switches to ui2 (Stage 3). Design system first.
- Fix build 16c: listing cache (no stale folder flash on sidebar nav), touch long-press+drag DnD, ancestor-column selection in Columns. Samsung "Select folder" move dialog screenshot received: centered dialog, title + search/new-folder/sort, storage chip, breadcrumb pill, sort row, list, bottom Cancel / Move here -> match in rebuild stage 3.
- Build 17: inline search (scope chip + recents menu in bar), views = List (auto wide columns) / Grid / Gallery / Columns, Samsung-style Select folder dialog, listing cache + sidebar preload.
- Build 18: Gallery reworked (masonry, real aspect, names, folder strip), pinch-zoom for Grid/Gallery, "digital blink" nav transition (alpha only, waits for load), DETAILS normalised to LIST everywhere, folder customisation (colour + glyph; ui/FolderStyles.kt, vm.folderStyles) via context menu / selection More menu.
- Build 19: photo viewer (ui/Viewer.kt), gallery fixes (probe-all-before-show, folder cards, non-media tiles), start on Recents, softer blink, progress line only if slow.
- Build 20: visual rework phase 1: Theme.kt now derives ALL colours from ui2/design Palette (+LocalPalette provided), spring press on IconBtn + selection actions, dock-style selection pill (overlay surface, deeper shadow), tighter title tracking. Next: inline rename, Settings cards, video/audio.
- Build 21: gallery folders in equal-width aligned grid.

## UNIFORMITY RULE (user, 2026-11-01) — applies to every build
Views, gestures, menus and actions must work identically everywhere: categories (Images, Documents, Recent...) and real folders alike. No "works only in some places". Known gap: wide table (List+columns) only shows in real folders (`!tab.isVirtual` in Pane.kt view routing) -> make it work in all places (virtual pages get a Location column instead of Type). Audit: Columns/Gallery/Grid/selection/drag/context menu/sort strip/kind filter on virtual pages.
- Build 22 (uniformity): wide table + sort strip + kind filter now on EVERY page incl. categories/Recent; virtual pages show Location instead of Type; Home-only chips removed (strip filter replaces them).
