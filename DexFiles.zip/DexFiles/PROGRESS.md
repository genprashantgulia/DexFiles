# DexFiles progress (read this first, don't re-explore)

## Done
- Full app written: Kotlin + Compose, ~5,700 lines (core logic, ViewModel, UI, drag-and-drop, preview, sidebar, tabs, dual pane, trash, search, zip, batch rename).
- Core logic (`app/src/main/java/app/dexfiles/core/`) is plain Kotlin: compiled and **26/26 unit tests pass** (checked 2026-10-28).
- GitHub Actions workflow builds an APK (`.github/workflows/build.yml`).

## Not verified
- The Android/UI layer (state/, ui/, data/, MainActivity) has NEVER been compiled; no Android SDK in the sandbox.

## Next chunks (do ONE per session, tick when done)
- [x] 1. Uploaded zip to GitHub; build runs via workflow that unzips DexFiles.zip.
- [x] 2a. First build error: MainActivity needed DexFilesApp + PermissionScreen -> written in ui/App.kt (2026-10-28).
- [x] 2b-1. JVM name clash on 9 VM setters fixed with @JvmName (2026-10-28).
- [x] 2b. Build is GREEN (2026-10-28), APK produced.
- [ ] 2c. STILL MISSING UI: dialogs host (DialogState: Rename, NewItem, ConfirmDelete, Conflicts, Properties, BatchRenameDlg, Compress, Archive, Message, EmptyTrash, Settings, Shortcuts) and right-click context menu (vm.menu / CtxMenu). VM already sets them; nothing draws them yet.
- [ ] 3. Install APK on DeX, grant "All files access", report what breaks.
- [ ] 4. Fix runtime bugs found in step 3.
- [ ] 5. Polish: shortcuts, drag-and-drop feel, themes.

## Notes from first install (2026-10-28)
- APK installs and opens; permission screen works. After granting access the app FORCE-CLOSES on the file view and on every icon tap.
- Added CrashLog (DexApp.kt) + CrashScreen (ui/App.kt): next launch shows the stack trace with a Copy button. NEXT: get that trace, fix crash.
- User feedback: UI feels too "desktop only"; wants a real blend of touch + keyboard/mouse (bigger touch targets, long-press menus, swipe, adaptive layout). Do after crash + dialogs.
- [x] CRASH 1 FIXED (2026-10-28): "ExplorerViewModel not provided" -> DexFilesApp now provides LocalVm + LocalHostActivity (ui/App.kt). Waiting on user to retest; any new crash shows in the on-screen crash report.

## Build 3 feedback (2026-10-28) - APP WORKS, browsing OK
- [x] Dark-mode invisible text: DexTheme now wraps content in Surface (Theme.kt).
- Design problems to fix, ONE CHUNK PER SESSION, in this order:
  - [x] D1 (done by an earlier session that hit the usage limit; reviewed, all referenced symbols exist; needs a build to confirm).  Remove duplication: Home screen repeats sidebar (Favorites, Library, Storage). Decide: sidebar = places only; Home = recents/storage summary, or drop Home tab.
  - [ ] D2. Adaptive layout: touch-first on narrow/phone (bottom bar, bigger targets, long-press select + menus), desktop-first with mouse/keyboard on DeX (compact rows, hover, right-click). Detect by window width + pointer presence.
  - [ ] D3. Pinch-to-zoom for grid/thumbnail size (vm.gridSize exists, 72..240) + Ctrl+scroll on mouse.
  - [ ] D4. Declutter toolbar (too many icons: keep few, rest in a menu; bigger touch targets).
  - [ ] D5. Draw the missing dialogs + context menu (2c above).
  - [ ] D6. Test deeper: copy/paste, delete/trash, rename, zip, search, dual pane, drag-drop.

## iPad-style redesign (requested 2026-10-29) - one chunk per session
- [x] U1. Theme.kt: fixed iPad-like palettes (light #F2F2F7 canvas/white cards, dark pure black/charcoal), no wallpaper dynamic colour, larger type. FileIcons.kt: drawn yellow FolderIcon (replaces flat Material folder). Needs build + visual check.
- [ ] U2. Grid/icon view like iPad: spacious tiles, whole-image thumbnails (ContentScale.Fit), name + date/size below, selection circle, folder item counts.
- [ ] U3. All view types: Icons (grid), List, Details/columns, Gallery (large thumbs), Column view (Mac-style) -> view picker menu. Currently: Details, Grid, Compact list (check vm.ViewMode).
- [ ] U4. Toolbar/title bar iPad style: back/forward, breadcrumb title, rounded pill buttons, tabs as top pills.
- [ ] U5. Pinch-to-zoom + Ctrl+scroll tile size; size slider.
- [ ] U6. Menus/dialogs (2c): context menu, rename, new folder, delete confirm, properties, Settings.
- [ ] U7. Bugs: dual pane second pane not interactive; image viewer swipe; half-hidden arrows in full-screen viewer.

## Structural redesign (user feedback 2026-10-29 14:20: "rudimentary, scaled-down desktop, not native on tablet")
- [x] S1. Adaptive shell wired (2026-10-29): ui/Shell.kt (written by earlier session, reviewed, imports checked) = AdaptiveTopBar (one row, pill groups, 44dp targets, title+item count, path editor, search pill, view/sort menu, more menu), SelectionBar, BottomActionBar (phone). ui/App.kt now uses windowClassFor(width): Compact <600 (drawer sidebar, bottom action bar, no dual/preview), Medium <840 (drawer sidebar), Expanded (permanent sidebar, preview, dual). Pane.kt hides tab strip when only 1 tab. TopBar.kt is now unused (can delete later). NEEDS BUILD + visual check.
- [ ] S2. Folder icon redesign (user: "not aesthetic"): prototype in SVG/PNG here with Chromium to SEE it, then port to Canvas (ui/FileIcons.kt FolderIcon).
- [ ] S3. Grid tiles iPad-style: thumbnails in ORIGINAL aspect ratio (Fit, not square crop), spacing, name + date/size below, selection circle.
- [ ] S4. Diagnose "view modes work randomly in some folders" (read Pane.kt ListingBody / vm.setViewMode / virtual folders).
- [ ] S5. Tabs look (iPad pill tabs), pinch-zoom, menus/dialogs (2c), bugs (dual pane focus, viewer swipe, arrows).
