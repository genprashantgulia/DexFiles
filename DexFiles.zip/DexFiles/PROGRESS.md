# DexFiles progress (read this first, don't re-explore)

## Done
- Full app written: Kotlin + Compose, ~5,700 lines (core logic, ViewModel, UI, drag-and-drop, preview, sidebar, tabs, dual pane, trash, search, zip, batch rename).
- Core logic (`app/src/main/java/app/dexfiles/core/`) is plain Kotlin: compiled and **26/26 unit tests pass** (checked 2026-10-28).
- GitHub Actions workflow builds an APK (`.github/workflows/build.yml`).

## Not verified
- The Android/UI layer (state/, ui/, data/, MainActivity) has NEVER been compiled; no Android SDK in the sandbox.

## Next chunks (do ONE per session, tick when done)
- [x] 1. Uploaded zip to GitHub; build runs via workflow that unzips DexFiles.zip.
- [x] 2a. First build error: MainActivity needed DexFilesApp + PermissionScreen -> written in ui/App.kt (2026-10-28).
- [x] 2b-1. JVM name clash on 9 VM setters fixed with @JvmName (2026-10-28).
- [x] 2b. Build is GREEN (2026-10-28), APK produced.
- [ ] 2c. STILL MISSING UI: dialogs host (DialogState: Rename, NewItem, ConfirmDelete, Conflicts, Properties, BatchRenameDlg, Compress, Archive, Message, EmptyTrash, Settings, Shortcuts) and right-click context menu (vm.menu / CtxMenu). VM already sets them; nothing draws them yet.
- [ ] 3. Install APK on DeX, grant "All files access", report what breaks.
- [ ] 4. Fix runtime bugs found in step 3.
- [ ] 5. Polish: shortcuts, drag-and-drop feel, themes.

## Notes from first install (2026-10-28)
- APK installs and opens; permission screen works. After granting access the app FORCE-CLOSES on the file view and on every icon tap.
- Added CrashLog (DexApp.kt) + CrashScreen (ui/App.kt): next launch shows the stack trace with a Copy button. NEXT: get that trace, fix crash.
- User feedback: UI feels too "desktop only"; wants a real blend of touch + keyboard/mouse (bigger touch targets, long-press menus, swipe, adaptive layout). Do after crash + dialogs.
- [x] CRASH 1 FIXED (2026-10-28): "ExplorerViewModel not provided" -> DexFilesApp now provides LocalVm + LocalHostActivity (ui/App.kt). Waiting on user to retest; any new crash shows in the on-screen crash report.

## Build 3 feedback (2026-10-28) - APP WORKS, browsing OK
- [x] Dark-mode invisible text: DexTheme now wraps content in Surface (Theme.kt).
- Design problems to fix, ONE CHUNK PER SESSION, in this order:
  - [x] D1 (done by an earlier session that hit the usage limit; reviewed, all referenced symbols exist; needs a build to confirm).  Remove duplication: Home screen repeats sidebar (Favorites, Library, Storage). Decide: sidebar = places only; Home = recents/storage summary, or drop Home tab.
  - [ ] D2. Adaptive layout: touch-first on narrow/phone (bottom bar, bigger targets, long-press select + menus), desktop-first with mouse/keyboard on DeX (compact rows, hover, right-click). Detect by window width + pointer presence.
  - [ ] D3. Pinch-to-zoom for grid/thumbnail size (vm.gridSize exists, 72..240) + Ctrl+scroll on mouse.
  - [ ] D4. Declutter toolbar (too many icons: keep few, rest in a menu; bigger touch targets).
  - [ ] D5. Draw the missing dialogs + context menu (2c above).
  - [ ] D6. Test deeper: copy/paste, delete/trash, rename, zip, search, dual pane, drag-drop.

## iPad-style redesign (requested 2026-10-29) - one chunk per session
- [x] U1. Theme.kt: fixed iPad-like palettes (light #F2F2F7 canvas/white cards, dark pure black/charcoal), no wallpaper dynamic colour, larger type. FileIcons.kt: drawn yellow FolderIcon (replaces flat Material folder). Needs build + visual check.
- [ ] U2. Grid/icon view like iPad: spacious tiles, whole-image thumbnails (ContentScale.Fit), name + date/size below, selection circle, folder item counts.
- [ ] U3. All view types: Icons (grid), List, Details/columns, Gallery (large thumbs), Column view (Mac-style) -> view picker menu. Currently: Details, Grid, Compact list (check vm.ViewMode).
- [ ] U4. Toolbar/title bar iPad style: back/forward, breadcrumb title, rounded pill buttons, tabs as top pills.
- [ ] U5. Pinch-to-zoom + Ctrl+scroll tile size; size slider.
- [ ] U6. Menus/dialogs (2c): context menu, rename, new folder, delete confirm, properties, Settings.
- [ ] U7. Bugs: dual pane second pane not interactive; image viewer swipe; half-hidden arrows in full-screen viewer.

## Structural redesign (user feedback 2026-10-29 14:20: "rudimentary, scaled-down desktop, not native on tablet")
- [x] S1. Adaptive shell wired (2026-10-29): ui/Shell.kt (written by earlier session, reviewed, imports checked) = AdaptiveTopBar (one row, pill groups, 44dp targets, title+item count, path editor, search pill, view/sort menu, more menu), SelectionBar, BottomActionBar (phone). ui/App.kt now uses windowClassFor(width): Compact <600 (drawer sidebar, bottom action bar, no dual/preview), Medium <840 (drawer sidebar), Expanded (permanent sidebar, preview, dual). Pane.kt hides tab strip when only 1 tab. TopBar.kt is now unused (can delete later). NEEDS BUILD + visual check.
- [x] S2. Folder icon redesigned (2026-10-30): prototyped as SVG, rendered with Chromium at 200/110/64/32px on light/dark, then ported to Canvas in ui/FileIcons.kt FolderIcon (amber back+tab, cream paper strip, yellow->gold front, gloss). NEEDS BUILD + user opinion. Later: per-folder glyph overlay (camera for DCIM, arrow for Download).
- [ ] S3. Grid tiles iPad-style: thumbnails in ORIGINAL aspect ratio (Fit, not square crop), spacing, name + date/size below, selection circle.
- [ ] S4. Diagnose "view modes work randomly in some folders" (read Pane.kt ListingBody / vm.setViewMode / virtual folders).
- [ ] S5. Tabs look (iPad pill tabs), pinch-zoom, menus/dialogs (2c), bugs (dual pane focus, viewer swipe, arrows).
- [x] FONT (2026-10-29): Inter (OFL) bundled in res/font + licence in assets/licenses; Theme.kt applies it to all text styles. Samsung's own font is proprietary and can't be bundled; idea for later: Settings option "Use system font".
- User asked (14:53) for screenshots-based design: waiting for One UI 9 My Files (sidebar, grid, list, selection) and iPad Files (icons, list, tab bar, sidebar, long-press menu) screenshots before the "Views" chunk. Video links can't be watched.
- [x] One UI 9 screenshots received (2026-10-29) and distilled into DESIGN_NOTES.md (READ IT before any UI work). iPad screenshots still pending.
- NEXT chunk "Views": folder icon, real-aspect thumbnails (Fit), iPad-style Icons + List views (no column headers), Home must respect view mode, visible "new tab" button.

## Working agreement (user 2026-10-30)
- Free plan: usage limit resets mid-task. SAVE continuously: update PROGRESS.md after every chunk, ship a zip after every chunk, record durable decisions in memory. Project lives at /home/claude/DexFiles; if missing, unzip the latest DexFiles.zip attachment and copy PROGRESS.md + DESIGN_NOTES.md back in.

## Views chunk (2026-10-30) - written, NOT yet built
- [x] FileThumb: crop=false keeps real aspect ratio, icon hidden once image loaded.
- [x] Pane.kt: GridView = iPad-style (bigger cells, bold name 2 lines, "date · N items/size", selection circle); new PlainList (LIST mode: 64dp rows, 44dp thumb, subtitle, chevron on folders, inset hairlines). Columns view still uses old CompactList (TODO Samsung Miller look).
- [x] Tab strip always shown on width>=600dp so the "+" new-tab button is visible.
- [x] Home honours LIST/DETAILS (list rows) else grid.
- TODO next: build check, Miller columns, gallery, centred title/pill breadcrumb, selection pill, Settings, dialogs, context menu (see DESIGN_NOTES batch 2), pinch zoom, dual-pane, viewer swipe.

## Build 4 feedback (2026-10-30 14:48) - build GREEN, Views visible
- User: Home only had Icons+List; Home thumbs square; Details/Columns UI too small; overall not polished like iPad/Samsung. "Absolutely beautiful; fonts, sizes, UI and UX in proportion and synergy; should flow."
- [x] Home: all non-GRID modes -> rows; thumbs crop=false.
- [x] Details: rows 54dp, 36dp thumbs, bodyLarge, wider columns, accent-coloured 44dp header. Columns: 52dp rows, 280dp parent column, chevrons.
- NEXT (polish pass): define ONE spacing/radius/type scale (Dimens.kt) and apply across Shell, Sidebar, Pane; centred title, pill breadcrumb, floating selection pill, Settings sheet, menus/dialogs, motion (animateContentSize, crossfade view switch).

## Menus/dialogs chunk (2026-10-30) - written, NOT yet built
- [x] ui/Dialogs.kt: ContextMenuHost (file/folder/empty/trash), DialogHost (Rename, NewItem, Compress, ConfirmDelete, EmptyTrash, Conflicts, Properties, BatchRename, Archive, Message), SettingsDialog (grouped cards: theme, icon size, hidden, folders first, trash, single tap, sidebar/preview/dual), ShortcutsDialog. Wired in App.kt after QuickLook.
- ROADMAP.md created: A = absolute basics (tick these first), B = iPadOS features, C = Samsung features, D = desktop extras.
- User notes: tabs strip "unnaturally placed" (redesign later: iPad-like pill tabs near top bar); Details columns resize/reorder + pinch zoom later.

## Build 6 feedback (2026-10-30 15:09) - user was likely running build 5 (no dialogs yet)
- [x] Home now loads Recent entries through loadEntries and uses the SAME ListingBody as every folder (all 4 views identical code path). HomeScreen no longer used.
- [x] Columns view: parent column only when pane >=560dp wide AND parent readable (was blank 280dp column on roots/virtual and overflowed in dual pane -> "random little icons"); width = min(280dp, 36%).
- [x] Size text padding in Columns rows.
- Still to verify on device: Rename/Settings (Dialogs.kt) - needs Build 6/7 APK.
- Build 7 compile fix: restored rememberSubtitle/SelectCircle (accidentally cut), captured maxWidth. Rename 'not possible' on build 6: need exact symptom.

## Build 7 feedback (2026-10-31 00:16): build green; Home views OK; Columns OK
- [x] Rename/Compress now in context menu for real files in category/virtual views (only Trash excluded).
- [x] Rename/New name box: popover near top, name selected without extension, keyboard auto-opens, Enter confirms.
- [x] Back/Up no longer auto-select the folder you came from.
- TODO: true inline rename (editing in the row, iPad style); tabs placement; dual pane re-test.

## UX SPEC (2026-10-31) - READ UX_SPEC.md BEFORE ANY UI WORK
- User corrections: Samsung keeps VIEWS in the 3-dot menu and SORT in a strip above the files (key + direction arrow). Needs a real Move (destination sheet). Views must each have a purpose (iPad List = tree rows with chevrons that expand folders inline). Dual pane postponed (two app windows work). Priority: UI polish + well-reasoned UX.
- Build order in UX_SPEC.md section 5 (tokens -> top bar/path pill/sort strip -> views -> selection+Move sheet -> inline rename -> tabs/sidebar -> settings -> viewers -> pinch).

## Design bible (Docs artifact) - SAVED STATE 2026-10-31
Doc: https://claude.ai/artifact/R1hfYTY1DrbC69iVa2CCei  (project id c2746363-e201-47e4-a6c8-0c9d3f9542ff, body node 17b7a002-4d2d, session prefix mjf5xw1grbw)
Decision: Samsung My Files is the DEFAULT skeleton; iPad Files features grafted inside Samsung places.
Filled: s1 (two apps compared), s2 (Samsung keep), s3 (iPad graft), s4 (merge table), s5 (screens by window size), s6 (menus exactly).
STILL PENDING blocks (fill one per update, replace pending id with "## N. heading" + markdown; ids are mjf5xw1grbw.285 .. .290):
 s7 .285 Views/sorting/Details tree | s8 .286 Tabs (single + circle -> pill tabs, phone tab switcher) | s9 .287 Touch/mouse/keyboard
 s10 .288 Feature inventory + phases | s11 .289 Android limits/open questions | s12 .290 Sources
Then: user says "go" -> build per UX_SPEC.md order (tokens, top bar/path pill/sort strip, views, selection pill + Move sheet, inline rename, tabs, settings, viewers).

## Design bible - ALL 12 SECTIONS FILLED (2026-10-31)
Doc: https://claude.ai/artifact/R1hfYTY1DrbC69iVa2CCei. Awaiting user review / "go". Next: build per UX_SPEC.md order, phases in doc section 10.

## Build 9 (Phase 1-2 started, 2026-10-31)
Added ui/Dimens.kt (tokens), ui/PathPill.kt (PathPill + SortStrip). Shell.kt: real folders show PathPill instead of title dropdown; ⋮ view menu no longer has sort (strip owns it). Pane.kt: SortStrip above ListingBody.
TODO next: long-press crumb = sibling menu; "All" filter on strip; centred title+subtitle on Home/virtual; then Phase 3 views (Details tree, resizable columns), Phase 4 selection pill + Move sheet.

## Build 10 (UI consistency pass, 2026-10-31) - user feedback on Build 9
User: top-bar pills inconsistent (3 styles/heights), selection only tinted (wants check circle), sort menu missing options, Folders first still in view menu; "fix whole app, UI first".
Done: Modifier.barPill() (48dp, surface fill, hairline border) used by PillGroup, PathPill, search, path editor; select circles in Details + Columns lists; sort strip menu = keys + asc/desc + Folders first (removed from view menu); pill tab chips + single circled +; sidebar: coloured category icons, 48dp rows, storage card "used / total".
NOT yet: real Home (recent strip, category buttons, storage cards), Details tree/resizable columns, selection pill + Move sheet, inline rename, centred titles, viewers.

## Build 11 (layered overhaul, 2026-10-31)
Layers: canvas (background) > floating rounded cards (sidebar 264dp, each pane's listing, preview) with 12dp gaps; tab strip + top bar sit on canvas. Menus: all DropdownMenus rounded 20dp + surfaceContainerHigh; theme Shapes 12/16/20/24/28. Hairline row dividers (rowDivider) in Details + Columns lists. Close (X) right-aligned in selection bar.
Ideas pending: zebra rows option (macOS), real Home, Details tree/resizable cols, selection pill + Move sheet, inline rename, centred titles.

## Build 12 (2026-10-31): scroll perf + Home + selection pill + Move/Copy sheet
Perf: EntryBox no longer writes state on every scroll frame (coordsRef array, not mutableState) - was recomposing every visible row each frame; folder-count SubtitleCache; contentType on lazy lists; Coil rgb565 + disk cache.
UI: ui/Home.kt HomeTop (round category buttons, storage cards, pinned chips, "Recent files"); ui/Selection.kt SelectionPill (Move/Copy/Share/Delete/More floating bottom pill, all sizes) + DestinationSheet; SelectionBar = All circle, "N selected" + size, X on right. vm.transferSelectionTo(dest, move).
Remaining for "finished UI": inline rename, Details tree + resizable/reorderable columns, centred header titles, Settings screen as grouped cards, viewers, long-press crumb sibling menu, "All" filter on strip.

## Build 13 (2026-10-31): de-duplicate Home/sidebar, Samsung Recent files
User: Home repeated sidebar content; wanted Samsung/iPad polish. Done: Home = "Recent files" page (PageTitle big centred title, HomeChips filter pill All/Images/Videos/Audio/Documents/Other via vm.homeFilter, date group headers Today/Yesterday... with dotted rule in PlainList); all virtual pages use PageTitle (no sort strip); top bar shows no title on virtual pages; sidebar = Samsung layout (Recent files, dotted dividers, outlined coloured category icons, APK text, expandable 2-line Internal storage with top-level folder tree, pinned (minus Download/Documents), Trash, Analyze storage); neutral selected highlight; tab strip only when 2+ tabs, single-tab "+" lives in top-bar right pill.
Next: inline rename, Details tree + resizable columns, Settings grouped cards, viewers, long-press crumb menu.

## Build 14 (2026-10-31): Samsung columns, tree lists, collapsing titles, search icon
Columns: one column per ancestor (320dp each), horizontal scroll, last column = open folder, auto-scrolls to the end. List + Details: chevron expands folders inline (ui/Tree.kt rememberTree; vm.treeEntries lets expanded rows be selected/copied/deleted). Page titles collapse while scrolling (CollapsingTitle + nested scroll in Home.kt). Search = icon in right pill that expands over the path pill. Sidebar footer (gear + keyboard) removed; Settings/Shortcuts live only in the top-right menu.

## Build 15 (2026-10-31): feel + gestures
Tab strip ALWAYS visible (pill per tab + circled + right after the last pill; single tab not closable); + removed from top bar. Up button removed (Back/Forward only; Alt+Up still works). Touch: tap only opens (no selection), LONG-PRESS selects (haptic) - context menu on touch removed (More in pill instead); mouse unchanged. AMOLED dark: bg #000, card #0F0F11, pills #19191B. Page titles float on canvas above the card; sidebar on canvas (no card). Animations: sidebar expand/shrink, drawer slide+scrim, search/path crossfade, tab pills grow-in, selection pill slide-up, list animateItem. Samsung "All v" kind filter (vm.setKindFilter, tab.kindFilter) left of the sort strip.
Perf note for user: debug APK is JIT-only (first scroll janky); a release build (R8, debug-signed) would be smoother.

## Build 16 TODO (user feedback after Build 15)
1 Samsung search screen (Filters: current-folder-only toggle; recent searches chips+Clear all; bottom floating search pill with scope chip) - search scope bug: only searched current folder.
2 System back retraces history, then goes to Recent files, then exits.
3 Columns view must not auto-open preview pane.
4 Smooth transitions: folder nav slide/fade, selection (row colour + circle expand), top bar crossfade to selection bar, view switch crossfade.
5 Samsung polish: filled pills no border, bigger type, tinted rounded file tiles, no divider under sort strip.
Then continue design-bible feature list one by one: inline rename, Settings cards, viewers, Edit home, tags...

## Build 16 (done, awaiting compile)
- Samsung search screen (ui/SearchScreen.kt): Filters (current folder only / hidden), recent searches chips, bottom floating search pill with scope chip.
- Back retraces: quickLook > search > selection > drawer > history > Home > exit.
- Columns no longer auto-opens preview.
- Transitions: nav slide/fade, row colour anim, select-circle expand, top bar crossfade, view crossfade.
- Polish: filled borderless pills, barHeight 52, larger type, tinted file tiles, no divider under sort strip.

## REBUILD (started 2026-11-01) — see REBUILD.md
Decision: keep engine (core/, data/, state/) — it works. Rewrite UI layer as package app.dexfiles.ui2 stage by stage; old ui/ stays compiling until MainActivity switches to ui2 (Stage 3). Design system first.
- Fix build 16c: listing cache (no stale folder flash on sidebar nav), touch long-press+drag DnD, ancestor-column selection in Columns. Samsung "Select folder" move dialog screenshot received: centered dialog, title + search/new-folder/sort, storage chip, breadcrumb pill, sort row, list, bottom Cancel / Move here -> match in rebuild stage 3.
- Build 17: inline search (scope chip + recents menu in bar), views = List (auto wide columns) / Grid / Gallery / Columns, Samsung-style Select folder dialog, listing cache + sidebar preload.
- Build 18: Gallery reworked (masonry, real aspect, names, folder strip), pinch-zoom for Grid/Gallery, "digital blink" nav transition (alpha only, waits for load), DETAILS normalised to LIST everywhere, folder customisation (colour + glyph; ui/FolderStyles.kt, vm.folderStyles) via context menu / selection More menu.
- Build 19: photo viewer (ui/Viewer.kt), gallery fixes (probe-all-before-show, folder cards, non-media tiles), start on Recents, softer blink, progress line only if slow.
- Build 20: visual rework phase 1: Theme.kt now derives ALL colours from ui2/design Palette (+LocalPalette provided), spring press on IconBtn + selection actions, dock-style selection pill (overlay surface, deeper shadow), tighter title tracking. Next: inline rename, Settings cards, video/audio.
- Build 21: gallery folders in equal-width aligned grid.

## UNIFORMITY RULE (user, 2026-11-01) — applies to every build
Views, gestures, menus and actions must work identically everywhere: categories (Images, Documents, Recent...) and real folders alike. No "works only in some places". Known gap: wide table (List+columns) only shows in real folders (`!tab.isVirtual` in Pane.kt view routing) -> make it work in all places (virtual pages get a Location column instead of Type). Audit: Columns/Gallery/Grid/selection/drag/context menu/sort strip/kind filter on virtual pages.
- Build 22 (uniformity): wide table + sort strip + kind filter now on EVERY page incl. categories/Recent; virtual pages show Location instead of Type; Home-only chips removed (strip filter replaces them).
- Build 23: columns rows show full name + date/size line; gallery name chip (no gradient bar); grid/gallery column count settles after sidebar animation; sidebar uses Motion.page easing.
- Build 24: blink on sidebar/preview toggle, search keeps per-query result cache (backspace restores instantly, 40ms start), Settings page fills width + gear in sidebar. NOTE: disk had newer EntryLines/paneFinal code than Build 23 zip.
- Build 25: pinch = grid scales under fingers from the pinch point, then commits size with soft fade; Details columns auto-size to widest value (names get the rest).
- Build 26: stepped pinch zoom (6 levels, cross-fade between old/new grid, scroll position kept, haptic tick), details columns now optional (View menu toggle, default off), Settings = floating card from gear (bottom-left) or ⋮ (top-right), search results scroll to top on each query.

## Build 27
- Repaired Pane.kt (duplicated ListingBody/TabChip from a bad splice). Added tools/check.py static checker.
- Search: matched letters highlighted in names (EntryName/highlightName); results ease in one after another (resultIn modifier).
- Page title no longer repeats the item count (sort strip keeps it).
- Inline rename in List/Grid/Gallery/Columns: vm.renaming + EntryName/RenameField (name stem selected, Enter confirms, Esc/Back cancels, blur commits); falls back to the dialog if no row shows it.
- Still to do: video/audio player, PDF thumbnails, tags, network storage.

## Build 28 (foundation pass, step 1)
- Rules.kt: single source for what is allowed where (rename works in categories/Recent/search; not Trash).
- View menu: "Details columns" switch nested under List (only while List is active).
- Debug build set non-debuggable for smoother scrolling (build.gradle.kts).
- Next steps: shared Row/Menu/Dialog/Button pieces driven by ui2 tokens; list views; grid/gallery; sidebar/topbar; menus/dialogs.

## Build 29 (foundation step 2)
- Corner radii collapsed to 5 tokens (Radius.xs/s/m/l/xl = 8/12/16/20/28) across all ui files.
- Rename: keyboard-hide cancels; cancel/unchanged clears the row highlight (vm.endRename).
- Next: spacing tokens (Space.*) in rows/bars; shared Row/Menu/Dialog pieces; then list, grid/gallery, sidebar/topbar.

## Build 30 (motion pass 1)
- Selection circle: colour fade + spring-popped tick.
- Icon grid items slide into place on sort/delete/rename (animateItem).
- Audit: menus already share one style (Radius.l, surfaceContainerHigh); dialogs inherit Shapes.extraLarge. Spacing is mostly on the 4-pt grid (odd 10/6/14/18/22 left alone on purpose).
- Ideas queue: JobStrip enter/exit, dialog scale-in, toast styling, tab open/close animation, sidebar item press states.

## Build 31
- Fixed grid/gallery double-shift when sidebar/preview toggles: settledWidth re-flows immediately for big width jumps (hidden by the dim), debounces small drag changes; grid tiles only glide (animateItem) when column count is stable.
- JobStrip grows/shrinks smoothly.

## Design direction (2026-11-04)
- Mockup approved as the target look (AMOLED black, amber accent, raised rounded content card, pill controls). Folder icon options board pending a choice.
- docs/MASTER_PROMPT.md holds the user's master guideline prompt; check roadmap against it (tags, network/cloud, smart folders, analyzer cleaners, 7z/RAR, theme engine, shortcut cheatsheet, pointer icons are still missing).

## Design round 2 (in progress, 2026-11-05)
- Mockup canvas (claude.ai artifact VoKiT729JTXdv7G57noBmF) boards done: 1-5, Header (now with Forward + search mode), Sidebar, 6 Search.
- To do: Menus (context/view/sort/more), Dialogs, Settings card, States (empty/loading/error/no results), Preview+drag+toast, Motion rulebook + live demos, then DESIGN_SPEC.md.
- Motion basis (from knowledge; research pages failed to load): M3 Expressive springs spatial fast/default/slow = stiffness 1400/700/300 damping 0.9; effects fast/default/slow = 3800/1600/800 damping 1.0; Apple fluid: interruptible, momentum projection, rubber band c=0.55, decel rate 0.998.
- Round 2 boards done (all published): 6 Search, 7 Menus, 8 Dialogs+inline rename, 9 Settings card, 10 Empty/loading/error, 11 Preview/drag/toast/progress. Remaining: Motion rulebook + live demos board, DESIGN_SPEC.md.
- Design round 2 COMPLETE (12 boards). Exact values in docs/DESIGN_SPEC.md. Next: build step 1 (Header w/ Back+Forward, Sidebar, folder papers icon in 2 states, side-panel rebuild).
- 2026-11-05 feedback applied to mockup: ⋮ menu lost Trash/Analyze; View menu shows Simple|Detailed segmented beside List (board 13 has 4 options); Settings reorganised with Appearance sub-page and Default + placeholder slots.

## Build 32a (first redesign build, checkpoint)
- Palette switched to approved amber/AMOLED (Palette.kt dark+light, Theme.kt outline/hi). Whole app recolours (blue -> amber).
- FolderIcon: papers-peeking style, two states (hasFiles animates; empty = no papers, 50%); background empty check cached.
- Top bar: separate 44dp round buttons (RoundBtn), Back + Forward adjacent, New-folder button removed from bar (in More menu), View menu has Simple|Detailed beside List.
- Still to do for 32b: sidebar restyle, tab row restyle, side-panel open/close rebuild (lay-out-once), selection circle/tint to amber spec check.

## Build 32b
- Side panel / preview toggle rebuilt: laid out once, dim-then-flip blink, no ghost gap (needs user verification in Icons/Gallery).
- Sidebar: amber pill items, plain 12sp semibold captions, volume cards radius 16.
- Tabs: 44 row, pill tabs 34 high (active = raised neutral), filled + circle 34.
- Not yet: path pill, text-size stepped slider, Settings card rebuild.

## Build 33
- Zoom cross-fade removed: tiles glide (spring) to new spots; sidebar/preview toggle no longer dims/blinks (pane laid out at final width, revealed by clip).
- Each location gets fresh scroll state (key by path) -> categories open at the top; placement animation off for 700 ms after entering a place so cached->fresh listing swap doesn't shuffle.
- View menu: Show hidden and Simple|Detailed keep it open; choosing a view closes it.
- Build 33c: softer feel: tile glide spring 320/0.8, sidebar spatialSlow(300), new place rises 18dp+fades on spring 240/0.8 (user: felt stiff like a mechanical switch).
- Build 33d: heavier/less bouncy: glide 260/0.92, enter 200/0.93 rise 24dp.
- Build 33e: springs start abruptly -> moved big moves (tile glide 440, sidebar 420, new place 480) to ease-in-out Motion.glide (cubic 0.4,0,0.1,1).

## Build 34
- Sidebar: slide starts frame 1; page re-flow delayed 90 ms (hitch no longer steals the start).
- Pinch: content follows fingers immediately (resisted scale 0.88-1.14) and springs home on step/release; no threshold dead zone.
- List rows 68 high with 48 tile; sort key + arrow as pills (path pill already matched mock).

## Build 35 (look overhaul pass)
- Typography re-based on mock: body 16/500, 14, 13; labels 14/500, 12/600; letterSpacing 0 (Material tracking removed).
- DexMenu.kt: same-package DropdownMenu/DropdownMenuItem/AlertDialog wrappers -> every menu is #26262C ring, radius 20, 44dp rows radius 12, hover fill; dialogs #1E1E22 radius 28.
- Settings: single floating card (radius 32) with main list + Appearance/Browsing/Files pages sliding inside; SteppedSlider (text size 12-20 live via Density fontScale, icon size levels), placeholders Theme/Colour/Style/Font.
- Still to do: selection header (tick + N selected + close right), dialogs content layout, search screen restyle, ScreenStates, tabular digits.

## Build 36
- Pinch: one level per deliberate pinch (threshold 1.32/0.76 + 340 ms pause); at min/max size only a tiny resisted wobble, no flicker (zoomGrid returns Boolean, canZoomGrid).
- Name dialog restyled (#1E1E22, amber focus, pill buttons); tabular digits (tnum) on 13sp meta text.

## Build 37 IN PROGRESS: exact-mock pass (user: "uncanny valley, make it exactly like the mock")
Mock facts (from project/*.dc.html): tab row 44 at VERY TOP full width (tabs 34 high, no icon, text 13, x on each, + circle 34 with 1dp border) THEN top bar 56 (btn 44, gap 10, path pill 44 h, parent 15 dim > current 600 white, no pencil);
sidebar 264 = pad 12 left/8 right, items 46 pill 15/500, CAPS captions (CATEGORIES/STORAGE) 12/600, Internal storage + sub-items (42, indent 44), Trash/Analyze/Settings at bottom;
card margin 0 12 12 0 r28 with title INSIDE (34/600, pad 26/14), chips (Recent only), sort strip = "N items" left 13 dim, "Date modified ↓" right 13/600 (no pills, no All dropdown);
list row 68: pad 0 16, gap 16, tile 48 r12 with EXT text (PNG/PDF..), name 16/500, date 13 dim left + size 13/600 right, 1px #1C1C20 rule under text column; select: circle 24 gap 14, row tint r18;
icons: 6 cols gap 12, folder 104 + name 13/600 + count 12 dim, photo thumb 148 r16 crop, name 13/500, date 12 dim; select header: 26 circle amber + "N selected" 20/600 + X right.
Done so far: pinch softened (160ms/1.2/0.83), Sidebar.kt rewritten. TODO: App.kt (tabs on top, sidebar width 252 no spacer, drawer padding), TabsRow restyle, bar/path pill/select header, PaneView card+title+chips, SortStrip, list rows, ext tiles, icon grid, selection pill.
- Build 37 progress: tabs on top, bar 56, select header, path pill, card+title+chips+sort strip, selection pill done. TODO: list rows, ext tiles, icon grid, menus rows 46 touch.
- Build 37 done (uncompiled): list rows/ext tiles/icon grid/selection circle/select pill per mock; default icon size 148.

## Build 38 TODO (user feedback 11-07): 1 sidebar: no pinned bottom items (put in scroll), 2 coloured category icons back (Downloads teal, Documents orange, Images pink, Audio indigo, Videos purple, Install green), 3 sidebar folders use FolderIcon empty/filled, 4 real expandable tree that auto-expands to current folder, 5 motion: chips sliding indicator + content glide on filter, search expands leftward from button (not fade), 6 gap between adjacent selected rows, 7 selection pill: outlined icons, full-pill container + concentric pill More chip, menu icons outlined 20, rows 46

## Build 38 (uncompiled)
- Sidebar: all scrolls (no pinned items; Trash/Analyze/Settings after storage), coloured outlined category icons incl. Downloads, real folder tree following current folder with folder icons (filled/empty).
- Search expands leftward from button; Recent chips: sliding amber indicator + content glide on filter change.
- Selection pill: concentric radii (38 outer / 8 pad / 30 inner), outlined icons. List rows get 1dp vertical gap between selected rows.
- Build 38b: fixed Shell.kt fillMaxSize import; dates 'd MMM, h:mm am' (year only if not this year); category pages show title pill in top bar.
- Build 39: search per mock (scope chip + grey clear circle right, 48 pill, back replaces menu), DexIcons stroke family (ui2/design/DexIcons.kt) applied to bar/tabs/menus basics, Settings card rewritten per mock, tab padding centred, list filenames weight 400.
- Build 39b: fix FolderStyles MenuBook + duplicate DexIcons import; grid thumbs real aspect (Fit); light palette reworked (neutral grey canvas, white cards); gallery clean (no labels, hairline ring, wider margins); IME padding + bringIntoView for rename.
- Build 39c: ime import fix; gallery gap 14 radius 20 per user's reference (masonry, no overlays).

## Build 40 TODO (user 11-07 evening)
1 views = List / Icons / Columns; Icons gets "Thumbnails | Gallery" toggle (like Simple|Detailed). 2 icons: real-ratio thumbs, no grey card. 3 icon-view text: name->details tight, bigger gap to next item; folders show only count (no date). 4 columns view: same row style both columns, drop chevrons. 5 rename: hide selection pill while renaming, reveal whole tile with margin. 6 Samsung/system font option (Settings > Appearance > Font). 7 sort strip alignment with content edges. 8 settings: mock-style main page (switches inline), version footer small/dim.
- Build 40 done (uncompiled): 3 views + Thumbnails|Gallery toggle, real-ratio icon thumbs, tighter text, folders count only, columns unified w/o chevrons, rename hides pill + reveals tile, System font option, settings main page inline switches + dim footer.
- Build 41: collapsing title restored (nestedScroll + Modifier.collapsing), columns detailed rows for all columns (no arrows), icon thumbs fit via aspectRatio, rename reveal in EntryBox (whole tile, 4dp), full mock icon set in DexIcons (sidebar, pill, menus) swapped globally.
- Build 41b: fixed mangled icon reference in Dialogs.kt, isImeVisible import in Pane.kt.
- Build 42: icon rail sidebar (68dp) instead of hiding; tree Samsung-style (grey outline folder icons, chevron right only if subfolders, no auto-open, highlight deepest visible ancestor); grid file names centred, pictures bottom-aligned in slot; default font = system (tnum removed; pref fontModeV2).
- Build 42b: Theme comma fix; column rows 1dp gap; settings rows uniform icon tiles (no special Appearance card).
- Build 43: Settings removed from sidebar+rail, gear icon, tree indent 16+18*depth, unified selectRing (amber ring+wash on visual, no tile bg) for thumbnails/gallery/masonry, Columns rows 64dp/46dp square thumb/15+12sp, default font back to Inter. Open: Downloads as MediaStore category (chips, File/Folder view), drag count badge + drop wobble, search/empty-state restyle.
- Build 43b: drawOutline import fix; touch drag via detectDragGesturesAfterLongPress (+mouse branch); selection pill smaller (72dp actions, 22 icon, 11sp).
- Build 43c: selectRing drawn with drawRoundRect (drawOutline unresolved).
- Round 3 mocks published (artifact 6EV9Vj8EVrAoxkzgpbgrFc): selection A-E, thumbnails 3 densities, hover, light tokens, 8 fonts, drag rules, columns in categories. Not built; awaiting user's picks.
- Build 44: quiet-amber selection recipe (ui2/design/Sel.kt: plate 7%, 1px edge 24%, white text, hover white 7%) in sidebar/rail/rows/columns/thumbnails; iPad-style Thumbnails (8dp padded tiles, 2-line centred names with middle ellipsis, tick top-left 8dp, hover shows circle); Gallery: ring 1.5dp + name scrim on hover (fade 120 in / 150 delay out); drag lifts only on 2nd hold of selected item; Internal storage tree collapsed by default; menus non-focusable while keyboard up (no keyboard glide); light palette tokens + readable scope chip; Columns in categories = grouped (folder/day) first column; Figtree default font (downloaded at build by fetchFigtree task, falls back to Inter), font modes 0 Figtree/1 System/2 Inter (fontModeV3).
- Build 44b: build.gradle.kts import java.net.URL (java.net unresolved in script).
- Build 44c: imports/OptIn fixes (DexMenu isImeVisible, EntryName fillMaxWidth, Theme ExperimentalTextApi).
- Build 45: Downloads is now a virtual category dex://downloads (MediaStore LIKE %/Download/%, owner package -> MediaQueries.sources) so Columns groups by source app; Onest font (mode 3) + theme keyed on font so names change too; Settings 'Selection' option Amber/Grey (selStyle, Sel via LocalSelGrey); gallery selected pictures shrink to 88% inside plate; drag decoration = card stack + count badge.
- Build 46: subtle dim of unselected icon/gallery tiles while selecting; selection options = Whisper + edge / Whisper (selStyleV2); Onest default (fontModeV4=3); sidebar folders/volumes spring-open after 650ms of drag hover; drag decoration shows real thumbnails (DragThumbs cache) + haptic on lift.
- Build 47: grouped-column chosen row grey (neutral 'open' vs amber 'selected'); mock Empty/No results/Loading skeleton/Error states (StateCard); spring-load folders (750ms) + tabs (600ms) while dragging, drag edge auto-scroll (vm.dragScrollDir), folder wobble on drop, softer drop-hover; remaining old Material icons in menus/shell/topbar replaced by DexIcons (OpenIn, NewTab, Star, Link, Home added); unselected tick circle gets dark backing.
- Build 47b: import androidx.compose.animation.core.animateFloat (InfiniteTransition extension).
- Build 48 (uncompiled): List expand arrow moved to leading slot via shared ExpandLead (Tree.kt), hidden on empty folders in List+Details; Details divider inset fixed when tree off; duplicate DragAutoScroll removed. Sidebar tree unchanged (already hides arrow without subfolders).
- Build 49 (uncompiled): DexDialog kit (DexDialog/DexButton/DexOption/DexField/DexKV) from Dialogs mock; Delete/Empty/Conflicts(radio)/Extract(radio)/Properties(perms, bytes, copy path)/Batch rename/Shortcuts/Settings/Message use it; NameDialog uses shared field+buttons and scrim-tap dismiss; preview panel + Screens buttons use DexButton. Context menu already on DexIcons. Light-mode pass not yet done.
- Build 49b (uncompiled): fixed detectTapGestures import (Dialogs.kt); toolbar view button now shows the current view's icon (CurrentViewIcon, crossfade 180ms) with new Details and Gallery glyphs.
- Build 50 (uncompiled): own drag picture (fixed size 92dp cards, opaque, thumbnails, badge, name pill; via view.startDragAndDrop + DRAG_FLAG_OPAQUE); live DropRegistry + window-wide dropRoot (zones hit-tested live, smallest zone wins, refresh tick while scrolling); touch tap = focus (plate+edge, preview), double tap opens files, folders single tap (Single tap to open setting applies to touch); preview image card follows picture aspect (EXIF aware); Settings card uses dialog surface/radius/border/spring.
- Build 50b (uncompiled): fix drag crash (hardware bitmaps copied to software before drawing drag picture).
- Build 51 (uncompiled): drag stack follows selection mid-drag (DragSession + updateDragShadow, payload.paths var); focused row = grey plate+hairline (amber stays for selected); sidebar top aligned with pane top; Settings scroll kept across font change; DualPane icon + ToggleMenuRow (icons on Dual pane/Preview/Show hidden); DexToast replaces Material snackbar; Material sort arrow, folder icons, switches (batch rename/legacy settings/foldersFirst), job progress bar restyled.
- Build 52 (uncompiled): Undo toast after moves without name clashes (works for drag, paste, Move sheet); status/nav bar icons follow app theme; light-mode: deeper category icon tints, amber text -> primary in Settings, value bubble inverted, danger colour in selection pill. Job strip card not yet restyled.
- Build 53 (uncompiled): Duplicate (Ctrl+D + context menu, 'name (1)'), job progress as floating card bottom-right (appears after 350ms, % + Cancel), Trash banner restyled, Analyze chips/buttons -> DexChip/DexButton, hamburger active fill deeper amber in light. Cut-dimming already existed (vm.isCut). Deliberately NOT added: clipboard chip, Move/Copy-to in context menu (pill has it), global Ctrl+Z, drag Move/Copy label.
- Round 4 started (mocks only, no build): see docs/r4/PLAN.md
- Round 4: published boards Main, Engine, Search to https://claude.ai/artifact/GXj5p4MGsAjtCVBwp5e3Eq (publish needs root=r4 dir, file_path project/canvas.json, files project/*.dc.html). Next: Viewer, Analyze, Win, Kit, T01-T10. Full canvas at scratchpad/r4/full.canvas.json
- Round 4: ALL boards published (Main, Engine, Search, Viewer, Analyze, T01-T10) to artifact GXj5p4MGsAjtCVBwp5e3Eq. Themes: Studio VGA, Phosphor, Outrun, Blueprint, Broadsheet, Neo-Brutal, Aero Gel, Rams, Lacquer, Cockpit. Awaiting user pick; then build ThemeSpec engine. Generator: scratchpad/r4/gen
- Settings: removed Theme/Accent/Folder style/Selection placeholders (user: themes later, Phosphor/Cockpit/Blueprint/Outrun liked). Next: finish app first (see plan in chat).
- Build 54: viewer hi-res region tiles + wheel/pinch zoom at pointer + keys (arrows,+,-,0,1,Esc,I); search path chips (every view), Show in folder (menu + Ctrl+Enter), ThemeSpec/Ember/LocalSpec foundation (rowSearch/rowDetails wired), Settings theme placeholders removed. Uncompiled.
- Build 55: Onest bundled (res/font/onest.ttf, OFL), Figtree/Inter/build-time font download + font and selStyle prefs removed; viewer overflow clip + stronger top scrim; removed !! and a compiler-hack line. Uncompiled.
- Build 56 in progress: done GroupBy (core/Grouping.kt, heads in List/Details/Icons, Sort menu), per-folder view memory (Prefs.FolderLayout, VM applyLayout/saveLayout, toggles in menus+Settings), dead old Settings dialog/Loc.SETTINGS removed. TODO: scrollbars, breadcrumbs, 7z/RAR, Analyze cleaners, search filters, light-mode pass
- Build 56: Group by (Type/Date/Size, List/Details/Icons), per-folder view memory toggle (menus + Settings), thin scroll indicators (all lists/grids), breadcrumb folding, 7z+RAR extract/list (commons-compress, xz, junrar), Analyze: Empty folders + Installers shortcut + keep-oldest for duplicates, search Type/Date/Size filter chips, dead code removed (old Settings screen, Loc.SETTINGS, kindFilter). Type-ahead already existed. Uncompiled.
- Build 56b: PasswordRequiredException package fix
- Build 56c: search results no longer get date headers in Recent files; grey 'N matches' bar removed (only shows searching/no matches/10k cap)
- Build 56d: Recent files type chips hidden while searching
- DIRECTION CHANGE (2026-11-10): user wants a true desktop-class manager: storage foundation for cloud/server is REQUIRED, not optional. Plan: Build 57 = FileSystem abstraction (LocalFs = today, zero visible change; route list/stat/stream/mkdir/rename/delete/copy/move/search/thumbnails through it) -> Build 58 = SAF/DocumentsProvider backend (Drive, OneDrive, Dropbox, USB) -> Build 59 = SMB + SFTP (+FTP/WebDAV). Other gaps to add: folder size, checksums, open archive as folder, tar/7z create, command palette (Ctrl+K), compare folders, FTP server. Themes after.
- Build 57 (2026-11-11, uncompiled): Ctrl+K palette (core/QuickIndex.kt, ui/Palette.kt, DialogState.Palette, VM openPalette/quickFolders), MD5/SHA-1/SHA-256 checksum rows in Properties (ChecksumRows in ui/Dialogs.kt), QuickIndexTest. Folder size was already in Properties (skipped Details column: recursive scan per row too costly). Next: build 58 = browse inside archives, Move/Copy to.
- Build 58 (2026-11-11, uncompiled): phone layout (LocalCompact in ui/Shell.kt: slimmer top bar with the View button moved beside Sort, no big page title, 60dp rows, tighter margins/gutters), drag 'Drop here to cancel' pill (CancelDropPill, DropZone.cancel in ui/Dnd.kt; replaces selection pill while dragging), Show in folder (menu + Ctrl+Enter) in Recent/category lists, sort strip aligned to row text. Archives-as-folders and Move/Copy to pushed to build 59.
- Build 59 (2026-11-11, uncompiled): Samsung-style phone mode: Recent chips scroll sideways (no wrap), page title folded away on phone and pulled out by pulling down, full-screen Settings and sidebar on phone, touch hold on a selected item shows the stack + actions menu (release keeps them, moving starts the drag; HoldStackOverlay in ui/Dnd.kt), context-menu position corrected for system-bar insets. Move/Copy sheet (DestinationSheet) already existed. Next: phone full-screen search page (Filters + recent searches), source line in category rows, archives-as-folders.
- Build 59b (2026-11-11): fix compile error, missing import androidx.compose.foundation.layout.systemBars in Dialogs.kt and Dnd.kt. User rule: do not build separate phone-only screens (e.g. no separate search page); one component that reflows.
- Build 60 (2026-11-11, uncompiled): universal width-based reflow. One ChipBar component (ui/Home.kt) used by Recent's filter and, in Columns view of categories, by the source groups when the pane is narrower than 600dp (groups stay a side column on wide panes); ChipBar scrolls, keeps selected chip in view, fades edges, has 12/8 padding (was touching the card top). Folder Columns drop ancestor columns when fewer than two fit. Sidebar gets 8dp top padding (Recent row touched the status bar). Spacing: date header 12/4, list padding 2, sort strip 2/0. RULE: every change must work at all sizes, adapt by available width, no phone-only code paths.

- Vision canvas (ten mocks, not themes) delivered: 01 layout contract, 02 say-it-once, 03 search, 04 one action model, 05 drag/drop/cancel, 06 operations+undo, 07 workspaces, 08 look without opening, 09 Home, 10 remote locations. Suggested build order: 02,03,04,05,06,01,08,09,07,10.
- Deferred small fixes (user said leave for now): snap heading, close-sidebar control, files-card top aligned with chip bar, decongest search field. Folded into boards 02 and 03.

- Build 61 (uncompiled): header snaps open/closed (no scrub); sidebar drawer has a close button and clears system bars, sidebar top padding 0 so it lines up with the files card; search field = leading icon (closes) + text + clear only when text, scope moved to chips under the field (shown as soon as search opens, scrolls sideways); shared fling (1.3x release velocity, Fling.kt) on all lists/grids/sidebar. Not done from boards 02/03: shared-element title-to-path animation, filter tokens inside the field.
- Build 62 (uncompiled): search cross restored (clears text, closes search when empty); Medium widths (600-840dp) show the icon rail by default, menu button opens the full drawer; fling = exponential decay (no boost, friction 0.75, FLING_FRICTION in Fling.kt) for a long smooth taper; heading fold now swallows the drag while animating so the list stays flush at the top. Open question to user: Settings as a right-hand panel to match the left sidebar.
- Build 63 (uncompiled): board 04 one action model (ui/FileActions.kt: single Act list drives right-click/long-press menu and selection-pill More; primary row Move/Copy/Share/Delete; Move/Copy via vm.destination folder picker); Settings is a right-hand panel (400dp, same inset/radius) on non-phone widths; heading fold 360ms with fade, fling momentum no longer eaten while it folds; fling friction 0.65, speed x1.15.
- Build 64 (uncompiled): heading = Samsung-style resisted drag (0.55x), list waits, soft critically-damped spring on release (close past 35% or flick), flick keeps full energy into list; Show in folder only focuses (grey outline) instead of selecting; surfaces unified: page-level panels (sidebar, drawer, Settings full-screen and right panel) = cs.surface, everything that floats (dialogs, menus, pill, folder picker) = dialogSurface() = surfaceContainerHigh; PanelCloseButton shared by Settings and drawer; folder picker rebuilt on DexDialog (volume chips only with >1 storage, path bar styled like top bar, DexButton actions); selection pill buttons share available width so More is never clipped on narrow windows.
- Build 65 (uncompiled): heading RESIST 0.4, close threshold 50%, firm spring (stiffness 520), gentle release settles alone and eats the flick (list stays flush under the sort strip), hard flick (>2400px/s) snaps heading and throws the list; Settings docked on the right like the sidebar (380dp, on canvas, no card/scrim) when the page keeps >=480dp, else overlay; folder picker opens at the files own folder, shows files dimmed, hides selected folders, disables Move here for same folder / inside selected folder.
- Pending for next build: heading commit distance capped at 56dp so tall headers (Recents: title+chips) feel the same as short ones.

## Build 66
- Drag and drop (board 05): live label above the cancel pill ("Move 3 items to Trip" / "Copy ... to ...", Ctrl flips, "Already in X" for a no-op); one hover-to-open delay (SPRING_MS = 650) for folders, tabs and sidebar branches; `vm.dropMoves` shared by label and drop. Breadcrumb-segment targets skipped: there is no segment bar, the title is a menu.
- Colour sweep: hard-coded colours in Sidebar, SettingsCard, DexDialog, Theme, Shell, Selection, Pane moved onto Palette/theme tokens; new `Palette.strong` and `Tint` (category colours). Stack picture in Dnd.kt keeps its bitmap greys.
- Heading commit distance capped at 56dp (consistent snap in Recents).

## Build 66b
- Fix: Amber read inside slider draw lambda (captured outside). Added pop animation (stack swell + badge bounce) when items are added to or removed from a lifted stack.

## Build 67
- Drag stack picture: cards are the real thumbnail or the list's type tile (same colour + label), folder glyph on a light/dark card, hairline edge and shadow tuned per theme, badge ring follows the dialog surface; stack cards behind show the other selected items' own thumbs/tiles. Theme colours via StackPal (rememberUpdatedState).
- Properties: header with icon tile, name (wraps to 3 lines) and type; General / Checksums sections with sidebar-style headings; size with exact bytes line; checksums in 8-char groups; scrolls if tall.

## Build 68 (board 06)
- Undo for copy, duplicate (unless it replaced something), zip and extract-into-folder (the new items go to Trash, so the undo is itself recoverable); rename (Renamed to X + Undo); Trash move now via the shared announce path.
- Recent operations list (sidebar Tools, rail, Ctrl+K): last 20, Undo works once, same action as the toast.
- Progress card shows time left once there is a fair estimate.
- Not done: conflict choice is already one per operation (no change); Undo for external-app drops and for extract-into-current-folder.

## Build 69 (board 01 + Recent operations page)
- Layout contract written down (docs/LAYOUT_CONTRACT.md): breakpoints 600/900 (was 600/840), 24 dp hysteresis (rememberWindowClass), sidebar/rail/none as one animated box so crossing a breakpoint glides, hit areas grown to 48 dp on the small round buttons (search leading, tree arrows, path pill view button).
- Recent operations is a page (dex://history, Loc.HISTORY) like Analyze: day groups, kind icons, what-it-touched texts, Undo, Clear; history persisted as text (50 entries), earlier-session rows marked can't-be-undone. Dialog version removed.
- Tools order: Recent operations, Analyze storage, Trash (sidebar, rail).
- OpKind passed to launchJob/announce; copy/move/trash texts now name the items and destination.

## Build 70 (board 08: look without opening)
- Quick look (Space; also 'Quick look' in the menu so touch can reach it): floating card on the dialog surface, eases in, content slides 24 dp + cross-fades between files, header shows type, dimensions, size, date, with Share and Open; wider card on phone widths.
- Inspector (docked preview panel): image dimensions; folder size on demand ('Calculate size'); archive summary (items, compressed, unpacked) + Extract…; no work starts by itself.
- Not built: bottom-sheet inspector on narrow windows (Quick look serves there); card growing out of its thumbnail.
