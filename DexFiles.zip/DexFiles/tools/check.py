import re,glob,sys
bad=0
for f in glob.glob('app/src/**/*.kt',recursive=True):
    s=open(f).read()
    if s.count('{')!=s.count('}') or s.count('(')!=s.count(')'): print('BRACE',f);bad=1
    names=re.findall(r'^(?:private |internal )?fun (?:<[^>]+> )?(?:[\w.]+\.)?(\w+)\(([^)]*)',s,re.M)
    seen={}
    for n,a in names:
        k=(n,a.split(':')[1].split(',')[0].strip() if ':' in a else '')
        if k in seen: print('DUP',f,n);bad=1
        seen[k]=1
sys.exit(bad)
