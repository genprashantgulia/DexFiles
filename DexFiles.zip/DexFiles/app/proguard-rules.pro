# DexFiles uses no reflection of its own; Coil and AndroidX ship their own consumer rules.
-keepattributes SourceFile,LineNumberTable
