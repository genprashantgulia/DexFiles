import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.dexfiles"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.dexfiles"
        minSdk = 30 // Android 11: all-files access + StorageVolume.directory
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        debug {
            // Not debuggable = the runtime optimises the app fully, so scrolling and animation are much smoother.
            isDebuggable = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Personal-use build: signed with the debug key so the release APK installs directly.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")

    testImplementation("junit:junit:4.13.2")
}

// Figtree (SIL Open Font License) is fetched once at build time and cached in res/font; if the download fails the build falls back to Inter so it never breaks.
val fetchFigtree = tasks.register("fetchFigtree") {
    val out = file("src/main/res/font/figtree.ttf")
    outputs.file(out)
    doLast {
        if (!out.exists() || out.length() < 100_000L) {
            try {
                val bytes = URL("https://github.com/google/fonts/raw/main/ofl/figtree/Figtree%5Bwght%5D.ttf").openStream().use { it.readBytes() }
                if (bytes.size < 100_000) error("font download too small")
                out.writeBytes(bytes)
            } catch (e: Exception) {
                logger.warn("Figtree download failed (" + e.message + "), using Inter")
                file("src/main/res/font/inter_regular.ttf").copyTo(out, overwrite = true)
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchFigtree) }
