package app.dexfiles.core

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class CoreTest {
    private lateinit var tmp: File

    @Before
    fun setUp() {
        tmp = Files.createTempDirectory("dexfiles-test").toFile()
    }

    @After
    fun tearDown() {
        tmp.deleteRecursively()
    }

    private fun file(rel: String, text: String = rel): File {
        val f = File(tmp, rel)
        f.parentFile.mkdirs()
        f.writeText(text)
        return f
    }

    // ------------------------------------------------------------ types & sorting

    @Test
    fun fileKinds() {
        assertEquals(FileKind.IMAGE, FileTypes.kindOf("IMG_001.JPG", false))
        assertEquals(FileKind.FOLDER, FileTypes.kindOf("photos.jpg", true))
        assertEquals(FileKind.OTHER, FileTypes.kindOf(".bashrc", false))
        assertEquals("", FileTypes.extensionOf("noext"))
        assertEquals("gz", FileTypes.extensionOf("a.tar.gz"))
        assertEquals("PNG image", FileTypes.typeLabel("x.png", false))
        assertEquals("XYZ file", FileTypes.typeLabel("x.xyz", false))
        assertEquals("image/jpeg", FileTypes.mimeOf("a.JPG"))
    }

    @Test
    fun naturalOrder() {
        val names = listOf("file10.txt", "file2.txt", "File1.txt", "file02.txt", "a.txt")
        val sorted = names.sortedWith { a, b -> Sorting.naturalCompare(a, b) }
        assertEquals(listOf("a.txt", "File1.txt", "file2.txt", "file02.txt", "file10.txt"), sorted)
    }

    @Test
    fun sortFoldersFirstAndDescending() {
        val list = listOf(
            FileEntry("/a/z.txt", "z.txt", false, 5, 1, false),
            FileEntry("/a/b", "b", true, 0, 2, false),
            FileEntry("/a/a.txt", "a.txt", false, 50, 3, false),
        )
        val byName = Sorting.sort(list, SortSpec(SortKey.NAME, true, true)).map { it.name }
        assertEquals(listOf("b", "a.txt", "z.txt"), byName)
        val bySizeDesc = Sorting.sort(list, SortSpec(SortKey.SIZE, false, true)).map { it.name }
        assertEquals(listOf("b", "a.txt", "z.txt"), bySizeDesc)
        val mixed = Sorting.sort(list, SortSpec(SortKey.NAME, false, false)).map { it.name }
        assertEquals(listOf("z.txt", "b", "a.txt"), mixed)
    }

    // ------------------------------------------------------------ paths

    @Test
    fun breadcrumbs() {
        val roots = mapOf("/storage/emulated/0" to "Internal storage", "/storage/1234-ABCD" to "SD card")
        val c = PathUtils.crumbs("/storage/emulated/0/DCIM/Camera", roots)
        assertEquals(listOf("Internal storage", "DCIM", "Camera"), c.map { it.label })
        assertEquals("/storage/emulated/0/DCIM", c[1].path)
        assertEquals(listOf("/", "etc"), PathUtils.crumbs("/etc", roots).map { it.label })
        assertEquals(listOf("SD card"), PathUtils.crumbs("/storage/1234-ABCD", roots).map { it.label })
    }

    @Test
    fun typedPaths() {
        assertEquals("/a/c", PathUtils.resolveTyped("/a/b", "../c", "/home"))
        assertEquals("/x/y", PathUtils.resolveTyped("/a", "/x/y/", "/home"))
        assertEquals("/home/docs", PathUtils.resolveTyped("/a", "~/docs", "/home"))
        assertTrue(PathUtils.isInside("/a/b/c", "/a/b"))
        assertFalse(PathUtils.isInside("/a/bc", "/a/b"))
    }

    // ------------------------------------------------------------ file operations

    @Test
    fun uniqueNames() {
        file("report.pdf")
        assertEquals("report (1).pdf", FileOps.uniqueChild(tmp, "report.pdf", false).name)
        file("report (1).pdf")
        assertEquals("report (2).pdf", FileOps.uniqueChild(tmp, "report.pdf", false).name)
        File(tmp, "My.Folder").mkdir()
        assertEquals("My.Folder (1)", FileOps.uniqueChild(tmp, "My.Folder", true).name)
        assertEquals("new.txt", FileOps.uniqueChild(tmp, "new.txt", false).name)
    }

    @Test
    fun nameValidation() {
        assertNotNull(FileOps.validateName(""))
        assertNotNull(FileOps.validateName("a/b"))
        assertNotNull(FileOps.validateName("what?"))
        assertNotNull(FileOps.validateName(".."))
        assertNull(FileOps.validateName("Holiday photos 2026 (final).jpg"))
    }

    @Test
    fun renameRules() {
        val a = file("a.txt")
        file("b.txt")
        try {
            FileOps.rename(a, "b.txt")
            throw AssertionError("expected failure")
        } catch (e: FileOpException) {
            assertTrue(e.message!!.contains("already exists"))
        }
        val c = FileOps.rename(a, "c.txt")
        assertTrue(c.exists())
        assertFalse(a.exists())
        val upper = FileOps.rename(c, "C.txt")
        assertEquals("C.txt", upper.name)
        assertEquals(setOf("C.txt", "b.txt"), tmp.list()!!.toSet())
    }

    @Test
    fun copyKeepsBothAndReplaces() {
        val src = file("src/a.txt", "new")
        val dest = File(tmp, "dest").also { it.mkdirs() }
        file("dest/a.txt", "old")
        assertEquals(listOf(src), FileOps.findConflicts(listOf(src), dest))

        val keep = FileOps.copy(listOf(src), dest, OnConflict.KEEP_BOTH)
        assertTrue(keep.ok)
        assertEquals("old", File(dest, "a.txt").readText())
        assertEquals("new", File(dest, "a (1).txt").readText())

        val skip = FileOps.copy(listOf(src), dest, OnConflict.SKIP)
        assertEquals(1, skip.skipped)

        val rep = FileOps.copy(listOf(src), dest, OnConflict.REPLACE)
        assertTrue(rep.ok)
        assertEquals("new", File(dest, "a.txt").readText())
        assertTrue(dest.list()!!.none { it.endsWith(".dexpart") })
    }

    @Test
    fun pasteInSameFolderDuplicates() {
        val a = file("a.txt", "x")
        val r = FileOps.copy(listOf(a), tmp, OnConflict.REPLACE)
        assertTrue(r.ok)
        assertEquals("x", File(tmp, "a (1).txt").readText())
        assertEquals("x", a.readText())
    }

    @Test
    fun copyAndMoveFolders() {
        file("proj/src/main.kt", "fun main()")
        file("proj/readme.md", "hi")
        val dest = File(tmp, "out").also { it.mkdirs() }
        val progress = ArrayList<Progress>()
        val copied = FileOps.copy(listOf(File(tmp, "proj")), dest, OnConflict.KEEP_BOTH) { progress.add(it) }
        assertTrue(copied.ok)
        assertEquals("fun main()", File(dest, "proj/src/main.kt").readText())
        assertTrue(progress.last().fraction >= 0.99f)

        val moved = FileOps.move(listOf(File(tmp, "proj")), File(tmp, "out2").also { it.mkdirs() }, OnConflict.KEEP_BOTH)
        assertTrue(moved.ok)
        assertFalse(File(tmp, "proj").exists())
        assertTrue(File(tmp, "out2/proj/readme.md").exists())
    }

    @Test
    fun cannotCopyFolderIntoItself() {
        val dir = File(tmp, "a").also { it.mkdirs() }
        val sub = File(dir, "b").also { it.mkdirs() }
        val r = FileOps.copy(listOf(dir), sub, OnConflict.KEEP_BOTH)
        assertFalse(r.ok)
        assertTrue(r.failures.first().contains("inside itself"))
    }

    @Test
    fun cancelStopsOperation() {
        val src = file("big.bin", "x".repeat(10_000))
        val dest = File(tmp, "d").also { it.mkdirs() }
        val token = CancelToken()
        token.cancel()
        val r = FileOps.copy(listOf(src), dest, OnConflict.KEEP_BOTH, token)
        assertTrue(r.cancelled)
        assertEquals(0, dest.list()!!.size)
    }

    @Test
    fun deleteRecursive() {
        file("x/y/z.txt")
        file("x/w.txt")
        val r = FileOps.delete(listOf(File(tmp, "x")))
        assertTrue(r.ok)
        assertFalse(File(tmp, "x").exists())
    }

    @Test
    fun sizesAndFormatting() {
        file("d/a.bin", "x".repeat(1000))
        file("d/e/b.bin", "x".repeat(24))
        assertEquals(1024L, FileOps.sizeOf(File(tmp, "d")))
        assertEquals("1.00 KB", Format.size(1024))
        assertEquals("512 B", Format.size(512))
        assertEquals("15.0 MB", Format.size(15L * 1024 * 1024))
        assertEquals("120 GB", Format.size(120L * 1024 * 1024 * 1024))
    }

    @Test
    fun hashes() {
        val f = file("abc.txt", "abc")
        assertEquals("900150983cd24fb0d6963f7d28e17f72", Hashing.hex(f, "MD5"))
        assertEquals("a9993e364706816aba3e25717850c26c9cd0d89d", Hashing.hex(f, "SHA-1"))
    }

    @Test
    fun listingHidesDotFiles() {
        file("visible.txt")
        file(".hidden")
        File(tmp, "dir").mkdir()
        assertEquals(setOf("visible.txt", "dir"), Listing.list(tmp, false).map { it.name }.toSet())
        assertEquals(3, Listing.list(tmp, true).size)
    }

    // ------------------------------------------------------------ archives

    @Test
    fun zipRoundTrip() {
        file("pics/a.txt", "AAA")
        file("pics/sub/b.txt", "BBB")
        val zip = File(tmp, "pics.zip")
        Archives.create(listOf(File(tmp, "pics")), zip)
        val names = Archives.list(zip).map { it.name }
        assertTrue(names.contains("pics/a.txt"))
        assertTrue(names.contains("pics/sub/"))

        val out = File(tmp, "extracted")
        assertEquals(2, Archives.extract(zip, out))
        assertEquals("BBB", File(out, "pics/sub/b.txt").readText())
        assertEquals("pics", Archives.folderNameFor(zip))
    }

    @Test
    fun zipSlipIsBlocked() {
        val zip = File(tmp, "evil.zip")
        ZipOutputStream(zip.outputStream()).use { z ->
            z.putNextEntry(ZipEntry("../escaped.txt"))
            z.write("boom".toByteArray())
            z.closeEntry()
        }
        try {
            Archives.extract(zip, File(tmp, "safe"))
            throw AssertionError("expected zip-slip rejection")
        } catch (e: FileOpException) {
            assertTrue(e.message!!.contains("unsafe"))
        }
        assertFalse(File(tmp, "escaped.txt").exists())
    }

    // ------------------------------------------------------------ batch rename

    @Test
    fun batchRename() {
        val spec = BatchRenameSpec(find = "IMG_", replace = "Trip ", numbering = true, startAt = 1, digits = 3, caseMode = CaseMode.KEEP)
        val out = BatchRename.preview(listOf("IMG_a.jpg" to false, "IMG_b.jpg" to false), spec)
        assertEquals(listOf("Trip a 001.jpg", "Trip b 002.jpg"), out)

        val title = BatchRename.apply("hello big WORLD.TXT", false, 0, BatchRenameSpec(caseMode = CaseMode.TITLE))
        assertEquals("Hello Big World.TXT", title)

        val rx = BatchRenameSpec(find = "(\\d+)-(\\d+)", replace = "$2-$1", useRegex = true)
        assertEquals("02-01.png", BatchRename.apply("01-02.png", false, 0, rx))
        assertFalse(BatchRename.isValid(BatchRenameSpec(find = "(", useRegex = true)))
        assertEquals("folder.v2", BatchRename.apply("folder.v2", true, 0, BatchRenameSpec()))
    }

    @Test
    fun batchRenameProblems() {
        val bad = BatchRename.problems(listOf("a.txt", "b.txt"), listOf("x.txt", "X.txt"), setOf("a.txt", "b.txt"))
        assertEquals(setOf(0, 1), bad)
        val clash = BatchRename.problems(listOf("a.txt"), listOf("keep.txt"), setOf("a.txt", "keep.txt"))
        assertEquals(setOf(0), clash)
        assertTrue(BatchRename.problems(listOf("a.txt", "b.txt"), listOf("b.txt", "a.txt"), setOf("a.txt", "b.txt")).isEmpty())
    }

    // ------------------------------------------------------------ search

    @Test
    fun searchQueryParsing() {
        val q = SearchQuery.parse("holiday kind:image size>1mb newer:7d", now = 1_000_000_000L)
        assertEquals(listOf("holiday"), q.terms)
        assertEquals(setOf(FileKind.IMAGE), q.kinds)
        assertEquals(1024L * 1024, q.minSize)
        assertEquals(1_000_000_000L - 7 * 86_400_000L, q.newerThan)
        assertTrue(SearchQuery.parse("   ").isEmpty)
        assertEquals(setOf("pdf"), SearchQuery.parse("ext:.PDF").exts)
    }

    @Test
    fun searchFindsMatches() {
        file("docs/Invoice 2026.pdf")
        file("docs/notes.txt")
        file("docs/deep/er/invoice-old.pdf")
        file("docs/.hidden/invoice.pdf")
        val hits = ArrayList<String>()
        Search.run(tmp, SearchQuery.parse("invoice ext:pdf"), CancelToken()) { hits.add(it.name) }
        assertEquals(setOf("Invoice 2026.pdf", "invoice-old.pdf"), hits.toSet())

        val globHits = ArrayList<String>()
        Search.run(tmp, SearchQuery.parse("*.txt"), CancelToken()) { globHits.add(it.name) }
        assertEquals(listOf("notes.txt"), globHits)

        val folders = ArrayList<String>()
        Search.run(tmp, SearchQuery.parse("kind:folder er"), CancelToken()) { folders.add(it.name) }
        assertEquals(listOf("er"), folders)
    }

    // ------------------------------------------------------------ analyzer

    @Test
    fun analyzerReportsSizesAndDuplicates() {
        file("a/one.jpg", "x".repeat(300))
        file("a/two.jpg", "x".repeat(300))
        file("a/clip.mp4", "y".repeat(2000))
        file("b/three.txt", "z".repeat(10))
        file("b/four.txt", "w".repeat(300))

        val rep = Analyzer.analyze(tmp, CancelToken(), topN = 2)
        assertEquals(5, rep.fileCount)
        assertEquals(2000L, rep.byKind[FileKind.VIDEO])
        assertEquals(600L, rep.byKind[FileKind.IMAGE])
        assertEquals(listOf("clip.mp4"), rep.largest.take(1).map { it.name })
        assertEquals(2, rep.largest.size)

        val dups = Analyzer.findDuplicates(tmp, CancelToken())
        assertEquals(1, dups.size)
        assertEquals(2, dups[0].files.size)
        assertEquals(300L, dups[0].wasted)
    }

    // ------------------------------------------------------------ trash

    @Test
    fun trashRoundTrip() {
        val store = TrashStore(File(tmp, ".trash"))
        val f = file("docs/a.txt", "hello")
        val item = store.moveToTrash(f)
        assertFalse(f.exists())
        assertEquals(1, store.list().size)
        assertEquals(5L, store.list()[0].size)

        file("docs/a.txt", "occupied")
        val restored = store.restore(item)
        assertEquals("a (1).txt", restored.name)
        assertEquals("hello", restored.readText())
        assertEquals(0, store.list().size)

        val d = File(tmp, "folder").also { it.mkdirs() }
        file("folder/x.txt")
        val di = store.moveToTrash(d)
        assertTrue(di.isDir)
        assertEquals(1, store.empty())
        assertEquals(0, store.list().size)
    }

    @Test
    fun trashPurgesOldItems() {
        val store = TrashStore(File(tmp, ".trash"))
        store.moveToTrash(file("old.txt"))
        assertEquals(0, store.purgeOlderThan(30))
        assertEquals(1, store.purgeOlderThan(30, now = System.currentTimeMillis() + 40L * 86_400_000L))
    }
}
