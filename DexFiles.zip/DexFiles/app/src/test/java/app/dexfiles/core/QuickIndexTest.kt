package app.dexfiles.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuickIndexTest {
    private fun s(q: String, path: String) = QuickIndex.score(QuickIndex.words(q), path.substringAfterLast('/'), path)

    @Test fun noMatchIsNegative() = assertEquals(-1, s("zzq", "/a/Documents"))

    @Test fun everyWordMustMatch() {
        assertTrue(s("tax 2026", "/a/Tax/2026") >= 0)
        assertEquals(-1, s("tax 2027", "/a/Tax/2026"))
    }

    @Test fun prefixBeatsInfixAndShallowBeatsDeep() {
        assertTrue(s("doc", "/a/Documents") > s("doc", "/a/My Documents".replace("My ", "xdoc")))
        assertTrue(s("doc", "/a/Docs") > s("doc", "/a/b/c/d/Docs"))
    }

    @Test fun pathMatchStillCounts() = assertTrue(s("tax", "/a/Tax/2026") >= 0)

    @Test fun emptyQueryMatchesAll() = assertEquals(0, QuickIndex.score(emptyList(), "x", "/x"))
}
