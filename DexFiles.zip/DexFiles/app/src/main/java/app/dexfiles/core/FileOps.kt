package app.dexfiles.core

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.security.MessageDigest
import java.util.Locale

class OperationCancelled : RuntimeException("Cancelled")
class FileOpException(message: String) : IOException(message)

/** Thread-safe cancel flag shared between the UI and a running operation. */
class CancelToken {
    @Volatile
    var isCancelled: Boolean = false
        private set

    fun cancel() {
        isCancelled = true
    }

    fun check() {
        if (isCancelled) throw OperationCancelled()
    }
}

enum class OnConflict { REPLACE, KEEP_BOTH, SKIP }

data class Progress(val doneBytes: Long, val totalBytes: Long, val current: String) {
    val fraction: Float
        get() = if (totalBytes <= 0L) 0f else (doneBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

class OpResult {
    /** Human readable "name: reason" lines. */
    val failures = mutableListOf<String>()
    val created = mutableListOf<String>()
    var skipped = 0
    var succeeded = 0
    var cancelled = false
    val ok: Boolean get() = failures.isEmpty() && !cancelled
}

object FileOps {
    private const val BUFFER = 256 * 1024

    fun isSymlink(f: File): Boolean = try {
        Files.isSymbolicLink(f.toPath())
    } catch (e: Exception) {
        false
    }

    private fun exists(f: File): Boolean = f.exists() || isSymlink(f)

    // ---------------------------------------------------------------- sizes

    fun sizeOf(f: File, cancel: CancelToken? = null): Long {
        if (!f.isDirectory) return f.length()
        if (isSymlink(f)) return 0L
        var total = 0L
        val stack = java.util.ArrayDeque<File>()
        stack.push(f)
        while (stack.isNotEmpty()) {
            cancel?.check()
            val d = stack.pop()
            val kids = d.listFiles() ?: continue
            for (k in kids) {
                if (k.isDirectory) {
                    if (!isSymlink(k)) stack.push(k)
                } else {
                    total += k.length()
                }
            }
        }
        return total
    }

    /** Number of direct children, or -1 when unreadable. */
    fun childCount(dir: File): Int = dir.list()?.size ?: -1

    // ---------------------------------------------------------------- names

    private val illegal = charArrayOf('\\', '/', ':', '*', '?', '"', '<', '>', '|', '\u0000')

    /** Returns an error message, or null when [name] is acceptable on Android, SD cards (exFAT) and Windows. */
    fun validateName(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Name can't be empty"
        if (n == "." || n == "..") return "That name isn't allowed"
        if (n.length > 255) return "Name is too long"
        val bad = n.firstOrNull { it in illegal }
        if (bad != null) return "Name can't contain $bad"
        return null
    }

    /** "report.pdf" -> "report (1).pdf" -> "report (2).pdf"; folders have no extension. */
    fun uniqueChild(dir: File, name: String, isDir: Boolean): File {
        var f = File(dir, name)
        if (!exists(f)) return f
        val dot = if (isDir) -1 else name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        val m = Regex("^(.*) \\((\\d+)\\)$").find(stem)
        val base = m?.groupValues?.get(1) ?: stem
        var n = (m?.groupValues?.get(2)?.toIntOrNull() ?: 0) + 1
        while (true) {
            f = File(dir, "$base ($n)$ext")
            if (!exists(f)) return f
            n++
        }
    }

    fun rename(file: File, newName: String): File {
        val n = newName.trim()
        validateName(n)?.let { throw FileOpException(it) }
        val parent = file.parentFile ?: throw FileOpException("Can't rename this location")
        val target = File(parent, n)
        if (target.path == file.path) return file
        if (n.equals(file.name, ignoreCase = true)) {
            // Case-only change on a case-insensitive file system: go through a temporary name.
            val tmp = File(parent, ".rename-${System.nanoTime()}")
            if (!file.renameTo(tmp)) throw FileOpException("Couldn't rename \"${file.name}\"")
            if (!tmp.renameTo(target)) {
                tmp.renameTo(file)
                throw FileOpException("Couldn't rename \"${file.name}\"")
            }
            return target
        }
        if (exists(target)) throw FileOpException("\"$n\" already exists")
        if (!file.renameTo(target)) throw FileOpException("Couldn't rename \"${file.name}\"")
        return target
    }

    fun createFolder(parent: File, name: String): File {
        val n = name.trim()
        validateName(n)?.let { throw FileOpException(it) }
        val f = File(parent, n)
        if (exists(f)) throw FileOpException("\"$n\" already exists")
        if (!f.mkdir()) throw FileOpException("Couldn't create folder \"$n\"")
        return f
    }

    fun createFile(parent: File, name: String): File {
        val n = name.trim()
        validateName(n)?.let { throw FileOpException(it) }
        val f = File(parent, n)
        if (exists(f)) throw FileOpException("\"$n\" already exists")
        if (!f.createNewFile()) throw FileOpException("Couldn't create file \"$n\"")
        return f
    }

    // ---------------------------------------------------------------- conflicts

    /** Sources that would collide with an existing item in [destDir] (excluding pasting a file onto itself). */
    fun findConflicts(sources: List<File>, destDir: File): List<File> =
        sources.filter { s ->
            val t = File(destDir, s.name)
            exists(t) && t.path != s.path
        }

    // ---------------------------------------------------------------- copy / move

    private class Ctx(val cancel: CancelToken, val total: Long, val onProgress: (Progress) -> Unit) {
        var done = 0L
        private var lastEmit = 0L
        fun add(n: Long, name: String) {
            done += n
            val now = System.nanoTime()
            if (now - lastEmit > 100_000_000L) {
                lastEmit = now
                onProgress(Progress(done, total, name))
            }
        }

        fun emit(name: String) {
            lastEmit = System.nanoTime()
            onProgress(Progress(done, total, name))
        }
    }

    fun copy(
        sources: List<File>,
        destDir: File,
        policy: OnConflict,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ): OpResult = transfer(sources, destDir, policy, move = false, cancel, onProgress)

    fun move(
        sources: List<File>,
        destDir: File,
        policy: OnConflict,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ): OpResult = transfer(sources, destDir, policy, move = true, cancel, onProgress)

    private fun resolveTarget(src: File, destDir: File, policy: OnConflict, move: Boolean): File? {
        if (src.isDirectory && PathUtils.isInside(destDir.canonicalPath, src.canonicalPath)) {
            throw FileOpException("Can't put \"${src.name}\" inside itself")
        }
        val direct = File(destDir, src.name)
        if (!exists(direct)) return direct
        if (direct.canonicalPath == src.canonicalPath) {
            return if (move) null else uniqueChild(destDir, src.name, src.isDirectory)
        }
        return when (policy) {
            OnConflict.SKIP -> null
            OnConflict.KEEP_BOTH -> uniqueChild(destDir, src.name, src.isDirectory)
            OnConflict.REPLACE -> direct
        }
    }

    private fun transfer(
        sources: List<File>,
        destDir: File,
        policy: OnConflict,
        move: Boolean,
        cancel: CancelToken,
        onProgress: (Progress) -> Unit,
    ): OpResult {
        val res = OpResult()
        try {
            if (!destDir.isDirectory) throw FileOpException("Destination folder doesn't exist")
            val sizes = sources.map { sizeOf(it, cancel) }
            val ctx = Ctx(cancel, sizes.sum(), onProgress)
            for ((i, src) in sources.withIndex()) {
                cancel.check()
                try {
                    val target = resolveTarget(src, destDir, policy, move)
                    if (target == null) {
                        res.skipped++
                        ctx.add(sizes[i], src.name)
                        continue
                    }
                    ctx.emit(src.name)
                    if (move) {
                        if (!exists(target) && src.renameTo(target)) {
                            ctx.add(sizes[i], src.name)
                        } else {
                            copyTree(src, target, replace = true, ctx = ctx)
                            deleteRecursive(src)
                        }
                    } else {
                        copyTree(src, target, replace = policy == OnConflict.REPLACE, ctx = ctx)
                    }
                    res.created.add(target.path)
                    res.succeeded++
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: Exception) {
                    res.failures.add("${src.name}: ${e.message ?: "failed"}")
                }
            }
            ctx.emit("")
        } catch (e: OperationCancelled) {
            res.cancelled = true
        } catch (e: Exception) {
            res.failures.add(e.message ?: "failed")
        }
        return res
    }

    private fun copyTree(src: File, dst: File, replace: Boolean, ctx: Ctx) {
        ctx.cancel.check()
        if (src.isDirectory) {
            if (isSymlink(src)) return
            if (exists(dst) && !dst.isDirectory) {
                if (replace) dst.delete() else throw FileOpException("\"${dst.name}\" is a file")
            }
            if (!dst.exists() && !dst.mkdirs()) throw FileOpException("Couldn't create folder \"${dst.name}\"")
            val kids = src.listFiles() ?: throw FileOpException("Can't read \"${src.name}\"")
            for (k in kids) copyTree(k, File(dst, k.name), replace, ctx)
            dst.setLastModified(src.lastModified())
        } else {
            copyFile(src, dst, ctx)
        }
    }

    private fun copyFile(src: File, dst: File, ctx: Ctx) {
        if (dst.isDirectory) throw FileOpException("\"${dst.name}\" is a folder")
        val tmp = File(dst.parentFile, dst.name + ".dexpart")
        try {
            FileInputStream(src).use { input ->
                FileOutputStream(tmp).use { output ->
                    val buf = ByteArray(BUFFER)
                    while (true) {
                        ctx.cancel.check()
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        ctx.add(n.toLong(), src.name)
                    }
                }
            }
            if (exists(dst) && !dst.delete()) throw FileOpException("Couldn't replace \"${dst.name}\"")
            if (!tmp.renameTo(dst)) throw FileOpException("Couldn't finish writing \"${dst.name}\"")
            dst.setLastModified(src.lastModified())
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
    }

    // ---------------------------------------------------------------- delete

    fun deleteRecursive(f: File, cancel: CancelToken? = null) {
        cancel?.check()
        if (f.isDirectory && !isSymlink(f)) {
            f.listFiles()?.forEach { deleteRecursive(it, cancel) }
        }
        if (!f.delete() && exists(f)) throw FileOpException("Couldn't delete \"${f.name}\"")
    }

    fun delete(files: List<File>, cancel: CancelToken = CancelToken(), onProgress: (Progress) -> Unit = {}): OpResult {
        val res = OpResult()
        try {
            for ((i, f) in files.withIndex()) {
                cancel.check()
                onProgress(Progress(i.toLong(), files.size.toLong(), f.name))
                try {
                    deleteRecursive(f, cancel)
                    res.succeeded++
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: Exception) {
                    res.failures.add("${f.name}: ${e.message ?: "failed"}")
                }
            }
            onProgress(Progress(files.size.toLong(), files.size.toLong(), ""))
        } catch (e: OperationCancelled) {
            res.cancelled = true
        }
        return res
    }
}

object Hashing {
    fun hex(file: File, algorithm: String, cancel: CancelToken? = null, onBytes: ((Long) -> Unit)? = null): String {
        val md = MessageDigest.getInstance(algorithm)
        FileInputStream(file).use { input ->
            val buf = ByteArray(256 * 1024)
            var total = 0L
            while (true) {
                cancel?.check()
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                total += n
                onBytes?.invoke(total)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}

object Format {
    private val units = arrayOf("B", "KB", "MB", "GB", "TB")

    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024.0 && i < units.size - 1) {
            v /= 1024.0
            i++
        }
        val fmt = when {
            v >= 100 -> "%.0f %s"
            v >= 10 -> "%.1f %s"
            else -> "%.2f %s"
        }
        return String.format(Locale.US, fmt, v, units[i])
    }

    fun items(n: Int): String = if (n == 1) "1 item" else "$n items"
}
