package app.dexfiles.data

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import app.dexfiles.MainActivity
import app.dexfiles.core.FileTypes
import java.io.File

object Opener {
    fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun mimeOf(f: File): String {
        val ext = FileTypes.extensionOf(f.name)
        val m = if (ext.isNotEmpty()) MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) else null
        return m ?: FileTypes.mimeOf(f.name)
    }

    private fun launch(ctx: Context, intent: Intent): String? {
        if (ctx !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            null
        } catch (e: ActivityNotFoundException) {
            "No app can open this file"
        } catch (e: Exception) {
            e.message ?: "Couldn't open this file"
        }
    }

    /** Opens [f] with the default app (or shows the chooser when [chooser] is true). Returns an error message or null. */
    fun open(ctx: Context, f: File, chooser: Boolean = false): String? {
        val mime = mimeOf(f)
        if (FileTypes.extensionOf(f.name) == "apk" && !ctx.packageManager.canRequestPackageInstalls()) {
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
            launch(ctx, i)
            return "Allow DexFiles to install apps, then open the file again"
        }
        val view = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(ctx, f), if (FileTypes.extensionOf(f.name) == "apk") "application/vnd.android.package-archive" else mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        val intent = if (chooser) Intent.createChooser(view, "Open with") else view
        val err = launch(ctx, intent)
        if (err != null && FileTypes.isTextual(f.name) && !chooser) {
            // Unknown code/config files: offer any text editor.
            val text = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriFor(ctx, f), "text/plain")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            return launch(ctx, text)
        }
        return err
    }

    fun share(ctx: Context, files: List<File>): String? {
        val list = files.filter { it.isFile }
        if (list.isEmpty()) return "Folders can't be shared directly. Compress them first."
        val intent = if (list.size == 1) {
            Intent(Intent.ACTION_SEND).setType(mimeOf(list[0])).putExtra(Intent.EXTRA_STREAM, uriFor(ctx, list[0]))
        } else {
            val mimes = list.map { mimeOf(it) }.distinct()
            val type = if (mimes.size == 1) mimes[0] else "*/*"
            Intent(Intent.ACTION_SEND_MULTIPLE).setType(type)
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list.map { uriFor(ctx, it) }))
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return launch(ctx, Intent.createChooser(intent, "Share"))
    }

    /** Opens another DexFiles window (side by side in DeX / freeform). */
    fun newWindow(ctx: Context, startPath: String?) {
        val i = Intent(ctx, MainActivity::class.java)
        i.data = Uri.parse("dexfiles://window/" + System.nanoTime())
        i.addFlags(
            Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT,
        )
        if (startPath != null) i.putExtra(MainActivity.EXTRA_PATH, startPath)
        launch(ctx, i)
    }

    /** Clip carrying content URIs so other apps (and other DeX windows) can accept a dragged file. */
    fun dragClip(ctx: Context, paths: List<String>): ClipData {
        val files = paths.map { File(it) }.filter { it.isFile }
        if (files.isEmpty()) return ClipData.newPlainText("files", paths.joinToString("\n"))
        val clip = ClipData.newUri(ctx.contentResolver, files[0].name, uriFor(ctx, files[0]))
        for (f in files.drop(1)) clip.addItem(ClipData.Item(uriFor(ctx, f)))
        return clip
    }
}
