package app.dexfiles.data

import android.content.ContentResolver
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import app.dexfiles.core.FileEntry
import app.dexfiles.state.Loc
import java.io.File

/** Category views (Images, Videos, Recent...) answered from the MediaStore index, like Samsung My Files. */
object MediaQueries {
    private val docExts = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "ods", "odp", "csv", "epub", "rtf", "md")
    private val apkExts = listOf("apk", "xapk", "apks")

    @Suppress("DEPRECATION")
    fun query(ctx: Context, loc: String, limit: Int = 3000): List<FileEntry> {
        val uri = MediaStore.Files.getContentUri("external")
        val data = MediaStore.Files.FileColumns.DATA
        val args = ArrayList<String>()
        val selection: String = when (loc) {
            Loc.IMAGES -> "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}"
            Loc.VIDEOS -> "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}"
            Loc.AUDIO -> "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}"
            Loc.DOCS -> docExts.joinToString(" OR ") { args.add("%.$it"); "$data LIKE ?" }
            Loc.APKS -> apkExts.joinToString(" OR ") { args.add("%.$it"); "$data LIKE ?" }
            else -> "${MediaStore.Files.FileColumns.SIZE} > 0" // recent: anything with content
        }
        val extra = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args.toTypedArray())
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, if (loc == Loc.RECENT) 600 else limit)
        }
        val out = ArrayList<FileEntry>()
        val cursor = ctx.contentResolver.query(uri, arrayOf(data), extra, null) ?: return out
        cursor.use { c ->
            val idx = c.getColumnIndexOrThrow(data)
            while (c.moveToNext()) {
                val p = c.getString(idx) ?: continue
                if (p.contains("/.") || p.contains("/Android/data/") || p.contains("/Android/obb/") || p.endsWith(".dexpart")) continue
                val f = File(p)
                if (!f.isFile) continue
                out.add(FileEntry.from(f))
                if (loc == Loc.RECENT && out.size >= 150) break
            }
        }
        return out
    }
}
