package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Immutable
class DexType(f: FontFamily) {
    val title = TextStyle(f, fontWeight = FontWeight.SemiBold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.4).sp)
    val heading = TextStyle(f, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp)
    val body = TextStyle(f, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp)
    val bodyStrong = TextStyle(f, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp)
    val label = TextStyle(f, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 18.sp)
    val caption = TextStyle(f, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp)
}
