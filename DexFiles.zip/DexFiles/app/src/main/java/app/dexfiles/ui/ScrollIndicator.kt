package app.dexfiles.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.staggeredgrid.LazyStaggeredGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * A thin position marker on the right edge that appears while the list moves and fades away afterwards.
 * [progress] is how far through the content the viewport is (0..1) and [fraction] how much of the content is visible.
 */
@Composable
private fun Modifier.scrollMarker(moving: Boolean, fraction: () -> Float, progress: () -> Float): Modifier {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(moving) {
        if (moving) shown = true else { delay(900); shown = false }
    }
    val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(if (shown) 120 else 350), label = "scrollMarker")
    val color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    return drawWithContent {
        drawContent()
        val f = fraction()
        if (alpha > 0.01f && f < 0.98f) {
            val w = 4.dp.toPx(); val pad = 3.dp.toPx()
            val h = (size.height * f).coerceAtLeast(36.dp.toPx()).coerceAtMost(size.height)
            val y = (size.height - h) * progress().coerceIn(0f, 1f)
            drawRoundRect(color.copy(alpha = color.alpha * alpha), Offset(size.width - w - pad, y), Size(w, h), CornerRadius(w / 2f))
        }
    }
}

@Composable
fun Modifier.scrollIndicator(state: LazyListState): Modifier = scrollMarker(
    moving = state.isScrollInProgress,
    fraction = {
        val info = state.layoutInfo
        if (info.totalItemsCount == 0) 1f else info.visibleItemsInfo.size.toFloat() / info.totalItemsCount
    },
    progress = {
        val info = state.layoutInfo
        val hidden = info.totalItemsCount - info.visibleItemsInfo.size
        if (hidden <= 0) 0f else {
            val first = info.visibleItemsInfo.firstOrNull()
            val part = if (first != null && first.size > 0) -first.offset.toFloat() / first.size else 0f
            (state.firstVisibleItemIndex + part) / hidden
        }
    },
)

@Composable
fun Modifier.scrollIndicator(state: LazyGridState): Modifier = scrollMarker(
    moving = state.isScrollInProgress,
    fraction = {
        val info = state.layoutInfo
        if (info.totalItemsCount == 0) 1f else info.visibleItemsInfo.size.toFloat() / info.totalItemsCount
    },
    progress = {
        val info = state.layoutInfo
        val hidden = info.totalItemsCount - info.visibleItemsInfo.size
        if (hidden <= 0) 0f else state.firstVisibleItemIndex.toFloat() / hidden
    },
)

@Composable
fun Modifier.scrollIndicator(state: LazyStaggeredGridState): Modifier = scrollMarker(
    moving = state.isScrollInProgress,
    fraction = {
        val info = state.layoutInfo
        if (info.totalItemsCount == 0) 1f else info.visibleItemsInfo.size.toFloat() / info.totalItemsCount
    },
    progress = {
        val info = state.layoutInfo
        val hidden = info.totalItemsCount - info.visibleItemsInfo.size
        if (hidden <= 0) 0f else state.firstVisibleItemIndex.toFloat() / hidden
    },
)
