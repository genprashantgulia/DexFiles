package app.dexfiles.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import android.os.ParcelFileDescriptor
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.Format
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.ViewerState
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

// One chrome for every viewer (mock F16): a back-and-name pill top left, an info chip and a ⋮ pill top right, one control pill at the
// bottom centre. The file fills the screen; the pills fade with a tap. Images use the same pieces in Viewer.kt.

private val PillFill = Color(0xCC0E0E12)

/** A floating pill: translucent dark, hairline ring, the app's rounded square. */
@Composable
internal fun ViewerPill(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.clip(Radius.s).background(PillFill).border(BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)), Radius.s)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .heightIn(min = 48.dp).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

@Composable
internal fun PillIcon(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Box(Modifier.size(app.dexfiles.ui2.design.Size.touch).clip(Radius.xs).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, label, Modifier.size(18.dp), tint = tint)
    }
}

@Composable
internal fun PillText(label: String, on: Boolean = false, onClick: (() -> Unit)? = null) {
    val m = Modifier.clip(Radius.xs).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 6.dp, vertical = 5.dp)
    Text(label, modifier = m, fontSize = 12.5.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
        color = if (on) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = if (onClick != null) 0.92f else 0.7f), maxLines = 1)
}

/** Back and name on the left; the facts and the ⋮ menu on the right. */
@Composable
internal fun BoxScope.ViewerTop(vm: ExplorerViewModel, cur: FileEntry, info: String, visible: Boolean) {
    AnimatedVisibility(visible, Modifier.align(Alignment.TopCenter), enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ViewerPill(Modifier.widthIn(max = 360.dp), onClick = { vm.viewer = null }) {
                Icon(DexIcons.Back, "Close", Modifier.size(18.dp), tint = Color.White)
                Text(cur.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.weight(1f))
            if (info.isNotEmpty()) ViewerPill { Text(info, fontSize = 12.sp, color = Color.White.copy(alpha = 0.75f), maxLines = 1) }
            var menu by remember { mutableStateOf(false) }
            Box {
                ViewerPill(onClick = { menu = true }) { Icon(DexIcons.More, "More", Modifier.size(18.dp), tint = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    MenuRow("Share", DexIcons.Share) { menu = false; vm.share(listOf(cur)) }
                    MenuRow("Open with…", DexIcons.OpenIn) { menu = false; vm.openExternally(cur, chooser = true) }
                    MenuRow("Properties", DexIcons.Info, hint = "Ctrl+I") { menu = false; vm.dialog = DialogState.Properties(listOf(cur)) }
                    MenuRow("Move to Trash", DexIcons.Trash) {
                        menu = false
                        vm.viewer = null
                        if (vm.useTrash) vm.moveToTrash(listOf(cur)) else vm.dialog = DialogState.ConfirmDelete(listOf(cur), permanent = true)
                    }
                }
            }
        }
    }
}

/** The one control pill, bottom centre. */
@Composable
internal fun BoxScope.ViewerBottom(visible: Boolean, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    AnimatedVisibility(visible, Modifier.align(Alignment.BottomCenter), enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
        ViewerPill(modifier.navigationBarsPadding().padding(bottom = 16.dp), content = content)
    }
}

/** Opens the right viewer for the file the session starts on. */
@Composable
fun Viewer(vm: ExplorerViewModel, st: ViewerState) {
    if (st.items[st.start].kind == FileKind.IMAGE) ImageViewer(vm, st) else ReaderViewer(vm, st)
}

private fun clock(ms: Int): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun ReaderViewer(vm: ExplorerViewModel, st: ViewerState) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = st.start) { st.items.size }
    val scope = rememberCoroutineScope()
    val cur = st.items[pager.currentPage]
    var chrome by remember { mutableStateOf(true) }
    val infos = remember { mutableStateMapOf<String, String>() }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    fun step(d: Int) { scope.launch { pager.animateScrollToPage((pager.currentPage + d).coerceIn(0, st.items.lastIndex)) } }
    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(focus).focusable()
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.key) {
                    Key.DirectionRight -> { step(1); true }
                    Key.DirectionLeft -> { step(-1); true }
                    Key.Escape -> { vm.viewer = null; true }
                    Key.I -> { vm.dialog = DialogState.Properties(listOf(cur)); true }
                    else -> false
                }
            }
            .pointerInput(Unit) { detectTapGestures { chrome = !chrome } },
    ) {
        // Swipe sideways to move through the folder's files of the same kind. Only the settled page builds its body, so players and page caches are released as you go.
        androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxSize(), key = { st.items[it].path }, beyondViewportPageCount = 0) { i ->
            val f = st.items[i]
            if (i == pager.settledPage) {
                val set: (String) -> Unit = { infos[f.path] = it }
                when (f.kind) {
                    FileKind.PDF -> PdfBody(f, chrome, set)
                    FileKind.VIDEO -> VideoBody(f, chrome, set, { chrome = !chrome }, ::step)
                    FileKind.AUDIO -> AudioBody(f, chrome, set, ::step)
                    else -> TextBody(f, chrome, set)
                }
            }
        }
        ViewerTop(vm, cur, infos[cur.path] ?: Format.size(cur.size), chrome)
    }
}

// ------------------------------------------------------------------------------------------------ text and code

private const val TEXT_LIMIT = 512 * 1024
private val token = Regex("""(//.*|#.*)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|\b(fun|val|var|class|object|interface|import|package|return|if|else|when|for|while|in|is|null|true|false|def|function|const|let|new|this|override|private|public|static|void)\b""")

/** Light syntax colour: comments, strings and a few keywords. Very long lines are left plain. */
private fun highlight(line: String, dim: Color, str: Color, kw: Color): AnnotatedString {
    if (line.length > 600) return AnnotatedString(line)
    return buildAnnotatedString {
        var at = 0
        for (m in token.findAll(line)) {
            append(line.substring(at, m.range.first))
            withStyle(SpanStyle(color = if (m.groups[1] != null) dim else if (m.groups[2] != null) str else kw)) { append(m.value) }
            at = m.range.last + 1
        }
        append(line.substring(at))
    }
}

@Composable
private fun BoxScope.TextBody(e: FileEntry, chrome: Boolean, onInfo: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val lines by produceState<List<String>?>(null, e.path) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                java.io.FileInputStream(e.path).use { s ->
                    val b = ByteArray(TEXT_LIMIT); var n = 0
                    while (n < TEXT_LIMIT) { val r = s.read(b, n, TEXT_LIMIT - n); if (r < 0) break; n += r }
                    String(b, 0, n, Charsets.UTF_8).lines()
                }
            }.getOrDefault(emptyList())
        }
    }
    val all = lines
    LaunchedEffect(all) { if (all != null) onInfo("UTF-8 · ${all.size} lines · ${Format.size(e.size)}${if (e.size > TEXT_LIMIT) " (first 512 KB)" else ""}") }
    var fs by remember { mutableIntStateOf(14) }
    var wrap by remember { mutableStateOf(false) }
    val hs = rememberScrollState()
    val code = e.kind == FileKind.CODE
    val dim = Color.White.copy(alpha = 0.42f)
    val str = app.dexfiles.ui2.design.LocalPalette.current.ok
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 72.dp, bottom = 96.dp)) {
        itemsIndexed(all.orEmpty()) { i, l ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${i + 1}", Modifier.widthIn(min = 32.dp), fontSize = fs.sp, fontFamily = FontFamily.Monospace, color = dim, textAlign = TextAlign.End)
                Box(Modifier.weight(1f).then(if (wrap) Modifier else Modifier.horizontalScroll(hs))) {
                    Text(
                        if (code) highlight(l, dim, str, cs.primary) else AnnotatedString(l),
                        fontSize = fs.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFE6E6EA), softWrap = wrap,
                    )
                }
            }
        }
    }
    ViewerBottom(chrome) {
        PillText("A−") { fs = (fs - 1).coerceAtLeast(10) }
        PillText("$fs")
        PillText("A+") { fs = (fs + 1).coerceAtMost(24) }
        PillText("·")
        PillText("Wrap", on = wrap) { wrap = !wrap }
    }
}

// ------------------------------------------------------------------------------------------------ PDF

/** One open PDF. The system renderer shows one page at a time, so renders queue behind a lock. */
private class PdfDoc(path: String) {
    private val fd = ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
    private val r = PdfRenderer(fd)
    private val lock = Mutex()
    private var open = true
    val pages = r.pageCount

    suspend fun render(i: Int, width: Int): Bitmap? = lock.withLock {
        if (!open) return@withLock null
        withContext(Dispatchers.IO) {
            r.openPage(i).use { p ->
                val h = (width * p.height / p.width.toFloat()).toInt().coerceAtLeast(1)
                Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888).also { it.eraseColor(android.graphics.Color.WHITE); p.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) }
            }
        }
    }

    fun close() = runBlocking { lock.withLock { open = false; runCatching { r.close(); fd.close() } } }
}

@Composable
private fun BoxScope.PdfBody(e: FileEntry, chrome: Boolean, onInfo: (String) -> Unit) {
    val doc by produceState<PdfDoc?>(null, e.path) {
        value = withContext(Dispatchers.IO) { runCatching { PdfDoc(e.path) }.getOrNull() }
        awaitDispose { value?.close() }
    }
    val d = doc
    if (d == null) { Text("Can't show this PDF here", Modifier.align(Alignment.Center), color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp); return }
    LaunchedEffect(d) { onInfo("${d.pages} pages · ${Format.size(e.size)}") }
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val hs = rememberScrollState()
    var zoom by remember { mutableStateOf(1f) }
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val pageW = (maxWidth - 32.dp) * zoom
        val px = with(density) { pageW.roundToPx() }
        LazyColumn(Modifier.fillMaxSize(), state = list, contentPadding = PaddingValues(top = 72.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(d.pages) { i ->
                val bmp by produceState<ImageBitmap?>(null, d, i, px) { value = d.render(i, px)?.asImageBitmap() }
                Box(Modifier.fillMaxWidth().horizontalScroll(hs).padding(horizontal = 16.dp)) {
                    val b = bmp
                    if (b == null) Box(Modifier.width(pageW).aspectRatio(0.707f).background(Color.White))
                    else Image(b, null, Modifier.width(pageW), contentScale = ContentScale.FillWidth)
                }
            }
        }
    }
    ViewerBottom(chrome) {
        val at = list.firstVisibleItemIndex
        PillIcon(DexIcons.Back, "Previous page") { scope.launch { list.animateScrollToItem((at - 1).coerceAtLeast(0)) } }
        PillText("${at + 1} / ${d.pages}")
        PillIcon(DexIcons.ChevronRight, "Next page") { scope.launch { list.animateScrollToItem((at + 1).coerceAtMost(d.pages - 1)) } }
        PillText("·")
        PillIcon(DexIcons.Minus, "Zoom out") { zoom = (zoom / 1.25f).coerceAtLeast(1f) }
        PillText("Fit width", on = zoom == 1f) { zoom = 1f }
        PillIcon(DexIcons.Plus, "Zoom in") { zoom = (zoom * 1.25f).coerceAtMost(4f) }
    }
}

// ------------------------------------------------------------------------------------------------ audio and video

@Composable
private fun RowScope.Scrubber(pos: Int, dur: Int, onSeek: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Slider(
        value = pos.coerceIn(0, dur).toFloat(), onValueChange = { onSeek(it.toInt()) }, valueRange = 0f..dur.coerceAtLeast(1).toFloat(),
        modifier = Modifier.weight(1f).heightIn(max = 28.dp).widthIn(min = 120.dp),
        colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary, inactiveTrackColor = Color.White.copy(alpha = 0.2f)),
    )
}

@Composable
private fun BoxScope.AudioBody(e: FileEntry, chrome: Boolean, onInfo: (String) -> Unit, step: (Int) -> Unit) {
    val player = remember { runCatching { MediaPlayer().apply { setDataSource(e.path); prepare() } }.getOrNull() }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    // The viewer is not a music player: sound stops the moment it is closed (the fade-out still composes it for a moment), and when the app leaves the screen.
    val vm = LocalVm.current
    LaunchedEffect(vm.viewer == null) { if (vm.viewer == null) runCatching { player?.pause() } }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val watch = androidx.lifecycle.LifecycleEventObserver { _, ev -> if (ev == androidx.lifecycle.Lifecycle.Event.ON_STOP) runCatching { player?.pause() } }
        owner.lifecycle.addObserver(watch)
        onDispose { owner.lifecycle.removeObserver(watch) }
    }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    val dur = remember { player?.duration ?: 0 }
    LaunchedEffect(Unit) {
        if (player == null) return@LaunchedEffect
        onInfo(clock(dur)); player.start()
        while (true) { pos = player.currentPosition; playing = player.isPlaying; delay(250) }
    }
    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(84.dp).clip(Radius.l).background(Color(0xFF1C1C21)), contentAlignment = Alignment.Center) {
            Icon(DexIcons.Music, null, Modifier.size(34.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Text(e.name.substringBeforeLast('.'), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
        Text(if (player == null) "Can't play this file here" else "${e.ext.uppercase()} · ${Format.size(e.size)}", fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
    }
    if (player != null) ViewerBottom(chrome, Modifier.widthIn(max = 480.dp).fillMaxWidth(0.92f)) {
        PillIcon(DexIcons.Prev, "Previous file") { step(-1) }
        PillIcon(if (playing) DexIcons.Pause else DexIcons.Play, if (playing) "Pause" else "Play", MaterialTheme.colorScheme.primary) { if (player.isPlaying) player.pause() else player.start(); playing = player.isPlaying }
        PillIcon(DexIcons.Next, "Next file") { step(1) }
        PillText(clock(pos))
        Scrubber(pos, dur) { pos = it; player.seekTo(it) }
        PillText(clock(dur))
    }
}

@Composable
private fun BoxScope.VideoBody(e: FileEntry, chrome: Boolean, onInfo: (String) -> Unit, onTap: () -> Unit, step: (Int) -> Unit) {
    var view by remember { mutableStateOf<VideoView?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) { onDispose { view?.stopPlayback() } }
    LaunchedEffect(view) { while (true) { view?.let { pos = it.currentPosition; playing = it.isPlaying }; delay(250) } }
    AndroidView(
        factory = { c ->
            VideoView(c).apply {
                setVideoPath(e.path)
                setOnPreparedListener { mp -> dur = mp.duration; onInfo("${mp.videoWidth} × ${mp.videoHeight} · ${Format.size(e.size)}"); start() }
                view = this
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
    // The video view swallows touches, so a layer above it does the tap and the double-tap skips.
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        detectTapGestures(
            onTap = { onTap() },
            onDoubleTap = { p -> view?.let { v -> v.seekTo((v.currentPosition + if (p.x < size.width / 2) -10_000 else 10_000).coerceIn(0, dur)) } },
        )
    })
    ViewerBottom(chrome, Modifier.widthIn(max = 520.dp).fillMaxWidth(0.92f)) {
        PillIcon(if (playing) DexIcons.Pause else DexIcons.Play, if (playing) "Pause" else "Play", MaterialTheme.colorScheme.primary) { view?.let { if (it.isPlaying) it.pause() else it.start(); playing = it.isPlaying } }
        PillText(clock(pos))
        Scrubber(pos, dur) { pos = it; view?.seekTo(it) }
        PillText(clock(dur))
    }
}
