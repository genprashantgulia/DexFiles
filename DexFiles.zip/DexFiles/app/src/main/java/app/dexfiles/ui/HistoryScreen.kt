package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.OpKind
import app.dexfiles.state.OpRecord
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius

/**
 * Recent operations: a page like Analyze storage, reached from Tools. Newest first, grouped by day, one row per operation with the icon of
 * what was done, what it touched, and Undo while it can still be undone. Rows from an earlier session keep their text but cannot be undone.
 */
@Composable
fun HistoryScreen(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val z = java.time.ZoneId.systemDefault()
    val today = java.time.LocalDate.now(z)
    fun dayLabel(ms: Long): String {
        val d = java.time.LocalDate.ofInstant(java.time.Instant.ofEpochMilli(ms), z)
        return when (d) { today -> "Today"; today.minusDays(1) -> "Yesterday"; else -> Fmt.date(ms) }
    }
    Column(Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Recent operations", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    "What you copied, moved, deleted and renamed. Undo works until you close the app.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.65f),
                )
            }
            if (vm.history.isNotEmpty()) DexButton("Clear", DexBtn.Plain) { vm.clearHistory() }
        }
        Spacer(Modifier.height(16.dp))
        if (vm.history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 48.dp)) {
                    Icon(DexIcons.Reset, null, Modifier.size(40.dp), tint = cs.onSurfaceVariant.copy(alpha = 0.6f))
                    Text("Nothing here yet", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    Text(
                        "Copies, moves, deletes, renames and zips will show up here, with Undo where it is possible.",
                        fontSize = 13.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
                    )
                }
            }
        } else {
            // Day headings and rows in one flat list.
            val flat = ArrayList<Any>()
            var last: String? = null
            for (r in vm.history) {
                val label = dayLabel(r.at)
                if (label != last) { flat.add(label); last = label }
                flat.add(r)
            }
            LazyColumn(Modifier.fillMaxSize(), flingBehavior = dexFling(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(flat.size) { i ->
                    when (val x = flat[i]) {
                        is String -> Text(
                            x.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.08.em, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, top = if (i == 0) 0.dp else 12.dp, bottom = 2.dp),
                        )
                        is OpRecord -> HistoryRow(x)
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(r: OpRecord) {
    val cs = MaterialTheme.colorScheme
    val status = when {
        r.used -> "Undone"
        r.expired && r.kind != OpKind.Undo -> "Can’t be undone now"
        else -> null
    }
    Row(
        Modifier.fillMaxWidth().clip(Radius.l).background(cs.surfaceContainer).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(44.dp).clip(Radius.m).background(cs.surfaceContainerHigh), contentAlignment = Alignment.Center) {
            Icon(iconFor(r.kind), null, Modifier.size(22.dp), tint = cs.onSurfaceVariant)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(r.text, fontSize = 14.sp, color = cs.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(listOfNotNull(Fmt.dateTime(r.at), status).joinToString(" · "), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        if (r.undo != null && !r.used) DexButton("Undo", DexBtn.Plain) { r.run() }
    }
}

private fun iconFor(k: OpKind) = when (k) {
    OpKind.Copy -> DexIcons.Copy
    OpKind.Move -> DexIcons.Move
    OpKind.Trash, OpKind.Delete -> DexIcons.Trash
    OpKind.Rename -> DexIcons.Rename
    OpKind.Zip, OpKind.Extract -> DexIcons.Compress
    OpKind.Restore, OpKind.Undo -> DexIcons.Reset
    OpKind.Other -> DexIcons.Info
}
