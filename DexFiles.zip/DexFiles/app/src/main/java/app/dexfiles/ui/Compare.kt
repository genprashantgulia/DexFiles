package app.dexfiles.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.Format
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel

/** How one name stands between the two panes. Nothing here ever deletes. */
private enum class Diff(val glyph: String) { OnlyLeft("→"), OnlyRight("←"), NewerLeft("≠"), NewerRight("≠"), Same("=") }

private class CmpRow(val name: String, val left: FileEntry?, val right: FileEntry?, val diff: Diff)

private fun compare(a: List<FileEntry>, b: List<FileEntry>): List<CmpRow> {
    val bm = b.associateBy { it.name }
    val am = a.associateBy { it.name }
    val out = ArrayList<CmpRow>()
    for (l in a) {
        val r = bm[l.name]
        val d = when {
            r == null -> Diff.OnlyLeft
            l.isDir && r.isDir -> Diff.Same
            l.isDir != r.isDir -> Diff.NewerLeft
            l.size == r.size && kotlin.math.abs(l.modified - r.modified) <= 2000L -> Diff.Same
            l.modified >= r.modified -> Diff.NewerLeft
            else -> Diff.NewerRight
        }
        out += CmpRow(l.name, l, r, d)
    }
    for (r in b) if (am[r.name] == null) out += CmpRow(r.name, null, r, Diff.OnlyRight)
    return out.sortedWith(compareBy({ it.diff == Diff.Same }, { it.name.lowercase() }))
}

private enum class CmpFilter(val label: String) { Differences("Differences"), All("All"), OnlyHere("Only here") }

/**
 * Compare: the two panes' folders side by side, one glyph per name saying what would happen (copy across, copy back, newer one wins,
 * same). The plan is written in plain words and nothing is deleted. "Run plan" sends the copies through the normal Move/Copy path,
 * so progress, conflicts and Undo behave as anywhere else.
 */
@Composable
fun CompareDialog(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val left = vm.panes[0].tab
    val right = vm.panes.getOrNull(1)?.tab
    val close = { vm.dialog = null }
    if (right == null || left.isVirtual || right.isVirtual || left.isSearch || right.isSearch) {
        DexDialog(title = "Compare", onDismiss = close, actions = { DexButton("OK", DexBtn.Primary) { close() } }) {
            DexBody("Open a real folder in each pane to compare them.")
        }
        return
    }
    val rows = remember(left.entries.size, right.entries.size, left.path, right.path) { compare(left.entries, right.entries) }
    var filter by remember { mutableStateOf(CmpFilter.Differences) }
    val diffs = rows.count { it.diff != Diff.Same }
    val shown = when (filter) {
        CmpFilter.Differences -> rows.filter { it.diff != Diff.Same }
        CmpFilter.All -> rows
        CmpFilter.OnlyHere -> rows.filter { it.diff == Diff.OnlyLeft }
    }
    val toRight = rows.filter { it.diff == Diff.OnlyLeft || it.diff == Diff.NewerLeft }
    val toLeft = rows.filter { it.diff == Diff.OnlyRight || it.diff == Diff.NewerRight }
    val newerRight = toRight.count { it.diff == Diff.NewerLeft }
    val newerLeft = toLeft.count { it.diff == Diff.NewerRight }
    val leftName = java.io.File(left.path).name.ifEmpty { "left" }
    val rightName = java.io.File(right.path).name.ifEmpty { "right" }

    DexDialog(
        title = "Compare",
        onDismiss = close,
        width = 560.dp,
        actions = {
            DexButton("Close") { close() }
            DexButton("Run plan", DexBtn.Primary, enabled = toRight.isNotEmpty() || toLeft.isNotEmpty()) {
                close()
                if (toRight.isNotEmpty()) vm.copyPathsTo(toRight.map { it.left!!.path }, right.path)
                if (toLeft.isNotEmpty()) vm.copyPathsTo(toLeft.map { it.right!!.path }, left.path)
            }
        },
    ) {
        Text("$leftName ⇄ $rightName", fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (f in CmpFilter.entries) {
                val on = f == filter
                Text(
                    if (f == CmpFilter.Differences) "Differences $diffs" else if (f == CmpFilter.All) "All ${rows.size}" else f.label,
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = if (on) cs.onPrimary else cs.onSurface.copy(alpha = 0.8f),
                    modifier = Modifier.clip(Radius.xs).background(if (on) cs.primary else cs.onSurface.copy(alpha = 0.08f))
                        .clickable { filter = f }.padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
        LazyColumn(Modifier.padding(top = 8.dp).heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(shown, key = { it.name }) { r -> CompareLine(r) }
            if (shown.isEmpty()) item { Text("Nothing to show here.", fontSize = 14.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(12.dp)) }
        }
        Column(
            Modifier.padding(top = 10.dp).fillMaxWidth().clip(Radius.m).background(Sel.plate()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            val sendNew = toRight.size - newerRight
            if (toRight.isEmpty() && toLeft.isEmpty()) Text("Both folders already match.", fontSize = 13.sp, color = cs.onSurface)
            if (sendNew > 0) Text("Copy $sendNew new ${if (sendNew == 1) "item" else "items"} to $rightName.", fontSize = 13.sp, color = cs.onSurface)
            if (newerRight > 0) Text("Replace $newerRight older ${if (newerRight == 1) "file" else "files"} in $rightName with newer ones.", fontSize = 13.sp, color = cs.onSurface)
            val backNew = toLeft.size - newerLeft
            if (backNew > 0) Text("Copy $backNew ${if (backNew == 1) "item" else "items"} back to $leftName.", fontSize = 13.sp, color = cs.onSurface)
            if (newerLeft > 0) Text("Replace $newerLeft older ${if (newerLeft == 1) "file" else "files"} in $leftName with newer ones.", fontSize = 13.sp, color = cs.onSurface)
            Text("Nothing is deleted.", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
        }
    }
}

@Composable
private fun CompareLine(r: CmpRow) {
    val cs = MaterialTheme.colorScheme
    val dim = r.diff == Diff.Same
    val glyphColor = when (r.diff) {
        Diff.OnlyLeft -> Color(0xFF7C8CFF)
        Diff.OnlyRight -> Color(0xFF3DDC97)
        Diff.NewerLeft, Diff.NewerRight -> Color(0xFFFF8A65)
        Diff.Same -> cs.onSurface.copy(alpha = 0.35f)
    }
    fun side(e: FileEntry?) = if (e == null) "missing" else if (e.isDir) "folder" else Format.size(e.size)
    Row(
        Modifier.fillMaxWidth().height(44.dp).clip(Radius.s).background(cs.onSurface.copy(alpha = 0.05f)).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(if (r.left != null) r.name else "", fontSize = 13.5.sp, color = if (dim) cs.onSurfaceVariant else cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(side(r.left), fontSize = 11.5.sp, color = cs.onSurfaceVariant, maxLines = 1)
        }
        Box(Modifier.size(26.dp).clip(Radius.xs).background(glyphColor.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Text(r.diff.glyph, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = glyphColor)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(if (r.right != null) r.name else "", fontSize = 13.5.sp, color = if (dim) cs.onSurfaceVariant else cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End)
            Text(side(r.right), fontSize = 11.5.sp, color = cs.onSurfaceVariant, maxLines = 1)
        }
    }
}
