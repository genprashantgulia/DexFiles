package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.ViewerState
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File

/**
 * Full-screen photo viewer: swipe (or arrow keys) between the folder's images, pinch / wheel / double-tap to zoom,
 * tap for the bars. Zooming in swaps in a full-resolution region of the real file, so big photos stay sharp.
 */
@Composable
fun ImageViewer(vm: ExplorerViewModel, st: ViewerState) {
    val pager = rememberPagerState(initialPage = st.start) { st.items.size }
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var cmd by remember { mutableStateOf(0 to 0) } // (kind, serial): 1 in, 2 out, 3 fit, 4 actual size
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val cur = st.items[pager.currentPage.coerceIn(0, st.items.lastIndex)]
    fun send(k: Int) { cmd = k to (cmd.second + 1) }
    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(focus).focusable()
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.key) {
                    Key.DirectionRight, Key.PageDown, Key.Spacebar -> { if (!zoomed && pager.currentPage < st.items.lastIndex) scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }; true }
                    Key.DirectionLeft, Key.PageUp -> { if (!zoomed && pager.currentPage > 0) scope.launch { pager.animateScrollToPage(pager.currentPage - 1) }; true }
                    Key.Plus, Key.Equals, Key.NumPadAdd -> { send(1); true }
                    Key.Minus, Key.NumPadSubtract -> { send(2); true }
                    Key.Zero, Key.NumPad0 -> { send(3); true }
                    Key.One, Key.NumPad1 -> { send(4); true }
                    Key.Escape -> { vm.viewer = null; true }
                    Key.I -> { vm.dialog = DialogState.Properties(listOf(cur)); true }
                    else -> false
                }
            },
    ) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { st.items[it].path }) { i ->
            ZoomImage(
                st.items[i], active = i == pager.currentPage, cmd = cmd,
                onTap = { chrome = !chrome }, onZoom = { zoomed = it },
            )
        }
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = fadeIn(), exit = fadeOut()) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconBtn(DexIcons.Back, "Close", size = 48.dp, tint = Color.White) { vm.viewer = null }
                Text(
                    cur.name, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("${pager.currentPage + 1} / ${st.items.size}", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.75f))
                IconBtn(DexIcons.Share, "Share", size = 48.dp, tint = Color.White) { vm.share(listOf(cur)) }
                IconBtn(DexIcons.OpenIn, "Open with", size = 48.dp, tint = Color.White) { vm.openExternally(cur, chooser = true) }
                IconBtn(DexIcons.Info, "Details", size = 48.dp, tint = Color.White) { vm.dialog = DialogState.Properties(listOf(cur)) }
            }
        }
    }
}

/** Source size and EXIF rotation of an image file, read without decoding the pixels. */
private class ImgInfo(val w: Int, val h: Int, val rotated: Boolean)

private fun readInfo(path: String): ImgInfo? = runCatching {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    if (o.outWidth <= 0 || o.outHeight <= 0) return null
    val ori = runCatching { android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1) }.getOrDefault(1)
    ImgInfo(o.outWidth, o.outHeight, ori != 1 && ori != 0)
}.getOrNull()

/** Decodes the part of the file that is on screen at (roughly) screen resolution. */
private class Tile(val bmp: ImageBitmap, val x: Float, val y: Float, val w: Float, val h: Float)

private fun decodeTile(path: String, info: ImgInfo, rx: Float, ry: Float, rw: Float, rh: Float, destW: Float): Tile? = runCatching {
    val l = rx.toInt().coerceIn(0, info.w - 1); val t = ry.toInt().coerceIn(0, info.h - 1)
    val r = (rx + rw).toInt().coerceIn(l + 1, info.w); val b = (ry + rh).toInt().coerceIn(t + 1, info.h)
    var sample = 1
    while ((r - l) / (sample * 2f) >= destW) sample *= 2
    val dec = BitmapRegionDecoder.newInstance(path, false) ?: return null
    val bm = try {
        dec.decodeRegion(Rect(l, t, r, b), BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888 })
    } finally { dec.recycle() }
    if (bm == null) null else Tile(bm.asImageBitmap(), l.toFloat(), t.toFloat(), (r - l).toFloat(), (b - t).toFloat())
}.getOrNull()

@Composable
private fun ZoomImage(e: FileEntry, active: Boolean, cmd: Pair<Int, Int>, onTap: () -> Unit, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var tile by remember { mutableStateOf<Tile?>(null) }
    val ctx = LocalContext.current
    val info = remember(e.path, e.modified) { readInfo(e.path) }
    // Rotated photos can't use region decoding (it ignores EXIF), so they get a larger single decode instead.
    val req = remember(e.path, e.modified) {
        ImageRequest.Builder(ctx).data(File(e.path)).size(if (info?.rotated == true) 4096 else 2400).build()
    }
    fun clampOff(s: Float, o: Offset): Offset {
        if (s <= 1f) return Offset.Zero
        val mx = box.width * (s - 1f) / 2f; val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    /** Zoom to [ns] keeping the screen point [p] (relative to the top-left) fixed. */
    fun zoomAt(ns: Float, p: Offset) {
        val s = ns.coerceIn(1f, 8f)
        val c = Offset(box.width / 2f, box.height / 2f)
        val q = c + (p - c - off) / scale
        off = clampOff(s, p - c - (q - c) * s)
        scale = s
        onZoom(s > 1f)
    }
    LaunchedEffect(cmd) {
        if (!active || cmd.first == 0 || box.width == 0) return@LaunchedEffect
        val c = Offset(box.width / 2f, box.height / 2f)
        when (cmd.first) {
            1 -> zoomAt(scale * 1.4f, c)
            2 -> zoomAt(scale / 1.4f, c)
            3 -> { scale = 1f; off = Offset.Zero; onZoom(false) }
            4 -> if (info != null) {
                val f = min(box.width / info.w.toFloat(), box.height / info.h.toFloat())
                zoomAt(if (f > 0f) (1f / f).coerceAtLeast(1f) else 1f, c)
            }
        }
    }
    // Once the gesture settles, fetch the real pixels for what is on screen and draw them over the fitted copy.
    LaunchedEffect(scale, off, box) {
        if (scale < 1.15f || info == null || info.rotated || box.width == 0) { tile = null; return@LaunchedEffect }
        delay(140)
        val bw = box.width.toFloat(); val bh = box.height.toFloat()
        val f = min(bw / info.w, bh / info.h)
        val fw = info.w * f; val fh = info.h * f
        val cx = bw / 2f; val cy = bh / 2f
        // visible rectangle in unscaled layout coordinates
        val vl = cx + (0f - cx - off.x) / scale; val vr = cx + (bw - cx - off.x) / scale
        val vt = cy + (0f - cy - off.y) / scale; val vb = cy + (bh - cy - off.y) / scale
        val il = max(vl, cx - fw / 2f); val ir = min(vr, cx + fw / 2f)
        val it = max(vt, cy - fh / 2f); val ib = min(vb, cy + fh / 2f)
        if (ir <= il || ib <= it) return@LaunchedEffect
        val rx = (il - (cx - fw / 2f)) / f; val ry = (it - (cy - fh / 2f)) / f
        val rw = (ir - il) / f; val rh = (ib - it) / f
        val destW = (ir - il) * scale
        tile = withContext(Dispatchers.IO) { decodeTile(e.path, info, rx, ry, rw, rh, destW) }
    }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { p -> if (scale > 1.05f) { scale = 1f; off = Offset.Zero; onZoom(false) } else zoomAt(2.5f, p) },
                )
            }
            .pointerInput(Unit) {
                // mouse wheel zooms around the pointer (DeX); the viewer has no vertical scrolling to compete with
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent()
                        if (ev.type == PointerEventType.Scroll) {
                            val ch = ev.changes.first()
                            zoomAt(scale * exp(-ch.scrollDelta.y * 0.12f), ch.position)
                            ev.changes.forEach { it.consume() }
                        }
                    }
                }
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        if (ev.changes.size >= 2 || scale > 1f) {
                            val z = ev.calculateZoom()
                            val c = ev.changes.map { it.position }.let { ps -> Offset(ps.sumOf { it.x.toDouble() }.toFloat() / ps.size, ps.sumOf { it.y.toDouble() }.toFloat() / ps.size) }
                            if (z != 1f) zoomAt(scale * z, c)
                            off = clampOff(scale, off + ev.calculatePan())
                            onZoom(scale > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(model = req, contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        val t = tile
        if (t != null && info != null) {
            Canvas(Modifier.fillMaxSize()) {
                val f = min(size.width / info.w, size.height / info.h)
                val fw = info.w * f; val fh = info.h * f
                val ox = (size.width - fw) / 2f; val oy = (size.height - fh) / 2f
                drawImage(
                    t.bmp,
                    dstOffset = IntOffset((ox + t.x * f).toInt(), (oy + t.y * f).toInt()),
                    dstSize = IntSize((t.w * f).toInt().coerceAtLeast(1), (t.h * f).toInt().coerceAtLeast(1)),
                )
            }
        }
    }
}
