package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.ViewerState
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File

/** Full-screen photo viewer: swipe between the folder's images, pinch or double-tap to zoom, tap for the bars. */
@Composable
fun ImageViewer(vm: ExplorerViewModel, st: ViewerState) {
    val pager = rememberPagerState(initialPage = st.start) { st.items.size }
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    val cur = st.items[pager.currentPage.coerceIn(0, st.items.lastIndex)]
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { st.items[it].path }) { i ->
            ZoomImage(st.items[i], onTap = { chrome = !chrome }, onZoom = { zoomed = it })
        }
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = fadeIn(), exit = fadeOut()) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconBtn(DexIcons.Back, "Close", size = 48.dp, tint = Color.White) { vm.viewer = null }
                Text(
                    cur.name, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("${pager.currentPage + 1} / ${st.items.size}", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.75f))
                IconBtn(Icons.Filled.Share, "Share", size = 48.dp, tint = Color.White) { vm.share(listOf(cur)) }
                IconBtn(Icons.Filled.OpenInNew, "Open with", size = 48.dp, tint = Color.White) { vm.openExternally(cur, chooser = true) }
                IconBtn(Icons.Filled.Info, "Details", size = 48.dp, tint = Color.White) { vm.dialog = DialogState.Properties(listOf(cur)) }
            }
        }
    }
}

@Composable
private fun ZoomImage(e: FileEntry, onTap: () -> Unit, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    val ctx = LocalContext.current
    val req = remember(e.path, e.modified) { ImageRequest.Builder(ctx).data(File(e.path)).size(2400).build() }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f
                        onZoom(scale > 1f)
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        if (ev.changes.size >= 2 || scale > 1f) {
                            scale = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                            val maxX = size.width * (scale - 1f) / 2f
                            val maxY = size.height * (scale - 1f) / 2f
                            val n = off + ev.calculatePan()
                            off = if (scale > 1f) Offset(n.x.coerceIn(-maxX, maxX), n.y.coerceIn(-maxY, maxY)) else Offset.Zero
                            onZoom(scale > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(model = req, contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
    }
}
