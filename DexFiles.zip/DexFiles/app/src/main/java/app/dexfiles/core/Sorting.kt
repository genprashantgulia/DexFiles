package app.dexfiles.core

enum class SortKey(val label: String) { NAME("Name"), MODIFIED("Date modified"), SIZE("Size"), TYPE("Type") }

data class SortSpec(
    val key: SortKey = SortKey.NAME,
    val ascending: Boolean = true,
    val foldersFirst: Boolean = true,
)

object Sorting {
    /**
     * Case-insensitive "natural" comparison like Windows Explorer: "file2" sorts before "file10",
     * and leading zeros don't matter numerically.
     */
    fun naturalCompare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ie = i
                while (ie < a.length && a[ie].isDigit()) ie++
                var je = j
                while (je < b.length && b[je].isDigit()) je++
                var ia = i
                while (ia < ie - 1 && a[ia] == '0') ia++
                var ja = j
                while (ja < je - 1 && b[ja] == '0') ja++
                val lenA = ie - ia
                val lenB = je - ja
                if (lenA != lenB) return lenA.compareTo(lenB)
                val c = a.substring(ia, ie).compareTo(b.substring(ja, je))
                if (c != 0) return c
                i = ie
                j = je
            } else {
                val x = ca.lowercaseChar()
                val y = cb.lowercaseChar()
                if (x != y) return x.compareTo(y)
                i++
                j++
            }
        }
        return (a.length - i).compareTo(b.length - j)
    }

    fun comparator(spec: SortSpec): Comparator<FileEntry> = Comparator { x, y ->
        if (spec.foldersFirst && x.isDir != y.isDir) {
            return@Comparator if (x.isDir) -1 else 1
        }
        var c = when (spec.key) {
            SortKey.NAME -> naturalCompare(x.name, y.name)
            SortKey.MODIFIED -> x.modified.compareTo(y.modified)
            SortKey.SIZE -> x.size.compareTo(y.size)
            SortKey.TYPE -> {
                val t = x.kind.ordinal.compareTo(y.kind.ordinal)
                if (t != 0) t else x.ext.compareTo(y.ext)
            }
        }
        if (!spec.ascending) c = -c
        if (c == 0) c = naturalCompare(x.name, y.name)
        if (c == 0) c = x.name.compareTo(y.name)
        c
    }

    fun sort(list: List<FileEntry>, spec: SortSpec): List<FileEntry> = list.sortedWith(comparator(spec))
}
