package app.dexfiles

import android.app.Application
import android.content.Context
import java.io.File
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.memory.MemoryCache

/** Application class: only sets up the thumbnail loader (images and video frames). */
class DexApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .crossfade(false)
            .allowRgb565(true)
            .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("thumbs")).maxSizeBytes(256L * 1024 * 1024).build() }
            .build()
}

/** Saves the last crash so the next launch can show it on screen (no computer needed to read logs). */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                file(app).writeText("Thread: ${t.name}\n" + e.stackTraceToString().take(8000))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = try {
        file(ctx).takeIf { it.exists() }?.readText()
    } catch (_: Throwable) {
        null
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Throwable) {
        }
    }
}
