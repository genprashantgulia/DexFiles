package app.dexfiles.core

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.PriorityQueue

data class UsageReport(
    val byKind: Map<FileKind, Long>,
    val countByKind: Map<FileKind, Int>,
    val totalBytes: Long,
    val fileCount: Int,
    val largest: List<FileEntry>,
)

data class DuplicateGroup(val sizeEach: Long, val files: List<String>) {
    val wasted: Long get() = sizeEach * (files.size - 1)
}

object Analyzer {
    fun analyze(root: File, cancel: CancelToken, topN: Int = 50, onProgress: (Int) -> Unit = {}): UsageReport {
        val byKind = HashMap<FileKind, Long>()
        val counts = HashMap<FileKind, Int>()
        val heap = PriorityQueue<FileEntry>(topN + 1, compareBy { it.size })
        var total = 0L
        var count = 0
        val stack = java.util.ArrayDeque<File>()
        stack.push(root)
        while (stack.isNotEmpty()) {
            cancel.check()
            val d = stack.pop()
            val kids = d.listFiles() ?: continue
            for (k in kids) {
                if (k.isDirectory) {
                    if (!FileOps.isSymlink(k)) stack.push(k)
                    continue
                }
                val e = FileEntry.from(k)
                byKind[e.kind] = (byKind[e.kind] ?: 0L) + e.size
                counts[e.kind] = (counts[e.kind] ?: 0) + 1
                total += e.size
                count++
                if (heap.size < topN) heap.add(e)
                else if (e.size > heap.peek().size) {
                    heap.poll()
                    heap.add(e)
                }
                if (count % 500 == 0) onProgress(count)
            }
        }
        onProgress(count)
        return UsageReport(byKind, counts, total, count, heap.sortedByDescending { it.size })
    }

    private fun sha1(file: File, limit: Long = Long.MAX_VALUE, cancel: CancelToken): String {
        val md = MessageDigest.getInstance("SHA-1")
        FileInputStream(file).use { input ->
            val buf = ByteArray(64 * 1024)
            var left = limit
            while (left > 0) {
                cancel.check()
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) break
                md.update(buf, 0, n)
                left -= n
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Groups of byte-identical files (size, then first 64 KB, then full hash). Biggest waste first. */
    fun findDuplicates(root: File, cancel: CancelToken, minSize: Long = 1L, onProgress: (Int) -> Unit = {}): List<DuplicateGroup> {
        val bySize = HashMap<Long, MutableList<File>>()
        var seen = 0
        val stack = java.util.ArrayDeque<File>()
        stack.push(root)
        while (stack.isNotEmpty()) {
            cancel.check()
            val d = stack.pop()
            val kids = d.listFiles() ?: continue
            for (k in kids) {
                if (k.isDirectory) {
                    if (!FileOps.isSymlink(k) && !k.name.startsWith(".")) stack.push(k)
                    continue
                }
                val len = k.length()
                if (len >= minSize) bySize.getOrPut(len) { ArrayList() }.add(k)
                seen++
                if (seen % 500 == 0) onProgress(seen)
            }
        }
        val groups = ArrayList<DuplicateGroup>()
        for ((size, files) in bySize) {
            if (files.size < 2) continue
            val byHead = HashMap<String, MutableList<File>>()
            for (f in files) {
                try {
                    byHead.getOrPut(sha1(f, 64 * 1024, cancel)) { ArrayList() }.add(f)
                } catch (e: OperationCancelled) {
                    throw e
                } catch (_: Exception) {
                }
            }
            for (candidates in byHead.values) {
                if (candidates.size < 2) continue
                val byFull = HashMap<String, MutableList<File>>()
                for (f in candidates) {
                    try {
                        byFull.getOrPut(sha1(f, Long.MAX_VALUE, cancel)) { ArrayList() }.add(f)
                    } catch (e: OperationCancelled) {
                        throw e
                    } catch (_: Exception) {
                    }
                }
                for (same in byFull.values) {
                    if (same.size > 1) groups.add(DuplicateGroup(size, same.map { it.path }.sorted()))
                }
            }
        }
        return groups.sortedByDescending { it.wasted }
    }
}
