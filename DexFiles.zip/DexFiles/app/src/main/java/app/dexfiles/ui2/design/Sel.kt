package app.dexfiles.ui2.design

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/**
 * "Quiet amber": the one selection recipe for every view (sidebar, rows, columns, thumbnails, gallery).
 * A low-alpha accent plate, a 1px accent hairline, white text; the amber is kept for the tick. Hover is always white 7%.
 */
val LocalSelGrey = androidx.compose.runtime.staticCompositionLocalOf { false }

object Sel {
    private val dark: Boolean @Composable get() = MaterialTheme.colorScheme.background.luminance() < 0.5f

    /** Plate colour; the inactive pane uses neutral instead of accent. */
    @Composable fun plate(active: Boolean = true): Color {
        val cs = MaterialTheme.colorScheme
        val grey = LocalSelGrey.current
        return if (!active) cs.onSurface.copy(alpha = 0.08f) else if (grey) cs.onSurface.copy(alpha = if (dark) 0.10f else 0.09f) else cs.primary.copy(alpha = if (dark) 0.07f else 0.12f)
    }

    @Composable fun edge(active: Boolean = true): Color {
        val cs = MaterialTheme.colorScheme
        if (LocalSelGrey.current) return Color.Transparent
        return if (!active) cs.onSurface.copy(alpha = 0.12f) else cs.primary.copy(alpha = if (dark) 0.24f else 0.28f)
    }

    /** Gallery pictures have no plate to carry the edge, so their ring is stronger. */
    @Composable fun ring(): Color = if (LocalSelGrey.current) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)

    @Composable fun hover(): Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
}
