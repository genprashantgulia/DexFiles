package app.dexfiles.state

import android.os.FileObserver
import android.view.MotionEvent
import android.view.KeyEvent
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import app.dexfiles.core.CancelToken
import app.dexfiles.core.DuplicateGroup
import app.dexfiles.core.FileEntry
import app.dexfiles.core.OnConflict
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.UsageReport
import kotlinx.coroutines.Job
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

enum class ViewMode(val label: String) {
    DETAILS("List+"),
    LIST("List"),
    GRID("Icons"),
    COLUMNS("Columns"),
    GALLERY("Gallery"),
}

/** Virtual locations live under the dex:// scheme; everything else is a real path. */
object Loc {
    const val HOME = "dex://home"
    const val RECENT = "dex://recent"
    const val IMAGES = "dex://images"
    const val VIDEOS = "dex://videos"
    const val AUDIO = "dex://audio"
    const val DOCS = "dex://docs"
    const val APKS = "dex://apks"
    const val DOWNLOADS = "dex://downloads"
    const val TRASH = "dex://trash"
    const val ANALYZE = "dex://analyze"
    const val HISTORY = "dex://history"

    private val media = setOf(RECENT, IMAGES, VIDEOS, AUDIO, DOCS, APKS, DOWNLOADS)

    fun isVirtual(p: String) = p.startsWith("dex://")
    fun isMedia(p: String) = p in media

    fun title(p: String, rootLabels: Map<String, String>): String = when (p) {
        HOME -> "Recent files"
        RECENT -> "Recent files"
        IMAGES -> "Images"
        VIDEOS -> "Videos"
        AUDIO -> "Audio"
        DOCS -> "Documents"
        APKS -> "Installation files"
        DOWNLOADS -> "Downloads"
        TRASH -> "Trash"
        ANALYZE -> "Storage analysis"
        HISTORY -> "Recent operations"
        else -> rootLabels[p.trimEnd('/')] ?: File(p).name.ifEmpty { "/" }
    }
}

/** What Ctrl+C / Ctrl+X put on our internal clipboard. */
class Clip(val paths: List<String>, val cut: Boolean)

/** Local state for a drag that stays inside the app (moves/copies without going through URIs). */
class DragPayload(var paths: List<String>)

data class CtxMenu(val pane: Int, val pos: Offset, val target: FileEntry?)

/** The lifted stack shown while a hold-menu is open (touch): [pos] is where the finger is, [tx]/[ty] the point of the picture that sits under it. */
class HoldStack(val image: androidx.compose.ui.graphics.ImageBitmap, val pos: Offset, val tx: Float, val ty: Float)

data class UiEvent(val message: String, val actionLabel: String? = null, val onAction: (() -> Unit)? = null)

/** Written by the pane's pointer handlers so the context menu knows which row was right-clicked. */
class HitTracker {
    var entry: FileEntry? = null
}

class TransferJob(val id: Long, val title: String) {
    val token = CancelToken()
    var fraction by mutableFloatStateOf(0f)
    var detail by mutableStateOf("")
    val startedAt = System.currentTimeMillis()
}

enum class OpKind { Copy, Move, Trash, Delete, Restore, Rename, Zip, Extract, Undo, Other }

/**
 * One finished operation in Recent operations. [undo] is null when it cannot be reversed; it runs at most once.
 * [expired] marks a record loaded from an earlier session: the text is kept, the undo is not.
 */
class OpRecord(val kind: OpKind, val text: String, val at: Long, val undo: (() -> Unit)?, val expired: Boolean = false) {
    var used by mutableStateOf(false)
    fun run() { if (!used) { used = true; undo?.invoke() } }

    companion object {
        fun encode(list: List<OpRecord>): String =
            list.joinToString("\n") { "${it.at}|${it.kind.name}|${it.text.replace('\n', ' ').replace('|', ' ')}" }

        fun decode(s: String): List<OpRecord> = s.split('\n').mapNotNull { line ->
            val parts = line.split('|', limit = 3)
            if (parts.size < 3) return@mapNotNull null
            val at = parts[0].toLongOrNull() ?: return@mapNotNull null
            val kind = runCatching { OpKind.valueOf(parts[1]) }.getOrDefault(OpKind.Other)
            OpRecord(kind, parts[2], at, null, expired = true)
        }
    }
}

sealed interface DialogState {
    data class Rename(val entry: FileEntry) : DialogState
    data class NewItem(val folder: Boolean, val parent: String) : DialogState
    data class ConfirmDelete(val entries: List<FileEntry>, val permanent: Boolean) : DialogState
    data class Conflicts(val names: List<String>, val onChoose: (OnConflict?, Boolean) -> Unit, val incoming: java.io.File? = null, val existing: java.io.File? = null) : DialogState
    data class Properties(val entries: List<FileEntry>) : DialogState
    data class CustomizeFolder(val entry: FileEntry) : DialogState
    data class BatchRenameDlg(val entries: List<FileEntry>) : DialogState
    data class Compress(val entries: List<FileEntry>, val parent: String) : DialogState
    data class Archive(val entry: FileEntry) : DialogState
    data class Message(val title: String, val lines: List<String>, val retry: (() -> Unit)? = null) : DialogState
    data object EmptyTrash : DialogState
    data object Shortcuts : DialogState
    data object Palette : DialogState
    data object Compare : DialogState
}

class TabState(val id: Long, initialPath: String, sort: SortSpec, mode: ViewMode) {
    var path by mutableStateOf(initialPath)

    /** Unsorted listing as loaded; [entries] is the sorted copy the UI shows. */
    var raw: List<FileEntry> = emptyList()
    var entries by mutableStateOf<List<FileEntry>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    var selection by mutableStateOf<Set<String>>(emptySet())
    var anchor: String? = null
    var focus by mutableStateOf<String?>(null)
    var scrollTick by mutableIntStateOf(0)

    var sort by mutableStateOf(sort)
    var virtualSort by mutableStateOf(SortSpec(SortKey.MODIFIED, ascending = false, foldersFirst = false))
    var viewMode by mutableStateOf(if (mode == ViewMode.DETAILS) ViewMode.LIST else mode)
    var groupBy by mutableStateOf(app.dexfiles.core.GroupBy.NONE)
    /** Photo-heavy folder sorted by date: day headers appear by themselves (mock A4). Only while no grouping was chosen. */
    var autoDate by mutableStateOf(false)
    val groupShown: app.dexfiles.core.GroupBy get() = if (groupBy == app.dexfiles.core.GroupBy.NONE && autoDate) app.dexfiles.core.GroupBy.DATE else groupBy

    /** Search results are ranked by relevance until the user picks a sort. */
    var relevanceSort by mutableStateOf(true)

    /** First visible grid item, kept so a zoom level change doesn't throw you back to the top. */
    var zoomAnchor: Int = 0

    /** Finished results per query string, so shortening the query brings the earlier list back instantly. */
    val searchCache = HashMap<String, List<FileEntry>>()

    var query by mutableStateOf("")
    var searchRoot by mutableStateOf<String?>(null)
    var searching by mutableStateOf(false)

    /** Number of grid columns currently on screen (set by the grid so arrow keys can move by row). */
    var columns: Int = 1

    val back = mutableStateListOf<String>()
    val forward = mutableStateListOf<String>()

    var loadJob: Job? = null
    var searchJob: Job? = null
    var searchToken: CancelToken? = null
    var refreshJob: Job? = null
    var observer: FileObserver? = null

    var typeBuffer: String = ""
    var typeAt: Long = 0L

    val isVirtual: Boolean get() = Loc.isVirtual(path)
    val isSearch: Boolean get() = searchRoot != null
    val effectiveSort: SortSpec get() = if (isVirtual) virtualSort else sort
}

class PaneState(val index: Int) {
    val tabs = mutableStateListOf<TabState>()
    var active by mutableIntStateOf(0)
    val tab: TabState get() = tabs[active.coerceIn(0, tabs.lastIndex)]
}

class AnalyzeState {
    var volume by mutableStateOf<String?>(null)
    var running by mutableStateOf(false)
    var scanned by mutableIntStateOf(0)
    var report by mutableStateOf<UsageReport?>(null)
    var dupRunning by mutableStateOf(false)
    var dups by mutableStateOf<List<DuplicateGroup>?>(null)
    var emptyRunning by mutableStateOf(false)
    var empties by mutableStateOf<List<String>?>(null)
    var token: CancelToken? = null
}

/** Modifier keys and mouse buttons as of the last pointer event, fed by MainActivity. */
object Mods {
    @Volatile var ctrl = false
    @Volatile var shift = false
    @Volatile var alt = false
    @Volatile var secondaryDown = false
    @Volatile var tertiaryDown = false
    @Volatile var mouse = false

    fun update(ev: MotionEvent) {
        val m = ev.metaState
        ctrl = (m and KeyEvent.META_CTRL_ON) != 0 || (m and KeyEvent.META_META_ON) != 0
        shift = (m and KeyEvent.META_SHIFT_ON) != 0
        alt = (m and KeyEvent.META_ALT_ON) != 0
        val a = ev.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_BUTTON_PRESS) {
            secondaryDown = (ev.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
            tertiaryDown = (ev.buttonState and MotionEvent.BUTTON_TERTIARY) != 0
        }
        if (ev.pointerCount > 0) mouse = ev.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
    }
}


/** Photo viewer session: the images of the folder and which one to show first. */
class ViewerState(val items: List<FileEntry>, val start: Int)
