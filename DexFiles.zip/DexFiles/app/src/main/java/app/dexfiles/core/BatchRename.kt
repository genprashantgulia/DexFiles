package app.dexfiles.core

import java.util.Locale
import java.util.regex.PatternSyntaxException

enum class CaseMode(val label: String) { KEEP("Keep"), LOWER("lowercase"), UPPER("UPPERCASE"), TITLE("Title Case") }

data class BatchRenameSpec(
    val find: String = "",
    val replace: String = "",
    val useRegex: Boolean = false,
    val prefix: String = "",
    val suffix: String = "",
    val numbering: Boolean = false,
    val startAt: Int = 1,
    val digits: Int = 2,
    val caseMode: CaseMode = CaseMode.KEEP,
    /** A name made of {tokens} (see [NamePattern]); empty leaves the name as it is. {name} stands for the old name. */
    val pattern: String = "",
)

object BatchRename {
    /** False when the find pattern is an invalid regular expression. */
    fun isValid(spec: BatchRenameSpec): Boolean {
        if (!spec.useRegex || spec.find.isEmpty()) return true
        return try {
            Regex(spec.find)
            true
        } catch (e: PatternSyntaxException) {
            false
        }
    }

    /**
     * New name for one item. The extension of files is preserved and never touched by the rules.
     * [modified] and [parent] feed the {date} and {parent} tokens of the pattern.
     */
    fun apply(name: String, isDir: Boolean, index: Int, spec: BatchRenameSpec, modified: Long = 0L, parent: String = ""): String {
        val dot = if (isDir) -1 else name.lastIndexOf('.')
        val ext = if (dot > 0) name.substring(dot) else ""
        var stem = if (dot > 0) name.substring(0, dot) else name

        if (spec.find.isNotEmpty()) {
            stem = try {
                if (spec.useRegex) stem.replace(Regex(spec.find), spec.replace)
                else stem.replace(spec.find, spec.replace, ignoreCase = true)
            } catch (e: Exception) {
                stem
            }
        }
        stem = when (spec.caseMode) {
            CaseMode.KEEP -> stem
            CaseMode.LOWER -> stem.lowercase(Locale.ROOT)
            CaseMode.UPPER -> stem.uppercase(Locale.ROOT)
            CaseMode.TITLE -> stem.split(' ').joinToString(" ") { w ->
                w.lowercase(Locale.ROOT).replaceFirstChar { it.titlecase(Locale.ROOT) }
            }
        }
        if (spec.pattern.isNotBlank()) stem = NamePattern.expand(spec.pattern, stem, spec.startAt + index, spec.digits, modified, parent)
        stem = spec.prefix + stem + spec.suffix
        if (spec.numbering) {
            val n = (spec.startAt + index).toString().padStart(spec.digits.coerceIn(1, 9), '0')
            stem = "$stem $n"
        }
        return stem + ext
    }

    fun preview(items: List<Pair<String, Boolean>>, spec: BatchRenameSpec): List<String> =
        items.mapIndexed { i, (name, isDir) -> apply(name, isDir, i, spec) }


    /**
     * Indexes whose new name is invalid, duplicated inside the batch, or collides with an
     * existing name in the folder that isn't itself being renamed.
     */
    fun problems(oldNames: List<String>, newNames: List<String>, existingInFolder: Set<String>): Set<Int> {
        val bad = HashSet<Int>()
        val lowerOld = oldNames.map { it.lowercase(Locale.ROOT) }.toSet()
        val others = existingInFolder.map { it.lowercase(Locale.ROOT) }.filter { it !in lowerOld }.toSet()
        val seen = HashMap<String, Int>()
        for ((i, n) in newNames.withIndex()) {
            val key = n.lowercase(Locale.ROOT)
            if (FileOps.validateName(n) != null) bad.add(i)
            if (key in others) bad.add(i)
            val prev = seen.put(key, i)
            if (prev != null) {
                bad.add(i)
                bad.add(prev)
            }
        }
        return bad
    }
}


/**
 * Names built from a few pieces instead of typed out. A pattern is plain text with {tokens}:
 *   {name}    the current name (without its extension)
 *   {n}       a counter, {n:3} pads it to three digits
 *   {date}    the day the file was last changed, {date:yyyyMMdd} picks the layout
 *   {today}   today, same layouts
 *   {parent}  the name of the folder the file is in
 * Anything else, including an unknown {token}, stays as typed.
 */
object NamePattern {
    /** Offered as one-tap chips in the rename dialog, in this order. */
    val TOKENS = listOf("{name}", "{date}", "{n}", "{parent}", "{today}")

    /** Patterns shown until the user has saved their own. */
    val SUGGESTIONS = listOf("{date} {name}", "{parent} {n}", "{name} {n}")

    private val token = Regex("\\{([a-z]+)(?::([^}]*))?\\}")

    /** [counter] is the number this item gets (start + position); [digits] pads it unless the token says otherwise. */
    fun expand(pattern: String, stem: String, counter: Int, digits: Int, modified: Long, parent: String, now: Long = System.currentTimeMillis()): String =
        token.replace(pattern) { m ->
            val arg = m.groupValues[2]
            when (m.groupValues[1]) {
                "name" -> stem
                "n" -> counter.toString().padStart((arg.toIntOrNull() ?: digits).coerceIn(1, 9), '0')
                "date" -> day(modified, arg) ?: m.value
                "today" -> day(now, arg) ?: m.value
                "parent" -> parent
                else -> m.value
            }
        }

    private fun day(millis: Long, layout: String): String? {
        if (millis <= 0L) return ""
        return try {
            java.text.SimpleDateFormat(layout.ifEmpty { "yyyy-MM-dd" }, Locale.US).format(java.util.Date(millis))
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}

/** "Select similar": names that differ only in their numbers belong together (IMG_0412.jpg, IMG_0413.jpg). */
object NameShape {
    /** Every run of digits becomes one "#": Screenshot_20261102_074036.jpg -> screenshot_#_#.jpg. */
    fun of(name: String): String = name.lowercase(Locale.ROOT).replace(Regex("\\d+"), "#")

    /** The leading word and the extension: a looser match for names that share a start but not their numbers. */
    fun loose(name: String): String {
        val dot = name.lastIndexOf('.')
        val ext = if (dot > 0) name.substring(dot).lowercase(Locale.ROOT) else ""
        return name.takeWhile { it.isLetter() }.lowercase(Locale.ROOT) + "|" + ext
    }

    /** Names that look like [name]: the same shape, or when nothing else does, the same first word and extension. */
    fun similar(name: String, others: List<String>): List<String> {
        val strict = others.filter { of(it) == of(name) }
        if (strict.size > 1) return strict
        val first = name.takeWhile { it.isLetter() }
        return if (first.length < 2) strict else others.filter { loose(it) == loose(name) }
    }
}
