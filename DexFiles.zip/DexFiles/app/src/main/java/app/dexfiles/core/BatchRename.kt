package app.dexfiles.core

import java.util.Locale
import java.util.regex.PatternSyntaxException

enum class CaseMode(val label: String) { KEEP("Keep"), LOWER("lowercase"), UPPER("UPPERCASE"), TITLE("Title Case") }

data class BatchRenameSpec(
    val find: String = "",
    val replace: String = "",
    val useRegex: Boolean = false,
    val prefix: String = "",
    val suffix: String = "",
    val numbering: Boolean = false,
    val startAt: Int = 1,
    val digits: Int = 2,
    val caseMode: CaseMode = CaseMode.KEEP,
)

object BatchRename {
    /** False when the find pattern is an invalid regular expression. */
    fun isValid(spec: BatchRenameSpec): Boolean {
        if (!spec.useRegex || spec.find.isEmpty()) return true
        return try {
            Regex(spec.find)
            true
        } catch (e: PatternSyntaxException) {
            false
        }
    }

    /** New name for one item. The extension of files is preserved and never touched by the rules. */
    fun apply(name: String, isDir: Boolean, index: Int, spec: BatchRenameSpec): String {
        val dot = if (isDir) -1 else name.lastIndexOf('.')
        val ext = if (dot > 0) name.substring(dot) else ""
        var stem = if (dot > 0) name.substring(0, dot) else name

        if (spec.find.isNotEmpty()) {
            stem = try {
                if (spec.useRegex) stem.replace(Regex(spec.find), spec.replace)
                else stem.replace(spec.find, spec.replace, ignoreCase = true)
            } catch (e: Exception) {
                stem
            }
        }
        stem = when (spec.caseMode) {
            CaseMode.KEEP -> stem
            CaseMode.LOWER -> stem.lowercase(Locale.ROOT)
            CaseMode.UPPER -> stem.uppercase(Locale.ROOT)
            CaseMode.TITLE -> stem.split(' ').joinToString(" ") { w ->
                w.lowercase(Locale.ROOT).replaceFirstChar { it.titlecase(Locale.ROOT) }
            }
        }
        stem = spec.prefix + stem + spec.suffix
        if (spec.numbering) {
            val n = (spec.startAt + index).toString().padStart(spec.digits.coerceIn(1, 9), '0')
            stem = "$stem $n"
        }
        return stem + ext
    }

    fun preview(items: List<Pair<String, Boolean>>, spec: BatchRenameSpec): List<String> =
        items.mapIndexed { i, (name, isDir) -> apply(name, isDir, i, spec) }

    /**
     * Indexes whose new name is invalid, duplicated inside the batch, or collides with an
     * existing name in the folder that isn't itself being renamed.
     */
    fun problems(oldNames: List<String>, newNames: List<String>, existingInFolder: Set<String>): Set<Int> {
        val bad = HashSet<Int>()
        val lowerOld = oldNames.map { it.lowercase(Locale.ROOT) }.toSet()
        val others = existingInFolder.map { it.lowercase(Locale.ROOT) }.filter { it !in lowerOld }.toSet()
        val seen = HashMap<String, Int>()
        for ((i, n) in newNames.withIndex()) {
            val key = n.lowercase(Locale.ROOT)
            if (FileOps.validateName(n) != null) bad.add(i)
            if (key in others) bad.add(i)
            val prev = seen.put(key, i)
            if (prev != null) {
                bad.add(i)
                bad.add(prev)
            }
        }
        return bad
    }
}
