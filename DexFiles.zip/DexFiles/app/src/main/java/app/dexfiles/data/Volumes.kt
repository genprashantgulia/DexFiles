package app.dexfiles.data

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import app.dexfiles.core.PathUtils
import java.io.File

data class Volume(
    val path: String,
    val label: String,
    val primary: Boolean,
    val removable: Boolean,
    val total: Long,
    val free: Long,
) {
    val used: Long get() = (total - free).coerceAtLeast(0L)
    val usedFraction: Float get() = if (total <= 0L) 0f else (used.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
}

object Volumes {
    const val TRASH_DIR = ".dexfiles-trash"

    /** Mounted storage: internal storage first, then SD cards and USB drives (they appear live in DeX). */
    fun list(ctx: Context): List<Volume> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        val out = ArrayList<Volume>()
        for (sv in sm.storageVolumes) {
            val dir = sv.directory ?: continue
            val state = sv.state
            if (state != Environment.MEDIA_MOUNTED && state != Environment.MEDIA_MOUNTED_READ_ONLY) continue
            var total = 0L
            var free = 0L
            try {
                val st = StatFs(dir.path)
                total = st.totalBytes
                free = st.availableBytes
            } catch (_: Exception) {
            }
            val label = if (sv.isPrimary) "Internal storage" else (sv.getDescription(ctx) ?: "External storage")
            out.add(Volume(dir.path, label, sv.isPrimary, sv.isRemovable, total, free))
        }
        if (out.isEmpty()) {
            val d = Environment.getExternalStorageDirectory()
            out.add(Volume(d.path, "Internal storage", true, false, d.totalSpace, d.freeSpace))
        }
        return out.sortedByDescending { it.primary }
    }

    fun rootFor(path: String, volumes: List<Volume>): Volume? =
        volumes.filter { PathUtils.isInside(path, it.path) }.maxByOrNull { it.path.length }

    fun trashDirFor(volume: Volume): File = File(volume.path, TRASH_DIR)
}
