package app.dexfiles.ui

import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.relocation.bringIntoViewRequester
import app.dexfiles.ui2.design.Radius
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import app.dexfiles.core.SearchQuery
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.core.FileEntry
import app.dexfiles.state.TabState

/** Marks the letters of [name] that the search typed so far matched: whole words first, otherwise the letters in order. */
fun highlightName(name: String, query: String, mark: Color): androidx.compose.ui.text.AnnotatedString {
    val terms = SearchQuery.parse(query).terms.filter { it.isNotBlank() }
    if (terms.isEmpty()) return androidx.compose.ui.text.AnnotatedString(name)
    val on = BooleanArray(name.length)
    for (t in terms) {
        val i = name.indexOf(t, ignoreCase = true)
        if (i >= 0) {
            for (k in i until i + t.length) on[k] = true
        } else {
            var p = 0
            val hit = ArrayList<Int>()
            for (c in t) {
                val j = name.indexOf(c, p, ignoreCase = true)
                if (j < 0) { hit.clear(); break }
                hit.add(j); p = j + 1
            }
            hit.forEach { on[it] = true }
        }
    }
    return buildAnnotatedString {
        var k = 0
        while (k < name.length) {
            var j = k
            while (j < name.length && on[j] == on[k]) j++
            if (on[k]) withStyle(SpanStyle(color = mark, fontWeight = FontWeight.Bold)) { append(name.substring(k, j)) }
            else append(name.substring(k, j))
            k = j
        }
    }
}

/** The one place a file's name is drawn: highlights search matches, and turns into an editable field while renaming. */
@Composable
fun EntryName(
    vm: ExplorerViewModel,
    tab: TabState,
    e: FileEntry,
    style: TextStyle,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    maxLines: Int = 1,
    textAlign: TextAlign = TextAlign.Unspecified,
) {
    if (vm.renaming == e.path) {
        RenameField(vm, e, style, modifier, textAlign)
        return
    }
    val mark = MaterialTheme.colorScheme.primary
    val text = remember(e.name, tab.query, tab.isSearch, mark) {
        if (tab.isSearch && tab.query.isNotBlank()) highlightName(e.name, tab.query, mark) else androidx.compose.ui.text.AnnotatedString(e.name)
    }
    Text(text, style = style, color = color, maxLines = maxLines, overflow = TextOverflow.Ellipsis, textAlign = textAlign, modifier = modifier)
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun RenameField(vm: ExplorerViewModel, e: FileEntry, style: TextStyle, modifier: Modifier, textAlign: TextAlign) {
    val cs = MaterialTheme.colorScheme
    val stem = if (e.isDir || !e.name.contains('.') || e.name.startsWith(".") && e.name.count { it == '.' } == 1) e.name.length else e.name.lastIndexOf('.')
    var value by remember(e.path) { mutableStateOf(TextFieldValue(e.name, TextRange(0, stem))) }
    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    var finished by remember(e.path) { mutableStateOf(false) }
    var focused by remember(e.path) { mutableStateOf(false) }
    fun commit() {
        if (finished) return
        finished = true
        val n = value.text.trim()
        if (n.isEmpty() || n == e.name) { vm.endRename(true); return }
        val err = vm.renameNow(e, n)
        vm.endRename(err != null)
        if (err != null) vm.toast(err)
    }
    fun cancel() { finished = true; vm.endRename(true) }
    DisposableEffect(Unit) { vm.typing = true; vm.renameClaimed = true; onDispose { vm.typing = false; vm.renameClaimed = false } }
    LaunchedEffect(e.path) { focus.requestFocus(); kb?.show() }
    BackHandler { cancel() }
    // Hiding the keyboard (its own back press) also ends the rename, so nothing stays half-edited.
    val imeUp = androidx.compose.foundation.layout.WindowInsets.isImeVisible
    var imeSeen by remember(e.path) { mutableStateOf(false) }
    LaunchedEffect(imeUp) { if (imeUp) imeSeen = true else if (imeSeen) cancel() }
    val reveal = remember { androidx.compose.foundation.relocation.BringIntoViewRequester() }
    var fieldSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val dens = androidx.compose.ui.platform.LocalDensity.current
    // Bring the whole tile (field plus the line under it) into view with some air around it, not just the field itself.
    LaunchedEffect(imeUp) {
        if (imeUp) {
            kotlinx.coroutines.delay(320)
            val up = with(dens) { 28.dp.toPx() }; val down = with(dens) { 64.dp.toPx() }
            reveal.bringIntoView(androidx.compose.ui.geometry.Rect(0f, -up, fieldSize.width.toFloat(), fieldSize.height + down))
        }
    }
    BasicTextField(
        value = value,
        onValueChange = { value = it.copy(text = it.text.replace("\n", "")) },
        singleLine = true,
        textStyle = style.copy(color = cs.onSurface, textAlign = textAlign),
        cursorBrush = SolidColor(cs.primary),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { commit() }),
        modifier = modifier
            .bringIntoViewRequester(reveal)
            .onSizeChanged { fieldSize = it }
            .background(cs.surfaceVariant.copy(alpha = 0.7f), Radius.xs)
            .padding(horizontal = 6.dp, vertical = 2.dp)
            .focusRequester(focus)
            .onFocusChanged { if (it.isFocused) focused = true else if (focused) commit() }
            .onPreviewKeyEvent {
                if (it.type == KeyEventType.KeyDown && it.key == Key.Escape) { cancel(); true } else false
            },
    )
}

/** Search results ease in one after another (the first dozen), so narrowing the list feels alive instead of snapping. */
fun Modifier.resultIn(active: Boolean, key: Any, index: Int): Modifier = composed {
    if (!active) return@composed this
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        kotlinx.coroutines.delay((index.coerceAtMost(12) * 22).toLong())
        a.animateTo(1f, tween(220, easing = FastOutSlowInEasing))
    }
    this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14f }
}
