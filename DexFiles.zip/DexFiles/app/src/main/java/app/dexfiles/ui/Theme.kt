package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import app.dexfiles.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Colours come from the design system (ui2/design/Palette.kt) so the whole app has one source of truth.

private fun schemeOf(p: app.dexfiles.ui2.design.Palette, dark: Boolean): ColorScheme {
    val hi = if (dark) Color(0xFF26262B) else Color(0xFFE3E3E9)
    val outlineV = if (dark) Color(0xFF1C1C20) else Color(0xFFE6E6EC)
    return if (dark) darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, primaryContainer = p.accentSoft, onPrimaryContainer = p.accent,
        secondary = p.textDim, onSecondary = p.canvas, secondaryContainer = p.accentSoft, onSecondaryContainer = p.accent,
        background = p.canvas, onBackground = p.text, surface = p.card, onSurface = p.text,
        surfaceVariant = p.raised, onSurfaceVariant = p.textDim,
        surfaceContainerLowest = p.canvas, surfaceContainerLow = p.card, surfaceContainer = p.raised,
        surfaceContainerHigh = p.overlay, surfaceContainerHighest = hi,
        outline = p.textFaint, outlineVariant = outlineV, error = p.danger,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, primaryContainer = p.accentSoft, onPrimaryContainer = p.accent,
        secondary = p.textDim, onSecondary = p.card, secondaryContainer = p.accentSoft, onSecondaryContainer = p.accent,
        background = p.canvas, onBackground = p.text, surface = p.card, onSurface = p.text,
        surfaceVariant = p.raised, onSurfaceVariant = p.textDim,
        surfaceContainerLowest = p.card, surfaceContainerLow = p.card, surfaceContainer = p.raised,
        surfaceContainerHigh = p.overlay, surfaceContainerHighest = hi,
        outline = p.textFaint, outlineVariant = outlineV, error = p.danger,
    )
}

/** Inter (SIL Open Font License, see assets/licenses): clean and neutral, close in feel to the system fonts of iPadOS and One UI. */
val InterFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun Typography.withFont(f: FontFamily) = copy(
    displayLarge = displayLarge.copy(fontFamily = f),
    displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f),
    headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f),
    titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f),
    bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f),
    labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f),
)

/** Slightly larger than a desktop app so it stays comfortable to read and tap on a tablet. */
private val DexTypography: Typography = Typography().let { t ->
    t.copy(
        headlineSmall = t.headlineSmall.copy(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
        titleLarge = t.titleLarge.copy(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
        titleMedium = t.titleMedium.copy(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
        titleSmall = t.titleSmall.copy(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
        // Scale taken from the approved mock: row names 16/500, dates and sizes 13, menu text 14/500, captions 12/600.
        bodyLarge = t.bodyLarge.copy(letterSpacing = 0.sp, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
        bodyMedium = t.bodyMedium.copy(letterSpacing = 0.sp, fontSize = 14.sp, lineHeight = 20.sp),
        bodySmall = t.bodySmall.copy(letterSpacing = 0.sp, fontSize = 13.sp, lineHeight = 18.sp)
        labelLarge = t.labelLarge.copy(letterSpacing = 0.sp, fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
        labelMedium = t.labelMedium.copy(letterSpacing = 0.sp, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold),
        labelSmall = t.labelSmall.copy(letterSpacing = 0.sp, fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium),
    ).withFont(InterFamily)
}

private val DexShapes = androidx.compose.material3.Shapes(
    extraSmall = Radius.s,
    small = Radius.m,
    medium = Radius.l,
    large = Radius.xl,
    extraLarge = Radius.xl,
)

@Composable
fun DexTheme(mode: Int, textSize: Int = 16, fontMode: Int = 0, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val palette = if (dark) app.dexfiles.ui2.design.DarkPalette else app.dexfiles.ui2.design.LightPalette
    val scheme: ColorScheme = schemeOf(palette, dark)
    androidx.compose.runtime.CompositionLocalProvider(app.dexfiles.ui2.design.LocalPalette provides palette) {
        val d = androidx.compose.ui.platform.LocalDensity.current
        // Text size setting: 16 is the design size; every step scales all text by 1/16.
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density, d.fontScale * (textSize / 16f)),
        ) {
            MaterialTheme(colorScheme = scheme, typography = if (fontMode == 1) DexTypography.withFont(FontFamily.Default) else DexTypography, shapes = DexShapes) {
                // Surface supplies the default text colour; without it text stays black on dark backgrounds.
                Surface(color = scheme.background, contentColor = scheme.onBackground, content = content)
            }
        }
    }
}
