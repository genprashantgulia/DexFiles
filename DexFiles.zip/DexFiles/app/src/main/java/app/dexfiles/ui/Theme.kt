package app.dexfiles.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp

private val Accent = Color(0xFF1B6EF3)

private val LightScheme = lightColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E6FF),
    onPrimaryContainer = Color(0xFF001B3F),
    secondaryContainer = Color(0xFFDCE6F7),
    background = Color(0xFFF7F8FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE9ECF1),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7AA9FF),
    onPrimary = Color(0xFF00255C),
    primaryContainer = Color(0xFF1B3D78),
    onPrimaryContainer = Color(0xFFD8E6FF),
    secondaryContainer = Color(0xFF2B3750),
    background = Color(0xFF16181C),
    surface = Color(0xFF1C1F24),
    surfaceVariant = Color(0xFF2A2E35),
)

/** Compact sizes: this is a pointer-and-keyboard desktop app, not a phone app. */
private val DexTypography: Typography = Typography().let { t ->
    t.copy(
        titleLarge = t.titleLarge.copy(fontSize = 20.sp, lineHeight = 26.sp),
        titleMedium = t.titleMedium.copy(fontSize = 15.sp, lineHeight = 20.sp),
        titleSmall = t.titleSmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
        bodyLarge = t.bodyLarge.copy(fontSize = 14.sp, lineHeight = 20.sp),
        bodyMedium = t.bodyMedium.copy(fontSize = 13.sp, lineHeight = 18.sp),
        bodySmall = t.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp),
        labelLarge = t.labelLarge.copy(fontSize = 13.sp, lineHeight = 18.sp),
        labelMedium = t.labelMedium.copy(fontSize = 12.sp, lineHeight = 16.sp),
        labelSmall = t.labelSmall.copy(fontSize = 11.sp, lineHeight = 14.sp),
    )
}

@Composable
fun DexTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme: ColorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    MaterialTheme(colorScheme = scheme, typography = DexTypography, content = content)
}
