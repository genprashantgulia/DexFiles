package app.dexfiles.core

import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes

/** Immutable snapshot of one file or folder as shown in a listing. */
data class FileEntry(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val isHidden: Boolean,
) {
    val kind: FileKind get() = FileTypes.kindOf(name, isDir)
    val ext: String get() = FileTypes.extensionOf(name)
    val parentPath: String? get() = File(path).parent
    fun toFile(): File = File(path)

    companion object {
        /** One stat call per entry (instead of four) keeps big folders fast. */
        fun from(f: File): FileEntry {
            val name = f.name
            return try {
                val a = Files.readAttributes(f.toPath(), BasicFileAttributes::class.java)
                FileEntry(f.path, name, a.isDirectory, if (a.isDirectory) 0L else a.size(), a.lastModifiedTime().toMillis(), name.startsWith("."))
            } catch (e: Exception) {
                val dir = f.isDirectory
                FileEntry(f.path, name, dir, if (dir) 0L else f.length(), f.lastModified(), name.startsWith("."))
            }
        }
    }
}

object Listing {
    /** Lists a directory. Throws [java.io.IOException] if it can't be read (permissions, removed drive...). */
    fun list(dir: File, showHidden: Boolean): List<FileEntry> {
        val files = dir.listFiles() ?: throw java.io.IOException("Can't open this folder. It may be protected or no longer exist.")
        val out = ArrayList<FileEntry>(files.size)
        for (f in files) {
            if (!showHidden && f.name.startsWith(".")) continue
            out.add(FileEntry.from(f))
        }
        return out
    }
}
