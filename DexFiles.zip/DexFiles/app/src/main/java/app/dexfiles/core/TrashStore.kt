package app.dexfiles.core

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Properties
import java.util.Random

/**
 * A recycle bin that lives inside a storage volume (so moving into it is an instant rename).
 * Layout: root/<id>/<original name> plus root/<id>/.info with the original location.
 */
class TrashStore(val root: File) {
    data class Item(
        val id: String,
        val name: String,
        val originalPath: String,
        val deletedAt: Long,
        val size: Long,
        val isDir: Boolean,
        val file: File,
    )

    private val random = Random()

    private fun newId(): String =
        java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Integer.toString(random.nextInt(46656), 36)

    fun moveToTrash(f: File): Item {
        if (!root.exists()) root.mkdirs()
        try {
            File(root, ".nomedia").createNewFile()
        } catch (_: Exception) {
        }
        val id = newId()
        val dir = File(root, id)
        if (!dir.mkdirs()) throw FileOpException("Can't create the trash folder")
        val isDir = f.isDirectory
        val size = FileOps.sizeOf(f)
        val now = System.currentTimeMillis()
        val p = Properties()
        p.setProperty("name", f.name)
        p.setProperty("original", f.path)
        p.setProperty("deleted", now.toString())
        p.setProperty("size", size.toString())
        p.setProperty("dir", isDir.toString())
        FileOutputStream(File(dir, ".info")).use { p.store(it, null) }
        val stored = File(dir, f.name)
        if (!f.renameTo(stored)) {
            val r = FileOps.move(listOf(f), dir, OnConflict.REPLACE)
            if (!r.ok) {
                FileOps.deleteRecursive(dir)
                throw FileOpException(r.failures.firstOrNull() ?: "Couldn't move to trash")
            }
        }
        return Item(id, f.name, f.path, now, size, isDir, stored)
    }

    fun list(): List<Item> {
        val dirs = root.listFiles { x -> x.isDirectory } ?: return emptyList()
        val out = ArrayList<Item>()
        for (d in dirs) {
            val info = File(d, ".info")
            if (!info.exists()) continue
            try {
                val p = Properties()
                FileInputStream(info).use { p.load(it) }
                val name = p.getProperty("name") ?: continue
                val stored = File(d, name)
                if (!stored.exists()) continue
                out.add(
                    Item(
                        id = d.name,
                        name = name,
                        originalPath = p.getProperty("original") ?: "",
                        deletedAt = p.getProperty("deleted")?.toLongOrNull() ?: 0L,
                        size = p.getProperty("size")?.toLongOrNull() ?: 0L,
                        isDir = p.getProperty("dir") == "true",
                        file = stored,
                    ),
                )
            } catch (_: Exception) {
            }
        }
        return out.sortedByDescending { it.deletedAt }
    }

    /** Puts the item back where it came from (with a "(1)" suffix if the name is taken). Returns the restored file. */
    fun restore(item: Item): File {
        val parent = File(item.originalPath).parentFile ?: throw FileOpException("Original location is unknown")
        if (!parent.exists() && !parent.mkdirs()) throw FileOpException("Original folder no longer exists")
        val target = FileOps.uniqueChild(parent, item.name, item.isDir)
        if (!item.file.renameTo(target)) {
            val r = FileOps.move(listOf(item.file), parent, OnConflict.KEEP_BOTH)
            if (!r.ok) throw FileOpException(r.failures.firstOrNull() ?: "Couldn't restore")
            FileOps.deleteRecursive(File(root, item.id))
            return File(r.created.firstOrNull() ?: target.path)
        }
        FileOps.deleteRecursive(File(root, item.id))
        return target
    }

    fun purge(item: Item) {
        FileOps.deleteRecursive(File(root, item.id))
    }

    fun empty(): Int {
        val items = list()
        items.forEach { purge(it) }
        return items.size
    }

    /** Deletes items older than [days]; returns how many were removed. */
    fun purgeOlderThan(days: Int, now: Long = System.currentTimeMillis()): Int {
        val cutoff = now - days * 86_400_000L
        var n = 0
        for (i in list()) {
            if (i.deletedAt in 1 until cutoff) {
                purge(i)
                n++
            }
        }
        return n
    }
}
