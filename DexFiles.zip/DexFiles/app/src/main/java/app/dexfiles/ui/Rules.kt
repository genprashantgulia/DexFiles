package app.dexfiles.ui

import app.dexfiles.state.Loc
import app.dexfiles.state.TabState

/** What is allowed where. Every menu, bar and shortcut asks here, so a rule can't differ from one screen to the next. */
object Rules {
    /** Rename acts on the file itself, so it works anywhere a real file is listed (categories, Recent, search), never in Trash. */
    fun canRename(tab: TabState) = tab.path != Loc.TRASH

    /** New folder / paste need a real folder to put things in. */
    fun canWriteHere(tab: TabState) = !tab.isVirtual && !tab.isSearch
}
