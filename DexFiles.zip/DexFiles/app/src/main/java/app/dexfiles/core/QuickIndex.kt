package app.dexfiles.core

import java.io.File
import java.nio.file.Files
import java.util.Locale

/**
 * Folder index behind the Ctrl+K palette. A breadth-first walk so shallow folders (the ones you jump to most) are always indexed
 * first, even when the cap is hit. Hidden folders, symlinks and the locked Android/ tree are skipped.
 */
object QuickIndex {
    const val MAX_FOLDERS = 40_000
    const val MAX_DEPTH = 10

    fun scan(roots: List<String>, cancel: CancelToken): List<String> {
        val out = ArrayList<String>()
        var level = roots.map { File(it) }
        var depth = 0
        while (level.isNotEmpty() && depth < MAX_DEPTH && out.size < MAX_FOLDERS) {
            val next = ArrayList<File>()
            for (dir in level) {
                cancel.check()
                val kids = dir.listFiles() ?: continue
                for (k in kids) {
                    if (out.size >= MAX_FOLDERS) break
                    if (!k.isDirectory || k.name.startsWith('.')) continue
                    if (depth == 0 && k.name.equals("Android", ignoreCase = true)) continue
                    if (Files.isSymbolicLink(k.toPath())) continue
                    out.add(k.path)
                    next.add(k)
                }
            }
            level = next
            depth++
        }
        return out
    }

    /**
     * Every space-separated word of [query] must appear in [name] (best) or [path]. Matches at the start of the name or of a word
     * rank higher, and shorter, shallower results rank higher. Returns -1 for no match.
     */
    fun score(query: List<String>, name: String, path: String): Int {
        if (query.isEmpty()) return 0
        val n = name.lowercase(Locale.ROOT)
        var total = 0
        for (w in query) {
            val i = n.indexOf(w)
            total += when {
                i == 0 -> 100
                i > 0 && !n[i - 1].isLetterOrDigit() -> 80
                i > 0 -> 50
                path.lowercase(Locale.ROOT).contains(w) -> 10
                else -> return -1
            }
        }
        val depth = path.count { it == '/' }
        return total * 4 - n.length.coerceAtMost(60) - depth
    }

    fun words(q: String): List<String> = q.trim().lowercase(Locale.ROOT).split(' ').filter { it.isNotEmpty() }
}
