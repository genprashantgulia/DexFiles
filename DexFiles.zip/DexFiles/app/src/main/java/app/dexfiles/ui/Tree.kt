package app.dexfiles.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.Listing
import app.dexfiles.core.Sorting
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class TreeRow(val e: FileEntry, val depth: Int)

/** Flat list of rows with folders expanded in place (iPadOS Files list view): the chevron opens a folder under itself, indented. */
class TreeModel(val rows: List<TreeRow>, val enabled: Boolean, val isOpen: (String) -> Boolean, val toggle: (String) -> Unit)

@Composable
fun rememberTree(vm: ExplorerViewModel, tab: TabState, enabled: Boolean): TreeModel {
    val open = remember(tab.id, tab.path) { mutableStateListOf<String>() }
    val kids = remember(tab.id, tab.path, tab.effectiveSort, vm.showHidden) { mutableStateMapOf<String, List<FileEntry>>() }
    val snapshot = open.toList()
    LaunchedEffect(snapshot, kids) {
        for (p in snapshot) {
            if (p in kids) continue
            val l = withContext(Dispatchers.IO) {
                runCatching { Sorting.sort(Listing.list(File(p), vm.showHidden), tab.effectiveSort) }.getOrDefault(emptyList())
            }
            l.forEach { vm.treeEntries[it.path] = it }
            kids[p] = l
        }
    }
    val rows = ArrayList<TreeRow>(tab.entries.size + 16)
    fun add(list: List<FileEntry>, depth: Int) {
        for (e in list) {
            rows += TreeRow(e, depth)
            if (enabled && e.isDir && e.path in open) kids[e.path]?.let { add(it, depth + 1) }
        }
    }
    add(tab.entries, 0)
    return TreeModel(rows, enabled, { it in open }, { p -> if (p in open) open.remove(p) else open.add(p) })
}

@Composable
fun TreeChevron(open: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(
            Icons.Filled.ChevronRight, contentDescription = if (open) "Collapse" else "Expand",
            modifier = Modifier.size(22.dp).rotate(if (open) 90f else 0f), tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
