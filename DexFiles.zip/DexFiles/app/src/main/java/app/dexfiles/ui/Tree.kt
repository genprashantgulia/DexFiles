package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.Listing
import app.dexfiles.core.Sorting
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class TreeRow(val e: FileEntry, val depth: Int)

/** Flat list of rows with folders expanded in place (iPadOS Files list view): the chevron opens a folder under itself, indented. */
class TreeModel(val rows: List<TreeRow>, val enabled: Boolean, val isOpen: (String) -> Boolean, val toggle: (String) -> Unit)

@Composable
fun rememberTree(vm: ExplorerViewModel, tab: TabState, enabled: Boolean): TreeModel {
    val open = remember(tab.id, tab.path) { mutableStateListOf<String>() }
    val kids = remember(tab.id, tab.path, tab.effectiveSort, vm.showHidden) { mutableStateMapOf<String, List<FileEntry>>() }
    val snapshot = open.toList()
    LaunchedEffect(snapshot, kids) {
        for (p in snapshot) {
            if (p in kids) continue
            val l = withContext(Dispatchers.IO) {
                runCatching { Sorting.sort(Listing.list(File(p), vm.showHidden), tab.effectiveSort) }.getOrDefault(emptyList())
            }
            l.forEach { vm.treeEntries[it.path] = it }
            kids[p] = l
        }
    }
    val rows = ArrayList<TreeRow>(tab.entries.size + 16)
    fun add(list: List<FileEntry>, depth: Int) {
        for (e in list) {
            rows += TreeRow(e, depth)
            if (enabled && e.isDir && e.path in open) kids[e.path]?.let { add(it, depth + 1) }
        }
    }
    add(tab.entries, 0)
    return TreeModel(rows, enabled, { it in open }, { p -> if (p in open) open.remove(p) else open.add(p) })
}

@Composable
fun TreeChevron(open: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(
            DexIcons.ChevronRight, contentDescription = if (open) "Collapse" else "Expand",
            modifier = Modifier.size(22.dp).rotate(if (open) 90f else 0f), tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}


/** Folder has something to reveal (respects hidden files). Cached so rows never pop twice while scrolling. */
private object KidsCache {
    private val map = object : java.util.LinkedHashMap<String, Boolean>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 3000
    }
    @Synchronized fun get(k: String): Boolean? = map[k]
    @Synchronized fun put(k: String, v: Boolean) { map[k] = v }
}

/**
 * The one expand slot used by List and Details: a 32dp column in front of the thumbnail.
 * Folders with contents show the arrow (fades in once counted); empty folders and files keep the slot blank so icons stay aligned.
 */
@Composable
fun ExpandLead(vm: ExplorerViewModel, tree: TreeModel, e: FileEntry) {
    if (!tree.enabled) return
    if (!e.isDir) { androidx.compose.foundation.layout.Spacer(Modifier.size(32.dp)); return }
    val key = e.path + "|" + e.modified + "|" + vm.showHidden
    val has by androidx.compose.runtime.produceState(KidsCache.get(key) ?: false, key) {
        value = KidsCache.get(key) ?: withContext(Dispatchers.IO) {
            runCatching { File(e.path).list()?.any { vm.showHidden || !it.startsWith(".") } ?: false }.getOrDefault(false)
        }.also { KidsCache.put(key, it) }
    }
    val a by androidx.compose.animation.core.animateFloatAsState(if (has) 1f else 0f, androidx.compose.animation.core.tween(140), label = "expandSlot")
    Box(Modifier.size(32.dp).graphicsLayer { alpha = a }) {
        if (has) TreeChevron(tree.isOpen(e.path)) { tree.toggle(e.path) }
    }
}
