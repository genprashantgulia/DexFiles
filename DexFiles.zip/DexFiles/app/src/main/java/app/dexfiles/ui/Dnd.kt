@file:OptIn(ExperimentalFoundationApi::class)

package app.dexfiles.ui

import android.view.View
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipPath
import app.dexfiles.ui.DragThumbs
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlinx.coroutines.launch
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.draganddrop.dragAndDropSource
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.DragAndDropTransferData
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.data.Opener
import app.dexfiles.state.DragPayload
import app.dexfiles.state.Mods
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState

// ---------------------------------------------------------------------------------------------- drop zones

/** How long a drag must rest on a folder, tab or sidebar branch before it opens. One value, so every target behaves the same. */
const val SPRING_MS = 650L

class DragSession(val key: () -> Any, val rebuild: () -> Unit, val paths: () -> List<String> = { emptyList() })

/** One folder (row, tile, tab, sidebar node, pane) that can receive a drop. Bounds are read live at hit-test time. */
class DropZone {
    var coords: androidx.compose.ui.layout.LayoutCoordinates? = null
    var dest: String? = null
    /** A zone that accepts the drop and does nothing with it: the "drop here to cancel" pill. */
    var cancel = false
    var onHover: (Boolean) -> Unit = {}
    var onMove: ((Float) -> Unit)? = null
    var onDropped: (() -> Unit)? = null
}

/**
 * Compose's own nested drop targets only learn about a node when a drag STARTS, so folders that appear mid-drag
 * (a sidebar branch that springs open, rows that scroll into view) never highlight. Zones register here as they are composed and one
 * window-wide target hit-tests them on every move, so what you point at is always what lights up and receives the drop.
 */
class DropRegistry {
    val zones = ArrayList<DropZone>()
    var hovered: DropZone? = null
    var active by androidx.compose.runtime.mutableStateOf(false)
    /** The lift in progress, so the picture and the payload can follow the selection while the finger is still down. */
    var session by androidx.compose.runtime.mutableStateOf<DragSession?>(null)
    /** What releasing here would do, e.g. "Move 3 to Trip"; null when the pointer is not over a target. */
    var label by androidx.compose.runtime.mutableStateOf<String?>(null)
    var labeler: ((DropZone) -> String?)? = null
    private var lastX = 0f
    private var lastY = 0f

    private fun rect(z: DropZone): androidx.compose.ui.geometry.Rect? {
        val c = z.coords ?: return null
        if (!c.isAttached) return null
        return c.boundsInRoot()
    }

    private fun hit(x: Float, y: Float): DropZone? {
        var best: DropZone? = null
        var bestArea = Float.MAX_VALUE
        for (z in zones) {
            if (z.dest == null && !z.cancel) continue
            val r = rect(z) ?: continue
            if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) {
                val a = r.width * r.height
                if (a < bestArea) { best = z; bestArea = a }
            }
        }
        return best
    }

    fun update(x: Float, y: Float) {
        lastX = x; lastY = y; active = true
        for (z in zones.toList()) {
            val mv = z.onMove ?: continue
            val r = rect(z) ?: continue
            if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) mv(y)
        }
        val h = hit(x, y)
        if (h !== hovered) { hovered?.onHover(false); hovered = h; h?.onHover(true) }
        // Recomputed on every move: holding Ctrl flips Move to Copy while the stack is in the air.
        label = h?.takeIf { !it.cancel }?.let { labeler?.invoke(it) }
    }

    fun refresh() = update(lastX, lastY)

    fun clear() { hovered?.onHover(false); hovered = null; active = false; label = null }
}

private val registries = java.util.WeakHashMap<ExplorerViewModel, DropRegistry>()
fun dropRegistry(vm: ExplorerViewModel): DropRegistry = registries.getOrPut(vm) { DropRegistry() }

/** The single window-wide drop target. Put it once on the outermost container. */
@Composable
fun Modifier.dropRoot(vm: ExplorerViewModel): Modifier {
    val activity = LocalHostActivity.current
    val reg = remember(vm) { dropRegistry(vm) }
    // While the list scrolls under a still finger the pointer does not move, so re-test the zones on a short tick.
    androidx.compose.runtime.LaunchedEffect(reg.active) {
        while (reg.active) { kotlinx.coroutines.delay(70); reg.refresh() }
    }
    androidx.compose.runtime.LaunchedEffect(reg.session) {
        val sess = reg.session ?: return@LaunchedEffect
        androidx.compose.runtime.snapshotFlow { sess.key() }.collect { sess.rebuild() }
    }
    reg.labeler = { z ->
        val d = z.dest
        if (d == null) null else {
            val paths = reg.session?.paths?.invoke().orEmpty()
            val name = vm.rootLabelMap()[d] ?: java.io.File(d).name.ifEmpty { d }
            val n = paths.size
            when {
                n > 0 && paths.all { java.io.File(it).parent == d } -> "Already in $name"
                n == 0 -> "Copy to $name"
                else -> (if (vm.dropMoves(paths, d, Mods.ctrl)) "Move " else "Copy ") + (if (n == 1) "1 item" else "$n items") + " to $name"
            }
        }
    }
    val target = remember(vm) {
        object : DragAndDropTarget {
            override fun onEntered(event: DragAndDropEvent) { val a = event.toAndroidDragEvent(); reg.update(a.x, a.y) }
            override fun onMoved(event: DragAndDropEvent) { val a = event.toAndroidDragEvent(); reg.update(a.x, a.y) }
            override fun onExited(event: DragAndDropEvent) { reg.clear(); vm.dragScrollDir = 0f }
            override fun onEnded(event: DragAndDropEvent) { reg.clear(); reg.session = null; vm.dragScrollDir = 0f }
            override fun onDrop(event: DragAndDropEvent): Boolean {
                val a = event.toAndroidDragEvent()
                reg.update(a.x, a.y)
                val z = reg.hovered
                val d = z?.dest
                val cancelled = z?.cancel == true
                reg.clear()
                reg.session = null
                vm.dragScrollDir = 0f
                if (cancelled) return true
                if (z == null || d == null) return false
                val ok = vm.handleDrop(a, activity, d)
                if (ok) z.onDropped?.invoke()
                return ok
            }
        }
    }
    return this.dragAndDropTarget(shouldStartDragAndDrop = { true }, target = target)
}

/**
 * Makes a view a drop zone: our own rows (move, or copy with Ctrl), and files dragged in from other apps or windows (copied in).
 * [dest] is the folder that receives the drop, or null to refuse. The smallest zone under the pointer wins, so a folder row beats the pane around it.
 */
@Composable
fun Modifier.folderDrop(vm: ExplorerViewModel, dest: String?, onMove: ((Float) -> Unit)? = null, onDropped: (() -> Unit)? = null, onHover: (Boolean) -> Unit): Modifier =
    dropZone(vm, dest, false, onMove, onDropped, onHover)

/** The cancel pill's zone: dropping on it ends the drag without moving or copying anything. */
@Composable
fun Modifier.cancelDrop(vm: ExplorerViewModel, onHover: (Boolean) -> Unit): Modifier = dropZone(vm, null, true, null, null, onHover)

@Composable
private fun Modifier.dropZone(vm: ExplorerViewModel, dest: String?, cancel: Boolean, onMove: ((Float) -> Unit)?, onDropped: (() -> Unit)?, onHover: (Boolean) -> Unit): Modifier {
    val reg = remember(vm) { dropRegistry(vm) }
    val zone = remember { DropZone() }
    zone.dest = dest
    zone.cancel = cancel
    zone.onHover = onHover
    zone.onMove = onMove
    zone.onDropped = onDropped
    androidx.compose.runtime.DisposableEffect(reg, zone) {
        reg.zones.add(zone)
        onDispose { reg.zones.remove(zone); if (reg.hovered === zone) reg.hovered = null }
    }
    return this.onGloballyPositioned { zone.coords = it }
}

// ---------------------------------------------------------------------------------------------- drag picture

private class StackShadow(view: View, val bmp: android.graphics.Bitmap, val tx: Int, val ty: Int) : View.DragShadowBuilder(view) {
    override fun onProvideShadowMetrics(outShadowSize: android.graphics.Point, outShadowTouchPoint: android.graphics.Point) {
        outShadowSize.set(bmp.width, bmp.height)
        outShadowTouchPoint.set(tx, ty)
    }
    override fun onDrawShadow(canvas: android.graphics.Canvas) { canvas.drawBitmap(bmp, 0f, 0f, null) }
}

private class StackPic(val bmp: android.graphics.Bitmap, val tx: Int, val ty: Int)

/** Theme colours the stack picture needs, as ARGB ints (it is a bitmap, drawn outside Compose). Rebuilt on every recomposition, so a theme switch applies at once. */
private class StackPal(val primary: Int, val onPrimary: Int, val ring: Int, val dark: Boolean)

/**
 * The lifted stack, drawn by us at one fixed size so it is the same in every view (the system clips a Compose decoration to the row you grabbed,
 * which made it tiny in List and Columns). Fully opaque. Each card is the file's real thumbnail, or its type tile (the same colour and label as the
 * list icon), edged with a hairline that works on both dark and light backgrounds. Count badge for several items, name pill for one.
 */
private fun renderStack(ctx: android.content.Context, e: FileEntry, others: List<FileEntry>, n: Int, pal: StackPal, pulse: Float = 0f): StackPic {
    val d = ctx.resources.displayMetrics.density
    fun dp(v: Float) = v * d
    val primary = pal.primary; val onPrimary = pal.onPrimary
    val pad = dp(20f); val card = dp(96f); val w = dp(236f)
    val cardL = (w - card) / 2f; val cardT = pad
    val pill = if (n == 1) dp(44f) else 0f
    val h = pad + card + pill + pad
    val bmp = android.graphics.Bitmap.createBitmap(w.toInt(), h.toInt(), android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    val r = dp(18f)
    val rect = android.graphics.RectF(cardL, cardT, cardL + card, cardT + card)
    val cx = rect.centerX(); val cy = rect.centerY()
    val edge = if (pal.dark) 0x55FFFFFF else 0x33000000
    val shade = if (pal.dark) 0x99000000.toInt() else 0x55000000

    // Coil keeps hardware bitmaps, which a software canvas refuses to draw; copy them to ordinary ones first.
    fun soft(b: android.graphics.Bitmap?): android.graphics.Bitmap? =
        if (b == null) null else if (b.config == android.graphics.Bitmap.Config.HARDWARE) runCatching { b.copy(android.graphics.Bitmap.Config.ARGB_8888, false) }.getOrNull() else b

    /** One card: thumbnail if there is one, otherwise the type tile (folder glyph or extension label). */
    fun drawCard(x: FileEntry) {
        val thumb = if (x.isDir) null else soft(DragThumbs.get(x.path))
        p.reset(); p.isAntiAlias = true; p.isFilterBitmap = true
        p.color = when {
            x.isDir -> if (pal.dark) 0xFF2C2C32.toInt() else 0xFFFFFFFF.toInt()
            else -> tileColor(x.kind).toArgb()
        }
        p.setShadowLayer(dp(12f), 0f, dp(5f), shade)
        c.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        if (thumb != null) {
            val side = minOf(thumb.width, thumb.height)
            val src = android.graphics.Rect((thumb.width - side) / 2, (thumb.height - side) / 2, (thumb.width + side) / 2, (thumb.height + side) / 2)
            val path = android.graphics.Path().apply { addRoundRect(rect, r, r, android.graphics.Path.Direction.CW) }
            c.save(); c.clipPath(path); c.drawBitmap(thumb, src, rect, p); c.restore()
        } else if (x.isDir) {
            p.reset(); p.isAntiAlias = true
            p.color = kindColor(app.dexfiles.core.FileKind.FOLDER).toArgb()
            c.drawRoundRect(android.graphics.RectF(cx - dp(26f), cy - dp(22f), cx - dp(2f), cy - dp(10f)), dp(4f), dp(4f), p)
            c.drawRoundRect(android.graphics.RectF(cx - dp(28f), cy - dp(15f), cx + dp(28f), cy + dp(20f)), dp(8f), dp(8f), p)
        } else {
            p.reset(); p.isAntiAlias = true
            p.color = 0xFFFFFFFF.toInt(); p.textSize = dp(19f); p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.textAlign = android.graphics.Paint.Align.CENTER
            c.drawText(x.name.substringAfterLast('.', "FILE").take(4).uppercase(), cx, cy + dp(7f), p)
        }
        p.reset(); p.isAntiAlias = true; p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = dp(1.25f); p.color = edge
        c.drawRoundRect(rect, r, r, p)
    }

    val grow = 1f + 0.07f * pulse
    c.save(); c.scale(grow, grow, cx, cy)
    if (n >= 3) { c.save(); c.rotate(-9f, cx, cy); drawCard(others.getOrElse(1) { e }); c.restore() }
    if (n >= 2) { c.save(); c.rotate(7f, cx, cy); drawCard(others.getOrElse(0) { e }); c.restore() }
    drawCard(e)
    c.restore()
    if (n > 1) {
        val bx = rect.right - dp(2f); val by = rect.top + dp(4f)
        val br = dp(17f) * (1f + 0.4f * pulse)
        p.reset(); p.isAntiAlias = true; p.color = primary; p.setShadowLayer(dp(5f), 0f, dp(2f), 0x66000000)
        c.drawCircle(bx, by, br, p); p.clearShadowLayer()
        p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = dp(2.5f); p.color = pal.ring; c.drawCircle(bx, by, br, p)
        p.reset(); p.isAntiAlias = true; p.color = onPrimary; p.textSize = dp(15f); p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.textAlign = android.graphics.Paint.Align.CENTER
        c.drawText(if (n > 99) "99+" else n.toString(), bx, by + dp(5.2f), p)
    } else {
        p.reset(); p.isAntiAlias = true; p.textSize = dp(14f); p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val label = android.text.TextUtils.ellipsize(e.name, android.text.TextPaint(p), dp(200f), android.text.TextUtils.TruncateAt.MIDDLE).toString()
        val tw = p.measureText(label)
        val pw = tw + dp(28f); val ph = dp(30f)
        val pr = android.graphics.RectF(w / 2 - pw / 2, rect.bottom + dp(10f), w / 2 + pw / 2, rect.bottom + dp(10f) + ph)
        val q = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); q.color = primary; q.setShadowLayer(dp(8f), 0f, dp(3f), 0x55000000)
        c.drawRoundRect(pr, ph / 2, ph / 2, q)
        p.color = onPrimary; p.textAlign = android.graphics.Paint.Align.CENTER
        c.drawText(label, w / 2, pr.centerY() + dp(5f), p)
    }
    return StackPic(bmp, (w / 2).toInt(), (cardT + card / 2).toInt())
}

/** Mouse: press and move lifts. Finger: only a hold on an item that is already selected lifts it. Uses the system drag with our own picture. */
@Composable
fun Modifier.entryDragSource(vm: ExplorerViewModel, tab: TabState, e: FileEntry): Modifier {
    val ctx = LocalContext.current
    val view = androidx.compose.ui.platform.LocalView.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val cs0 = MaterialTheme.colorScheme
    val palS = rememberUpdatedState(StackPal(cs0.primary.toArgb(), cs0.onPrimary.toArgb(), dialogSurface().toArgb(), cs0.background.luminance() < 0.5f))
    val eS = rememberUpdatedState(e)
    val tabS = rememberUpdatedState(tab)
    var coords by remember { androidx.compose.runtime.mutableStateOf<androidx.compose.ui.layout.LayoutCoordinates?>(null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density

    /**
     * Touch hold on a selected item: the stack is lifted and the actions menu opens beside it. Releasing leaves both on screen so an
     * action can be tapped; moving the finger closes the menu and hands the stack to the system drag.
     */
    fun hold(fingerRoot: Offset) {
        val en = eS.value; val tb = tabS.value
        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
        val paths = vm.dragPaths(tb, en)
        val pic = renderStack(ctx, en, vm.selectedEntries(tb).filter { it.path != en.path }, paths.size, palS.value)
        vm.holdStack = app.dexfiles.state.HoldStack(pic.bmp.asImageBitmap(), fingerRoot, pic.tx.toFloat(), pic.ty.toFloat())
        // The menu opens to the right of the stack (half its width plus a gap), not under the finger.
        vm.showContext(vm.activePane, Offset(fingerRoot.x + (pic.bmp.width / 2f) + 8f * density, fingerRoot.y - pic.ty + 20f * density), en)
    }

    fun start() {
        val en = eS.value; val tb = tabS.value
        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
        val paths = vm.dragPaths(tb, en)
        val n = paths.size
        val pic = renderStack(ctx, en, vm.selectedEntries(tb).filter { it.path != en.path }, n, palS.value)
        val payload = DragPayload(paths)
        val ok = view.startDragAndDrop(
            Opener.dragClip(ctx, paths),
            StackShadow(view, pic.bmp, pic.tx, pic.ty),
            payload,
            View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ or View.DRAG_FLAG_OPAQUE,
        )
        // Adding or removing items with another finger while the stack is in the air updates the picture and what will be dropped.
        if (ok) dropRegistry(vm).session = DragSession(
            key = { tb.selection.toList() },
            rebuild = {
                val ps = vm.selectedEntries(tb).map { it.path }
                if (ps.isNotEmpty() && ps != payload.paths) {
                    payload.paths = ps
                    // A short pop: the stack swells and the count badge bounces, so you see the item land on it.
                    val others = vm.selectedEntries(tb).filter { it.path != en.path }
                    val t0 = android.os.SystemClock.uptimeMillis()
                    lateinit var frame: Runnable
                    frame = Runnable {
                        val t = ((android.os.SystemClock.uptimeMillis() - t0) / 280f).coerceIn(0f, 1f)
                        val pulse = kotlin.math.sin(Math.PI * t).toFloat() * (1f - 0.35f * t)
                        val np = renderStack(ctx, en, others, ps.size, palS.value, pulse)
                        view.updateDragShadow(StackShadow(view, np.bmp, np.tx, np.ty))
                        if (t < 1f && dropRegistry(vm).session != null) view.postDelayed(frame, 36)
                    }
                    frame.run()
                }
            },
            paths = { payload.paths },
        )
    }
    return this.onGloballyPositioned { coords = it }.pointerInput(Unit) {
        kotlinx.coroutines.coroutineScope {
            launch {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.type == PointerType.Mouse) return@awaitEachGesture
                    if (eS.value.path !in tabS.value.selection) return@awaitEachGesture
                    val held = awaitLongPressOrCancellation(down.id) ?: return@awaitEachGesture
                    val root = coords?.localToRoot(held.position) ?: return@awaitEachGesture
                    hold(root)
                    // Stay with the finger: a release keeps the menu open, a move past the slop starts the drag.
                    while (true) {
                        val ch = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) return@awaitEachGesture
                        if ((ch.position - held.position).getDistance() > viewConfiguration.touchSlop) break
                    }
                    vm.menu = null
                    vm.holdStack = null
                    start()
                }
            }
            launch {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.type != PointerType.Mouse || !currentEvent.buttons.isPrimaryPressed) return@awaitEachGesture
                    val moved = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                    if (moved != null) start()
                }
            }
        }
    }
}

/**
 * While a stack is in the air a pill floats at the bottom: drop on it to cancel. It takes the slot of the selection pill,
 * glows when the finger is over it, and is gone the moment the drag ends.
 */
@Composable
fun CancelDropPill(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val reg = remember(vm) { dropRegistry(vm) }
    var over by remember { androidx.compose.runtime.mutableStateOf(false) }
    androidx.compose.animation.AnimatedVisibility(
        visible = reg.session != null,
        modifier = modifier,
        enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(220)) { it } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
        exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(160)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        val bg by androidx.compose.animation.animateColorAsState(if (over) cs.errorContainer else app.dexfiles.ui.dialogSurface(), androidx.compose.animation.core.tween(140), label = "cancelBg")
        val scale by androidx.compose.animation.core.animateFloatAsState(if (over) 1.08f else 1f, androidx.compose.animation.core.spring(0.55f, 500f), label = "cancelScale")
        androidx.compose.foundation.layout.Row(
            Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .softShadow()
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(bg)
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), androidx.compose.foundation.shape.CircleShape)
                .cancelDrop(vm) { over = it }
                .padding(horizontal = 22.dp, vertical = 14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
        ) {
            androidx.compose.material3.Icon(app.dexfiles.ui2.design.DexIcons.Close, null, Modifier.size(18.dp), tint = if (over) cs.onErrorContainer else cs.onSurface)
            androidx.compose.material3.Text(
                if (over) "Release to cancel" else "Drop here to cancel",
                fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                color = if (over) cs.onErrorContainer else cs.onSurface,
            )
        }
    }
}

/** The live sentence above the cancel pill: what letting go would do. */
@Composable
fun DropLabel(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val reg = remember(vm) { dropRegistry(vm) }
    var shown by remember { androidx.compose.runtime.mutableStateOf("") }
    reg.label?.let { shown = it }
    androidx.compose.animation.AnimatedVisibility(
        visible = reg.label != null,
        modifier = modifier,
        enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)) + androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(120), initialScale = 0.92f),
        exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(100)),
    ) {
        androidx.compose.material3.Text(
            shown, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, color = cs.onPrimary,
            modifier = Modifier.softShadow().clip(androidx.compose.foundation.shape.CircleShape).background(cs.primary).padding(horizontal = 18.dp, vertical = 10.dp),
        )
    }
}

private fun Modifier.softShadow(): Modifier = this.shadow(14.dp, androidx.compose.foundation.shape.CircleShape, ambientColor = Color.Black, spotColor = Color.Black)

/** The lifted stack drawn at the finger while the hold-menu is open. It goes away with the menu. */
@Composable
fun HoldStackOverlay(vm: ExplorerViewModel) {
    val h = vm.holdStack
    androidx.compose.runtime.LaunchedEffect(vm.menu == null) { if (vm.menu == null) vm.holdStack = null }
    if (h == null || vm.menu == null) return
    val bars = androidx.compose.foundation.layout.WindowInsets.systemBars
    val density = androidx.compose.ui.platform.LocalDensity.current
    val dir = androidx.compose.ui.platform.LocalLayoutDirection.current
    val pop = remember(h) { androidx.compose.animation.core.Animatable(0.86f) }
    androidx.compose.runtime.LaunchedEffect(h) { pop.animateTo(1f, androidx.compose.animation.core.spring(0.55f, 420f)) }
    androidx.compose.foundation.Image(
        bitmap = h.image,
        contentDescription = null,
        modifier = Modifier
            .offset { androidx.compose.ui.unit.IntOffset((h.pos.x - h.tx).toInt() - bars.getLeft(density, dir), (h.pos.y - h.ty).toInt() - bars.getTop(density)) }
            .graphicsLayer { scaleX = pop.value; scaleY = pop.value; transformOrigin = androidx.compose.ui.graphics.TransformOrigin(h.tx / h.image.width, h.ty / h.image.height) },
    )
}
