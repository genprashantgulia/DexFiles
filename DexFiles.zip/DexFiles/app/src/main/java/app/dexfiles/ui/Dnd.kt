@file:OptIn(ExperimentalFoundationApi::class)

package app.dexfiles.ui

import android.view.View
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipPath
import app.dexfiles.ui.DragThumbs
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlinx.coroutines.launch
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.draganddrop.dragAndDropSource
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.DragAndDropTransferData
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.data.Opener
import app.dexfiles.state.DragPayload
import app.dexfiles.state.Mods
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState

/**
 * Makes a view accept drops: our own rows (move, or copy with Ctrl), and files dragged in from other
 * apps or other DeX windows (copied in). [dest] is the folder that receives the drop, or null to refuse.
 */
@Composable
fun Modifier.folderDrop(vm: ExplorerViewModel, dest: String?, onMove: ((Float) -> Unit)? = null, onDropped: (() -> Unit)? = null, onHover: (Boolean) -> Unit): Modifier {
    val activity = LocalHostActivity.current
    val destState = rememberUpdatedState(dest)
    val hoverState = rememberUpdatedState(onHover)
    val moveState = rememberUpdatedState(onMove)
    val droppedState = rememberUpdatedState(onDropped)
    val target = remember(vm) {
        object : DragAndDropTarget {
            override fun onEntered(event: DragAndDropEvent) { hoverState.value(true) }
            override fun onExited(event: DragAndDropEvent) { hoverState.value(false) }
            override fun onEnded(event: DragAndDropEvent) { hoverState.value(false); vm.dragScrollDir = 0f }
            override fun onMoved(event: DragAndDropEvent) { moveState.value?.invoke(event.toAndroidDragEvent().y) }
            override fun onDrop(event: DragAndDropEvent): Boolean {
                hoverState.value(false)
                val d = destState.value ?: return false
                vm.dragScrollDir = 0f
                val ok = vm.handleDrop(event.toAndroidDragEvent(), activity, d)
                if (ok) droppedState.value?.invoke()
                return ok
            }
        }
    }
    return this.dragAndDropTarget(shouldStartDragAndDrop = { destState.value != null }, target = target)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.thumbCard(b: android.graphics.Bitmap, o: Offset, card: Float, d: Float, alpha: Float) {
    val img = b.asImageBitmap()
    val side = minOf(b.width, b.height)
    val path = androidx.compose.ui.graphics.Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(o.x, o.y, o.x + card, o.y + card, CornerRadius(14 * d))) }
    clipPath(path) {
        drawImage(
            img,
            srcOffset = androidx.compose.ui.unit.IntOffset((b.width - side) / 2, (b.height - side) / 2),
            srcSize = androidx.compose.ui.unit.IntSize(side, side),
            dstOffset = androidx.compose.ui.unit.IntOffset(o.x.toInt(), o.y.toInt()),
            dstSize = androidx.compose.ui.unit.IntSize(card.toInt(), card.toInt()),
            alpha = alpha,
        )
    }
}

/** Mouse-drag from a row starts a system drag carrying the selection (touch keeps scrolling). */
@Composable
fun Modifier.entryDragSource(vm: ExplorerViewModel, tab: TabState, e: FileEntry): Modifier {
    val ctx = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val measurer = rememberTextMeasurer()
    val bg = MaterialTheme.colorScheme.primary
    val fg = MaterialTheme.colorScheme.onPrimary
    return this.dragAndDropSource(
        drawDragDecoration = {
            // A small stack of cards (up to three) with a count badge, like the mock; one card plus the name for a single file.
            val d = 1.dp.toPx()
            val n = if (e.path in tab.selection && tab.selection.size > 1) tab.selection.size else 1
            val card = 68 * d
            val o = Offset(16 * d, 16 * d)
            val pivot = Offset(o.x + card / 2, o.y + card / 2)
            if (n >= 3) rotate(-7f, pivot) { drawRoundRect(Color(0xFF34343A), topLeft = o, size = Size(card, card), cornerRadius = CornerRadius(14 * d)) }
            if (n >= 2) rotate(6f, pivot) { drawRoundRect(Color(0xFF2C2C32), topLeft = o, size = Size(card, card), cornerRadius = CornerRadius(14 * d)) }
            // Back cards show the other selected pictures when they are known; the front card shows this item.
            if (n >= 2) {
                val others = tab.selection.filter { it != e.path }.mapNotNull { DragThumbs.get(it) }
                others.getOrNull(1)?.takeIf { n >= 3 }?.let { b -> rotate(-7f, pivot) { thumbCard(b, o, card, d, 0.85f) } }
                others.getOrNull(0)?.let { b -> rotate(6f, pivot) { thumbCard(b, o, card, d, 0.9f) } }
            }
            drawRoundRect(Color(0xFF26262C), topLeft = o, size = Size(card, card), cornerRadius = CornerRadius(14 * d))
            val front = if (e.isDir) null else DragThumbs.get(e.path)
            if (front != null) thumbCard(front, o, card, d, 1f)
            drawRoundRect(Color.White.copy(alpha = 0.14f), topLeft = o, size = Size(card, card), cornerRadius = CornerRadius(14 * d), style = Stroke(1 * d))
            if (front != null) { /* picture already drawn */ } else if (e.isDir) {
                drawRoundRect(bg, topLeft = Offset(o.x + 16 * d, o.y + 22 * d), size = Size(36 * d, 26 * d), cornerRadius = CornerRadius(6 * d))
            } else {
                val ext = measurer.measure(
                    e.name.substringAfterLast('.', "FILE").take(4).uppercase(),
                    style = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
                )
                drawText(ext, topLeft = Offset(o.x + (card - ext.size.width) / 2, o.y + (card - ext.size.height) / 2))
            }
            if (n > 1) {
                val c = Offset(o.x + card, o.y + 2 * d)
                drawCircle(bg, radius = 14 * d, center = c)
                val t = measurer.measure(n.toString(), style = TextStyle(color = fg, fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold))
                drawText(t, topLeft = Offset(c.x - t.size.width / 2f, c.y - t.size.height / 2f))
            } else {
                val label = measurer.measure(
                    e.name,
                    style = TextStyle(color = fg, fontSize = 13.sp),
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1,
                    constraints = Constraints(maxWidth = 220.dp.roundToPx()),
                )
                val top = o.y + card + 8 * d
                drawRoundRect(bg, topLeft = Offset(o.x, top), size = Size(label.size.width + 24f, label.size.height + 12f), cornerRadius = CornerRadius(12 * d))
                drawText(label, topLeft = Offset(o.x + 12f, top + 6f))
            }
        },
    ) {
        val scope = this
        fun start() {
            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
            val paths = vm.dragPaths(tab, e)
            scope.startTransfer(
                DragAndDropTransferData(
                    clipData = Opener.dragClip(ctx, paths),
                    localState = DragPayload(paths),
                    flags = View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ,
                ),
            )
        }
        kotlinx.coroutines.coroutineScope {
            // Finger: the FIRST hold only selects (handled by the row). Only a hold that starts on an item that is already selected lifts it.
            launch {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.type == PointerType.Mouse) return@awaitEachGesture
                    val alreadySelected = e.path in tab.selection
                    if (!alreadySelected) return@awaitEachGesture
                    if (awaitLongPressOrCancellation(down.id) == null) return@awaitEachGesture
                    start()
                }
            }
            // Mouse: just drag with the primary button.
            launch {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.type != PointerType.Mouse || !currentEvent.buttons.isPrimaryPressed) return@awaitEachGesture
                    val moved = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                    if (moved != null) start()
                }
            }
        }
    }
}
