@file:OptIn(ExperimentalFoundationApi::class)

package app.dexfiles.ui

import android.view.View
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import kotlinx.coroutines.launch
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.draganddrop.dragAndDropSource
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.DragAndDropTransferData
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.data.Opener
import app.dexfiles.state.DragPayload
import app.dexfiles.state.Mods
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState

/**
 * Makes a view accept drops: our own rows (move, or copy with Ctrl), and files dragged in from other
 * apps or other DeX windows (copied in). [dest] is the folder that receives the drop, or null to refuse.
 */
@Composable
fun Modifier.folderDrop(vm: ExplorerViewModel, dest: String?, onHover: (Boolean) -> Unit): Modifier {
    val activity = LocalHostActivity.current
    val destState = rememberUpdatedState(dest)
    val hoverState = rememberUpdatedState(onHover)
    val target = remember(vm) {
        object : DragAndDropTarget {
            override fun onEntered(event: DragAndDropEvent) { hoverState.value(true) }
            override fun onExited(event: DragAndDropEvent) { hoverState.value(false) }
            override fun onEnded(event: DragAndDropEvent) { hoverState.value(false) }
            override fun onDrop(event: DragAndDropEvent): Boolean {
                hoverState.value(false)
                val d = destState.value ?: return false
                return vm.handleDrop(event.toAndroidDragEvent(), activity, d)
            }
        }
    }
    return this.dragAndDropTarget(shouldStartDragAndDrop = { destState.value != null }, target = target)
}

/** Mouse-drag from a row starts a system drag carrying the selection (touch keeps scrolling). */
@Composable
fun Modifier.entryDragSource(vm: ExplorerViewModel, tab: TabState, e: FileEntry): Modifier {
    val ctx = LocalContext.current
    val measurer = rememberTextMeasurer()
    val bg = MaterialTheme.colorScheme.primary
    val fg = MaterialTheme.colorScheme.onPrimary
    return this.dragAndDropSource(
        drawDragDecoration = {
            val label = if (e.path in tab.selection && tab.selection.size > 1) "${tab.selection.size} items" else e.name
            val layout = measurer.measure(
                label,
                style = TextStyle(color = fg, fontSize = 13.sp),
                overflow = TextOverflow.Ellipsis,
                maxLines = 1,
                constraints = Constraints(maxWidth = 260.dp.roundToPx()),
            )
            drawRoundRect(bg, size = Size(layout.size.width + 24f, layout.size.height + 16f), cornerRadius = CornerRadius(14f, 14f))
            drawText(layout, topLeft = Offset(12f, 8f))
        },
    ) {
        val scope = this
        fun start() {
            val paths = vm.dragPaths(tab, e)
            scope.startTransfer(
                DragAndDropTransferData(
                    clipData = Opener.dragClip(ctx, paths),
                    localState = DragPayload(paths),
                    flags = View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ,
                ),
            )
        }
        kotlinx.coroutines.coroutineScope {
            // Finger: press-and-hold (which also selects the row), then drag.
            launch {
                detectDragGesturesAfterLongPress(
                    onDragStart = { if (!Mods.mouse) start() },
                    onDrag = { _, _ -> },
                )
            }
            // Mouse: just drag with the primary button.
            launch {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.type != PointerType.Mouse || !currentEvent.buttons.isPrimaryPressed) return@awaitEachGesture
                    val moved = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                    if (moved != null) start()
                }
            }
        }
    }
}
