package app.dexfiles.ui2.design

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** Single source of truth for spacing, sizes and shapes. Never use raw dp values in screens. */
object Space {
    val xs = 4.dp; val s = 8.dp; val m = 12.dp; val l = 16.dp; val xl = 24.dp; val xxl = 32.dp
}

object Size {
    val touch = 48.dp
    val bar = 56.dp
    val rowList = 68.dp
    val sidebar = 280.dp
}

object Radius {
    // The five corner sizes the whole app uses (smallest to largest).
    val xs = RoundedCornerShape(8.dp)
    val s = RoundedCornerShape(12.dp)
    val m = RoundedCornerShape(16.dp)
    val l = RoundedCornerShape(20.dp)
    val xl = RoundedCornerShape(28.dp)
    val control = RoundedCornerShape(12.dp)
    val card = RoundedCornerShape(20.dp)
    val sheet = RoundedCornerShape(28.dp)
    val pill = RoundedCornerShape(50)
}
