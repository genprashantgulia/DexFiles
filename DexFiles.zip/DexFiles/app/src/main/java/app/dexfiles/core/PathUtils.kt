package app.dexfiles.core

import java.nio.file.Paths

data class Crumb(val label: String, val path: String)

object PathUtils {
    fun isInside(child: String, parent: String): Boolean {
        val c = child.trimEnd('/')
        val p = parent.trimEnd('/')
        return c == p || c.startsWith("$p/")
    }

    /**
     * Breadcrumb trail for the address bar. [roots] maps a storage root path to its friendly label,
     * e.g. "/storage/emulated/0" -> "Internal storage". The deepest matching root becomes the first crumb.
     */
    fun crumbs(path: String, roots: Map<String, String>): List<Crumb> {
        val clean = path.trimEnd('/').ifEmpty { "/" }
        val root = roots.keys.filter { isInside(clean, it) }.maxByOrNull { it.length }
        val out = ArrayList<Crumb>()
        var acc: String
        val rest: String
        if (root != null) {
            out.add(Crumb(roots.getValue(root), root))
            acc = root.trimEnd('/')
            rest = clean.removePrefix(acc)
        } else {
            out.add(Crumb("/", "/"))
            acc = ""
            rest = clean
        }
        for (seg in rest.split('/')) {
            if (seg.isEmpty()) continue
            acc = "$acc/$seg"
            out.add(Crumb(seg, acc))
        }
        return out
    }

    /** Resolves text typed into the address bar relative to [base]; "~" expands to [home]. Returns normalized absolute path. */
    fun resolveTyped(base: String, typed: String, home: String): String {
        var t = typed.trim()
        if (t == "~") t = home
        else if (t.startsWith("~/")) t = home.trimEnd('/') + t.substring(1)
        val p = if (t.startsWith("/")) Paths.get(t) else Paths.get(base, t)
        val n = p.normalize().toString()
        return n.ifEmpty { "/" }
    }
}
