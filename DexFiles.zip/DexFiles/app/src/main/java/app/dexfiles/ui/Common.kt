@file:OptIn(ExperimentalMaterial3Api::class)

package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.getValue
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Text
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** The hosting activity, needed for drag-and-drop permission grants. */
val LocalHostActivity = staticCompositionLocalOf<Activity?> { null }

/** The explorer's view model, available to every composable without threading it through. */
val LocalVm = staticCompositionLocalOf<app.dexfiles.state.ExplorerViewModel> { error("ExplorerViewModel not provided") }

object Fmt {
    private val z = ZoneId.systemDefault()
    private val en = java.util.Locale.ENGLISH
    private fun f(p: String) = DateTimeFormatter.ofPattern(p, en).withZone(z)
    private val dayYear = f("d MMM yyyy"); private val day = f("d MMM")
    private val timeFmt = f("h:mm a")

    private fun sameYear(ms: Long) = java.time.LocalDate.ofInstant(Instant.ofEpochMilli(ms), z).year == java.time.LocalDate.now(z).year
    private fun ampm(s: String) = s.replace(" AM", " am").replace(" PM", " pm")

    /** "7 Nov, 10:10 pm" (year only when it is not this year): the way One UI writes recent dates. */
    fun stamp(ms: Long): String =
        if (ms <= 0L) "" else ampm("${(if (sameYear(ms)) day else dayYear).format(Instant.ofEpochMilli(ms))}, ${timeFmt.format(Instant.ofEpochMilli(ms))}")

    fun dateTime(ms: Long): String = stamp(ms)
    fun date(ms: Long): String = if (ms <= 0L) "" else (if (sameYear(ms)) day else dayYear).format(Instant.ofEpochMilli(ms))
}

/** Compact square icon button with a hover tooltip, like a desktop toolbar. */
@Composable
fun IconBtn(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    active: Boolean = false,
    tint: Color = Color.Unspecified,
    size: androidx.compose.ui.unit.Dp = 32.dp,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = { PlainTooltip { Text(label) } },
        state = rememberTooltipState(),
    ) {
        val src = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val sc by androidx.compose.animation.core.animateFloatAsState(if (pressed) 0.88f else 1f, app.dexfiles.ui2.design.Motion.press(), label = "iconPress")
        Box(
            modifier
                .size(size)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .clip(app.dexfiles.ui2.design.Radius.let { if (size >= 40.dp) it.s else it.xs })
                .background(if (active) (if (cs.background.luminance() > 0.5f) cs.primary.copy(alpha = 0.20f) else cs.secondaryContainer) else Color.Transparent)
                .clickable(interactionSource = src, indication = androidx.compose.material3.ripple(), enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            val base = if (tint == Color.Unspecified) cs.onSurface else tint
            Icon(icon, contentDescription = label, modifier = Modifier.size(if (size >= 40.dp) 22.dp else 18.dp), tint = if (enabled) base else base.copy(alpha = 0.38f))
        }
    }
}

/** A text button with an optional leading icon, sized for the command bar. */
@Composable
fun BarBtn(
    label: String,
    icon: ImageVector?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    showLabel: Boolean = true,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val c = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
    Row(
        modifier
            .clip(Radius.xs)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (icon != null) Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp), tint = c)
        if (showLabel || icon == null) Text(label, style = MaterialTheme.typography.labelLarge, color = c, maxLines = 1)
    }
}

/** Single-line field used for the address bar, search box and dialogs. */
@Composable
fun DexTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    focusRequester: FocusRequester? = null,
    isError: Boolean = false,
    onEnter: () -> Unit = {},
    onEscape: (() -> Unit)? = null,
    onFocusChange: ((Boolean) -> Unit)? = null,
    shape: androidx.compose.ui.graphics.Shape = Radius.xs,
    container: Color? = null,
    borderColor: Color? = null,
) {
    val cs = MaterialTheme.colorScheme
    var field = Modifier.fillMaxWidth()
    if (focusRequester != null) field = field.focusRequester(focusRequester)
    field = field.onFocusChanged { onFocusChange?.invoke(it.isFocused) }
    field = field.onPreviewKeyEvent { ev ->
        if (onEscape != null && ev.key == Key.Escape && ev.type == KeyEventType.KeyDown) {
            onEscape()
            true
        } else false
    }
    Row(
        modifier
            .clip(shape)
            .background(container ?: cs.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, if (isError) cs.error else (borderColor ?: cs.outlineVariant), shape)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (leading != null) leading()
        Box(Modifier.weight(1f)) {
            if (value.text.isEmpty() && placeholder.isNotEmpty()) {
                Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = cs.onSurface.copy(alpha = 0.5f), maxLines = 1)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onEnter() }),
                modifier = field,
            )
        }
        if (trailing != null) trailing()
    }
}
