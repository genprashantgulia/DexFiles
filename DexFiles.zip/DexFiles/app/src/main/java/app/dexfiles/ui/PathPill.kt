package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState

/** Samsung-style breadcrumb: a rounded pill, ancestors grey, current folder in the accent colour, every segment tappable. */
@Composable
fun PathPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val crumbs = PathUtils.crumbs(tab.path, vm.rootLabelMap())
    val scroll = rememberScrollState()
    LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    Row(
        modifier.height(Dimens.pillHeight).clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainer),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(start = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            crumbs.forEachIndexed { i, c ->
                val last = i == crumbs.lastIndex
                if (i > 0) Icon(Icons.Filled.ChevronRight, null, Modifier.size(18.dp), tint = cs.onSurfaceVariant)
                Text(
                    c.label,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (last) cs.primary else cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                        .clickable(enabled = !last) { vm.navigate(tab, c.path) }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                )
            }
        }
        Icon(
            Icons.Filled.Edit, "Type a path", Modifier.padding(end = 6.dp).size(32.dp).clip(CircleShape).clickable(onClick = onEdit).padding(7.dp),
            tint = cs.onSurfaceVariant,
        )
    }
}

/** Sits directly above the files: item count on the left, sort key + direction arrow on the right (Samsung My Files). */
@Composable
fun SortStrip(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    var menu by remember { mutableStateOf(false) }
    val n = tab.entries.size
    Row(
        Modifier.fillMaxWidth().height(Dimens.stripHeight - 4.dp).padding(horizontal = Dimens.s16),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            if (tab.loading) "Loading…" else if (n == 1) "1 item" else "$n items",
            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(spec.key.label, style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    for (k in SortKey.entries) {
                        DropdownMenuItem(
                            text = { Text(k.label) },
                            trailingIcon = { if (spec.key == k) Icon(Icons.Filled.Check, null, Modifier.size(18.dp), tint = cs.primary) },
                            onClick = { menu = false; if (spec.key != k) vm.setSort(tab, k) },
                        )
                    }
                }
            }
            Icon(
                if (spec.ascending) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                if (spec.ascending) "Ascending" else "Descending",
                Modifier.size(32.dp).clip(CircleShape).clickable { vm.setSortAscending(tab, !spec.ascending) }.padding(6.dp),
                tint = cs.onSurface,
            )
        }
    }
}
