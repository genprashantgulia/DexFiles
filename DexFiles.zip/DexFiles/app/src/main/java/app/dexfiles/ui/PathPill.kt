package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState

/** The ONE pill look used by every control group in the top bar: same height, fill and hairline border. */
@Composable
fun Modifier.barPill(): Modifier {
    val cs = MaterialTheme.colorScheme
    val shape = Radius.xl
    return this.height(Dimens.barHeight).clip(shape).background(cs.surfaceContainer)
}

/** Samsung-style breadcrumb: a rounded pill, ancestors grey, current folder in the accent colour, every segment tappable. */
@Composable
fun PathPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val crumbs = PathUtils.crumbs(tab.path, vm.rootLabelMap())
    val scroll = rememberScrollState()
    LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    Row(
        modifier.barPill().clickable(onClick = onEdit),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            crumbs.forEachIndexed { i, c ->
                val last = i == crumbs.lastIndex
                if (i > 0) Icon(Icons.Filled.ChevronRight, null, Modifier.size(14.dp), tint = cs.onSurface.copy(alpha = 0.4f))
                Text(
                    c.label,
                    fontSize = 15.sp,
                    fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (last) cs.onSurface else cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clip(Radius.s)
                        .clickable(enabled = !last) { vm.navigate(tab, c.path) }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                )
            }
        }
    }
}

private val KindFilters = listOf("All", "Folders", "Images", "Videos", "Audio", "Documents", "Archives", "Apps")

/** Mock: "48 items" on the left (13, dim), "Date modified ↓" on the right (13 semibold); tapping the right side opens the sort menu. */
@Composable
fun SortStrip(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    var menu by remember { mutableStateOf(false) }
    val n = tab.entries.size
    Row(
        Modifier.fillMaxWidth().padding(start = 28.dp, end = 20.dp, top = 6.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (tab.loading) "Loading\u2026" else if (n == 1) "1 item" else "$n items",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f),
        )
        Box {
            Row(
                Modifier.clip(CircleShape).clickable { menu = true }.padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(spec.key.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface.copy(alpha = 0.85f))
                Icon(
                    if (spec.ascending) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                    if (spec.ascending) "Ascending" else "Descending",
                    Modifier.size(14.dp), tint = cs.onSurface.copy(alpha = 0.85f),
                )
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                Text("Sort by", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, top = 6.dp, bottom = 4.dp))
                for (k in SortKey.entries) {
                    DropdownMenuItem(
                        text = { Text(k.label) },
                        trailingIcon = { if (spec.key == k) Icon(Icons.Filled.Check, null, Modifier.size(16.dp), tint = cs.primary) },
                        onClick = { menu = false; if (spec.key != k) vm.setSort(tab, k) },
                    )
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp, horizontal = 4.dp), color = cs.onSurface.copy(alpha = 0.10f))
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp).clip(Radius.m).background(cs.surfaceContainer).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for ((label, asc) in listOf("Ascending" to true, "Descending" to false)) {
                        val on = spec.ascending == asc
                        Box(
                            Modifier.weight(1f).clip(Radius.s).background(if (on) cs.primary else Color.Transparent)
                                .clickable { menu = false; vm.setSortAscending(tab, asc) }.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(label, fontSize = 13.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) cs.onPrimary else cs.onSurface.copy(alpha = 0.72f)) }
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp, horizontal = 4.dp), color = cs.onSurface.copy(alpha = 0.10f))
                DropdownMenuItem(
                    text = { Text("Folders first") },
                    trailingIcon = { androidx.compose.material3.Switch(checked = vm.foldersFirst, onCheckedChange = null) },
                    onClick = { vm.setFoldersFirst(!vm.foldersFirst) },
                )
            }
        }
    }
}

/** Samsung-style hairline under a row, starting after the icon so it reads as a list, not a grid of boxes. */
@Composable
fun Modifier.rowDivider(inset: androidx.compose.ui.unit.Dp): Modifier {
    val c = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
    return this.drawBehind {
        val y = size.height - 0.5f
        drawLine(c, androidx.compose.ui.geometry.Offset(inset.toPx(), y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 1.dp.toPx())
    }
}

@Composable
fun DottedLine(modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
    androidx.compose.foundation.Canvas(modifier.fillMaxWidth().height(2.dp)) {
        drawLine(
            c, androidx.compose.ui.geometry.Offset(0f, size.height / 2), androidx.compose.ui.geometry.Offset(size.width, size.height / 2),
            strokeWidth = 1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(0.1f, 6.dp.toPx())),
        )
    }
}
