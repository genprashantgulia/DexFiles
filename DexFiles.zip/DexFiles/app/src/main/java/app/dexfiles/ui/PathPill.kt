@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package app.dexfiles.ui

import androidx.compose.material3.minimumInteractiveComponentSize
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.ViewMode
import app.dexfiles.state.TabState

/** The ONE pill look used by every control group in the top bar: same height, fill and hairline border. */
@Composable
fun Modifier.barPill(): Modifier {
    val cs = MaterialTheme.colorScheme
    val shape = Radius.m
    return this.height(Dimens.barHeight).clip(shape).background(cs.surfaceContainer)
}

/**
 * Breadcrumb: a rounded bar. Each folder name opens that folder; the chevron between two names lists the folders inside the first one
 * (the current one ticked), so a sideways hop is one tap. The last name has no chevron. Tapping the empty end of the bar, or long-pressing
 * it, turns it into a typing field.
 */
@Composable
fun PathPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val crumbs = PathUtils.crumbs(tab.path, vm.rootLabelMap())
    val scroll = rememberScrollState()
    LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    Row(
        modifier.barPill().combinedClickable(onClick = onEdit, onLongClick = onEdit),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val phone = LocalCompact.current
        if (!phone) FolderIcon(Modifier.padding(start = 14.dp).size(20.dp), hasFiles = true)
        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(start = if (phone) 8.dp else 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Long paths keep the first folder and the last two visible; the ones in between fold into a menu.
            val fold = crumbs.size > 4
            var hiddenMenu by remember { mutableStateOf(false) }
            crumbs.forEachIndexed { i, c ->
                val last = i == crumbs.lastIndex
                // The chevron after crumb i opens crumb i's folders; when the middle is folded, the one after "…" belongs to the last hidden crumb.
                var chevronOf = i
                if (fold && i in 1 until crumbs.size - 2) {
                    if (i != 1) return@forEachIndexed
                    chevronOf = crumbs.size - 3
                    Box {
                        Text(
                            "\u2026", fontSize = 15.sp, color = cs.onSurfaceVariant,
                            modifier = Modifier.clip(Radius.s).clickable { hiddenMenu = true }.padding(horizontal = 8.dp, vertical = 8.dp),
                        )
                        DropdownMenu(expanded = hiddenMenu, onDismissRequest = { hiddenMenu = false }) {
                            for (h in crumbs.subList(1, crumbs.size - 2)) {
                                DropdownMenuItem(text = { Text(h.label) }, onClick = { hiddenMenu = false; vm.navigate(tab, h.path) })
                            }
                        }
                    }
                } else {
                    Text(
                        c.label,
                        fontSize = 15.sp,
                        fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (last) cs.onSurface else cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clip(Radius.s)
                            .clickable(enabled = !last) { vm.navigate(tab, c.path) }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                    )
                }
                if (!last) CrumbChevron(vm, tab, crumbs[chevronOf].path, crumbs[chevronOf + 1].path)
            }
        }
        // The empty end of the bar types a path; it is never covered by a name, so a stray tap on a name never does it.
        Box(Modifier.width(20.dp).fillMaxHeight().clickable(onClick = onEdit))
    }
}

/** The chevron between two crumbs: lists the folders inside [parent], the one on the path ticked. Turns down while open. */
@Composable
private fun CrumbChevron(vm: ExplorerViewModel, tab: TabState, parent: String, next: String) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val kids = remember(open, parent) {
        if (!open) emptyList()
        else java.io.File(parent).listFiles { f -> f.isDirectory && (vm.showHidden || !f.name.startsWith(".")) }?.sortedBy { it.name.lowercase() }.orEmpty()
    }
    val turn by androidx.compose.animation.core.animateFloatAsState(if (open) 90f else 0f, app.dexfiles.ui2.design.Motion.glide(180), label = "crumbTurn")
    Box {
        Box(Modifier.size(width = 28.dp, height = 44.dp).clip(Radius.xs).clickable { open = true }, contentAlignment = Alignment.Center) {
            Icon(DexIcons.ChevronRight, "Folders in this one", Modifier.size(16.dp).rotate(turn), tint = cs.onSurface.copy(alpha = 0.55f))
        }
        DropdownMenu(shape = Radius.l, containerColor = cs.surfaceContainerHigh, expanded = open, onDismissRequest = { open = false }) {
            for (f in kids) {
                val cur = f.path == next
                DropdownMenuItem(
                    text = { Text(f.name, fontWeight = if (cur) FontWeight.SemiBold else FontWeight.Normal, color = if (cur) cs.primary else cs.onSurface) },
                    leadingIcon = { FolderIcon(Modifier.size(22.dp), hasFiles = true) },
                    trailingIcon = if (cur) ({ Icon(DexIcons.Check, null, Modifier.size(16.dp), tint = cs.primary) }) else null,
                    onClick = { open = false; if (!cur) vm.navigate(tab, f.path) },
                )
            }
        }
    }
}

/** Mock F13-D: only the count sits here; Sort and View are two icon buttons on the path row. */
@Composable
fun SortStrip(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val n = tab.entries.size
    val compact = LocalCompact.current
    Row(
        Modifier.fillMaxWidth().padding(start = if (compact) 16.dp else 28.dp, end = if (compact) 8.dp else 20.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (tab.loading) "Loading\u2026" else if (tab.path == Loc.HOME && !tab.isSearch) "$n files in the last 30 days" else if (n == 1) "1 item" else "$n items",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f),
        )
        // Phone: the path row has no room for two more buttons, so Sort and View sit at the end of this strip instead.
        if (compact && !tab.isSearch && !tab.isVirtual) {
            var sortMenu by remember { mutableStateOf(false) }
            var viewMenu by remember { mutableStateOf(false) }
            Box {
                Box(Modifier.minimumInteractiveComponentSize().size(36.dp).clip(Radius.xs).clickable { sortMenu = true }, contentAlignment = Alignment.Center) {
                    Icon(DexIcons.Sort, "Sort", Modifier.size(20.dp), tint = cs.onSurface.copy(alpha = 0.85f))
                }
                SortMenu(vm, tab, sortMenu) { sortMenu = false }
            }
            Box {
                Box(Modifier.minimumInteractiveComponentSize().size(36.dp).clip(Radius.xs).clickable { viewMenu = true }, contentAlignment = Alignment.Center) {
                    Icon(CurrentViewIcon(vm, tab), "View options", Modifier.size(20.dp), tint = cs.onSurface.copy(alpha = 0.85f))
                }
                ViewOptionsMenu(vm, tab, viewMenu) { viewMenu = false }
            }
        }
    }
}

/** The sort menu, shared by the Sort icon on the path row. */
@Composable
fun SortMenu(vm: ExplorerViewModel, tab: TabState, expanded: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        Text("Sort by", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, top = 6.dp, bottom = 4.dp))
        for (k in SortKey.entries) {
            DropdownMenuItem(
                text = { Text(k.label) },
                trailingIcon = { if (spec.key == k) Icon(DexIcons.Check, null, Modifier.size(16.dp), tint = cs.primary) },
                onClick = { onDismiss(); if (spec.key != k) vm.setSort(tab, k) },
            )
        }
        HorizontalDivider(Modifier.padding(vertical = 6.dp, horizontal = 4.dp), color = cs.onSurface.copy(alpha = 0.10f))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp).clip(Radius.m).background(cs.surfaceContainer).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for ((label, asc) in listOf("Ascending" to true, "Descending" to false)) {
                val on = spec.ascending == asc
                Box(
                    Modifier.weight(1f).clip(Radius.s).background(if (on) cs.primary else Color.Transparent)
                        .clickable { onDismiss(); vm.setSortAscending(tab, asc) }.padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(label, fontSize = 13.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) cs.onPrimary else cs.onSurface.copy(alpha = 0.72f)) }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 6.dp, horizontal = 4.dp), color = cs.onSurface.copy(alpha = 0.10f))
        DropdownMenuItem(
            text = { Text("Folders first") },
            trailingIcon = { DexSwitch(vm.foldersFirst) },
            onClick = { vm.setFoldersFirst(!vm.foldersFirst) },
        )
        if (tab.viewMode != ViewMode.COLUMNS && tab.viewMode != ViewMode.GALLERY && !tab.isSearch && tab.path != Loc.HOME) {
            HorizontalDivider(Modifier.padding(vertical = 6.dp, horizontal = 4.dp), color = cs.onSurface.copy(alpha = 0.10f))
            Text("Group by", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, top = 6.dp, bottom = 4.dp))
            for (g in app.dexfiles.core.GroupBy.entries) {
                DropdownMenuItem(
                    text = { Text(g.label) },
                    trailingIcon = { if (tab.groupBy == g) Icon(DexIcons.Check, null, Modifier.size(16.dp), tint = cs.primary) },
                    onClick = { onDismiss(); if (tab.groupBy != g) vm.setGroupBy(tab, g) },
                )
            }
        }
    }
}

/** Samsung-style hairline under a row, starting after the icon so it reads as a list, not a grid of boxes. */
@Composable
fun Modifier.rowDivider(inset: androidx.compose.ui.unit.Dp): Modifier {
    val c = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
    return this.drawBehind {
        val y = size.height - 0.5f
        drawLine(c, androidx.compose.ui.geometry.Offset(inset.toPx(), y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 1.dp.toPx())
    }
}

@Composable
fun DottedLine(modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
    androidx.compose.foundation.Canvas(modifier.fillMaxWidth().height(2.dp)) {
        drawLine(
            c, androidx.compose.ui.geometry.Offset(0f, size.height / 2), androidx.compose.ui.geometry.Offset(size.width, size.height / 2),
            strokeWidth = 1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(0.1f, 6.dp.toPx())),
        )
    }
}
