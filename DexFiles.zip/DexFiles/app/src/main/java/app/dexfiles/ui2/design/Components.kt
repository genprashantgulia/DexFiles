package app.dexfiles.ui2.design

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** Round icon button with spring press feedback. */
@Composable
fun DexIconButton(icon: ImageVector, label: String, modifier: Modifier = Modifier, tint: Color = Dex.colors.text, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val c = Dex.colors
    Box(
        modifier.size(Size.touch).clip(Radius.pill).then(if (filled) Modifier.background(c.raised) else Modifier)
            .pressScale(0.9f, onTap = if (enabled) onClick else null),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, label, Modifier.size(24.dp), tint = if (enabled) tint else tint.copy(alpha = 0.35f)) }
}

/** Small pill: scope chip, kind filter, tab. */
@Composable
fun DexChip(text: String, modifier: Modifier = Modifier, selected: Boolean = false, leading: ImageVector? = null, onClick: () -> Unit) {
    val c = Dex.colors
    Row(
        modifier.height(36.dp).clip(Radius.pill).background(if (selected) c.accentSoft else c.raised)
            .pressScale(0.95f, onTap = onClick).padding(horizontal = Space.m),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.s),
    ) {
        if (leading != null) Icon(leading, null, Modifier.size(18.dp), tint = if (selected) c.accent else c.textDim)
        Text(text, style = Dex.type.label, color = if (selected) c.accent else c.text, maxLines = 1)
    }
}

/** Floating bottom dock: the thumb zone. All contextual actions live here. */
@Composable
fun DexDock(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val c = Dex.colors
    Row(
        modifier.shadow(18.dp, Radius.pill, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(Radius.pill).background(c.overlay).height(Size.dock).padding(horizontal = Space.s),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.xs), content = content,
    )
}
