package app.dexfiles.ui2.design

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp


/** Small pill: scope chip, kind filter, tab. */
@Composable
fun DexChip(text: String, modifier: Modifier = Modifier, selected: Boolean = false, leading: ImageVector? = null, onClick: () -> Unit) {
    val c = Dex.colors
    Row(
        modifier.height(36.dp).clip(Radius.pill).background(if (selected) c.accentSoft else c.raised)
            .pressScale(0.95f, onTap = onClick).padding(horizontal = Space.m),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.s),
    ) {
        if (leading != null) Icon(leading, null, Modifier.size(18.dp), tint = if (selected) c.accentUi else c.textDim)
        Text(text, style = Dex.type.label, color = if (selected) c.accentText else c.text, maxLines = 1)
    }
}

