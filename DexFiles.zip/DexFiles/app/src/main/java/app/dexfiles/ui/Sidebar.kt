package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.BarChart as OlBarChart
import androidx.compose.material.icons.outlined.Delete as OlDelete
import androidx.compose.material.icons.outlined.Description as OlDescription
import androidx.compose.material.icons.outlined.Image as OlImage
import androidx.compose.material.icons.outlined.Movie as OlMovie
import androidx.compose.material.icons.outlined.MusicNote as OlMusicNote
import androidx.compose.material.icons.outlined.PhoneAndroid as OlPhoneAndroid
import androidx.compose.material.icons.outlined.SdCard as OlSdCard
import androidx.compose.material.icons.outlined.Schedule as OlSchedule
import androidx.compose.material.icons.outlined.Settings as OlSettings
import androidx.compose.material.icons.outlined.Android as OlAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.data.Volume
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import java.io.File

// Built from the mock's Sidebar board: 264 wide, padding 4 / 8 / 12 / 12, items 46 high pills, 15/500, uppercase captions,
// storage tree with 42 high sub-items indented 44, and Trash / Analyze storage / Settings pinned to the bottom.

@Composable
fun Sidebar(vm: ExplorerViewModel, modifier: Modifier = Modifier, startPad: androidx.compose.ui.unit.Dp = 12.dp, onNavigated: () -> Unit = {}) {
    val O = Icons.Outlined
    fun go(path: String) {
        if (Mods.tertiaryDown && !Loc.isVirtual(path)) vm.openInNewTab(path) else vm.navigate(vm.current, path)
        onNavigated()
    }
    val cur = vm.current
    fun here(path: String) = cur.path == path && !cur.isSearch

    Column(modifier.fillMaxHeight().padding(start = startPad, end = 8.dp, top = 4.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            SideItem(O.OlSchedule, "Recent files", here(Loc.HOME)) { go(Loc.HOME) }
            Caption("CATEGORIES")
            SideItem(O.OlImage, "Images", here(Loc.IMAGES)) { go(Loc.IMAGES) }
            SideItem(O.OlMovie, "Videos", here(Loc.VIDEOS)) { go(Loc.VIDEOS) }
            SideItem(O.OlMusicNote, "Audio", here(Loc.AUDIO)) { go(Loc.AUDIO) }
            SideItem(O.OlDescription, "Documents", here(Loc.DOCS)) { go(Loc.DOCS) }
            SideItem(O.OlAndroid, "Installation files", here(Loc.APKS)) { go(Loc.APKS) }
            Caption("STORAGE")
            for (v in vm.volumes) VolumeTree(vm, v, ::go, ::here)
        }
        SideItem(O.OlDelete, "Trash", here(Loc.TRASH)) { go(Loc.TRASH) }
        SideItem(O.OlBarChart, "Analyze storage", here(Loc.ANALYZE)) { go(Loc.ANALYZE) }
        SideItem(O.OlSettings, "Settings", vm.settingsOpen) { vm.openSettings(fromLeft = true); onNavigated() }
    }
}

@Composable
private fun Caption(text: String) {
    Text(
        text,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
    )
}

/** Storage volume row (46 pill, chevron) with its folders as 42 high sub-items underneath. */
@Composable
private fun VolumeTree(vm: ExplorerViewModel, v: Volume, go: (String) -> Unit, here: (String) -> Boolean) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(v.primary) }
    val icon = if (v.primary) Icons.Outlined.OlPhoneAndroid else Icons.Outlined.OlSdCard
    val kids: List<File> = if (!v.primary || !open) emptyList() else {
        val root = File(v.path)
        val names = listOf("Download", "Documents", "DCIM", "Pictures", "Music", "Movies")
        val base = names.map { File(root, it) }.filter { it.isDirectory }
        val pins = vm.favorites.map { File(it) }.filter { it.isDirectory && it.parent == v.path && it !in base }
        base + pins
    }
    SideItem(
        icon, v.label, here(v.path), dropDest = v.path,
        trailing = {
            Icon(
                if (v.primary) Icons.Filled.KeyboardArrowDown else Icons.Filled.ChevronRight, if (open) "Collapse" else "Expand",
                Modifier.size(18.dp).rotate(if (v.primary && open) 180f else 0f), tint = cs.onSurfaceVariant,
            )
        },
        onTrailing = if (v.primary) ({ open = !open }) else null,
    ) { go(v.path) }
    for (k in kids) SubItem(k.name, here(k.path), k.path, vm) { go(k.path) }
}

@Composable
private fun SideItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    dropDest: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    onTrailing: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val vm = LocalVm.current
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.primary.copy(alpha = 0.16f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val ink = if (selected) Color(0xFFFFD257).takeIf { cs.background == Color.Black } ?: cs.primary else cs.onSurface.copy(alpha = 0.86f)
    Row(
        Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).background(bg).hoverable(src)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = ink)
        Text(label, fontSize = 15.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (trailing != null) {
            if (onTrailing != null) Row(Modifier.clip(CircleShape).clickable(onClick = onTrailing).padding(6.dp)) { trailing() } else trailing()
        }
    }
}

@Composable
private fun SubItem(label: String, selected: Boolean, path: String, vm: ExplorerViewModel, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.primary.copy(alpha = 0.16f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val ink = if (selected) Color(0xFFFFD257).takeIf { cs.background == Color.Black } ?: cs.primary else cs.onSurface.copy(alpha = 0.72f)
    Row(
        Modifier.fillMaxWidth().height(42.dp).clip(CircleShape).background(bg).hoverable(src)
            .folderDrop(vm, path) { dropHover = it }
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(start = 44.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(Icons.Filled.Folder, null, Modifier.size(20.dp), tint = kindColor(app.dexfiles.core.FileKind.FOLDER))
        Text(label, fontSize = 14.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
    }
}
