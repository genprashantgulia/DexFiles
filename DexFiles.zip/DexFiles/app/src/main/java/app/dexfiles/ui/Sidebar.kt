package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel
import androidx.compose.foundation.border
import androidx.compose.ui.draw.drawBehind
import androidx.compose.runtime.produceState
import app.dexfiles.ui2.design.DexIcons
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.BarChart as OlBarChart
import androidx.compose.material.icons.outlined.Delete as OlDelete
import androidx.compose.material.icons.outlined.FileDownload as OlDownload
import androidx.compose.material.icons.outlined.Description as OlDescription
import androidx.compose.material.icons.outlined.Image as OlImage
import androidx.compose.material.icons.outlined.Movie as OlMovie
import androidx.compose.material.icons.outlined.MusicNote as OlMusicNote
import androidx.compose.material.icons.outlined.PhoneAndroid as OlPhoneAndroid
import androidx.compose.material.icons.outlined.SdCard as OlSdCard
import androidx.compose.material.icons.outlined.Schedule as OlSchedule
import androidx.compose.material.icons.outlined.Settings as OlSettings
import androidx.compose.material.icons.outlined.Android as OlAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import app.dexfiles.core.FileEntry
import androidx.compose.foundation.relocation.bringIntoViewRequester
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.data.Volume
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import java.io.File

// Built from the mock's Sidebar board: 264 wide, padding 4 / 8 / 12 / 12, items 46 high pills, 15/500, uppercase captions,
// storage tree with 42 high sub-items indented 44, and Trash / Analyze storage / Settings pinned to the bottom.

@Composable
fun Sidebar(vm: ExplorerViewModel, modifier: Modifier = Modifier, startPad: androidx.compose.ui.unit.Dp = 12.dp, onNavigated: () -> Unit = {}) {
    val O = Icons.Outlined
    fun go(path: String) {
        if (Mods.tertiaryDown && !Loc.isVirtual(path)) vm.openInNewTab(path) else vm.navigate(vm.current, path)
        onNavigated()
    }
    val cur = vm.current
    fun here(path: String) = cur.path == path && !cur.isSearch
    // Tree state lives here so it survives navigation: which folders are open, and their sub-folders once loaded.
    val open = remember { mutableStateMapOf<String, Boolean>() }
    val kids = remember { mutableStateMapOf<String, List<String>>() }
    // One scrolling list: nothing is pinned, so the storage tree gets all the room (Settings is also in the ⋮ menu).
    Column(
        modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = startPad, end = 8.dp, top = 0.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        SideItem(DexIcons.Recent, "Recent files", here(Loc.HOME), tint = Color(0xFFFFC93C)) { go(Loc.HOME) }
        Caption("CATEGORIES")
        val dl = File(vm.primaryRoot, "Download").path
        SideItem(DexIcons.Download, "Downloads", here(Loc.DOWNLOADS), tint = Color(0xFF2EC4B6)) { go(Loc.DOWNLOADS) }
        SideItem(DexIcons.Images, "Images", here(Loc.IMAGES), tint = Color(0xFFFF6B8A)) { go(Loc.IMAGES) }
        SideItem(DexIcons.Videos, "Videos", here(Loc.VIDEOS), tint = Color(0xFFA98BFF)) { go(Loc.VIDEOS) }
        SideItem(DexIcons.Audio, "Audio", here(Loc.AUDIO), tint = Color(0xFF7C8CFF)) { go(Loc.AUDIO) }
        SideItem(DexIcons.Document, "Documents", here(Loc.DOCS), tint = Color(0xFFFFA23A)) { go(Loc.DOCS) }
        SideItem(DexIcons.Apk, "Installation files", here(Loc.APKS), tint = Color(0xFF5FD38A)) { go(Loc.APKS) }
        Caption("STORAGE")
        for (v in vm.volumes) VolumeTree(vm, v, open, kids, ::go, ::here)
        Caption("TOOLS")
        SideItem(DexIcons.Trash, "Trash", here(Loc.TRASH), tint = Color(0xFF9AA0AC)) { go(Loc.TRASH) }
        SideItem(DexIcons.Analyze, "Analyze storage", here(Loc.ANALYZE), tint = Color(0xFF5B9BFF)) { go(Loc.ANALYZE) }
    }
}

@Composable
private fun Caption(text: String) {
    Text(
        text,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
    )
}

private fun listDirs(path: String, showHidden: Boolean, root: Boolean): List<String> {
    val dirs = File(path).listFiles { f -> f.isDirectory && (showHidden || !f.name.startsWith(".")) }?.toList().orEmpty()
    val curated = listOf("Download", "Documents", "DCIM", "Pictures", "Music", "Movies")
    return dirs.sortedWith(
        compareBy<File>({ if (root) curated.indexOf(it.name).let { i -> if (i < 0) 99 else i } else 0 }, { it.name.lowercase() }),
    ).map { it.path }
}

/** A storage volume (46 high pill) and, beneath it, a real expandable tree of its folders. */
@Composable
private fun VolumeTree(
    vm: ExplorerViewModel, v: Volume, open: androidx.compose.runtime.snapshots.SnapshotStateMap<String, Boolean>,
    kids: androidx.compose.runtime.snapshots.SnapshotStateMap<String, List<String>>, go: (String) -> Unit, here: (String) -> Boolean,
) {
    val cs = MaterialTheme.colorScheme
    val isOpen = open[v.path] == true
    LaunchedEffect(isOpen, vm.showHidden) {
        if (isOpen) kids[v.path] = withContext(Dispatchers.IO) { listDirs(v.path, vm.showHidden, true) }
    }
    val vCur = vm.current
    val vUnder = !vCur.isSearch && vCur.path.startsWith(v.path.trimEnd('/') + "/")
    SideItem(
        if (v.primary) DexIcons.Phone else DexIcons.SdCard, v.label, here(v.path) || (vUnder && !isOpen), dropDest = v.path,
        tint = Color(0xFF5B9BFF),
        trailing = {
            Icon(DexIcons.ChevronDown, if (isOpen) "Collapse" else "Expand", Modifier.size(18.dp).rotate(if (isOpen) 180f else 0f), tint = cs.onSurfaceVariant)
        },
        onTrailing = { open[v.path] = !isOpen },
        onDropHold = { open[v.path] = true },
    ) { go(v.path) }
    androidx.compose.animation.AnimatedVisibility(
        visible = isOpen,
        enter = androidx.compose.animation.expandVertically(app.dexfiles.ui2.design.Motion.glide(320)) + androidx.compose.animation.fadeIn(app.dexfiles.ui2.design.Motion.glide(240)),
        exit = androidx.compose.animation.shrinkVertically(app.dexfiles.ui2.design.Motion.glide(260)) + androidx.compose.animation.fadeOut(app.dexfiles.ui2.design.Motion.glide(160)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (k in kids[v.path].orEmpty()) TreeNode(vm, k, 1, open, kids, go, here)
        }
    }
}

/**
 * One folder in the tree, Samsung style: a plain grey outline folder icon, the name, and a chevron on the right only when the
 * folder has sub-folders. The tree never opens by itself; the row that is highlighted is the deepest one you can SEE that contains
 * the folder you are in (so a collapsed Documents is highlighted while you are in Documents/Obsidian notes/Notes).
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TreeNode(
    vm: ExplorerViewModel, path: String, depth: Int, open: androidx.compose.runtime.snapshots.SnapshotStateMap<String, Boolean>,
    kids: androidx.compose.runtime.snapshots.SnapshotStateMap<String, List<String>>, go: (String) -> Unit, here: (String) -> Boolean,
) {
    val cs = MaterialTheme.colorScheme
    val isOpen = open[path] == true
    val cur = vm.current
    val under = !cur.isSearch && cur.path.startsWith(path.trimEnd('/') + "/")
    val selected = here(path) || (under && !isOpen)
    LaunchedEffect(isOpen, vm.showHidden) {
        if (isOpen) kids[path] = withContext(Dispatchers.IO) { listDirs(path, vm.showHidden, false) }
    }
    val hasSub by produceState(kids[path]?.isNotEmpty() ?: false, path, vm.showHidden) {
        value = withContext(Dispatchers.IO) { File(path).listFiles { f -> f.isDirectory && (vm.showHidden || !f.name.startsWith(".")) }?.isNotEmpty() ?: false }
    }
    val children = kids[path]
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    // Hovering a dragged item over a folder for a moment opens it, so deeper folders become reachable without letting go.
    LaunchedEffect(dropHover) { if (dropHover && hasSub && !isOpen) { kotlinx.coroutines.delay(650); open[path] = true } }
    val req = remember { androidx.compose.foundation.relocation.BringIntoViewRequester() }
    LaunchedEffect(selected) { if (selected) { kotlinx.coroutines.delay(260); req.bringIntoView() } }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> Sel.plate()
        hovered -> Sel.hover()
        else -> Color.Transparent
    }
    val ink = if (selected) cs.onSurface else cs.onSurface.copy(alpha = 0.86f)
    val edge = Sel.edge()
    val name = remember(path) { File(path).name }
    Row(
        Modifier.fillMaxWidth().height(46.dp).bringIntoViewRequester(req).clip(Radius.m).background(bg).then(if (selected) Modifier.border(1.dp, edge, Radius.m) else Modifier).hoverable(src)
            .folderDrop(vm, path) { dropHover = it }
            .clickable(interactionSource = src, indication = null) { go(path) }
            .padding(start = 16.dp + 18.dp * depth, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(DexIcons.Folder, null, Modifier.size(22.dp), tint = if (selected) ink else cs.onSurfaceVariant)
        Text(name, fontSize = 15.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (hasSub) {
            val turn by androidx.compose.animation.core.animateFloatAsState(if (isOpen) 180f else 0f, app.dexfiles.ui2.design.Motion.glide<Float>(260), label = "nodeChevron")
            Box(Modifier.size(34.dp).clip(CircleShape).clickable { open[path] = !isOpen }, contentAlignment = Alignment.Center) {
                Icon(DexIcons.ChevronDown, if (isOpen) "Collapse" else "Expand", Modifier.size(18.dp).rotate(turn), tint = cs.onSurfaceVariant)
            }
        }
    }
    androidx.compose.animation.AnimatedVisibility(
        visible = isOpen && !children.isNullOrEmpty(),
        enter = androidx.compose.animation.expandVertically(app.dexfiles.ui2.design.Motion.glide(300)) + androidx.compose.animation.fadeIn(app.dexfiles.ui2.design.Motion.glide(220)),
        exit = androidx.compose.animation.shrinkVertically(app.dexfiles.ui2.design.Motion.glide(240)) + androidx.compose.animation.fadeOut(app.dexfiles.ui2.design.Motion.glide(140)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (k in children.orEmpty()) TreeNode(vm, k, depth + 1, open, kids, go, here)
        }
    }
}

/** Collapsed sidebar (Samsung): just the icons, in the same groups, separated by dotted rules. */
@Composable
fun SidebarRail(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    fun go(path: String) { vm.navigate(vm.current, path) }
    val cur = vm.current
    fun here(path: String) = cur.path == path && !cur.isSearch
    val dl = File(vm.primaryRoot, "Download").path
    Column(modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(top = 0.dp, bottom = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        RailItem(DexIcons.Recent, Color(0xFFFFC93C), here(Loc.HOME)) { go(Loc.HOME) }
        RailDots()
        RailItem(DexIcons.Download, Color(0xFF2EC4B6), here(Loc.DOWNLOADS)) { go(Loc.DOWNLOADS) }
        RailItem(DexIcons.Images, Color(0xFFFF6B8A), here(Loc.IMAGES)) { go(Loc.IMAGES) }
        RailItem(DexIcons.Videos, Color(0xFFA98BFF), here(Loc.VIDEOS)) { go(Loc.VIDEOS) }
        RailItem(DexIcons.Audio, Color(0xFF7C8CFF), here(Loc.AUDIO)) { go(Loc.AUDIO) }
        RailItem(DexIcons.Document, Color(0xFFFFA23A), here(Loc.DOCS)) { go(Loc.DOCS) }
        RailItem(DexIcons.Apk, Color(0xFF5FD38A), here(Loc.APKS)) { go(Loc.APKS) }
        RailDots()
        for (v in vm.volumes) RailItem(if (v.primary) DexIcons.Phone else DexIcons.SdCard, Color(0xFF5B9BFF), cur.path == v.path || cur.path.startsWith(v.path.trimEnd('/') + "/")) { go(v.path) }
        RailDots()
        RailItem(DexIcons.Trash, Color(0xFF9AA0AC), here(Loc.TRASH)) { go(Loc.TRASH) }
        RailItem(DexIcons.Analyze, Color(0xFF5B9BFF), here(Loc.ANALYZE)) { go(Loc.ANALYZE) }
    }
}

@Composable
private fun RailItem(icon: ImageVector, tint: Color, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(width = 52.dp, height = 46.dp).clip(Radius.m).background(if (selected) Sel.plate() else Color.Transparent).then(if (selected) Modifier.border(1.dp, Sel.edge(), Radius.m) else Modifier).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, Modifier.size(22.dp), tint = lightSafe(tint)) }
}

@Composable
private fun RailDots() {
    val c = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)
    Box(
        Modifier.padding(vertical = 8.dp).size(width = 24.dp, height = 2.dp).drawBehind {
            drawLine(c, androidx.compose.ui.geometry.Offset(0f, 1.dp.toPx()), androidx.compose.ui.geometry.Offset(size.width, 1.dp.toPx()), strokeWidth = 1.5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(1f, 5.dp.toPx())))
        },
    )
}

@Composable
private fun SideItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    dropDest: String? = null,
    tint: Color? = null,
    trailing: (@Composable () -> Unit)? = null,
    onTrailing: (() -> Unit)? = null,
    onDropHold: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val vm = LocalVm.current
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    LaunchedEffect(dropHover) { if (dropHover && onDropHold != null) { kotlinx.coroutines.delay(650); onDropHold() } }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> Sel.plate()
        hovered -> Sel.hover()
        else -> Color.Transparent
    }
    val ink = if (selected) cs.onSurface else cs.onSurface.copy(alpha = 0.86f)
    val edge = Sel.edge()
    Row(
        Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).background(bg).then(if (selected) Modifier.border(1.dp, edge, CircleShape) else Modifier).hoverable(src)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = tint?.let { lightSafe(it) } ?: ink)
        Text(label, fontSize = 15.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (trailing != null) {
            if (onTrailing != null) Row(Modifier.clip(CircleShape).clickable(onClick = onTrailing).padding(6.dp)) { trailing() } else trailing()
        }
    }
}

/** Category colours are tuned for AMOLED; on the light canvas they are deepened so the amber and mint icons keep their contrast. */
@Composable
internal fun lightSafe(c: Color): Color =
    if (MaterialTheme.colorScheme.background.luminance() < 0.5f) c else androidx.compose.ui.graphics.lerp(c, Color.Black, 0.30f)
