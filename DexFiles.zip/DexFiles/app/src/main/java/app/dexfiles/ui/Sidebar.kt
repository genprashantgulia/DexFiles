package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.layout.width
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.Format
import app.dexfiles.data.Volume
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import java.io.File

@Composable
fun Sidebar(vm: ExplorerViewModel, modifier: Modifier = Modifier, onNavigated: () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    val cur = vm.current
    val O = androidx.compose.material.icons.Icons.Outlined

    fun go(path: String) {
        if (Mods.tertiaryDown && !Loc.isVirtual(path)) vm.openInNewTab(path) else vm.navigate(vm.current, path)
        onNavigated()
    }

    fun here(path: String) = cur.path == path && !cur.isSearch
    val downloads = File(vm.primaryRoot, "Download").path
    val pinned = vm.favorites.filter { it != downloads && it != File(vm.primaryRoot, "Documents").path }

    Column(modifier.fillMaxHeight()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp)) {
            SideItem(O.Schedule, cs.onSurface, "Recent files", here(Loc.HOME)) { go(Loc.HOME) }
            Dots()
            SideItem(O.Download, Color(0xFF29C5B5), "Downloads", here(downloads)) { go(downloads) }
            SideItem(O.Description, Color(0xFFF5A623), "Documents", here(Loc.DOCS)) { go(Loc.DOCS) }
            SideItem(O.Image, Color(0xFFEC5B8E), "Images", here(Loc.IMAGES)) { go(Loc.IMAGES) }
            SideItem(O.MusicNote, Color(0xFF6C7BFF), "Audio files", here(Loc.AUDIO)) { go(Loc.AUDIO) }
            SideItem(O.Movie, Color(0xFF9B5CF6), "Videos", here(Loc.VIDEOS)) { go(Loc.VIDEOS) }
            SideItem(
                O.Folder, Color(0xFF7ED321), "Installation files", here(Loc.APKS),
                leading = { Text("APK", style = MaterialTheme.typography.labelSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = Color(0xFF7ED321), modifier = Modifier.width(22.dp), maxLines = 1) },
            ) { go(Loc.APKS) }
            Dots()
            for (v in vm.volumes) VolumeTree(vm, v, here(v.path), ::go)
            if (pinned.isNotEmpty()) {
                Dots()
                for (fav in pinned) {
                    val name = File(fav).name.ifEmpty { fav }
                    SideItem(
                        favIcon(name), Color.Unspecified, name, here(fav), dropDest = fav,
                        trailing = { Icon(Icons.Filled.Close, "Unpin", Modifier.size(14.dp).clickable { vm.toggleFavorite(fav) }) },
                    ) { go(fav) }
                }
            }
            Dots()
            SideItem(O.Delete, cs.onSurface, "Trash", here(Loc.TRASH)) { go(Loc.TRASH) }
            SideItem(O.PieChart, cs.onSurface, "Analyze storage", here(Loc.ANALYZE)) { go(Loc.ANALYZE) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconBtn(Icons.Filled.Settings, "Settings", size = 44.dp) { vm.dialog = DialogState.Settings }
            IconBtn(Icons.Filled.Keyboard, "Keyboard shortcuts (F1)", size = 44.dp) { vm.dialog = DialogState.Shortcuts }
        }
    }
}

@Composable
private fun Dots() = DottedLine(Modifier.padding(horizontal = 12.dp, vertical = 10.dp))

/** Samsung storage entry: two lines (name, used / total) with a chevron that opens the top-level folders in place. */
@Composable
private fun VolumeTree(vm: ExplorerViewModel, v: Volume, selected: Boolean, go: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val kids by androidx.compose.runtime.produceState(initialValue = emptyList<File>(), open, vm.showHidden) {
        value = if (!open) emptyList() else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            File(v.path).listFiles { f -> f.isDirectory && (vm.showHidden || !f.name.startsWith(".")) }?.sortedBy { it.name.lowercase() }.orEmpty()
        }
    }
    val icon = when {
        v.primary -> androidx.compose.material.icons.Icons.Outlined.PhoneAndroid
        v.label.contains("usb", ignoreCase = true) -> Icons.Filled.Usb
        else -> androidx.compose.material.icons.Icons.Outlined.SdCard
    }
    Row(
        Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(Dimens.radiusRow))
            .background(if (selected) cs.onSurface.copy(alpha = 0.10f) else Color.Transparent)
            .folderDrop(vm, v.path) { }
            .clickable { go(v.path) }.padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = cs.onSurface)
        Column(Modifier.weight(1f)) {
            Text(v.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (v.total > 0) Text("${Format.size(v.used)} / ${Format.size(v.total)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Box(
            Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape).clickable { open = !open },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Filled.KeyboardArrowDown, if (open) "Collapse" else "Expand",
                Modifier.size(24.dp).rotate(if (open) 180f else 0f), tint = cs.onSurfaceVariant,
            )
        }
    }
    for (k in kids) {
        SideItem(Icons.Filled.Folder, Color.Unspecified, k.name, false, dropDest = k.path, indent = 18.dp) { go(k.path) }
    }
}

private fun favIcon(name: String): ImageVector = when (name.lowercase()) {
    "download", "downloads" -> Icons.Filled.Download
    "dcim", "pictures" -> Icons.Filled.Image
    "music" -> Icons.Filled.MusicNote
    "movies", "videos" -> Icons.Filled.Movie
    "documents" -> Icons.Filled.Description
    else -> Icons.Filled.Folder
}

@Composable
private fun SideHeader(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
        modifier = Modifier.padding(start = 12.dp, top = 20.dp, bottom = 6.dp),
    )
}

@Composable
private fun SideItem(
    icon: ImageVector,
    tint: Color,
    label: String,
    selected: Boolean,
    dropDest: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    indent: androidx.compose.ui.unit.Dp = 0.dp,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.onSurface.copy(alpha = 0.10f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val vm = LocalVm.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(Dimens.touch)
            .clip(RoundedCornerShape(Dimens.radiusRow))
            .background(bg)
            .hoverable(interaction)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(start = 10.dp + indent, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        val c = if (tint == Color.Unspecified) (if (icon == Icons.Filled.Folder) kindColor(app.dexfiles.core.FileKind.FOLDER) else cs.onSurface.copy(alpha = 0.8f)) else tint
        if (leading != null) leading() else Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = c)
        Text(label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (trailing != null && hovered) trailing()
    }
}

@Composable
private fun VolumeItem(vm: ExplorerViewModel, v: Volume, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.primary.copy(alpha = 0.16f)
        hovered -> cs.onSurface.copy(alpha = 0.07f)
        else -> Color.Transparent
    }
    val icon = when {
        v.primary -> Icons.Filled.PhoneAndroid
        v.label.contains("usb", ignoreCase = true) -> Icons.Filled.Usb
        else -> Icons.Filled.SdCard
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Dimens.radiusCard))
            .background(if (selected) bg else cs.surfaceContainer)
            .hoverable(interaction)
            .folderDrop(vm, v.path) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = cs.onSurface.copy(alpha = 0.8f))
            Text(v.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (v.total > 0) {
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(
                progress = { v.usedFraction },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = if (v.usedFraction > 0.9f) cs.error else cs.primary,
                trackColor = cs.onSurface.copy(alpha = 0.12f),
            )
            Text(
                "${Format.size(v.total - v.free)} / ${Format.size(v.total)} used",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
