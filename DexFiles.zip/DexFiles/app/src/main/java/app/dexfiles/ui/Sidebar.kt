package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.BarChart as OlBarChart
import androidx.compose.material.icons.outlined.Delete as OlDelete
import androidx.compose.material.icons.outlined.FileDownload as OlDownload
import androidx.compose.material.icons.outlined.Description as OlDescription
import androidx.compose.material.icons.outlined.Image as OlImage
import androidx.compose.material.icons.outlined.Movie as OlMovie
import androidx.compose.material.icons.outlined.MusicNote as OlMusicNote
import androidx.compose.material.icons.outlined.PhoneAndroid as OlPhoneAndroid
import androidx.compose.material.icons.outlined.SdCard as OlSdCard
import androidx.compose.material.icons.outlined.Schedule as OlSchedule
import androidx.compose.material.icons.outlined.Settings as OlSettings
import androidx.compose.material.icons.outlined.Android as OlAndroid
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import app.dexfiles.core.FileEntry
import androidx.compose.foundation.relocation.bringIntoViewRequester
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.data.Volume
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import java.io.File

// Built from the mock's Sidebar board: 264 wide, padding 4 / 8 / 12 / 12, items 46 high pills, 15/500, uppercase captions,
// storage tree with 42 high sub-items indented 44, and Trash / Analyze storage / Settings pinned to the bottom.

@Composable
fun Sidebar(vm: ExplorerViewModel, modifier: Modifier = Modifier, startPad: androidx.compose.ui.unit.Dp = 12.dp, onNavigated: () -> Unit = {}) {
    val O = Icons.Outlined
    fun go(path: String) {
        if (Mods.tertiaryDown && !Loc.isVirtual(path)) vm.openInNewTab(path) else vm.navigate(vm.current, path)
        onNavigated()
    }
    val cur = vm.current
    fun here(path: String) = cur.path == path && !cur.isSearch
    // Tree state lives here so it survives navigation: which folders are open, and their sub-folders once loaded.
    val open = remember { mutableStateMapOf<String, Boolean>() }
    val kids = remember { mutableStateMapOf<String, List<String>>() }
    LaunchedEffect(vm.volumes.size) { vm.volumes.firstOrNull { it.primary }?.let { open[it.path] = true } }
    // Follow the current folder: open every ancestor so the tree always shows where you are.
    LaunchedEffect(cur.path) {
        if (!Loc.isVirtual(cur.path) && !cur.isSearch) {
            val v = vm.volumes.firstOrNull { cur.path == it.path || cur.path.startsWith(it.path.trimEnd('/') + "/") }
            if (v != null) {
                var f = File(cur.path).parentFile
                while (f != null && f.path.length >= v.path.trimEnd('/').length) { open[f.path] = true; f = f.parentFile }
            }
        }
    }

    // One scrolling list: nothing is pinned, so the storage tree gets all the room (Settings is also in the ⋮ menu).
    Column(
        modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = startPad, end = 8.dp, top = 4.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        SideItem(O.OlSchedule, "Recent files", here(Loc.HOME), tint = Color(0xFFFFC93C)) { go(Loc.HOME) }
        Caption("CATEGORIES")
        val dl = File(vm.primaryRoot, "Download").path
        SideItem(O.OlDownload, "Downloads", here(dl), tint = Color(0xFF2EC4B6)) { go(dl) }
        SideItem(O.OlImage, "Images", here(Loc.IMAGES), tint = Color(0xFFFF6B8A)) { go(Loc.IMAGES) }
        SideItem(O.OlMovie, "Videos", here(Loc.VIDEOS), tint = Color(0xFFA98BFF)) { go(Loc.VIDEOS) }
        SideItem(O.OlMusicNote, "Audio", here(Loc.AUDIO), tint = Color(0xFF7C8CFF)) { go(Loc.AUDIO) }
        SideItem(O.OlDescription, "Documents", here(Loc.DOCS), tint = Color(0xFFFFA23A)) { go(Loc.DOCS) }
        SideItem(O.OlAndroid, "Installation files", here(Loc.APKS), tint = Color(0xFF5FD38A)) { go(Loc.APKS) }
        Caption("STORAGE")
        for (v in vm.volumes) VolumeTree(vm, v, open, kids, ::go, ::here)
        Caption("TOOLS")
        SideItem(O.OlDelete, "Trash", here(Loc.TRASH), tint = Color(0xFF9AA0AC)) { go(Loc.TRASH) }
        SideItem(O.OlBarChart, "Analyze storage", here(Loc.ANALYZE), tint = Color(0xFF5B9BFF)) { go(Loc.ANALYZE) }
        SideItem(O.OlSettings, "Settings", vm.settingsOpen, tint = Color(0xFF9AA0AC)) { vm.openSettings(fromLeft = true); onNavigated() }
    }
}

@Composable
private fun Caption(text: String) {
    Text(
        text,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
    )
}

private fun listDirs(path: String, showHidden: Boolean, root: Boolean): List<String> {
    val dirs = File(path).listFiles { f -> f.isDirectory && (showHidden || !f.name.startsWith(".")) }?.toList().orEmpty()
    val curated = listOf("Download", "Documents", "DCIM", "Pictures", "Music", "Movies")
    return dirs.sortedWith(
        compareBy<File>({ if (root) curated.indexOf(it.name).let { i -> if (i < 0) 99 else i } else 0 }, { it.name.lowercase() }),
    ).map { it.path }
}

/** A storage volume (46 high pill) and, beneath it, a real expandable tree of its folders. */
@Composable
private fun VolumeTree(
    vm: ExplorerViewModel, v: Volume, open: androidx.compose.runtime.snapshots.SnapshotStateMap<String, Boolean>,
    kids: androidx.compose.runtime.snapshots.SnapshotStateMap<String, List<String>>, go: (String) -> Unit, here: (String) -> Boolean,
) {
    val cs = MaterialTheme.colorScheme
    val isOpen = open[v.path] == true
    LaunchedEffect(isOpen, vm.showHidden) {
        if (isOpen) kids[v.path] = withContext(Dispatchers.IO) { listDirs(v.path, vm.showHidden, true) }
    }
    SideItem(
        if (v.primary) Icons.Outlined.OlPhoneAndroid else Icons.Outlined.OlSdCard, v.label, here(v.path), dropDest = v.path,
        tint = Color(0xFF5B9BFF),
        trailing = {
            Icon(Icons.Filled.KeyboardArrowDown, if (isOpen) "Collapse" else "Expand", Modifier.size(18.dp).rotate(if (isOpen) 180f else 0f), tint = cs.onSurfaceVariant)
        },
        onTrailing = { open[v.path] = !isOpen },
    ) { go(v.path) }
    androidx.compose.animation.AnimatedVisibility(
        visible = isOpen,
        enter = androidx.compose.animation.expandVertically(app.dexfiles.ui2.design.Motion.glide(320)) + androidx.compose.animation.fadeIn(app.dexfiles.ui2.design.Motion.glide(240)),
        exit = androidx.compose.animation.shrinkVertically(app.dexfiles.ui2.design.Motion.glide(260)) + androidx.compose.animation.fadeOut(app.dexfiles.ui2.design.Motion.glide(160)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (k in kids[v.path].orEmpty()) TreeNode(vm, k, 1, open, kids, go, here)
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TreeNode(
    vm: ExplorerViewModel, path: String, depth: Int, open: androidx.compose.runtime.snapshots.SnapshotStateMap<String, Boolean>,
    kids: androidx.compose.runtime.snapshots.SnapshotStateMap<String, List<String>>, go: (String) -> Unit, here: (String) -> Boolean,
) {
    val cs = MaterialTheme.colorScheme
    val isOpen = open[path] == true
    val selected = here(path)
    LaunchedEffect(isOpen, vm.showHidden) {
        if (isOpen) kids[path] = withContext(Dispatchers.IO) { listDirs(path, vm.showHidden, false) }
    }
    val children = kids[path]
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val req = remember { androidx.compose.foundation.relocation.BringIntoViewRequester() }
    LaunchedEffect(selected) { if (selected) { kotlinx.coroutines.delay(260); req.bringIntoView() } }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.primary.copy(alpha = 0.16f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val ink = if (selected) Color(0xFFFFD257).takeIf { cs.background == Color.Black } ?: cs.primary else cs.onSurface.copy(alpha = 0.78f)
    val entry = remember(path) { FileEntry(path, File(path).name, true, 0L, 0L, false) }
    Row(
        Modifier.fillMaxWidth().height(42.dp).bringIntoViewRequester(req).clip(CircleShape).background(bg).hoverable(src)
            .folderDrop(vm, path) { dropHover = it }
            .clickable(interactionSource = src, indication = null) { go(path) }
            .padding(start = 20.dp + 16.dp * (depth - 1), end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(24.dp).clip(CircleShape).clickable { open[path] = !isOpen }, contentAlignment = Alignment.Center) {
            if (children == null || children.isNotEmpty()) {
                Icon(Icons.Filled.ChevronRight, if (isOpen) "Collapse" else "Expand", Modifier.size(18.dp).rotate(if (isOpen) 90f else 0f), tint = cs.onSurfaceVariant)
            }
        }
        FileThumb(entry, 22.dp, crop = false)
        Text(entry.name, fontSize = 14.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
    }
    androidx.compose.animation.AnimatedVisibility(
        visible = isOpen && !children.isNullOrEmpty(),
        enter = androidx.compose.animation.expandVertically(app.dexfiles.ui2.design.Motion.glide(300)) + androidx.compose.animation.fadeIn(app.dexfiles.ui2.design.Motion.glide(220)),
        exit = androidx.compose.animation.shrinkVertically(app.dexfiles.ui2.design.Motion.glide(240)) + androidx.compose.animation.fadeOut(app.dexfiles.ui2.design.Motion.glide(140)),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (k in children.orEmpty()) TreeNode(vm, k, depth + 1, open, kids, go, here)
        }
    }
}

@Composable
private fun SideItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    dropDest: String? = null,
    tint: Color? = null,
    trailing: (@Composable () -> Unit)? = null,
    onTrailing: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val vm = LocalVm.current
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.28f)
        selected -> cs.primary.copy(alpha = 0.16f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val ink = if (selected) Color(0xFFFFD257).takeIf { cs.background == Color.Black } ?: cs.primary else cs.onSurface.copy(alpha = 0.86f)
    Row(
        Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).background(bg).hoverable(src)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = tint ?: ink)
        Text(label, fontSize = 15.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (trailing != null) {
            if (onTrailing != null) Row(Modifier.clip(CircleShape).clickable(onClick = onTrailing).padding(6.dp)) { trailing() } else trailing()
        }
    }
}
