package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Tone-based separation (no borders): canvas < card < raised < overlay. */
@Immutable
class Palette(
    val canvas: Color, val card: Color, val raised: Color, val overlay: Color,
    val text: Color, val textDim: Color, val textFaint: Color,
    val accent: Color, val onAccent: Color, val accentSoft: Color,
    val danger: Color, val hairline: Color,
)

val DarkPalette = Palette(
    canvas = Color(0xFF000000), card = Color(0xFF0C0C0E), raised = Color(0xFF121214), overlay = Color(0xFF26262C),
    text = Color(0xFFF2F2F4), textDim = Color(0xFF8E8E96), textFaint = Color(0xFF6C6C74),
    accent = Color(0xFFFFC93C), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFF29200A),
    danger = Color(0xFFFF8A80), hairline = Color(0x14FFFFFF),
)

val LightPalette = Palette(
    canvas = Color(0xFFF4F2EC), card = Color(0xFFFFFFFF), raised = Color(0xFFEDEAE2), overlay = Color(0xFFFFFFFF),
    text = Color(0xFF141412), textDim = Color(0xFF66625A), textFaint = Color(0xFF9C978C),
    accent = Color(0xFF9A6A00), onAccent = Color(0xFFFFFFFF), accentSoft = Color(0xFFFFEFC2),
    danger = Color(0xFFD93636), hairline = Color(0x14000000),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }
