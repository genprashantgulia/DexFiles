package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Tone-based separation (no borders): canvas < card < raised < overlay. */
@Immutable
class Palette(
    val canvas: Color, val card: Color, val raised: Color, val overlay: Color,
    val text: Color, val textDim: Color, val textFaint: Color,
    val accent: Color, val onAccent: Color, val accentSoft: Color,
    val danger: Color, val hairline: Color,
    /** Switch tracks, dashed outlines, slider rails: stronger than a hairline, quieter than text. */
    val strong: Color,
)

val DarkPalette = Palette(
    canvas = Color(0xFF000000), card = Color(0xFF0C0C0E), raised = Color(0xFF121214), overlay = Color(0xFF26262C),
    text = Color(0xFFF2F2F4), textDim = Color(0xFF8E8E96), textFaint = Color(0xFF6C6C74),
    accent = Color(0xFFFFC93C), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFF29200A),
    danger = Color(0xFFFF8A80), hairline = Color(0x14FFFFFF), strong = Color(0xFF3A3A42),
)

val LightPalette = Palette(
    canvas = Color(0xFFECECF1), card = Color(0xFFFFFFFF), raised = Color(0xFFF4F4F8), overlay = Color(0xFFFFFFFF),
    text = Color(0xFF17171A), textDim = Color(0xFF5A5A66), textFaint = Color(0xFF8A8A94),
    accent = Color(0xFFB07A00), onAccent = Color(0xFFFFFFFF), accentSoft = Color(0xFFFFE9A8),
    danger = Color(0xFFD93636), hairline = Color(0x14000000), strong = Color(0xFFC9C9D2),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

/** The category colours of the sidebar and rail. One place, so a place has the same colour wherever it appears. */
object Tint {
    val Recent = Color(0xFFFFC93C); val Downloads = Color(0xFF2EC4B6); val Images = Color(0xFFFF6B8A)
    val Videos = Color(0xFFA98BFF); val Audio = Color(0xFF7C8CFF); val Docs = Color(0xFFFFA23A)
    val Apks = Color(0xFF5FD38A); val Trash = Color(0xFF9AA0AC); val Storage = Color(0xFF5B9BFF)
}
