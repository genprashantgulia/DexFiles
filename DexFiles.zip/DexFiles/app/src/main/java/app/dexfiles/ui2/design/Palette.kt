package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Tone-based separation (no borders): canvas < card < raised < overlay. */
@Immutable
class Palette(
    val canvas: Color, val card: Color, val raised: Color, val overlay: Color,
    val text: Color, val textDim: Color, val textFaint: Color,
    val accent: Color, val onAccent: Color, val accentSoft: Color,
    val danger: Color, val ok: Color, val hairline: Color,
    /** Switch tracks, dashed outlines, slider rails: stronger than a hairline, quieter than text. */
    val strong: Color,
    /** Hairline drawn inside a selected plate. */
    val selectLine: Color,
    /** The step above [overlay] (menus on dialogs) and the quiet outline between rows. */
    val raisedHigh: Color, val outlineSoft: Color,
)

val DarkPalette = Palette(
    canvas = Color(0xFF000000), card = Color(0xFF0C0C0E), raised = Color(0xFF17171B), overlay = Color(0xFF1C1C21),
    text = Color(0xFFF2F2F4), textDim = Color(0xFF8E8E96), textFaint = Color(0xFF6C6C74),
    accent = Color(0xFFFFC93C), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFF29200A),
    danger = Color(0xFFFF6B5E), ok = Color(0xFF4CD08A), hairline = Color(0x14FFFFFF), strong = Color(0xFF3A3A42), selectLine = Color(0xFF6A521A),
    raisedHigh = Color(0xFF26262C), outlineSoft = Color(0xFF1D1D22),
)

val LightPalette = Palette(
    canvas = Color(0xFFF2F2F5), card = Color(0xFFFFFFFF), raised = Color(0xFFECECF0), overlay = Color(0xFFFFFFFF),
    text = Color(0xFF1A1A1F), textDim = Color(0xFF6A6A74), textFaint = Color(0xFF9A9AA6),
    accent = Color(0xFFD99A00), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFFFFF3CC),
    danger = Color(0xFFD93B2E), ok = Color(0xFF2E9E5B), hairline = Color(0x14000000), strong = Color(0xFFC9C9D2), selectLine = Color(0xFFE8C558),
    raisedHigh = Color(0xFFE9E9EE), outlineSoft = Color(0xFFDCDCE2),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

/** The category colours of the sidebar and rail. One place, so a place has the same colour wherever it appears. */
object Tint {
    val Recent = Color(0xFFFFC93C); val Downloads = Color(0xFF2EC4B6); val Images = Color(0xFFFF6B8A)
    val Videos = Color(0xFFA98BFF); val Audio = Color(0xFF7C8CFF); val Docs = Color(0xFFFFA23A)
    val Apks = Color(0xFF5FD38A); val Trash = Color(0xFF9AA0AC); val Storage = Color(0xFF5B9BFF)
}
