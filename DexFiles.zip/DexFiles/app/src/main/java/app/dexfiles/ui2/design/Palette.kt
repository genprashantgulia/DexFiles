package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Tone-based separation (no borders): canvas < card < raised < overlay. */
@Immutable
class Palette(
    val canvas: Color, val card: Color, val raised: Color, val overlay: Color,
    val text: Color, val textDim: Color, val textFaint: Color,
    val accent: Color, val onAccent: Color, val accentSoft: Color,
    val danger: Color, val ok: Color, val hairline: Color,
    /** Switch tracks, dashed outlines, slider rails: stronger than a hairline, quieter than text. */
    val strong: Color,
    /** Hairline drawn inside a selected plate: 3:1 against the card in both themes, so selection never depends on colour alone. */
    val selectLine: Color,
    /** The step above [overlay] (menus on dialogs) and the quiet outline between rows. */
    val raisedHigh: Color, val outlineSoft: Color,
    /** Amber that carries meaning as an outline or a mark (focus ring, checked controls). Equals [accent] in dark; darker in light so it reaches 3:1 on white. */
    val accentUi: Color,
    /** Amber used as text on a card or on the selection plate (4.5:1 in both themes). */
    val accentText: Color,
)

val DarkPalette = Palette(
    canvas = Color(0xFF000000), card = Color(0xFF0C0C0E), raised = Color(0xFF17171B), overlay = Color(0xFF1C1C21),
    text = Color(0xFFF2F2F4), textDim = Color(0xFF8E8E96), textFaint = Color(0xFF85858F),
    accent = Color(0xFFFFC93C), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFF29200A),
    danger = Color(0xFFFF6B5E), ok = Color(0xFF4CD08A), hairline = Color(0x14FFFFFF), strong = Color(0xFF3A3A42), selectLine = Color(0xFF7A5A14),
    raisedHigh = Color(0xFF26262C), outlineSoft = Color(0xFF1D1D22),
    accentUi = Color(0xFFFFC93C), accentText = Color(0xFFFFD257),
)

val LightPalette = Palette(
    canvas = Color(0xFFF2F2F5), card = Color(0xFFFFFFFF), raised = Color(0xFFECECF0), overlay = Color(0xFFFFFFFF),
    text = Color(0xFF1A1A1F), textDim = Color(0xFF6A6A74), textFaint = Color(0xFF5E626B),
    accent = Color(0xFFD99A00), onAccent = Color(0xFF1A1200), accentSoft = Color(0xFFFFF3CC),
    danger = Color(0xFFC0322A), ok = Color(0xFF1F7A44), hairline = Color(0x14000000), strong = Color(0xFFC9C9D2), selectLine = Color(0xFFB07A00),
    raisedHigh = Color(0xFFE9E9EE), outlineSoft = Color(0xFFDCDCE2),
    accentUi = Color(0xFFB07A00), accentText = Color(0xFF8F6200),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

/** The category colours of the sidebar and rail. One place, so a place has the same colour wherever it appears. */
object Tint {
    val Recent = Color(0xFFFFC93C); val Downloads = Color(0xFF2EC4B6); val Images = Color(0xFFFF6B8A)
    val Videos = Color(0xFFA98BFF); val Audio = Color(0xFF7C8CFF); val Docs = Color(0xFFFFA23A)
    val Apks = Color(0xFF5FD38A); val Trash = Color(0xFF9AA0AC); val Storage = Color(0xFF5B9BFF)
}
