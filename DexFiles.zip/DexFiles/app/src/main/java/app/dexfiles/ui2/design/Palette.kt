package app.dexfiles.ui2.design

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Tone-based separation (no borders): canvas < card < raised < overlay. */
@Immutable
class Palette(
    val canvas: Color, val card: Color, val raised: Color, val overlay: Color,
    val text: Color, val textDim: Color, val textFaint: Color,
    val accent: Color, val onAccent: Color, val accentSoft: Color,
    val danger: Color, val hairline: Color,
)

val DarkPalette = Palette(
    canvas = Color(0xFF000000), card = Color(0xFF0E0E10), raised = Color(0xFF1A1A1D), overlay = Color(0xFF242428),
    text = Color(0xFFF2F2F5), textDim = Color(0xFFA0A0A8), textFaint = Color(0xFF6C6C74),
    accent = Color(0xFF6BA4FF), onAccent = Color(0xFF001B3F), accentSoft = Color(0xFF14233B),
    danger = Color(0xFFFF6B6B), hairline = Color(0x14FFFFFF),
)

val LightPalette = Palette(
    canvas = Color(0xFFF2F2F6), card = Color(0xFFFFFFFF), raised = Color(0xFFEAEAF0), overlay = Color(0xFFFFFFFF),
    text = Color(0xFF111114), textDim = Color(0xFF5F5F68), textFaint = Color(0xFF9A9AA3),
    accent = Color(0xFF1F6BE8), onAccent = Color(0xFFFFFFFF), accentSoft = Color(0xFFDDE8FC),
    danger = Color(0xFFD93636), hairline = Color(0x14000000),
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }
