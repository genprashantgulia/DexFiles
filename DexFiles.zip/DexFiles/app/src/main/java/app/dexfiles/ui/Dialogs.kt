package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.em
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.dexfiles.core.BatchRename
import app.dexfiles.core.CancelToken
import app.dexfiles.core.Hashing
import app.dexfiles.core.OperationCancelled
import app.dexfiles.core.BatchRenameSpec
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.FileOps
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.OnConflict
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------- context menu

@Composable
private fun CtxItem(label: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val tint = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    DropdownMenuItem(
        text = { Text(label, color = tint) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp), tint = tint) },
        onClick = onClick,
    )
}

/** Right-click (mouse) or long-press (touch) menu, for a file, a folder, or empty space. */
@Composable
fun ContextMenuHost(vm: ExplorerViewModel) {
    val m = vm.menu ?: return
    val tab = vm.panes[m.pane].tab
    val target = m.target
    fun close() { vm.menu = null }
    // Positions are window coordinates; this host sits inside the system-bar padding, so take that padding off again.
    val bars = androidx.compose.foundation.layout.WindowInsets.systemBars
    val density = androidx.compose.ui.platform.LocalDensity.current
    val dir = androidx.compose.ui.platform.LocalLayoutDirection.current
    Box(Modifier.offset { IntOffset(m.pos.x.roundToInt() - bars.getLeft(density, dir), m.pos.y.roundToInt() - bars.getTop(density)) }) {
        DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = true, onDismissRequest = { close() }) {
            if (tab.path == Loc.TRASH) {
                if (target != null) {
                    ActionMenuItems(fileActions(vm, tab, vm.selectedEntries(tab).ifEmpty { listOf(target) }, vm.panes[m.pane]), primary = true, close = ::close)
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                }
                CtxItem("Empty Trash", DexIcons.Trash, danger = true) { close(); vm.dialog = DialogState.EmptyTrash }
                return@DropdownMenu
            }
            val canWrite = Rules.canWriteHere(tab)
            if (target != null) {
                // The same action list as the selection pill's More menu (see FileActions.kt).
                val sel = vm.selectedEntries(tab).ifEmpty { listOf(target) }
                ActionMenuItems(fileActions(vm, tab, sel, vm.panes[m.pane]), primary = true, close = ::close)
            } else {
                if (canWrite) {
                    CtxItem("New folder", DexIcons.NewFolder) { close(); vm.requestNew(folder = true) }
                    CtxItem("New file", DexIcons.NewFile) { close(); vm.requestNew(folder = false) }
                    if (vm.clip != null) CtxItem("Paste", DexIcons.Paste) { close(); vm.paste() }
                    HorizontalDivider()
                }
                CtxItem("Select all", DexIcons.SelectAll) { close(); vm.selectAll(tab) }
                CtxItem("Refresh", DexIcons.Reset) { close(); vm.refresh(tab) }
                if (!tab.isVirtual && !tab.isSearch) CtxItem("Properties", DexIcons.Info) { close(); vm.openProperties(tab) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- dialogs

@Composable
fun DialogHost(vm: ExplorerViewModel) {
    when (val d = vm.dialog) {
        null -> Unit
        is DialogState.Rename -> NameDialog(
            title = "Rename",
            confirm = "Rename",
            initial = d.entry.name,
            selectBaseName = !d.entry.isDir,
            onDismiss = { vm.dialog = null },
            onConfirm = { name ->
                if (name == d.entry.name) { vm.dialog = null; null }
                else vm.renameNow(d.entry, name).also { if (it == null) vm.dialog = null }
            },
        )
        is DialogState.NewItem -> NameDialog(
            title = if (d.folder) "New folder" else "New file",
            confirm = "Create",
            initial = if (d.folder) "New folder" else "New file.txt",
            selectBaseName = !d.folder,
            onDismiss = { vm.dialog = null },
            onConfirm = { name -> vm.createNow(d.folder, d.parent, name).also { if (it == null) vm.dialog = null } },
        )
        is DialogState.Compress -> NameDialog(
            title = "Compress to zip",
            confirm = "Compress",
            initial = if (d.entries.size == 1) d.entries[0].name.substringBeforeLast('.', d.entries[0].name) else "Archive",
            selectBaseName = false,
            onDismiss = { vm.dialog = null },
            onConfirm = { name -> vm.compress(d.entries, d.parent, name); vm.dialog = null; null },
        )
        is DialogState.ConfirmDelete -> {
            val n = d.entries.size
            val what = if (n == 1) "\u201C${d.entries[0].name}\u201D" else "$n items"
            DexDialog(
                title = if (d.permanent) "Delete $what permanently?" else "Move $what to Trash?",
                onDismiss = { vm.dialog = null },
                actions = {
                    DexButton("Cancel") { vm.dialog = null }
                    DexButton(if (d.permanent) "Delete" else "Move to Trash", DexBtn.Danger) {
                        vm.dialog = null
                        if (d.permanent) vm.deleteForever(d.entries) else vm.moveToTrash(d.entries)
                    }
                },
            ) { DexBody(if (d.permanent) "This can\u2019t be undone." else "You can restore ${if (n == 1) "it" else "them"} from Trash.") }
        }
        DialogState.EmptyTrash -> DexDialog(
            title = "Empty Trash?",
            onDismiss = { vm.dialog = null },
            actions = {
                DexButton("Cancel") { vm.dialog = null }
                DexButton("Empty Trash", DexBtn.Danger) { vm.dialog = null; vm.emptyTrashNow() }
            },
        ) { DexBody("Everything in Trash will be deleted for good.") }
        is DialogState.Conflicts -> ConflictDialog(vm, d)
        is DialogState.Properties -> PropertiesDialog(d.entries) { vm.dialog = null }
        is DialogState.CustomizeFolder -> CustomizeFolderDialog(vm, d.entry)
        is DialogState.BatchRenameDlg -> BatchRenameDialog(vm, d.entries)
        is DialogState.Archive -> ExtractDialog(vm, d.entry)
        is DialogState.Message -> DexDialog(
            title = d.title,
            onDismiss = { vm.dialog = null },
            actions = { DexButton("OK", DexBtn.Primary) { vm.dialog = null } },
        ) { d.lines.forEach { DexBody(it) } }
        DialogState.Shortcuts -> ShortcutsDialog { vm.dialog = null }
        DialogState.Palette -> Palette(vm)
    }
}

/**
 * iPad-style rename/new-name popover near the top of the window: the name is selected (without the extension),
 * the keyboard opens at once, Enter confirms. [onConfirm] returns an error message, or null when it worked.
 */
@Composable
private fun NameDialog(
    title: String,
    confirm: String,
    initial: String,
    selectBaseName: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> String?,
) {
    val cs = MaterialTheme.colorScheme
    var value by remember {
        val end = if (selectBaseName && initial.contains('.')) initial.lastIndexOf('.') else initial.length
        mutableStateOf(TextFieldValue(initial, TextRange(0, end)))
    }
    var error by remember { mutableStateOf<String?>(null) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    fun submit() {
        val problem = FileOps.validateName(value.text.trim())
        error = problem ?: onConfirm(value.text.trim())
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }, contentAlignment = Alignment.TopCenter) {
            androidx.compose.material3.Surface(
                shape = Radius.xl,
                color = dialogSurface(),
                tonalElevation = 0.dp,
                shadowElevation = 24.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
                modifier = Modifier.padding(top = 110.dp, start = 16.dp, end = 16.dp).width(440.dp).pointerInput(Unit) { detectTapGestures { } },
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(14.dp))
                    DexField(
                        value = value,
                        onChange = { value = it; error = null },
                        error = error != null,
                        imeDone = { submit() },
                        modifier = Modifier.focusRequester(focus),
                    )
                    error?.let { Text(it, fontSize = 12.sp, color = cs.error, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                        DexButton("Cancel", onClick = onDismiss)
                        DexButton(confirm, DexBtn.Primary) { submit() }
                    }
                }
            }
        }
    }
}

@Composable
private fun PropertiesDialog(entries: List<FileEntry>, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val total by produceState(initialValue = -1L, entries) {
        value = withContext(Dispatchers.IO) { entries.sumOf { runCatching { FileOps.sizeOf(File(it.path)) }.getOrDefault(0L) } }
    }
    val single = entries.size == 1
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    DexDialog(
        title = "Properties",
        onDismiss = onDismiss,
        actions = {
            if (single) DexButton("Copy path") { clip.setText(androidx.compose.ui.text.AnnotatedString(entries[0].path)) }
            DexButton("Done", DexBtn.Primary, onClick = onDismiss)
        },
    ) {
        Column(
            Modifier.heightIn(max = 480.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val sizeMain = if (total < 0) "Calculating\u2026" else Format.size(total)
            val sizeSub = if (total >= 1024) "${"%,d".format(total)} bytes" else null
            if (single) {
                val e = entries[0]
                val f = File(e.path)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                        if (e.isDir) Icon(DexIcons.Folder, null, Modifier.size(46.dp), tint = kindColor(FileKind.FOLDER)) else ExtTile(e, 56.dp)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(e.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(FileTypes.typeLabel(e.name, e.isDir), fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                }
                PropSection("General") {
                    PropRow("Size", sizeMain, sizeSub)
                    PropRow("Location", (f.parent ?: "").replace("/storage/emulated/0", "Internal storage").replace("/", " \u203A "))
                    PropRow("Modified", Fmt.dateTime(e.modified))
                    PropRow("Access", if (f.canWrite()) "Read and write" else if (f.canRead()) "Read only" else "No access")
                }
                if (!e.isDir && f.isFile) ChecksumRows(f)
            } else {
                val folders = entries.count { it.isDir }
                val files = entries.size - folders
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${entries.size} items", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                    Text(
                        listOfNotNull(
                            if (files > 0) (if (files == 1) "1 file" else "$files files") else null,
                            if (folders > 0) (if (folders == 1) "1 folder" else "$folders folders") else null,
                        ).joinToString(", "),
                        fontSize = 13.sp, color = cs.onSurfaceVariant,
                    )
                }
                PropSection("General") { PropRow("Total size", sizeMain, sizeSub) }
            }
        }
    }
}

/** A small-caps section title over a group of rows, in the sidebar's heading style, with a hairline above. */
@Composable
private fun PropSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
        Text(title.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.08.em, color = cs.onSurfaceVariant)
        content()
    }
}

/** One label / value line: fixed-width dim label, value that wraps, optional dim second line under it. */
@Composable
private fun PropRow(label: String, value: String, sub: String? = null, mono: Boolean = false, onClick: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, fontSize = 13.sp, color = cs.onSurfaceVariant, modifier = Modifier.width(84.dp))
        Column(Modifier.weight(1f).then(if (onClick != null) Modifier.clip(Radius.xs).clickable(onClick = onClick) else Modifier)) {
            Text(
                value, fontSize = if (mono) 12.sp else 14.sp, color = cs.onSurface,
                fontFamily = if (mono) androidx.compose.ui.text.font.FontFamily.Monospace else null,
            )
            if (sub != null) Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
}

/**
 * Checksums for one file, computed only when asked (a large file takes a while). Tapping a finished value copies it.
 * A newer request cancels the older one, so switching algorithm never leaves two hashes running.
 */
@Composable
private fun ChecksumRows(file: File) {
    val cs = MaterialTheme.colorScheme
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    val algos = listOf("MD5" to "MD5", "SHA-1" to "SHA-1", "SHA-256" to "SHA-256")
    val results = remember(file.path) { mutableStateMapOf<String, String>() }
    var running by remember(file.path) { mutableStateOf<String?>(null) }
    var request by remember(file.path) { mutableStateOf<String?>(null) }
    LaunchedEffect(request) {
        val algo = request ?: return@LaunchedEffect
        running = algo
        val token = CancelToken()
        try {
            results[algo] = withContext(Dispatchers.IO) { Hashing.hex(file, algo, token) }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OperationCancelled) {
            // the hash was stopped
        } catch (e: Exception) {
            results[algo] = "Couldn't read the file"
        } finally {
            token.cancel() // stops the background read if the dialog closed mid-hash
            if (running == algo) running = null
        }
    }
    PropSection("Checksums") {
        algos.forEach { (label, algo) ->
            val done = results[algo]
            when {
                done != null -> PropRow(label, done.chunked(8).joinToString(" "), mono = true) { clip.setText(androidx.compose.ui.text.AnnotatedString(done)) }
                running == algo -> PropRow(label, "Calculating\u2026")
                else -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, fontSize = 13.sp, color = cs.onSurfaceVariant, modifier = Modifier.width(84.dp))
                    DexButton("Calculate") { request = algo }
                }
            }
        }
        if (results.isNotEmpty()) Text("Tap a value to copy it", fontSize = 12.sp, color = cs.onSurfaceVariant)
    }
}

/** Mock "Name conflict": choose Replace / Keep both / Skip, one answer for every clash in this paste. */
@Composable
private fun ConflictDialog(vm: ExplorerViewModel, d: DialogState.Conflicts) {
    var pick by remember { mutableStateOf(OnConflict.REPLACE) }
    val one = d.names.size == 1
    DexDialog(
        title = if (one) "\u201C${d.names[0]}\u201D already exists" else "${d.names.size} items already exist",
        onDismiss = { vm.dialog = null; d.onChoose(null) },
        actions = {
            DexButton("Cancel") { vm.dialog = null; d.onChoose(null) }
            DexButton("Continue", DexBtn.Primary) { vm.dialog = null; d.onChoose(pick) }
        },
    ) {
        DexBody(if (one) "Another item with this name is already in the destination." else "Your choice applies to all of them.")
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            DexOption("Replace", pick == OnConflict.REPLACE) { pick = OnConflict.REPLACE }
            DexOption("Keep both", pick == OnConflict.KEEP_BOTH) { pick = OnConflict.KEEP_BOTH }
            DexOption("Skip", pick == OnConflict.SKIP) { pick = OnConflict.SKIP }
        }
    }
}

@Composable
private fun ExtractDialog(vm: ExplorerViewModel, entry: FileEntry) {
    var intoFolder by remember { mutableStateOf(true) }
    DexDialog(
        title = "Extract \u201C${entry.name}\u201D",
        onDismiss = { vm.dialog = null },
        actions = {
            DexButton("Cancel") { vm.dialog = null }
            DexButton("Extract", DexBtn.Primary) { vm.dialog = null; vm.extract(entry, intoFolder = intoFolder) }
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            DexOption("Into a new folder", intoFolder, hint = entry.name.substringBeforeLast('.', entry.name)) { intoFolder = true }
            DexOption("Here", !intoFolder, hint = "Next to the archive") { intoFolder = false }
        }
    }
}

@Composable
private fun BatchRenameDialog(vm: ExplorerViewModel, entries: List<FileEntry>) {
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var prefix by remember { mutableStateOf("") }
    var suffix by remember { mutableStateOf("") }
    var numbering by remember { mutableStateOf(false) }
    val spec = BatchRenameSpec(find = find, replace = replace, prefix = prefix, suffix = suffix, numbering = numbering)
    val valid = BatchRename.isValid(spec)
    DexDialog(
        title = "Rename ${entries.size} items",
        onDismiss = { vm.dialog = null },
        width = 460.dp,
        actions = {
            DexButton("Cancel") { vm.dialog = null }
            DexButton("Rename", DexBtn.Primary, enabled = valid) { vm.dialog = null; vm.applyBatchRename(entries, spec) }
        },
    ) {
        var fF by remember { mutableStateOf(TextFieldValue("")) }
        var rF by remember { mutableStateOf(TextFieldValue("")) }
        var pF by remember { mutableStateOf(TextFieldValue("")) }
        var sF by remember { mutableStateOf(TextFieldValue("")) }
        Column {
            DexLabel("Find"); DexField(fF, { fF = it; find = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Replace with"); DexField(rF, { rF = it; replace = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Add before name"); DexField(pF, { pF = it; prefix = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Add after name"); DexField(sF, { sF = it; suffix = it.text })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Add numbers", Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.clickable { numbering = !numbering }) { DexSwitch(numbering) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            DexLabel("Preview")
            entries.take(4).forEachIndexed { i, e ->
                val n = if (valid) BatchRename.apply(e.name, e.isDir, i, spec) else "Invalid pattern"
                Text("${e.name}  \u2192  $n", fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ShortcutsDialog(onDismiss: () -> Unit) {
    val rows = listOf(
        "Ctrl+C / X / V" to "Copy, cut, paste",
        "Ctrl+D" to "Duplicate",
        "Ctrl+A" to "Select all",
        "F2" to "Rename",
        "Delete" to "Move to Trash",
        "Shift+Delete" to "Delete permanently",
        "Ctrl+T / W" to "New tab / close tab",
        "Ctrl+L" to "Edit address",
        "Ctrl+K" to "Quick jump and commands",
        "Ctrl+F" to "Search",
        "Ctrl+Shift+N" to "New folder",
        "Alt+← / → / ↑" to "Back, forward, up",
        "Space" to "Quick look",
        "Ctrl+scroll" to "Resize icons",
    )
    DexDialog(title = "Keyboard shortcuts", onDismiss = onDismiss, width = 460.dp, actions = { DexButton("Done", DexBtn.Primary, onClick = onDismiss) }) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { rows.forEach { (k, v) -> DexKV(k, v, labelWidth = 150.dp, bold = false) } }
    }
}
