package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.dexfiles.core.BatchRename
import app.dexfiles.core.BatchRenameSpec
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.FileOps
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.OnConflict
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------- context menu

@Composable
private fun CtxItem(label: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val tint = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    DropdownMenuItem(
        text = { Text(label, color = tint) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp), tint = tint) },
        onClick = onClick,
    )
}

/** Right-click (mouse) or long-press (touch) menu, for a file, a folder, or empty space. */
@Composable
fun ContextMenuHost(vm: ExplorerViewModel) {
    val m = vm.menu ?: return
    val tab = vm.panes[m.pane].tab
    val target = m.target
    fun close() { vm.menu = null }
    Box(Modifier.offset { IntOffset(m.pos.x.roundToInt(), m.pos.y.roundToInt()) }) {
        DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = true, onDismissRequest = { close() }) {
            if (tab.path == Loc.TRASH) {
                if (target != null) {
                    CtxItem("Restore", DexIcons.Reset) { close(); vm.restoreSelected(tab) }
                    CtxItem("Delete forever", DexIcons.Trash, danger = true) { close(); vm.requestDelete(permanent = true, tab = tab) }
                    HorizontalDivider()
                }
                CtxItem("Empty Trash", DexIcons.Trash, danger = true) { close(); vm.dialog = DialogState.EmptyTrash }
                return@DropdownMenu
            }
            val canWrite = Rules.canWriteHere(tab)
            if (target != null) {
                val sel = vm.selectedEntries(tab).ifEmpty { listOf(target) }
                val single = sel.size == 1
                CtxItem(if (target.isDir && single) "Open" else "Open", DexIcons.OpenIn) { close(); vm.open(tab, target) }
                if (target.isDir && single) CtxItem("Open in new tab", DexIcons.NewTab) { close(); vm.openInNewTab(target.path, vm.panes[m.pane]) }
                if (!target.isDir && single) CtxItem("Open with…", DexIcons.OpenIn) { close(); vm.openExternally(target, chooser = true) }
                HorizontalDivider()
                CtxItem("Cut", DexIcons.Cut) { close(); vm.copySelection(cut = true, tab = tab) }
                CtxItem("Copy", DexIcons.Copy) { close(); vm.copySelection(cut = false, tab = tab) }
                if (target.isDir && single && vm.clip != null) CtxItem("Paste into folder", DexIcons.Paste) { close(); vm.paste(into = target.path) }
                HorizontalDivider()
                CtxItem("Rename", DexIcons.Rename) { close(); vm.requestRename(tab) }
                CtxItem("Share", DexIcons.Share) { close(); vm.share(sel.filter { !it.isDir }.ifEmpty { sel }) }
                CtxItem("Compress to zip", DexIcons.Compress) {
                    close(); vm.dialog = DialogState.Compress(sel, File(sel[0].path).parent ?: tab.path)
                }
                if (single && target.kind == FileKind.ARCHIVE) CtxItem("Extract…", DexIcons.Compress) { close(); vm.dialog = DialogState.Archive(target) }
                if (target.isDir && single) CtxItem("Customize folder", DexIcons.Info) { close(); vm.dialog = DialogState.CustomizeFolder(target) }
                if (target.isDir && single) {
                    val fav = target.path in vm.favorites
                    CtxItem(if (fav) "Remove from sidebar" else "Add to sidebar", DexIcons.Star) { close(); vm.toggleFavorite(target.path) }
                }
                CtxItem("Copy path", DexIcons.Link) { close(); vm.copyPath(sel) }
                CtxItem("Properties", DexIcons.Info) { close(); vm.dialog = DialogState.Properties(sel) }
                HorizontalDivider()
                CtxItem("Delete", DexIcons.Trash, danger = true) { close(); vm.requestDelete(tab = tab) }
            } else {
                if (canWrite) {
                    CtxItem("New folder", DexIcons.NewFolder) { close(); vm.requestNew(folder = true) }
                    CtxItem("New file", DexIcons.NewFile) { close(); vm.requestNew(folder = false) }
                    if (vm.clip != null) CtxItem("Paste", DexIcons.Paste) { close(); vm.paste() }
                    HorizontalDivider()
                }
                CtxItem("Select all", DexIcons.SelectAll) { close(); vm.selectAll(tab) }
                CtxItem("Refresh", DexIcons.Reset) { close(); vm.refresh(tab) }
                if (!tab.isVirtual && !tab.isSearch) CtxItem("Properties", DexIcons.Info) { close(); vm.openProperties(tab) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- dialogs

@Composable
fun DialogHost(vm: ExplorerViewModel) {
    when (val d = vm.dialog) {
        null -> Unit
        is DialogState.Rename -> NameDialog(
            title = "Rename",
            confirm = "Rename",
            initial = d.entry.name,
            selectBaseName = !d.entry.isDir,
            onDismiss = { vm.dialog = null },
            onConfirm = { name ->
                if (name == d.entry.name) { vm.dialog = null; null }
                else vm.renameNow(d.entry, name).also { if (it == null) vm.dialog = null }
            },
        )
        is DialogState.NewItem -> NameDialog(
            title = if (d.folder) "New folder" else "New file",
            confirm = "Create",
            initial = if (d.folder) "New folder" else "New file.txt",
            selectBaseName = !d.folder,
            onDismiss = { vm.dialog = null },
            onConfirm = { name -> vm.createNow(d.folder, d.parent, name).also { if (it == null) vm.dialog = null } },
        )
        is DialogState.Compress -> NameDialog(
            title = "Compress to zip",
            confirm = "Compress",
            initial = if (d.entries.size == 1) d.entries[0].name.substringBeforeLast('.', d.entries[0].name) else "Archive",
            selectBaseName = false,
            onDismiss = { vm.dialog = null },
            onConfirm = { name -> vm.compress(d.entries, d.parent, name); vm.dialog = null; null },
        )
        is DialogState.ConfirmDelete -> {
            val n = d.entries.size
            val what = if (n == 1) "\u201C${d.entries[0].name}\u201D" else "$n items"
            DexDialog(
                title = if (d.permanent) "Delete $what permanently?" else "Move $what to Trash?",
                onDismiss = { vm.dialog = null },
                actions = {
                    DexButton("Cancel") { vm.dialog = null }
                    DexButton(if (d.permanent) "Delete" else "Move to Trash", DexBtn.Danger) {
                        vm.dialog = null
                        if (d.permanent) vm.deleteForever(d.entries) else vm.moveToTrash(d.entries)
                    }
                },
            ) { DexBody(if (d.permanent) "This can\u2019t be undone." else "You can restore ${if (n == 1) "it" else "them"} from Trash.") }
        }
        DialogState.EmptyTrash -> DexDialog(
            title = "Empty Trash?",
            onDismiss = { vm.dialog = null },
            actions = {
                DexButton("Cancel") { vm.dialog = null }
                DexButton("Empty Trash", DexBtn.Danger) { vm.dialog = null; vm.emptyTrashNow() }
            },
        ) { DexBody("Everything in Trash will be deleted for good.") }
        is DialogState.Conflicts -> ConflictDialog(vm, d)
        is DialogState.Properties -> PropertiesDialog(d.entries) { vm.dialog = null }
        is DialogState.CustomizeFolder -> CustomizeFolderDialog(vm, d.entry)
        is DialogState.BatchRenameDlg -> BatchRenameDialog(vm, d.entries)
        is DialogState.Archive -> ExtractDialog(vm, d.entry)
        is DialogState.Message -> DexDialog(
            title = d.title,
            onDismiss = { vm.dialog = null },
            actions = { DexButton("OK", DexBtn.Primary) { vm.dialog = null } },
        ) { d.lines.forEach { DexBody(it) } }
        DialogState.Settings -> SettingsDialog(vm) { vm.dialog = null }
        DialogState.Shortcuts -> ShortcutsDialog { vm.dialog = null }
    }
}

/**
 * iPad-style rename/new-name popover near the top of the window: the name is selected (without the extension),
 * the keyboard opens at once, Enter confirms. [onConfirm] returns an error message, or null when it worked.
 */
@Composable
private fun NameDialog(
    title: String,
    confirm: String,
    initial: String,
    selectBaseName: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> String?,
) {
    val cs = MaterialTheme.colorScheme
    var value by remember {
        val end = if (selectBaseName && initial.contains('.')) initial.lastIndexOf('.') else initial.length
        mutableStateOf(TextFieldValue(initial, TextRange(0, end)))
    }
    var error by remember { mutableStateOf<String?>(null) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    fun submit() {
        val problem = FileOps.validateName(value.text.trim())
        error = problem ?: onConfirm(value.text.trim())
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }, contentAlignment = Alignment.TopCenter) {
            androidx.compose.material3.Surface(
                shape = Radius.xl,
                color = dialogSurface(),
                tonalElevation = 0.dp,
                shadowElevation = 24.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
                modifier = Modifier.padding(top = 110.dp, start = 16.dp, end = 16.dp).width(440.dp).pointerInput(Unit) { detectTapGestures { } },
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(14.dp))
                    DexField(
                        value = value,
                        onChange = { value = it; error = null },
                        error = error != null,
                        imeDone = { submit() },
                        modifier = Modifier.focusRequester(focus),
                    )
                    if (error != null) Text(error!!, fontSize = 12.sp, color = cs.error, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                        DexButton("Cancel", onClick = onDismiss)
                        DexButton(confirm, DexBtn.Primary) { submit() }
                    }
                }
            }
        }
    }
}

@Composable
private fun PropertiesDialog(entries: List<FileEntry>, onDismiss: () -> Unit) {
    val total by produceState(initialValue = -1L, entries) {
        value = withContext(Dispatchers.IO) { entries.sumOf { runCatching { FileOps.sizeOf(File(it.path)) }.getOrDefault(0L) } }
    }
    val single = entries.size == 1
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    val sizeText = if (total < 0) "Calculating\u2026" else if (total < 1024) Format.size(total) else "${Format.size(total)} (${"%,d".format(total)} bytes)"
    DexDialog(
        title = if (single) entries[0].name else "${entries.size} items",
        onDismiss = onDismiss,
        actions = {
            if (single) DexButton("Copy path") { clip.setText(androidx.compose.ui.text.AnnotatedString(entries[0].path)) }
            DexButton("Done", DexBtn.Primary, onClick = onDismiss)
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (single) {
                val e = entries[0]
                val f = File(e.path)
                DexKV("Type", FileTypes.typeLabel(e.name, e.isDir))
                DexKV("Size", sizeText)
                DexKV("Location", (f.parent ?: "").replace("/storage/emulated/0", "Internal storage").replace("/", " \u203A "))
                DexKV("Modified", Fmt.dateTime(e.modified))
                DexKV("Permissions", if (f.canWrite()) "Read and write" else if (f.canRead()) "Read only" else "No access")
            } else {
                val folders = entries.count { it.isDir }
                DexKV("Items", "${entries.size - folders} files, $folders folders")
                DexKV("Size", sizeText)
            }
        }
    }
}

/** Mock "Name conflict": choose Replace / Keep both / Skip, one answer for every clash in this paste. */
@Composable
private fun ConflictDialog(vm: ExplorerViewModel, d: DialogState.Conflicts) {
    var pick by remember { mutableStateOf(OnConflict.REPLACE) }
    val one = d.names.size == 1
    DexDialog(
        title = if (one) "\u201C${d.names[0]}\u201D already exists" else "${d.names.size} items already exist",
        onDismiss = { vm.dialog = null; d.onChoose(null) },
        actions = {
            DexButton("Cancel") { vm.dialog = null; d.onChoose(null) }
            DexButton("Continue", DexBtn.Primary) { vm.dialog = null; d.onChoose(pick) }
        },
    ) {
        DexBody(if (one) "Another item with this name is already in the destination." else "Your choice applies to all of them.")
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            DexOption("Replace", pick == OnConflict.REPLACE) { pick = OnConflict.REPLACE }
            DexOption("Keep both", pick == OnConflict.KEEP_BOTH) { pick = OnConflict.KEEP_BOTH }
            DexOption("Skip", pick == OnConflict.SKIP) { pick = OnConflict.SKIP }
        }
    }
}

@Composable
private fun ExtractDialog(vm: ExplorerViewModel, entry: FileEntry) {
    var intoFolder by remember { mutableStateOf(true) }
    DexDialog(
        title = "Extract \u201C${entry.name}\u201D",
        onDismiss = { vm.dialog = null },
        actions = {
            DexButton("Cancel") { vm.dialog = null }
            DexButton("Extract", DexBtn.Primary) { vm.dialog = null; vm.extract(entry, intoFolder = intoFolder) }
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            DexOption("Into a new folder", intoFolder, hint = entry.name.substringBeforeLast('.', entry.name)) { intoFolder = true }
            DexOption("Here", !intoFolder, hint = "Next to the archive") { intoFolder = false }
        }
    }
}

@Composable
private fun BatchRenameDialog(vm: ExplorerViewModel, entries: List<FileEntry>) {
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var prefix by remember { mutableStateOf("") }
    var suffix by remember { mutableStateOf("") }
    var numbering by remember { mutableStateOf(false) }
    val spec = BatchRenameSpec(find = find, replace = replace, prefix = prefix, suffix = suffix, numbering = numbering)
    val valid = BatchRename.isValid(spec)
    DexDialog(
        title = "Rename ${entries.size} items",
        onDismiss = { vm.dialog = null },
        width = 460.dp,
        actions = {
            DexButton("Cancel") { vm.dialog = null }
            DexButton("Rename", DexBtn.Primary, enabled = valid) { vm.dialog = null; vm.applyBatchRename(entries, spec) }
        },
    ) {
        var fF by remember { mutableStateOf(TextFieldValue("")) }
        var rF by remember { mutableStateOf(TextFieldValue("")) }
        var pF by remember { mutableStateOf(TextFieldValue("")) }
        var sF by remember { mutableStateOf(TextFieldValue("")) }
        Column {
            DexLabel("Find"); DexField(fF, { fF = it; find = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Replace with"); DexField(rF, { rF = it; replace = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Add before name"); DexField(pF, { pF = it; prefix = it.text })
            Spacer(Modifier.height(10.dp))
            DexLabel("Add after name"); DexField(sF, { sF = it; suffix = it.text })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Add numbers", Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.clickable { numbering = !numbering }) { DexSwitch(numbering) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            DexLabel("Preview")
            entries.take(4).forEachIndexed { i, e ->
                val n = if (valid) BatchRename.apply(e.name, e.isDir, i, spec) else "Invalid pattern"
                Text("${e.name}  \u2192  $n", fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- settings

@Composable
private fun SettingsGroup(title: String, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Text(title.uppercase(), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, bottom = 6.dp))
        Column(Modifier.fillMaxWidth().background(cs.surfaceContainer, Radius.m)) { content() }
    }
}

@Composable
private fun ToggleRow(label: String, hint: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DexSwitch(checked)
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
internal fun SettingsContent(vm: ExplorerViewModel) {
                SettingsGroup("Appearance") {
                    Column(Modifier.padding(12.dp)) {
                        Text("Theme", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                        val labels = listOf("System", "Light", "Dark")
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            labels.forEachIndexed { i, l ->
                                SegmentedButton(
                                    selected = vm.themeMode == i,
                                    onClick = { vm.setThemeMode(i) },
                                    shape = SegmentedButtonDefaults.itemShape(i, labels.size),
                                ) { Text(l) }
                            }
                        }
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text("Icon size", style = MaterialTheme.typography.bodyLarge)
                        val lv = ExplorerViewModel.GRID_LEVELS
                        Slider(
                            value = lv.indices.minByOrNull { Math.abs(lv[it] - vm.gridSize) }!!.toFloat(),
                            onValueChange = { vm.setGridSize(lv[it.roundToInt().coerceIn(0, lv.lastIndex)]) },
                            valueRange = 0f..lv.lastIndex.toFloat(),
                            steps = lv.size - 2,
                        )
                    }
                }
                SettingsGroup("Files") {
                    ToggleRow("Show hidden files", checked = vm.showHidden) { vm.setShowHidden(it) }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    ToggleRow("Folders first", checked = vm.foldersFirst) { vm.setFoldersFirst(it) }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    ToggleRow("Use Trash", "Deleted items can be restored", vm.useTrash) { vm.setUseTrash(it) }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    ToggleRow("Single tap to open", "Off: tap selects, double-tap opens", vm.singleClick) { vm.setSingleClick(it) }
                }
                SettingsGroup("Layout") {
                    ToggleRow("Sidebar", checked = vm.sidebarVisible) { vm.setSidebarVisible(it) }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    ToggleRow("Preview panel", "Wide windows only", vm.previewVisible) { vm.setPreviewVisible(it) }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    ToggleRow("Two panes", "Wide windows only", vm.dual) { vm.setDual(it) }
                }
                SettingsGroup("About") {
                    Column(Modifier.padding(16.dp)) {
                        Text("DexFiles", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text("A desktop-class file manager for touch, mouse and keyboard.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
}

/** Settings opens in place, as a page of grouped cards, like One UI. */
@Composable
fun SettingsScreen(vm: ExplorerViewModel) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopStart) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp))
            SettingsContent(vm)
            Spacer(Modifier.height(32.dp))
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun SettingsDialog(vm: ExplorerViewModel, onDismiss: () -> Unit) {
    DexDialog(title = "Settings", onDismiss = onDismiss, width = 520.dp, actions = { DexButton("Done", DexBtn.Primary, onClick = onDismiss) }) { SettingsContent(vm) }
}

@Composable
private fun ShortcutsDialog(onDismiss: () -> Unit) {
    val rows = listOf(
        "Ctrl+C / X / V" to "Copy, cut, paste",
        "Ctrl+A" to "Select all",
        "F2" to "Rename",
        "Delete" to "Move to Trash",
        "Shift+Delete" to "Delete permanently",
        "Ctrl+T / W" to "New tab / close tab",
        "Ctrl+L" to "Edit address",
        "Ctrl+F" to "Search",
        "Ctrl+Shift+N" to "New folder",
        "Alt+← / → / ↑" to "Back, forward, up",
        "Space" to "Quick look",
        "Ctrl+scroll" to "Resize icons",
    )
    DexDialog(title = "Keyboard shortcuts", onDismiss = onDismiss, width = 460.dp, actions = { DexButton("Done", DexBtn.Primary, onClick = onDismiss) }) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { rows.forEach { (k, v) -> DexKV(k, v, labelWidth = 150.dp, bold = false) } }
    }
}
