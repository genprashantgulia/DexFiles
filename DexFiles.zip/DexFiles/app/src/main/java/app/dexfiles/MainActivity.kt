package app.dexfiles

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Mods
import app.dexfiles.ui.CrashScreen
import app.dexfiles.ui.DexFilesApp
import app.dexfiles.ui.DexTheme
import app.dexfiles.ui.PermissionScreen

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_PATH = "app.dexfiles.PATH"
    }

    private val vm: ExplorerViewModel by viewModels()
    private var granted by mutableStateOf(false)
    private var started = false
    private var crash by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        granted = hasAccess()
        crash = CrashLog.read(this)
        startIfReady()
        setContent {
            DexTheme(vm.themeMode, vm.textSize) {
                val c = crash
                if (c != null) CrashScreen(c) {
                    CrashLog.clear(this@MainActivity)
                    crash = null
                    startIfReady()
                } else if (granted) DexFilesApp(vm, this) else PermissionScreen(onGrant = { requestAccess() })
            }
        }
    }

    private fun hasAccess(): Boolean = Environment.isExternalStorageManager()

    private fun startIfReady() {
        if (crash == null && granted && !started) {
            started = true
            vm.initSession(intent?.getStringExtra(EXTRA_PATH))
        }
    }

    private fun requestAccess() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    override fun onResume() {
        super.onResume()
        granted = hasAccess()
        if (granted) {
            if (!started) startIfReady() else vm.onResume()
        }
    }

    override fun onStop() {
        if (started) vm.saveSession()
        super.onStop()
    }

    // Modifier keys and mouse buttons are read from raw events so Ctrl/Shift-click and right-click work everywhere.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        Mods.update(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        Mods.update(ev)
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        if (granted && started && vm.handleKey(ev)) return true
        return super.dispatchKeyEvent(ev)
    }
}
