package app.dexfiles.core

import java.util.Locale

/** Broad family a file belongs to. Drives icons, sorting by type, search filters and categories. */
enum class FileKind(val label: String) {
    FOLDER("File folder"),
    IMAGE("Image"),
    VIDEO("Video"),
    AUDIO("Audio"),
    PDF("PDF document"),
    DOCUMENT("Document"),
    SHEET("Spreadsheet"),
    SLIDES("Presentation"),
    ARCHIVE("Archive"),
    APK("Android app"),
    CODE("Source code"),
    TEXT("Text file"),
    OTHER("File"),
}

object FileTypes {
    private fun group(kind: FileKind, vararg exts: String): List<Pair<String, FileKind>> = exts.map { it to kind }

    private val kinds: Map<String, FileKind> = (
        group(FileKind.IMAGE, "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "svg", "ico", "tif", "tiff", "dng", "raw", "arw", "cr2", "nef") +
            group(FileKind.VIDEO, "mp4", "mkv", "mov", "avi", "webm", "3gp", "m4v", "wmv", "flv", "mpg", "mpeg") +
            group(FileKind.AUDIO, "mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "wma", "amr", "mid", "midi") +
            group(FileKind.PDF, "pdf") +
            group(FileKind.DOCUMENT, "doc", "docx", "odt", "rtf", "pages", "epub", "mobi", "azw3", "hwp", "hwpx", "dotx") +
            group(FileKind.SHEET, "xls", "xlsx", "ods", "csv", "tsv", "numbers", "xlsm") +
            group(FileKind.SLIDES, "ppt", "pptx", "odp", "key", "pps", "ppsx") +
            group(FileKind.ARCHIVE, "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "jar", "cab", "iso") +
            group(FileKind.APK, "apk", "apks", "xapk", "aab") +
            group(
                FileKind.CODE,
                "kt", "kts", "java", "js", "mjs", "ts", "tsx", "jsx", "py", "c", "h", "cpp", "hpp", "cc", "cs", "go", "rs", "rb", "php",
                "swift", "sh", "bat", "ps1", "html", "htm", "css", "scss", "json", "xml", "yml", "yaml", "toml", "gradle", "sql", "lua", "dart",
            ) +
            group(FileKind.TEXT, "txt", "md", "markdown", "log", "ini", "cfg", "conf", "properties", "srt", "vtt", "nfo")
        ).toMap()

    private val mimes: Map<String, String> = mapOf(
        "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png", "gif" to "image/gif", "webp" to "image/webp",
        "bmp" to "image/bmp", "heic" to "image/heic", "heif" to "image/heif", "avif" to "image/avif", "svg" to "image/svg+xml",
        "mp4" to "video/mp4", "mkv" to "video/x-matroska", "mov" to "video/quicktime", "avi" to "video/x-msvideo", "webm" to "video/webm",
        "3gp" to "video/3gpp", "m4v" to "video/x-m4v",
        "mp3" to "audio/mpeg", "m4a" to "audio/mp4", "aac" to "audio/aac", "wav" to "audio/x-wav", "flac" to "audio/flac",
        "ogg" to "audio/ogg", "opus" to "audio/opus",
        "pdf" to "application/pdf", "txt" to "text/plain", "md" to "text/markdown", "csv" to "text/csv", "html" to "text/html",
        "json" to "application/json", "xml" to "text/xml", "zip" to "application/zip", "apk" to "application/vnd.android.package-archive",
        "doc" to "application/msword", "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "xls" to "application/vnd.ms-excel", "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "ppt" to "application/vnd.ms-powerpoint", "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "7z" to "application/x-7z-compressed", "rar" to "application/vnd.rar", "tar" to "application/x-tar", "gz" to "application/gzip",
    )

    /** Lower-case extension without the dot. Dot-files like ".bashrc" have no extension. */
    fun extensionOf(name: String): String {
        val dot = name.lastIndexOf('.')
        if (dot <= 0 || dot == name.length - 1) return ""
        return name.substring(dot + 1).lowercase(Locale.ROOT)
    }

    fun kindOf(name: String, isDir: Boolean): FileKind {
        if (isDir) return FileKind.FOLDER
        return kinds[extensionOf(name)] ?: FileKind.OTHER
    }

    /** "PNG image", "File folder", "ZIP archive", "File" - the string shown in the Type column. */
    fun typeLabel(name: String, isDir: Boolean): String {
        val kind = kindOf(name, isDir)
        if (kind == FileKind.FOLDER) return kind.label
        val ext = extensionOf(name)
        if (ext.isEmpty()) return kind.label
        return when (kind) {
            FileKind.OTHER -> "${ext.uppercase(Locale.ROOT)} file"
            FileKind.PDF, FileKind.APK -> kind.label
            else -> "${ext.uppercase(Locale.ROOT)} ${kind.label.lowercase(Locale.ROOT)}"
        }
    }

    /** Best-effort MIME type without Android. The Android layer asks MimeTypeMap first and falls back to this. */
    fun mimeOf(name: String): String = mimes[extensionOf(name)] ?: "application/octet-stream"

    /** Whether the file is readable as plain text for previews. */
    fun isTextual(name: String): Boolean {
        val k = kindOf(name, false)
        return k == FileKind.TEXT || k == FileKind.CODE || extensionOf(name) in setOf("csv", "tsv")
    }
}
