package app.dexfiles.state

import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.FileObserver
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.DragEvent
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.dexfiles.core.Analyzer
import app.dexfiles.core.Archives
import app.dexfiles.core.BatchRename
import app.dexfiles.core.BatchRenameSpec
import app.dexfiles.core.CancelToken
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileOps
import app.dexfiles.core.GroupBy
import app.dexfiles.core.Grouping
import app.dexfiles.core.Listing
import app.dexfiles.core.OnConflict
import app.dexfiles.core.OpResult
import app.dexfiles.core.OperationCancelled
import app.dexfiles.core.QuickIndex
import app.dexfiles.core.Search
import app.dexfiles.core.SearchQuery
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.Sorting
import app.dexfiles.core.TrashStore
import app.dexfiles.data.MediaQueries
import app.dexfiles.data.Opener
import app.dexfiles.data.Prefs
import app.dexfiles.data.Volume
import app.dexfiles.data.Volumes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class ExplorerViewModel(app: Application) : AndroidViewModel(app) {
    companion object { val GRID_LEVELS = listOf(72, 92, 116, 148, 188, 240) }

    private val ctx: Context = app.applicationContext
    val prefs = Prefs(ctx)

    // ------------------------------------------------------------------ settings (write-through to prefs)

    var showHidden by mutableStateOf(prefs.showHidden); private set
    var foldersFirst by mutableStateOf(prefs.foldersFirst); private set
    var sidebarVisible by mutableStateOf(prefs.sidebarVisible); private set
    var previewVisible by mutableStateOf(prefs.previewVisible); private set
    var dual by mutableStateOf(prefs.dualPane); private set
    var themeMode by mutableIntStateOf(prefs.themeMode); private set
    var useTrash by mutableStateOf(prefs.useTrash); private set
    var perFolderView by mutableStateOf(prefs.perFolderView); private set
    var singleClick by mutableStateOf(prefs.singleClick); private set
    /** Scroll positions of the Settings pages live here, so switching the font (which rebuilds the UI) doesn't throw you back to the top. */
    val settingsScrolls = arrayOf(androidx.compose.foundation.ScrollState(0), androidx.compose.foundation.ScrollState(0))
    var gridSize by mutableIntStateOf(prefs.gridSize); private set
    var textSize by mutableIntStateOf(prefs.textSize); private set
    /** While a drag is held near the top or bottom edge of a pane: -1 scrolls up, 1 scrolls down, 0 is still. */
    var dragScrollDir by mutableFloatStateOf(0f)
    private val paneBounds = arrayOfNulls<androidx.compose.ui.geometry.Rect>(2)
    fun setPaneBounds(pane: Int, r: androidx.compose.ui.geometry.Rect) { if (pane in paneBounds.indices) paneBounds[pane] = r }
    fun dragMoved(pane: Int, y: Float, edgePx: Float) {
        val b = paneBounds.getOrNull(pane) ?: return
        dragScrollDir = when { y < b.top + edgePx -> -1f; y > b.bottom - edgePx -> 1f; else -> 0f }
    }
    @JvmName("applyTextSize") fun setTextSize(v: Int) { textSize = v.coerceIn(12, 20); prefs.textSize = textSize }
    /** 0 = main list, 1 = Appearance, 2 = Browsing, 3 = Files. */
    var settingsPage by mutableIntStateOf(0)

    @JvmName("applyShowHidden") fun setShowHidden(v: Boolean) {
        showHidden = v
        prefs.showHidden = v
        allTabs().forEach { load(it, keepSelection = true) }
    }

    /** Switching modes re-applies the right layout to every open tab: each folder's own, or the one shared choice. */
    @JvmName("applyPerFolderView") fun setPerFolderView(v: Boolean) {
        perFolderView = v
        prefs.perFolderView = v
        allTabs().forEach { applyLayout(it); resort(it) }
    }

    @JvmName("applyFoldersFirst") fun setFoldersFirst(v: Boolean) {
        foldersFirst = v
        prefs.foldersFirst = v
        allTabs().forEach {
            it.sort = it.sort.copy(foldersFirst = v)
            resort(it)
        }
    }

    @JvmName("applySidebarVisible") fun setSidebarVisible(v: Boolean) { sidebarVisible = v; prefs.sidebarVisible = v }
    @JvmName("applyPreviewVisible") fun setPreviewVisible(v: Boolean) { previewVisible = v; prefs.previewVisible = v }
    @JvmName("applyThemeMode") fun setThemeMode(v: Int) { themeMode = v; prefs.themeMode = v }
    @JvmName("applyUseTrash") fun setUseTrash(v: Boolean) { useTrash = v; prefs.useTrash = v }
    @JvmName("applySingleClick") fun setSingleClick(v: Boolean) { singleClick = v; prefs.singleClick = v }

    @JvmName("applyGridSize") fun setGridSize(v: Int) {
        gridSize = v.coerceIn(72, 240)
        prefs.gridSize = gridSize
    }

    @JvmName("applyDual") fun setDual(v: Boolean) {
        dual = v
        prefs.dualPane = v
        if (!v) activePane = 0
    }

    // ------------------------------------------------------------------ storage

    var volumes by mutableStateOf<List<Volume>>(emptyList()); private set
    var favorites by mutableStateOf<List<String>>(emptyList()); private set

    val primaryRoot: String
        get() = volumes.firstOrNull()?.path ?: Environment.getExternalStorageDirectory().path

    fun refreshVolumes() {
        volumes = Volumes.list(ctx)
    }

    private fun trashStores(): List<TrashStore> =
        volumes.map { TrashStore(Volumes.trashDirFor(it)) }

    private fun storeFor(f: File): TrashStore {
        val v = Volumes.rootFor(f.path, volumes) ?: volumes.first()
        return TrashStore(Volumes.trashDirFor(v))
    }

    @Volatile
    private var trashIndex: Map<String, TrashStore.Item> = emptyMap()

    // ------------------------------------------------------------------ panes & tabs

    val panes = listOf(PaneState(0), PaneState(1))
    var activePane by mutableIntStateOf(0)
    val currentPane: PaneState get() = panes[activePane]
    val current: TabState get() = currentPane.tab
    val otherPane: PaneState get() = panes[1 - activePane]

    private var nextTabId = 1L
    private var initialized = false

    private fun allTabs(): List<TabState> = panes.flatMap { it.tabs.toList() }

    private fun defaultSort() = SortSpec(prefs.sortKey, prefs.sortAscending, foldersFirst)

    fun initSession(startPath: String?) {
        if (initialized) return
        initialized = true
        refreshVolumes()
        preloadVirtual()
        if (!prefs.hasFavorites) {
            val root = primaryRoot
            prefs.favorites = listOf("Download", "DCIM", "Pictures", "Documents", "Music", "Movies")
                .map { "$root/$it" }.filter { File(it).isDirectory }
        }
        favorites = prefs.favorites
        if (startPath != null && File(startPath).isDirectory) {
            addTab(panes[0], startPath)
            addTab(panes[1], startPath)
        } else {
            for (p in 0..1) {
                val saved = prefs.savedTabs(p).filter { Loc.isVirtual(it) || File(it).isDirectory }
                // Always start on Recent files, like Samsung's app.
                val paths = listOf(if (p == 0) Loc.HOME else primaryRoot)
                paths.forEach { addTab(panes[p], it, select = false) }
                panes[p].active = prefs.savedActiveTab(p).coerceIn(0, panes[p].tabs.lastIndex)
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                trashStores().forEach { it.purgeOlderThan(30) }
            } catch (_: Exception) {
            }
        }
    }

    fun saveSession() {
        for (p in panes) prefs.saveTabs(p.index, p.tabs.map { it.path }, p.active)
    }

    fun onResume() {
        refreshVolumes()
        refreshVisible()
    }

    fun addTab(pane: PaneState, path: String, select: Boolean = true) {
        val t = TabState(nextTabId++, path, defaultSort(), prefs.viewMode)
        t.groupBy = prefs.groupBy
        applyLayout(t)
        pane.tabs.add(t)
        if (select) {
            pane.active = pane.tabs.lastIndex
            activePane = pane.index
        }
        load(t)
    }

    fun newTab() {
        val tab = current
        addTab(currentPane, if (tab.isVirtual) Loc.HOME else tab.path)
    }

    fun selectTab(pane: PaneState, index: Int) {
        pane.active = index.coerceIn(0, pane.tabs.lastIndex)
        activePane = pane.index
    }

    fun closeTab(pane: PaneState, index: Int) {
        if (pane.tabs.size <= 1) {
            if (pane.index == 1) setDual(false)
            return
        }
        val t = pane.tabs.removeAt(index)
        disposeTab(t)
        if (pane.active >= pane.tabs.size) pane.active = pane.tabs.lastIndex
        else if (index < pane.active) pane.active--
    }

    fun cycleTab(forward: Boolean) {
        val p = currentPane
        if (p.tabs.size < 2) return
        p.active = (p.active + (if (forward) 1 else -1) + p.tabs.size) % p.tabs.size
    }

    private fun disposeTab(t: TabState) {
        t.loadJob?.cancel()
        t.searchJob?.cancel()
        t.searchToken?.cancel()
        t.refreshJob?.cancel()
        t.observer?.stopWatching()
        t.observer = null
    }

    override fun onCleared() {
        allTabs().forEach { disposeTab(it) }
        super.onCleared()
    }

    // ------------------------------------------------------------------ loading

    /** Chip on the Recent files page: 0 All, 1 Images, 2 Videos, 3 Audio, 4 Documents, 5 Other. */
    var homeFilter by mutableStateOf(0); private set

    fun setHomeFilter(i: Int, tab: TabState = current) {
        homeFilter = i
        refresh(tab)
    }

    private fun homeKindOk(f: Int, e: FileEntry): Boolean {
        val k = e.kind
        return when (f) {
            0 -> true
            1 -> k == app.dexfiles.core.FileKind.IMAGE
            2 -> k == app.dexfiles.core.FileKind.VIDEO
            3 -> k == app.dexfiles.core.FileKind.AUDIO
            4 -> k in setOf(app.dexfiles.core.FileKind.PDF, app.dexfiles.core.FileKind.DOCUMENT, app.dexfiles.core.FileKind.SHEET, app.dexfiles.core.FileKind.SLIDES, app.dexfiles.core.FileKind.TEXT)
            else -> k !in setOf(app.dexfiles.core.FileKind.IMAGE, app.dexfiles.core.FileKind.VIDEO, app.dexfiles.core.FileKind.AUDIO, app.dexfiles.core.FileKind.PDF, app.dexfiles.core.FileKind.DOCUMENT, app.dexfiles.core.FileKind.SHEET, app.dexfiles.core.FileKind.SLIDES, app.dexfiles.core.FileKind.TEXT)
        }
    }

    private fun loadEntries(path: String): List<FileEntry> = when {
        path == Loc.ANALYZE || path == Loc.HISTORY -> emptyList()
        path == Loc.HOME -> MediaQueries.query(ctx, Loc.RECENT).take(300).filter { homeKindOk(homeFilter, it) }.take(120)
        path == Loc.TRASH -> {
            val items = trashStores().flatMap { it.list() }
            trashIndex = items.associateBy { it.file.path }
            items.map { FileEntry(it.file.path, it.name, it.isDir, it.size, it.deletedAt, false) }
        }
        Loc.isMedia(path) -> MediaQueries.query(ctx, path)
        else -> Listing.list(File(path), showHidden)
    }

    fun load(tab: TabState, keepSelection: Boolean = false, select: String? = null, markOnly: Boolean = false) {
        if (tab.isSearch) return
        tab.loadJob?.cancel()
        val path = tab.path
        tab.loading = true
        tab.error = null
        tab.loadJob = viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { loadEntries(path) } }
            if (tab.path != path) return@launch
            result.onSuccess { list ->
                if (listingCache.size > 40) listingCache.clear()
                listingCache[path] = list
                tab.raw = list
                resort(tab)
                val present = HashSet<String>(tab.entries.size * 2)
                tab.entries.forEach { present.add(it.path) }
                val focus = tab.focus
                if (select != null && select in present) {
                    // markOnly: just point at the item (grey focus outline) without entering selection mode.
                    tab.selection = if (markOnly) emptySet() else setOf(select)
                    tab.anchor = select
                    tab.focus = select
                    tab.scrollTick++
                } else if (keepSelection) {
                    tab.selection = tab.selection.filterTo(HashSet()) { it in present }
                    if (focus != null && focus !in present) tab.focus = null
                } else {
                    tab.selection = emptySet()
                }
            }.onFailure {
                tab.raw = emptyList()
                tab.entries = emptyList()
                tab.error = it.message ?: "Couldn't open this location"
            }
            tab.loading = false
            watch(tab)
        }
    }

    fun refresh(tab: TabState = current) {
        if (tab.isSearch) setQuery(tab, tab.query) else load(tab, keepSelection = true)
        refreshVolumes()
    }

    fun refreshVisible() {
        panes.forEachIndexed { i, p -> if (i == 0 || dual) load(p.tab, keepSelection = true) }
    }

    fun resort(tab: TabState) {
        val filtered = tab.raw
        val sorted = if (tab.isSearch && tab.relevanceSort) filtered else Sorting.sort(filtered, tab.effectiveSort)
        tab.entries = if (tab.isSearch || tab.path == Loc.HOME) sorted else Grouping.arrange(sorted, tab.groupBy)
    }

    /** Auto-refresh when something changes on disk (a download finishes, another window deletes a file...). */
    private fun watch(tab: TabState) {
        tab.observer?.stopWatching()
        tab.observer = null
        if (tab.isVirtual || tab.isSearch) return
        val dir = File(tab.path)
        if (!dir.isDirectory) return
        val mask = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or
            FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.DELETE_SELF
        val obs = object : FileObserver(dir, mask) {
            override fun onEvent(event: Int, path: String?) {
                viewModelScope.launch {
                    tab.refreshJob?.cancel()
                    tab.refreshJob = launch {
                        delay(350)
                        load(tab, keepSelection = true)
                    }
                }
            }
        }
        obs.startWatching()
        tab.observer = obs
    }

    // ------------------------------------------------------------------ navigation

    private fun normalize(p: String): String = if (Loc.isVirtual(p)) p else p.trimEnd('/').ifEmpty { "/" }

    fun navigate(tab: TabState, path: String, push: Boolean = true, select: String? = null, markOnly: Boolean = false) {
        searchUi = false
        val p = normalize(path)
        if (!Loc.isVirtual(p) && !File(p).isDirectory) {
            toast("That folder doesn't exist")
            return
        }
        if (push && p != tab.path) {
            tab.back.add(tab.path)
            if (tab.back.size > 200) tab.back.removeAt(0)
            tab.forward.clear()
        }
        tab.searchJob?.cancel()
        tab.searchToken?.cancel()
        tab.searchCache.clear()
        tab.zoomAnchor = 0
        tab.path = p
        applyLayout(tab)
        tab.query = ""
        tab.searchRoot = null
        tab.searching = false
        tab.selection = emptySet()
        tab.anchor = null
        tab.focus = null
        // Show the last known listing for this place instantly (or nothing), never the previous place's files.
        val cached = listingCache[p]
        tab.raw = cached ?: emptyList()
        if (cached != null) resort(tab) else tab.entries = emptyList()
        load(tab, select = select, markOnly = markOnly)
    }

    private val listingCache = java.util.concurrent.ConcurrentHashMap<String, List<FileEntry>>()

    /** Warm the sidebar categories in the background so they open instantly. */
    private fun preloadVirtual() {
        viewModelScope.launch(Dispatchers.IO) {
            for (loc in listOf(Loc.IMAGES, Loc.VIDEOS, Loc.AUDIO, Loc.DOCS, Loc.APKS, Loc.DOWNLOADS)) {
                runCatching { listingCache[loc] = MediaQueries.query(ctx, loc) }
            }
        }
    }

    fun goBack(tab: TabState = current) {
        if (tab.isSearch) { clearSearch(tab); return }
        if (tab.back.isEmpty()) return
        val prev = tab.back.removeAt(tab.back.lastIndex)
        tab.forward.add(tab.path)
        navigate(tab, prev, push = false)
    }

    fun goForward(tab: TabState = current) {
        if (tab.forward.isEmpty()) return
        val next = tab.forward.removeAt(tab.forward.lastIndex)
        tab.back.add(tab.path)
        navigate(tab, next, push = false)
    }

    fun goUp(tab: TabState = current) {
        val p = tab.path
        if (tab.isSearch) { clearSearch(tab); return }
        if (Loc.isVirtual(p)) {
            if (p != Loc.HOME) navigate(tab, Loc.HOME)
            return
        }
        if (volumes.any { it.path == p }) { navigate(tab, Loc.HOME, select = null); return }
        val parent = File(p).parent ?: run { navigate(tab, Loc.HOME); return }
        navigate(tab, parent)
    }


    fun reveal(path: String) {
        val parent = File(path).parent ?: return
        navigate(current, parent, select = path, markOnly = true)
    }

    fun openInNewTab(path: String, pane: PaneState = currentPane) = addTab(pane, path, select = false)

    fun openInNewWindow(path: String?) = Opener.newWindow(ctx, path)

    // ------------------------------------------------------------------ sorting & view

    fun setSort(tab: TabState, key: SortKey) {
        val cur = tab.effectiveSort
        val next = if (cur.key == key) cur.copy(ascending = !cur.ascending)
        else cur.copy(key = key, ascending = key == SortKey.NAME || key == SortKey.TYPE)
        applySort(tab, next)
    }

    fun setSortAscending(tab: TabState, asc: Boolean) = applySort(tab, tab.effectiveSort.copy(ascending = asc))

    private fun applySort(tab: TabState, spec: SortSpec) {
        tab.relevanceSort = false
        if (tab.isVirtual) tab.virtualSort = spec else tab.sort = spec
        if (perFolderView) saveLayout(tab)
        else if (!tab.isVirtual) {
            prefs.sortKey = spec.key
            prefs.sortAscending = spec.ascending
        }
        resort(tab)
    }

    fun setViewMode(tab: TabState, mode: ViewMode) {
        tab.viewMode = mode
        if (perFolderView) saveLayout(tab) else prefs.viewMode = mode
    }

    fun setGroupBy(tab: TabState, g: GroupBy) {
        tab.groupBy = g
        tab.selection = emptySet()
        if (perFolderView) saveLayout(tab) else prefs.groupBy = g
        resort(tab)
    }

    /** Remember this folder's view, sort and grouping (per-folder mode only). */
    private fun saveLayout(tab: TabState) {
        if (tab.isSearch) return
        val s = tab.effectiveSort
        prefs.saveLayout(tab.path, Prefs.FolderLayout(tab.viewMode, s.key, s.ascending, tab.groupBy))
    }

    /**
     * Per-folder mode: a folder opens in the layout it was last given. A folder never customised opens in the shared default.
     * Shared mode leaves the tab alone, so there is exactly one rule in each mode.
     */
    private fun applyLayout(tab: TabState) {
        if (!perFolderView) return
        val l = prefs.layoutOf(tab.path)
        tab.viewMode = l?.mode ?: prefs.viewMode
        tab.groupBy = l?.group ?: prefs.groupBy
        if (tab.isVirtual) {
            tab.virtualSort = if (l != null) SortSpec(l.key, l.ascending, foldersFirst = false) else SortSpec(SortKey.MODIFIED, ascending = false, foldersFirst = false)
        } else {
            tab.sort = SortSpec(l?.key ?: prefs.sortKey, l?.ascending ?: prefs.sortAscending, foldersFirst)
        }
    }

    /** Thumbnail sizes are discrete levels, like Samsung's gallery: one pinch step moves one level. */
    fun canZoomGrid(steps: Int): Boolean {
        val i = GRID_LEVELS.indices.minByOrNull { Math.abs(GRID_LEVELS[it] - gridSize) } ?: 0
        return (i + steps) in 0..GRID_LEVELS.lastIndex
    }

    /** Returns false when already at the smallest / largest level (nothing changed). */
    fun zoomGrid(steps: Int): Boolean {
        val i = GRID_LEVELS.indices.minByOrNull { Math.abs(GRID_LEVELS[it] - gridSize) } ?: 0
        val j = (i + steps).coerceIn(0, GRID_LEVELS.lastIndex)
        if (j == i) return false
        setGridSize(GRID_LEVELS[j])
        return true
    }

    var detailsColumns by mutableStateOf(prefs.detailsColumns); private set
    @JvmName("applyDetailsColumns") fun setDetailsColumns(v: Boolean) { detailsColumns = v; prefs.detailsColumns = v }

    var settingsOpen by mutableStateOf(false)
    /** true = launched from the sidebar gear (opens bottom-left); false = from the top-right menu. */
    var settingsFromLeft by mutableStateOf(false)
    fun openSettings(fromLeft: Boolean) { settingsFromLeft = fromLeft; settingsPage = 0; settingsOpen = true }

    // ------------------------------------------------------------------ selection & keyboard cursor

    /** Rows shown by expanding folders in List/Details; kept so they can be selected, copied, deleted like any other row. */
    val treeEntries = HashMap<String, FileEntry>()

    fun selectedEntries(tab: TabState = current): List<FileEntry> {
        if (tab.selection.isEmpty()) return emptyList()
        val base = tab.entries.filter { it.path in tab.selection }
        if (base.size == tab.selection.size) return base
        val have = base.mapTo(HashSet()) { it.path }
        return base + tab.selection.filter { it !in have }.mapNotNull { treeEntries[it] }
    }

    fun selectOnly(tab: TabState, e: FileEntry) {
        tab.selection = setOf(e.path)
        tab.anchor = e.path
        tab.focus = e.path
    }

    fun toggleSelect(tab: TabState, e: FileEntry) {
        tab.selection = if (e.path in tab.selection) tab.selection - e.path else tab.selection + e.path
        tab.anchor = e.path
        tab.focus = e.path
    }

    private fun selectRange(tab: TabState, toPath: String) {
        val list = tab.entries
        val a = list.indexOfFirst { it.path == tab.anchor }
        val b = list.indexOfFirst { it.path == toPath }
        if (a < 0 || b < 0) {
            tab.selection = setOf(toPath)
            tab.anchor = toPath
        } else {
            tab.selection = list.subList(minOf(a, b), maxOf(a, b) + 1).mapTo(HashSet()) { it.path }
        }
        tab.focus = toPath
    }

    fun clickSelect(tab: TabState, e: FileEntry, ctrl: Boolean, shift: Boolean) {
        when {
            shift && tab.anchor != null -> selectRange(tab, e.path)
            ctrl -> toggleSelect(tab, e)
            else -> selectOnly(tab, e)
        }
    }

    fun selectAll(tab: TabState = current) {
        tab.selection = tab.entries.mapTo(HashSet()) { it.path }
        if (tab.anchor == null) tab.anchor = tab.entries.firstOrNull()?.path
    }

    fun invertSelection(tab: TabState = current) {
        tab.selection = tab.entries.filter { it.path !in tab.selection }.mapTo(HashSet()) { it.path }
    }

    fun clearSelection(tab: TabState = current) {
        tab.selection = emptySet()
        tab.anchor = null
    }

    fun moveFocus(tab: TabState, delta: Int, extend: Boolean) {
        val list = tab.entries
        if (list.isEmpty()) return
        val cur = list.indexOfFirst { it.path == tab.focus }
        val next = if (cur < 0) (if (delta > 0) 0 else list.lastIndex) else (cur + delta).coerceIn(0, list.lastIndex)
        val e = list[next]
        if (extend) {
            if (tab.anchor == null) tab.anchor = tab.focus ?: e.path
            selectRange(tab, e.path)
        } else {
            selectOnly(tab, e)
        }
        tab.scrollTick++
    }

    fun typeAhead(tab: TabState, ch: Char) {
        val now = SystemClock.uptimeMillis()
        tab.typeBuffer = if (now - tab.typeAt > 900) ch.toString() else tab.typeBuffer + ch
        tab.typeAt = now
        val list = tab.entries
        if (list.isEmpty()) return
        val buf = tab.typeBuffer
        val cur = list.indexOfFirst { it.path == tab.focus }
        val start = if (cur < 0) 0 else if (buf.length == 1) cur + 1 else cur
        for (k in list.indices) {
            val i = (start + k) % list.size
            if (list[i].name.startsWith(buf, ignoreCase = true)) {
                selectOnly(tab, list[i])
                tab.scrollTick++
                return
            }
        }
    }

    // ------------------------------------------------------------------ click / open

    private var lastClickPath: String? = null
    private var lastClickAt = 0L

    /** Touch: press and hold selects the item (Samsung); a plain tap only opens it. */
    fun longPressSelect(pane: PaneState, tab: TabState, e: FileEntry) {
        activePane = pane.index
        if (e.path !in tab.selection) toggleSelect(tab, e)
    }

    fun onEntryClick(pane: PaneState, tab: TabState, e: FileEntry) {
        activePane = pane.index
        if (Mods.secondaryDown) return
        if (Mods.tertiaryDown) {
            if (e.isDir) openInNewTab(e.path, pane)
            return
        }
        if (!Mods.mouse) {
            // Touch: while a selection is in progress taps toggle. Otherwise a tap on a file only highlights it (the preview shows it) and a
            // second tap opens it; folders open on one tap, and "Single tap to open" makes files do the same.
            if (tab.selection.isNotEmpty()) { toggleSelect(tab, e); return }
            tab.focus = e.path
            if (e.isDir || singleClick) { open(tab, e); return }
            val now = SystemClock.uptimeMillis()
            val dbl = lastClickPath == e.path && now - lastClickAt < 400
            lastClickAt = now
            lastClickPath = e.path
            if (dbl) { lastClickPath = null; open(tab, e) }
            return
        }
        val ctrl = Mods.ctrl
        val shift = Mods.shift
        if (singleClick && !ctrl && !shift) {
            selectOnly(tab, e)
            open(tab, e)
            return
        }
        val now = SystemClock.uptimeMillis()
        val dbl = !ctrl && !shift && lastClickPath == e.path && now - lastClickAt < 450
        lastClickAt = now
        lastClickPath = e.path
        if (dbl) {
            lastClickPath = null
            open(tab, e)
        } else {
            clickSelect(tab, e, ctrl, shift)
        }
    }

    fun open(tab: TabState, e: FileEntry) {
        if (tab.path == Loc.TRASH) {
            toast("Restore this item to open it")
            return
        }
        if (e.isDir) {
            navigate(tab, e.path)
        } else if (Archives.canExtract(e.name) && e.ext != "apk" && e.ext != "jar") {
            dialog = DialogState.Archive(e)
        } else if (e.kind == app.dexfiles.core.FileKind.IMAGE) {
            val imgs = tab.entries.filter { !it.isDir && it.kind == app.dexfiles.core.FileKind.IMAGE }
            val i = imgs.indexOfFirst { it.path == e.path }
            if (i >= 0) viewer = ViewerState(imgs, i) else openExternally(e)
        } else {
            openExternally(e)
        }
    }

    fun openExternally(e: FileEntry, chooser: Boolean = false) {
        val err = Opener.open(ctx, File(e.path), chooser)
        if (err != null) toast(err)
    }

    fun openSelection(tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (sel.isEmpty()) return
        val dir = sel.firstOrNull { it.isDir }
        if (dir != null && sel.size == 1) open(tab, dir) else sel.filter { !it.isDir }.take(5).forEach { open(tab, it) }
    }

    fun share(entries: List<FileEntry>) {
        val err = Opener.share(ctx, entries.map { File(it.path) })
        if (err != null) toast(err)
    }

    fun copyPath(entries: List<FileEntry>) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", entries.joinToString("\n") { it.path }))
        toast("Path copied")
    }

    // ------------------------------------------------------------------ dialogs, menus, toasts

    var dialog by mutableStateOf<DialogState?>(null)
    var menu by mutableStateOf<CtxMenu?>(null)
    /** Set by the Move / Copy actions: which tab's selection is being sent where (true = move). Shown as the folder picker. */
    var destination by mutableStateOf<Pair<TabState, Boolean>?>(null)
    /** Touch hold on a selected item: the stack stays on screen beside the menu until the menu closes. */
    var holdStack by mutableStateOf<app.dexfiles.state.HoldStack?>(null)
    var quickLook by mutableStateOf(false)
    /** The phone tab switcher sheet. */
    var tabSheet by mutableStateOf(false)
    /** The Tray: things picked up from any folder, to be dropped into another one. Lives until emptied. */
    val tray = mutableStateListOf<FileEntry>()
    /** Folders recently chosen in the Move / Copy picker, newest first (mock F6 "Recent"). */
    val recentDests = mutableStateListOf<String>()
    fun addToTray(sel: List<FileEntry>, tab: TabState = current) {
        val fresh = sel.filter { e -> tray.none { it.path == e.path } }
        tray.addAll(fresh)
        clearSelection(tab)
        toast(if (fresh.size == 1) "Added to the tray" else "Added ${fresh.size} to the tray")
    }
    fun removeFromTray(path: String) { tray.removeAll { it.path == path } }
    /** Sends the whole tray into the open folder, then empties it. */
    fun dropTray(move: Boolean, tab: TabState = current) {
        if (tray.isEmpty() || destDirOf(tab) == null) return
        clip = Clip(tray.map { it.path }, move)
        paste()
        tray.clear()
    }
    var typing by mutableStateOf(false)
    /** Path of the entry being renamed in place (null when none); `renameClaimed` is set by the visible name field. */
    var renaming by mutableStateOf<String?>(null)
    var renameClaimed = false
    /** Ends in-place renaming; a cancelled or unchanged rename also drops the row highlight. */
    fun endRename(clearSelect: Boolean) { renaming = null; if (clearSelect) clearSelection(current) }
    var addressTick by mutableIntStateOf(0)
    var searchTick by mutableIntStateOf(0)

    // Samsung-style search screen
    private val searchPrefs = ctx.getSharedPreferences("dexfiles_search", android.content.Context.MODE_PRIVATE)
    var searchUi by mutableStateOf(false); private set
    var searchCurrentOnly by mutableStateOf(searchPrefs.getBoolean("current_only", true)); private set
    val recentSearches = mutableStateListOf<String>().apply {
        addAll((searchPrefs.getString("recent", "") ?: "").split("\n").filter { it.isNotBlank() })
    }

    // iPad-style folder customisation, persisted as path -> "RRGGBB|glyph"
    private val folderPrefs = ctx.getSharedPreferences("dexfiles_folders", android.content.Context.MODE_PRIVATE)
    val folderStyles = androidx.compose.runtime.mutableStateMapOf<String, String>().apply {
        folderPrefs.all.forEach { (k, v) -> if (v is String) put(k, v) }
    }

    fun setFolderStyle(path: String, v: String?) {
        if (v == null) { folderStyles.remove(path); folderPrefs.edit().remove(path).apply() }
        else { folderStyles[path] = v; folderPrefs.edit().putString(path, v).apply() }
    }


    var viewer by mutableStateOf<ViewerState?>(null)

    fun openSearch() { searchUi = true }

    fun closeSearch() {
        current.query.takeIf { it.isNotBlank() }?.let { addRecent(it) }
        searchUi = false
        clearSearch(current)
    }

    @JvmName("applySearchCurrentOnly") fun setSearchCurrentOnly(v: Boolean) {
        searchCurrentOnly = v
        allTabs().forEach { it.searchCache.clear() }
        searchPrefs.edit().putBoolean("current_only", v).apply()
        val t = current
        if (t.query.isNotBlank()) setQuery(t, t.query)
    }

    private fun saveRecents() = searchPrefs.edit().putString("recent", recentSearches.joinToString("\n")).apply()

    fun addRecent(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        recentSearches.remove(t)
        recentSearches.add(0, t)
        while (recentSearches.size > 12) recentSearches.removeAt(recentSearches.lastIndex)
        saveRecents()
    }

    fun removeRecent(q: String) { recentSearches.remove(q); saveRecents() }
    fun clearRecents() { recentSearches.clear(); saveRecents() }
    val events = Channel<UiEvent>(Channel.BUFFERED)

    fun toast(msg: String, action: String? = null, onAction: (() -> Unit)? = null) {
        events.trySend(UiEvent(msg, action, onAction))
    }

    fun showContext(pane: Int, pos: Offset, target: FileEntry?) {
        activePane = pane
        val tab = panes[pane].tab
        if (target != null) {
            if (target.path !in tab.selection) selectOnly(tab, target) else tab.focus = target.path
        } else {
            clearSelection(tab)
        }
        menu = CtxMenu(pane, pos, target)
    }

    // ------------------------------------------------------------------ jobs

    val jobs = mutableStateListOf<TransferJob>()
    private var nextJobId = 1L

    private fun launchJob(
        title: String,
        kind: OpKind = OpKind.Other,
        doneText: ((OpResult) -> String)? = null,
        onDone: (OpResult) -> Unit = {},
        undo: ((OpResult) -> (() -> Unit)?)? = null,
        work: (TransferJob) -> OpResult,
    ) {
        val job = TransferJob(nextJobId++, title)
        jobs.add(job)
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    work(job)
                } catch (e: OperationCancelled) {
                    OpResult().also { it.cancelled = true }
                } catch (e: Throwable) {
                    OpResult().also { it.failures.add(e.message ?: "Something went wrong") }
                }
            }
            jobs.remove(job)
            when {
                res.cancelled -> toast("$title cancelled")
                res.failures.isNotEmpty() -> {
                    dialog = DialogState.Message("Some items couldn't be processed", res.failures.take(30))
                }
                else -> if (doneText != null) announce(kind, doneText(res), undo?.invoke(res))
            }
            onDone(res)
            refreshVisible()
        }
    }

    /** Finished operations, newest first, for the Recent operations page. Earlier sessions are loaded from preferences (text only). */
    val history = mutableStateListOf<OpRecord>().also { it.addAll(OpRecord.decode(prefs.opHistory)) }

    /** Tells the person what just happened (toast with Undo) and files it in [history]; the toast's Undo and the page's Undo are the same one-shot action. */
    private fun announce(kind: OpKind, text: String, undo: (() -> Unit)?) {
        val rec = OpRecord(kind, text, System.currentTimeMillis(), undo)
        history.add(0, rec)
        while (history.size > 50) history.removeAt(history.lastIndex)
        prefs.opHistory = OpRecord.encode(history)
        toast(text, if (undo != null) "Undo" else null, if (undo != null) ({ rec.run() }) else null)
    }

    fun clearHistory() {
        history.clear()
        prefs.opHistory = ""
    }

    /** "Round 3.pdf", "Round 3.pdf and 1 other", "Round 3.pdf and 2 others". */
    private fun nameOf(names: List<String>) =
        if (names.size == 1) names[0] else "${names[0]} and ${names.size - 1} other${if (names.size == 2) "" else "s"}"

    private fun destLabel(dest: File) = rootLabelMap()[dest.path.trimEnd('/')] ?: dest.name.ifEmpty { dest.path }

    /** Undo for something that made new items (copy, duplicate, zip, extract): they go to Trash, so the undo itself can be reversed. */
    private fun trashCreated(paths: List<String>) {
        val existing = paths.map { File(it) }.filter { it.exists() }
        if (existing.isEmpty()) { toast("Nothing left to undo"); return }
        launchJob("Undoing", OpKind.Undo, doneText = { r -> "Removed ${countText(r.succeeded)} (in Trash)" }) { job ->
            val res = OpResult()
            for ((i, f) in existing.withIndex()) {
                job.token.check()
                job.detail = f.name
                job.fraction = i.toFloat() / existing.size
                try {
                    storeFor(f).moveToTrash(f)
                    res.succeeded++
                } catch (x: OperationCancelled) {
                    throw x
                } catch (x: Exception) {
                    res.failures.add("${f.name}: ${x.message}")
                }
            }
            res
        }
    }

    private fun countText(n: Int) = if (n == 1) "1 item" else "$n items"

    // ------------------------------------------------------------------ clipboard operations

    var clip by mutableStateOf<Clip?>(null); private set

    fun copySelection(cut: Boolean, tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (sel.isEmpty()) return
        if (tab.path == Loc.TRASH) return
        clip = Clip(sel.map { it.path }, cut)
        toast("${countText(sel.size)} ${if (cut) "cut" else "copied"}")
    }

    private fun destDirOf(tab: TabState): File? {
        if (tab.isVirtual || tab.isSearch) return null
        val f = File(tab.path)
        return if (f.isDirectory) f else null
    }

    fun paste(into: String? = null) {
        val c = clip ?: return
        val dest = if (into != null) File(into) else destDirOf(current)
        if (dest == null || !dest.isDirectory) {
            toast("Open a folder to paste into")
            return
        }
        val files = c.paths.map { File(it) }.filter { it.exists() }
        if (files.isEmpty()) {
            toast("Those items no longer exist")
            clip = null
            return
        }
        val conflicts = FileOps.findConflicts(files, dest)
        if (conflicts.isEmpty()) {
            runTransfer(files, dest, OnConflict.KEEP_BOTH, c.cut, clearClip = c.cut)
        } else {
            dialog = DialogState.Conflicts(conflicts.map { it.name }, { choice ->
                if (choice != null) runTransfer(files, dest, choice, c.cut, clearClip = c.cut)
            }, conflicts.first(), File(dest, conflicts.first().name))
        }
    }

    /** Samsung-style Move / Copy: the destination was picked in the sheet, so transfer the selection straight there. */
    fun transferSelectionTo(dest: String, move: Boolean, tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (sel.isEmpty()) return
        clip = Clip(sel.map { it.path }, move)
        paste(dest)
        clearSelection(tab)
    }

    /** Ctrl+D / Duplicate: a copy next to each original, named "name (1)". Real folders only. */
    fun duplicate(tab: TabState = current) {
        if (tab.isVirtual || tab.isSearch) return
        val files = selectedEntries(tab).map { File(it.path) }.filter { it.exists() }
        if (files.isEmpty()) return
        runTransfer(files, File(tab.path), OnConflict.KEEP_BOTH, move = false, duplicate = true)
    }

    private fun runTransfer(files: List<File>, dest: File, policy: OnConflict, move: Boolean, clearClip: Boolean = false, duplicate: Boolean = false) {
        val verb = if (duplicate) "Duplicating" else if (move) "Moving" else "Copying"
        // Undo is only offered when no name clashed, so every moved item is known to be dest/<same name> and can go straight back.
        val clean = move && FileOps.findConflicts(files, dest).isEmpty()
        // A copy can be undone unless it replaced something: removing the copy would not bring the original back.
        val noReplace = move || policy != OnConflict.REPLACE || FileOps.findConflicts(files, dest).isEmpty()
        val backPairs = if (clean) files.mapNotNull { f -> f.parentFile?.let { par -> File(dest, f.name) to par } } else emptyList()
        launchJob(
            title = verb,
            kind = if (move) OpKind.Move else OpKind.Copy,
            doneText = { r ->
                val what = if (r.succeeded == files.size) nameOf(files.map { it.name }) else countText(r.succeeded)
                (if (duplicate) "Duplicated " else if (move) "Moved " else "Copied ") + what + (if (duplicate) "" else " to ${destLabel(dest)}") + (if (r.skipped > 0) ", skipped ${r.skipped}" else "")
            },
            onDone = { if (clearClip) clip = null },
            undo = { r ->
                if (!move) {
                    if (!noReplace || r.created.isEmpty()) null else ({ trashCreated(ArrayList(r.created)) })
                } else if (!clean || r.succeeded == 0 || r.skipped > 0) null else ({
                    launchJob("Undoing", OpKind.Undo, doneText = { u -> "Moved ${countText(u.succeeded)} back" }) { job ->
                        val total = OpResult()
                        backPairs.filter { it.first.exists() }.groupBy({ it.second }, { it.first }).forEach { (par, fs) ->
                            val rr = FileOps.move(fs, par, OnConflict.KEEP_BOTH, job.token) { p -> job.fraction = p.fraction; job.detail = p.current }
                            total.succeeded += rr.succeeded; total.failures.addAll(rr.failures)
                        }
                        total
                    }
                })
            },
        ) { job ->
            val cb: (app.dexfiles.core.Progress) -> Unit = { p ->
                job.fraction = p.fraction
                job.detail = p.current
            }
            if (move) FileOps.move(files, dest, policy, job.token, cb) else FileOps.copy(files, dest, policy, job.token, cb)
        }
    }

    /** Dual-pane quick transfer (Total Commander F5 / F6). */
    fun transferToOtherPane(move: Boolean) {
        if (!dual) return
        val src = current
        val dst = otherPane.tab
        val dest = destDirOf(dst)
        if (dest == null) { toast("Open a folder in the other pane first"); return }
        val files = selectedEntries(src).map { File(it.path) }
        if (files.isEmpty()) return
        val conflicts = FileOps.findConflicts(files, dest)
        if (conflicts.isEmpty()) runTransfer(files, dest, OnConflict.KEEP_BOTH, move)
        else dialog = DialogState.Conflicts(conflicts.map { it.name }, { c -> if (c != null) runTransfer(files, dest, c, move) }, conflicts.first(), File(dest, conflicts.first().name))
    }

    // ------------------------------------------------------------------ drag & drop

    fun dragPaths(tab: TabState, e: FileEntry): List<String> {
        if (e.path !in tab.selection) selectOnly(tab, e)
        return selectedEntries(tab).map { it.path }
    }

    /** Same storage moves, another storage copies; Ctrl ([forceCopy]) always copies. The drop label and the drop itself both ask this. */
    fun dropMoves(paths: List<String>, destDir: String, forceCopy: Boolean): Boolean {
        val first = paths.firstOrNull() ?: return false
        return !forceCopy && Volumes.rootFor(first, volumes)?.path == Volumes.rootFor(destDir, volumes)?.path
    }

    fun dropInternal(paths: List<String>, destDir: String, forceCopy: Boolean) {
        if (Loc.isVirtual(destDir)) return
        val files = paths.map { File(it) }.filter { it.exists() }
        if (files.isEmpty()) return
        val dest = File(destDir)
        if (!dest.isDirectory) return
        val move = dropMoves(paths, destDir, forceCopy)
        if (move && files.all { it.parent == destDir }) return
        val conflicts = FileOps.findConflicts(files, dest)
        if (conflicts.isEmpty()) runTransfer(files, dest, OnConflict.KEEP_BOTH, move)
        else dialog = DialogState.Conflicts(conflicts.map { it.name }, { c -> if (c != null) runTransfer(files, dest, c, move) }, conflicts.first(), File(dest, conflicts.first().name))
    }

    /** Handles anything dropped onto a folder: our own rows, or files from other apps/windows. */
    fun handleDrop(event: DragEvent, activity: Activity?, destDir: String): Boolean {
        if (Loc.isVirtual(destDir)) return false
        val local = event.localState
        if (local is DragPayload) {
            dropInternal(local.paths, destDir, Mods.ctrl)
            return true
        }
        val clipData = event.clipData ?: return false
        val uris = ArrayList<Uri>()
        for (i in 0 until clipData.itemCount) clipData.getItemAt(i).uri?.let { uris.add(it) }
        if (uris.isEmpty()) return false
        val perms = try { activity?.requestDragAndDropPermissions(event) } catch (_: Exception) { null }
        importUris(uris, destDir) { perms?.release() }
        return true
    }

    private fun displayName(uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    fun importUris(uris: List<Uri>, destDir: String, onFinished: () -> Unit) {
        launchJob("Copying", OpKind.Copy, doneText = { "Copied ${countText(it.succeeded)} to ${destLabel(File(destDir))}" }, onDone = { onFinished() }) { job ->
            val res = OpResult()
            for ((i, u) in uris.withIndex()) {
                job.token.check()
                job.detail = displayName(u) ?: "file"
                job.fraction = i.toFloat() / uris.size
                try {
                    val name = displayName(u)?.takeIf { FileOps.validateName(it) == null } ?: "file"
                    val target = FileOps.uniqueChild(File(destDir), name, false)
                    val input = ctx.contentResolver.openInputStream(u) ?: throw java.io.IOException("Can't read the dropped item")
                    input.use { ins -> FileOutputStream(target).use { out -> ins.copyTo(out) } }
                    res.succeeded++
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: Exception) {
                    res.failures.add("${displayName(u) ?: "item"}: ${e.message}")
                }
            }
            res
        }
    }

    // ------------------------------------------------------------------ delete / trash

    fun requestDelete(permanent: Boolean = false, tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (sel.isEmpty()) return
        if (tab.path == Loc.TRASH) {
            dialog = DialogState.ConfirmDelete(sel, permanent = true)
            return
        }
        if (permanent || !useTrash) dialog = DialogState.ConfirmDelete(sel, permanent = true)
        else moveToTrash(sel)
    }

    fun moveToTrash(entries: List<FileEntry>) {
        val moved = ArrayList<TrashStore.Item>()
        launchJob(
            "Moving to Trash",
            OpKind.Trash,
            doneText = { r -> "Moved ${if (r.succeeded == entries.size) nameOf(entries.map { it.name }) else countText(r.succeeded)} to Trash" },
            undo = { r -> if (r.succeeded > 0) ({ restoreItems(ArrayList(moved)) }) else null },
        ) { job ->
            val res = OpResult()
            for ((i, e) in entries.withIndex()) {
                job.token.check()
                job.detail = e.name
                job.fraction = i.toFloat() / entries.size
                try {
                    val f = File(e.path)
                    moved.add(storeFor(f).moveToTrash(f))
                    res.succeeded++
                } catch (x: OperationCancelled) {
                    throw x
                } catch (x: Exception) {
                    res.failures.add("${e.name}: ${x.message}")
                }
            }
            res
        }
    }

    fun deleteForever(entries: List<FileEntry>) {
        launchJob("Deleting", OpKind.Delete, doneText = { "Deleted ${countText(it.succeeded)}" }) { job ->
            val idx = trashIndex
            val res = OpResult()
            for ((i, e) in entries.withIndex()) {
                job.token.check()
                job.detail = e.name
                job.fraction = i.toFloat() / entries.size
                try {
                    val item = idx[e.path]
                    if (item != null) TrashStore(trashRootOf(item)).purge(item)
                    else FileOps.deleteRecursive(File(e.path), job.token)
                    res.succeeded++
                } catch (x: OperationCancelled) {
                    throw x
                } catch (x: Exception) {
                    res.failures.add("${e.name}: ${x.message}")
                }
            }
            res
        }
    }

    private fun restoreItems(items: List<TrashStore.Item>) {
        launchJob("Restoring", OpKind.Restore, doneText = { "Restored ${countText(it.succeeded)}" }) { job ->
            val res = OpResult()
            for ((i, it) in items.withIndex()) {
                job.fraction = i.toFloat() / items.size
                try {
                    TrashStore(trashRootOf(it)).restore(it)
                    res.succeeded++
                } catch (x: Exception) {
                    res.failures.add("${it.name}: ${x.message}")
                }
            }
            res
        }
    }

    fun restoreSelected(tab: TabState = current) {
        val idx = trashIndex
        val items = selectedEntries(tab).mapNotNull { idx[it.path] }
        if (items.isNotEmpty()) restoreItems(items)
    }

    fun emptyTrashNow() {
        launchJob("Emptying Trash", OpKind.Delete, doneText = { "Trash emptied" }) { job ->
            val res = OpResult()
            val stores = trashStores()
            for ((i, s) in stores.withIndex()) {
                job.fraction = i.toFloat() / stores.size
                try { s.empty(); res.succeeded++ } catch (x: Exception) { res.failures.add(x.message ?: "failed") }
            }
            res
        }
    }

    // ------------------------------------------------------------------ rename / create

    /** Returns an error message to show in the dialog, or null on success. */
    fun renameNow(e: FileEntry, newName: String): String? {
        return try {
            val target = FileOps.rename(File(e.path), newName)
            load(current, select = target.path)
            refreshVisible()
            announce(OpKind.Rename, "Renamed ${e.name} to ${target.name}", {
                try { FileOps.rename(target, e.name); refreshVisible() } catch (x: Exception) { toast(x.message ?: "Couldn't undo the rename") }
            })
            null
        } catch (x: Exception) {
            x.message ?: "Couldn't rename"
        }
    }

    fun createNow(folder: Boolean, parent: String, name: String): String? {
        return try {
            val f = if (folder) FileOps.createFolder(File(parent), name) else FileOps.createFile(File(parent), name)
            val tab = current
            if (tab.path == parent) load(tab, select = f.path)
            null
        } catch (x: Exception) {
            x.message ?: "Couldn't create it"
        }
    }

    fun requestNew(folder: Boolean) {
        val dir = destDirOf(current)
        if (dir == null) {
            toast("Open a folder first")
            return
        }
        dialog = DialogState.NewItem(folder, dir.path)
    }

    fun requestRename(tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (tab.path == Loc.TRASH || sel.isEmpty()) return
        if (sel.size != 1) { dialog = DialogState.BatchRenameDlg(sel); return }
        // Rename in place like iPadOS Files; if no row picks it up (not on screen) fall back to the dialog.
        val e = sel[0]
        renaming = e.path
        viewModelScope.launch {
            kotlinx.coroutines.delay(450)
            if (renaming == e.path && !renameClaimed) { renaming = null; dialog = DialogState.Rename(e) }
        }
    }


    fun applyBatchRename(entries: List<FileEntry>, spec: BatchRenameSpec) {
        launchJob("Renaming", OpKind.Rename, doneText = { "Renamed ${countText(it.succeeded)}" }) { job ->
            val res = OpResult()
            // Two phases so that swaps like a->b, b->a can't collide.
            val temps = ArrayList<Triple<File, File, String>>()
            for ((i, e) in entries.withIndex()) {
                val f = File(e.path)
                val newName = BatchRename.apply(e.name, e.isDir, i, spec)
                if (newName == e.name) continue
                val tmp = File(f.parentFile, ".dexrn-${System.nanoTime()}-$i")
                if (f.renameTo(tmp)) temps.add(Triple(tmp, f, newName)) else res.failures.add("${e.name}: couldn't rename")
            }
            for ((tmp, orig, newName) in temps) {
                val target = File(orig.parentFile, newName)
                if (target.exists() || !tmp.renameTo(target)) {
                    tmp.renameTo(orig)
                    res.failures.add("${orig.name}: couldn't rename to \"$newName\"")
                } else {
                    res.succeeded++
                }
            }
            job.fraction = 1f
            res
        }
    }

    // ------------------------------------------------------------------ archives

    /** The trash folder that owns a trashed item (its file lives at <trash>/<id>/<name>, and the store is rooted at <trash>). */
    private fun trashRootOf(item: TrashStore.Item): File =
        requireNotNull(item.file.parentFile?.parentFile) { "trash item outside a trash folder: ${item.file}" }

    fun compress(entries: List<FileEntry>, parent: String, name: String) {
        val clean = name.trim().let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        FileOps.validateName(clean)?.let { toast(it); return }
        val out = FileOps.uniqueChild(File(parent), clean, false)
        launchJob("Compressing", OpKind.Zip, doneText = { "Created ${out.name}" }, undo = { _ -> ({ trashCreated(listOf(out.path)) }) }) { job ->
            Archives.create(entries.map { File(it.path) }, out, job.token) { p ->
                job.fraction = p.fraction
                job.detail = p.current
            }
            OpResult().also { it.succeeded = 1 }
        }
    }

    fun extract(e: FileEntry, intoFolder: Boolean) {
        val zip = File(e.path)
        val parent = zip.parentFile ?: return
        val dest = if (intoFolder) FileOps.uniqueChild(parent, Archives.folderNameFor(zip), true) else parent
        // Only extracting into its own new folder can be undone; into the current folder there is no telling which files are new.
        launchJob("Extracting", OpKind.Extract, doneText = { "Extracted to ${dest.name}" }, undo = { _ -> if (intoFolder) ({ trashCreated(listOf(dest.path)) }) else null }) { job ->
            Archives.extract(zip, dest, job.token) { p ->
                job.fraction = p.fraction
                job.detail = p.current
            }
            OpResult().also { it.succeeded = 1 }
        }
    }

    // ------------------------------------------------------------------ favorites

    fun toggleFavorite(path: String) {
        favorites = if (path in favorites) favorites - path else favorites + path
        prefs.favorites = favorites
    }

    // ------------------------------------------------------------------ quick jump (Ctrl+K)

    /** Every folder on the visible volumes, shallowest first. Rebuilt when the palette opens and the last scan is over two minutes old. */
    var quickFolders by mutableStateOf<List<String>>(emptyList()); private set
    var quickIndexing by mutableStateOf(false); private set
    private var quickAt = 0L
    private var quickToken: CancelToken? = null

    /** Text the palette opens with (what was typed after ">" in the search field). */
    var paletteSeed = ""
    /** Copies the given paths into a folder through the normal paste path (progress, conflicts and Undo included). */
    fun copyPathsTo(paths: List<String>, dest: String) { clip = Clip(paths, false); paste(into = dest) }
    fun openPalette() {
        dialog = DialogState.Palette
        val fresh = quickFolders.isNotEmpty() && System.currentTimeMillis() - quickAt < 120_000
        if (fresh || quickIndexing) return
        val token = CancelToken()
        quickToken = token
        quickIndexing = true
        val roots = volumes.map { it.path }.ifEmpty { listOf(primaryRoot) }
        viewModelScope.launch {
            val found = try {
                withContext(Dispatchers.IO) { QuickIndex.scan(roots, token) }
            } catch (e: OperationCancelled) {
                null
            }
            if (found != null) { quickFolders = found; quickAt = System.currentTimeMillis() }
            quickIndexing = false
        }
    }

    // ------------------------------------------------------------------ search

    private fun rank(list: List<FileEntry>, q: SearchQuery): List<FileEntry> =
        list.sortedWith(compareBy<FileEntry>({ q.relevance(it.name) }, { !it.isDir }, { it.name.lowercase() }))

    fun setQuery(tab: TabState, q: String) {
        tab.query = q
        tab.zoomAnchor = 0
        tab.searchJob?.cancel()
        tab.searchToken?.cancel()
        if (q.isBlank()) {
            clearSearch(tab)
            return
        }
        val root = if (searchCurrentOnly && !tab.isVirtual) tab.path else primaryRoot
        val fromListing = tab.searchRoot == null
        tab.searchRoot = root
        if (fromListing) tab.relevanceSort = true
        val query = SearchQuery.parse(q).copy(includeHidden = showHidden)

        // Instant feedback: narrow what is already on screen right now, never blank the page.
        val cached = tab.searchCache[q.trim()]
        val seed = cached ?: tab.raw
        val instant = seed.filter { query.matches(it) }
        tab.raw = rank(instant, query)
        resort(tab)
        tab.selection = tab.selection.filterTo(HashSet()) { p -> instant.any { it.path == p } }
        tab.error = null
        tab.searching = true

        val token = CancelToken()
        tab.searchToken = token
        tab.searchJob = viewModelScope.launch {
            delay(40)
            val acc = java.util.Collections.synchronizedList(ArrayList<FileEntry>())
            fun publish() {
                val found = synchronized(acc) { ArrayList(acc) }
                val seen = found.mapTo(HashSet()) { it.path }
                tab.raw = rank(found + instant.filter { it.path !in seen }, query)
                resort(tab)
            }
            val ticker = launch {
                while (true) {
                    delay(150)
                    publish()
                }
            }
            try {
                withContext(Dispatchers.IO) {
                    try {
                        Search.run(File(root), query, token) { acc.add(it) }
                    } catch (_: OperationCancelled) {
                    }
                }
            } finally {
                ticker.cancel()
            }
            val finalList = rank(synchronized(acc) { ArrayList(acc) }, query)
            tab.raw = finalList
            tab.searchCache[q.trim()] = finalList
            resort(tab)
            tab.searching = false
        }
    }

    fun clearSearch(tab: TabState) {
        tab.searchJob?.cancel()
        tab.searchToken?.cancel()
        val was = tab.searchRoot != null
        tab.searchCache.clear()
        tab.query = ""
        tab.searchRoot = null
        tab.searching = false
        if (was || tab.entries.isEmpty()) {
            listingCache[tab.path]?.let { tab.raw = it; resort(tab) }
            load(tab)
        }
    }

    // ------------------------------------------------------------------ storage analysis

    val analyze = AnalyzeState()

    fun startAnalyze(volumePath: String) {
        analyze.token?.cancel()
        val token = CancelToken()
        analyze.token = token
        analyze.volume = volumePath
        analyze.running = true
        analyze.scanned = 0
        analyze.report = null
        analyze.dups = null
        viewModelScope.launch {
            val rep = withContext(Dispatchers.IO) {
                try {
                    Analyzer.analyze(File(volumePath), token) { analyze.scanned = it }
                } catch (_: OperationCancelled) {
                    null
                }
            }
            analyze.report = rep
            analyze.running = false
        }
    }

    fun startDuplicates(volumePath: String) {
        analyze.token?.cancel()
        val token = CancelToken()
        analyze.token = token
        analyze.dupRunning = true
        analyze.dups = null
        viewModelScope.launch {
            val d = withContext(Dispatchers.IO) {
                try {
                    Analyzer.findDuplicates(File(volumePath), token, minSize = 4096) { analyze.scanned = it }
                } catch (_: OperationCancelled) {
                    null
                }
            }
            analyze.dups = d
            analyze.dupRunning = false
        }
    }

    fun startEmptyFolders(volumePath: String) {
        analyze.token?.cancel()
        val token = CancelToken()
        analyze.token = token
        analyze.emptyRunning = true
        analyze.empties = null
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                try {
                    Analyzer.findEmptyFolders(File(volumePath), token) { analyze.scanned = it }
                } catch (_: OperationCancelled) {
                    null
                }
            }
            analyze.empties = found
            analyze.emptyRunning = false
        }
    }

    fun cancelAnalyze() {
        analyze.token?.cancel()
    }

    // ------------------------------------------------------------------ keyboard

    fun handleKey(ev: android.view.KeyEvent): Boolean {
        if (ev.action != android.view.KeyEvent.ACTION_DOWN) return false
        if (typing) return false
        if (viewer != null) return false // the image viewer handles its own keys (arrows, +/-, 0, Esc)
        val ctrl = ev.isCtrlPressed || ev.isMetaPressed
        val shift = ev.isShiftPressed
        val alt = ev.isAltPressed
        val tab = current
        val kc = ev.keyCode

        if (quickLook) {
            when (kc) {
                android.view.KeyEvent.KEYCODE_SPACE, android.view.KeyEvent.KEYCODE_ESCAPE,
                android.view.KeyEvent.KEYCODE_ENTER, android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> { quickLook = false; return true }
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT, android.view.KeyEvent.KEYCODE_DPAD_DOWN -> { moveFocus(tab, 1, false); return true }
                android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_UP -> { moveFocus(tab, -1, false); return true }
            }
            return false
        }

        val gridStep = if ((tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) tab.columns.coerceAtLeast(1) else 1
        when (kc) {
            android.view.KeyEvent.KEYCODE_C -> if (ctrl && !alt) { copySelection(false); return true }
            android.view.KeyEvent.KEYCODE_X -> if (ctrl) { copySelection(true); return true }
            android.view.KeyEvent.KEYCODE_V -> if (ctrl) { paste(); return true }
            android.view.KeyEvent.KEYCODE_A -> if (ctrl) { selectAll(); return true }
            android.view.KeyEvent.KEYCODE_N -> if (ctrl) {
                if (shift) requestNew(true) else openInNewWindow(if (tab.isVirtual) null else tab.path)
                return true
            }
            android.view.KeyEvent.KEYCODE_T -> if (ctrl) { newTab(); return true }
            android.view.KeyEvent.KEYCODE_W -> if (ctrl) { closeTab(currentPane, currentPane.active); return true }
            android.view.KeyEvent.KEYCODE_L -> if (ctrl) { addressTick++; return true }
            android.view.KeyEvent.KEYCODE_K -> if (ctrl) { openPalette(); return true }
            android.view.KeyEvent.KEYCODE_D -> { if (alt) { addressTick++; return true }; if (ctrl) { duplicate(); return true } }
            android.view.KeyEvent.KEYCODE_F, android.view.KeyEvent.KEYCODE_E -> if (ctrl) { searchTick++; return true }
            android.view.KeyEvent.KEYCODE_H -> if (ctrl) { setShowHidden(!showHidden); return true }
            android.view.KeyEvent.KEYCODE_R -> if (ctrl) { refresh(); return true }
            android.view.KeyEvent.KEYCODE_I -> if (ctrl) { openProperties(); return true }
            android.view.KeyEvent.KEYCODE_B -> if (ctrl) { setSidebarVisible(!sidebarVisible); return true }
            android.view.KeyEvent.KEYCODE_P -> if (alt) { setPreviewVisible(!previewVisible); return true }
            android.view.KeyEvent.KEYCODE_1 -> if (ctrl) { setViewMode(tab, ViewMode.LIST); return true }
            android.view.KeyEvent.KEYCODE_2 -> if (ctrl) { setViewMode(tab, ViewMode.LIST); return true }
            android.view.KeyEvent.KEYCODE_3 -> if (ctrl) { setViewMode(tab, ViewMode.GRID); return true }
            android.view.KeyEvent.KEYCODE_4 -> if (ctrl) { setViewMode(tab, ViewMode.COLUMNS); return true }
            android.view.KeyEvent.KEYCODE_SLASH -> if (ctrl) { dialog = DialogState.Shortcuts; return true }
            android.view.KeyEvent.KEYCODE_TAB -> {
                if (ctrl) { cycleTab(!shift); return true }
                if (dual) { activePane = 1 - activePane; return true }
            }
            android.view.KeyEvent.KEYCODE_F1 -> { dialog = DialogState.Shortcuts; return true }
            android.view.KeyEvent.KEYCODE_F2 -> { requestRename(); return true }
            android.view.KeyEvent.KEYCODE_F5 -> { if (dual) transferToOtherPane(false) else refresh(); return true }
            android.view.KeyEvent.KEYCODE_F6 -> if (dual) { transferToOtherPane(true); return true }
            android.view.KeyEvent.KEYCODE_F7 -> { requestNew(true); return true }
            android.view.KeyEvent.KEYCODE_F9 -> { setDual(!dual); return true }
            android.view.KeyEvent.KEYCODE_FORWARD_DEL -> { requestDelete(permanent = shift); return true }
            android.view.KeyEvent.KEYCODE_ENTER, android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (alt) openProperties()
                else if (ctrl && (current.isSearch || (current.isVirtual && current.path != Loc.TRASH))) { current.focus?.let { reveal(it) } ?: current.selection.firstOrNull()?.let { reveal(it) } }
                else openSelection()
                return true
            }
            android.view.KeyEvent.KEYCODE_SPACE -> {
                if (tab.focus != null || tab.selection.isNotEmpty()) { quickLook = true; return true }
            }
            android.view.KeyEvent.KEYCODE_ESCAPE -> {
                when {
                    tab.isSearch -> clearSearch(tab)
                    tab.selection.isNotEmpty() -> clearSelection(tab)
                    else -> return false
                }
                return true
            }
            android.view.KeyEvent.KEYCODE_DEL -> { goUp(); return true } // Backspace
            android.view.KeyEvent.KEYCODE_FORWARD -> { goForward(); return true }
            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (alt) goUp() else moveFocus(tab, -gridStep, shift)
                return true
            }
            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (ctrl && !shift) openSelection() else moveFocus(tab, gridStep, shift)
                return true
            }
            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                when {
                    alt -> goBack()
                    tab.viewMode == ViewMode.COLUMNS -> goUp()
                    (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY) -> moveFocus(tab, -1, shift)
                    else -> return false
                }
                return true
            }
            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                when {
                    alt -> goForward()
                    tab.viewMode == ViewMode.COLUMNS -> openSelection()
                    (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY) -> moveFocus(tab, 1, shift)
                    else -> return false
                }
                return true
            }
            android.view.KeyEvent.KEYCODE_MOVE_HOME -> { moveFocus(tab, -Int.MAX_VALUE / 2, shift); return true }
            android.view.KeyEvent.KEYCODE_MOVE_END -> { moveFocus(tab, Int.MAX_VALUE / 2, shift); return true }
            android.view.KeyEvent.KEYCODE_PAGE_UP -> { moveFocus(tab, -10 * gridStep, shift); return true }
            android.view.KeyEvent.KEYCODE_PAGE_DOWN -> { moveFocus(tab, 10 * gridStep, shift); return true }
        }
        if (!ctrl && !alt && ev.isPrintingKey) {
            val ch = ev.unicodeChar
            if (ch > 32) {
                typeAhead(tab, ch.toChar())
                return true
            }
        }
        return false
    }

    fun openProperties(tab: TabState = current) {
        val sel = selectedEntries(tab)
        if (sel.isNotEmpty()) {
            dialog = DialogState.Properties(sel)
        } else if (!tab.isVirtual) {
            val f = File(tab.path)
            dialog = DialogState.Properties(listOf(FileEntry.from(f)))
        }
    }

    /** True when [path] is inside the current clipboard "cut" set (rows are drawn dimmed). */
    fun isCut(path: String): Boolean = clip?.let { it.cut && path in it.paths } ?: false

    fun rootLabelMap(): Map<String, String> = volumes.associate { it.path to it.label }


}
