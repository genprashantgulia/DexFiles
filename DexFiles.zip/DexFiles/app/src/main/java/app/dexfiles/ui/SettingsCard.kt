package app.dexfiles.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import app.dexfiles.ui2.design.pressScale
import androidx.compose.foundation.layout.heightIn
import app.dexfiles.ui2.design.DexIcons
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Motion
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.LocalPalette
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

private val Amber: Color @Composable get() = LocalPalette.current.accent
private val AmberText: Color @Composable get() = MaterialTheme.colorScheme.primary

@Composable private fun dim() = MaterialTheme.colorScheme.onSurfaceVariant
@Composable private fun btnBg() = MaterialTheme.colorScheme.surfaceContainerHigh

/** Settings as one floating card (mock): 68 high header with 40 grey circle buttons, flat 58 rows, captions, option tiles. */
@Composable
fun SettingsCard(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val page = vm.settingsPage
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(start = 20.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (page != 0) CircleBtn(DexIcons.Back, "Back", 18.dp) { vm.settingsPage = 0 }
            Text(
                when (page) { 1 -> "Appearance"; else -> "Settings" },
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface,
                modifier = Modifier.weight(1f).padding(start = if (page != 0) 4.dp else 0.dp),
            )
            CircleBtn(DexIcons.Close, "Close", 16.dp) { vm.settingsOpen = false }
        }
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(Motion.glide(360)) { it / 6 * dir } + fadeIn(Motion.glide(300))) togetherWith
                    (slideOutHorizontally(Motion.glide(300)) { -it / 8 * dir } + fadeOut(Motion.glide(200)))
            },
            modifier = Modifier.weight(1f),
            label = "settingsPage",
        ) { p ->
            Column(Modifier.fillMaxSize().verticalScroll(vm.settingsScrolls[p.coerceIn(0, 1)]).padding(bottom = 20.dp)) {
                when (p) {
                    1 -> AppearancePage(vm)
                    else -> {
                        Caption("Appearance", top = 4.dp)
                        AppearancePage(vm)
                        Caption("Browsing")
                        SwitchItem("Show hidden files", null, DexIcons.Eye, vm.showHidden) { vm.setShowHidden(it) }
                        SwitchItem("Folders first", null, DexIcons.Folder, vm.foldersFirst) { vm.setFoldersFirst(it) }
                        SwitchItem("Remember view per folder", "Off: one view and sort everywhere", DexIcons.Folder, vm.perFolderView) { vm.setPerFolderView(it) }
                        SwitchItem("Single tap to open", "Off: tap selects, double-tap opens", DexIcons.Tap, vm.singleClick) { vm.setSingleClick(it) }
                        Caption("Layout")
                        SwitchItem("Sidebar", null, DexIcons.Sidebar, vm.sidebarVisible) { vm.setSidebarVisible(it) }
                        SwitchItem("Preview panel", "Wide windows only", DexIcons.Preview, vm.previewVisible) { vm.setPreviewVisible(it) }
                        SwitchItem("Two panes", "Wide windows only", DexIcons.DualPane, vm.dual) { vm.setDual(it) }
                        Caption("Operations")
                        SwitchItem("Confirm before replacing", "Off: name clashes keep both", DexIcons.Duplicate, vm.confirmReplace) { vm.setConfirmReplace(it) }
                        SwitchItem("Use Trash", "Deleted items can be restored", DexIcons.Trash, vm.useTrash) { vm.setUseTrash(it) }
                        Text(
                            "DexFiles 1.0 \u00b7 Onest font", fontSize = 12.sp, color = dim().copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

/** The close button every side panel shares (Settings, and the sidebar when it is a drawer): same circle, same place. */
@Composable
internal fun PanelCloseButton(onClick: () -> Unit) = CircleBtn(DexIcons.Close, "Close", 16.dp, onClick)

@Composable
private fun CircleBtn(icon: ImageVector, label: String, iconSize: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(Modifier.size(36.dp).clip(app.dexfiles.ui2.design.Radius.s).background(btnBg()).pressScale(0.92f, onTap = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, label, Modifier.size(iconSize), tint = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun Caption(text: String, top: androidx.compose.ui.unit.Dp = 20.dp) {
    Text(text.uppercase(), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.9.sp, color = dim().copy(alpha = 0.8f), modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = top, bottom = 4.dp))
}

/** One settings row, every row alike: 36 icon tile (radius 12), 15/500 title, 12 dim hint, anything at the right. */
@Composable
private fun Item(title: String, hint: String?, icon: ImageVector? = null, onClick: (() -> Unit)? = null, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.fillMaxWidth().heightIn(min = 46.dp).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(start = 20.dp, end = 20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Flat rows (mock F10): title and hint on the left, the control on the right; no icon tiles.
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
            if (hint != null) Text(hint, fontSize = 11.5.sp, color = dim(), modifier = Modifier.padding(top = 2.dp))
        }
        trailing()
    }
}


@Composable
private fun SwitchItem(title: String, hint: String?, icon: ImageVector, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) =
    Item(title, hint, icon, { if (enabled) onChange(!checked) }, modifier = if (enabled) Modifier else Modifier.graphicsLayer { alpha = 0.4f }) { DexSwitch(checked) }

/** Mock switch: 42 x 24, amber track with a dark 18 thumb when on, #3A3A42 with a grey thumb when off. */
@Composable
fun DexSwitch(on: Boolean) {
    val cs = MaterialTheme.colorScheme
    val x by animateDpAsState(if (on) 21.dp else 3.dp, Motion.glide(220), label = "swX")
    val track by animateColorAsState(if (on) cs.tertiary else LocalPalette.current.strong, Motion.glide(220), label = "swT")
    val thumb by animateColorAsState(if (on) cs.onPrimary else cs.onSurfaceVariant, Motion.glide(220), label = "swK")
    Box(Modifier.size(42.dp, 24.dp).clip(CircleShape).background(track)) {
        Box(Modifier.offset(x = x, y = 3.dp).size(18.dp).clip(CircleShape).background(thumb))
    }
}

@Composable
private fun AppearancePage(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Item("Theme", null) {
        SegChips(listOf("Light", "Dark", "System"), when (vm.themeMode) { 1 -> 0; 2 -> 1; else -> 2 }) { vm.setThemeMode(when (it) { 0 -> 1; 1 -> 2; else -> 0 }) }
    }
    SteppedSlider(
        label = "Text size", value = vm.textSize, min = 12, max = 20, default = 16,
        valueText = { it.toString() }, onChange = { vm.setTextSize(it) },
    )
}

/** Small segmented control (mock F10 "Dark | Light | System"): the chosen chip is amber and glides its colour. */
@Composable
private fun SegChips(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.clip(Radius.s).background(cs.surfaceContainer).padding(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        labels.forEachIndexed { i, l ->
            val on = i == selected
            val bg by animateColorAsState(if (on) cs.primary else Color.Transparent, Motion.glide(200), label = "segBg")
            Box(Modifier.clip(Radius.xs).background(bg).pressScale(0.95f, onTap = { onSelect(i) }).padding(horizontal = 12.dp, vertical = 7.dp)) {
                Text(l, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) cs.onPrimary else cs.onSurface, maxLines = 1)
            }
        }
    }
}

/**
 * Stepped slider (mock): reset circle, title with a "16 · default" hint, and a 232 wide track at the right. Whole steps only,
 * a white value bubble above the thumb while dragging (hides a moment after letting go), a light tick per step.
 */
@Composable
fun SteppedSlider(
    label: String,
    value: Int,
    min: Int,
    max: Int,
    default: Int,
    valueText: (Int) -> String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    var dragging by remember { mutableStateOf(false) }
    var bubble by remember { mutableStateOf(false) }
    var ping by remember { mutableIntStateOf(0) }
    var widthPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val padPx = with(density) { 10.dp.toPx() }
    val n = (max - min).coerceAtLeast(1)
    val cur by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    fun valueAt(x: Float): Int {
        val span = (widthPx - 2 * padPx).coerceAtLeast(1f)
        return min + (((x - padPx) / span).coerceIn(0f, 1f) * n).roundToInt()
    }
    fun set(v: Int) { if (v != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); change(v) } }
    LaunchedEffect(dragging, ping) { if (dragging) bubble = true else if (ping > 0 || bubble) { bubble = true; delay(800); bubble = false } }
    val frac by animateFloatAsState((value - min).toFloat() / n, Motion.spatialFast(), label = "thumb")
    val grow by animateFloatAsState(if (dragging) 1f else 0f, Motion.spatialFast(), label = "grow")
    val bubbleAlpha by animateFloatAsState(if (bubble) 1f else 0f, Motion.effects(), label = "bubble")
    val changed = value != default
    val amber = Amber
    val trackColor = LocalPalette.current.strong
    val tickOn = LocalPalette.current.canvas
    // Two lines: reset + title on top, the track under them across the whole panel width (a 330 dp panel has no room beside the title).
    Column(modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 6.dp)) {
    // Mock F10: the name on the left, the value and a Reset chip on the right, the track below.
    Row(Modifier.fillMaxWidth().heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Text(valueText(value), fontSize = 12.sp, color = dim())
        Box(
            Modifier.clip(Radius.xs).background(if (changed) Amber.copy(alpha = 0.18f) else cs.surfaceContainerHigh)
                .clickable(enabled = changed) { set(default) }.padding(horizontal = 10.dp, vertical = 5.dp),
        ) { Text("Reset", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (changed) AmberText else LocalPalette.current.textFaint) }
    }
        Box(
            Modifier.fillMaxWidth().padding(top = 14.dp).height(44.dp).onSizeChanged { widthPx = it.width }
                .pointerInput(min, max) { detectTapGestures { off -> ping++; set(valueAt(off.x)) } }
                .pointerInput(min, max) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true; set(valueAt(it.x)) },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change2, _ -> change2.consume(); set(valueAt(change2.position.x)) }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val x0 = padPx
                val x1 = size.width - padPx
                val tx = x0 + (x1 - x0) * frac
                drawLine(trackColor, Offset(x0, y), Offset(x1, y), strokeWidth = 6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                drawLine(amber, Offset(x0, y), Offset(tx, y), strokeWidth = 6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                for (i in 0..n) {
                    val x = x0 + (x1 - x0) * i / n
                    if (x <= tx + 1f) drawCircle(tickOn, 2.dp.toPx(), Offset(x, y))
                }
                if (grow > 0f) drawCircle(amber.copy(alpha = 0.22f * grow), 16.dp.toPx() * grow, Offset(tx, y))
                drawCircle(amber, 10.dp.toPx() + 2.dp.toPx() * grow, Offset(tx, y))
            }
            Box(
                Modifier
                    .offset { IntOffset((padPx + (widthPx - 2 * padPx) * frac - 24.dp.toPx()).roundToInt(), -40.dp.toPx().roundToInt()) }
                    .graphicsLayer { alpha = bubbleAlpha; translationY = (1f - bubbleAlpha) * 6.dp.toPx() }
                    .size(48.dp, 30.dp).clip(app.dexfiles.ui2.design.Radius.xs).background(LocalPalette.current.text),
                contentAlignment = Alignment.Center,
            ) { Text(valueText(value), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = LocalPalette.current.canvas, maxLines = 1, softWrap = false) }
        }
    }
}
