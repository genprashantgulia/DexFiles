package app.dexfiles.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.border
import app.dexfiles.ui2.design.pressScale
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.heightIn
import app.dexfiles.ui2.design.DexIcons
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Motion
import app.dexfiles.ui2.design.Radius
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val Amber = Color(0xFFFFC93C)
private val AmberText: Color @Composable get() = if (dark()) Color(0xFFFFD257) else MaterialTheme.colorScheme.primary

@Composable private fun dark() = MaterialTheme.colorScheme.background == Color.Black
@Composable private fun dim() = if (dark()) Color(0xFF8E8E96) else MaterialTheme.colorScheme.onSurfaceVariant
@Composable private fun btnBg() = if (dark()) Color(0xFF2A2A30) else MaterialTheme.colorScheme.surfaceContainerHigh

/** Settings as one floating card (mock): 68 high header with 40 grey circle buttons, flat 58 rows, captions, option tiles. */
@Composable
fun SettingsCard(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val page = vm.settingsPage
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(68.dp).padding(start = 20.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (page != 0) CircleBtn(DexIcons.Back, "Back", 18.dp) { vm.settingsPage = 0 }
            Text(
                when (page) { 1 -> "Appearance"; else -> "Settings" },
                fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface,
                modifier = Modifier.weight(1f).padding(start = if (page != 0) 4.dp else 8.dp),
            )
            CircleBtn(DexIcons.Close, "Close", 16.dp) { vm.settingsOpen = false }
        }
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(Motion.glide(360)) { it / 6 * dir } + fadeIn(Motion.glide(300))) togetherWith
                    (slideOutHorizontally(Motion.glide(300)) { -it / 8 * dir } + fadeOut(Motion.glide(200)))
            },
            modifier = Modifier.weight(1f),
            label = "settingsPage",
        ) { p ->
            Column(Modifier.fillMaxSize().verticalScroll(vm.settingsScrolls[p.coerceIn(0, 1)]).padding(bottom = 20.dp)) {
                when (p) {
                    1 -> AppearancePage(vm)
                    else -> {
                        NavItem("Appearance", "Theme, accent colour, folders, font", DexIcons.Appearance) { vm.settingsPage = 1 }
                        Caption("Browsing")
                        SwitchItem("Show hidden files", null, DexIcons.Eye, vm.showHidden) { vm.setShowHidden(it) }
                        SwitchItem("Folders first", null, DexIcons.Folder, vm.foldersFirst) { vm.setFoldersFirst(it) }
                        SwitchItem("Single tap to open", "Off: tap selects, double-tap opens", DexIcons.Tap, vm.singleClick) { vm.setSingleClick(it) }
                        Caption("Layout")
                        SwitchItem("Sidebar", null, DexIcons.Sidebar, vm.sidebarVisible) { vm.setSidebarVisible(it) }
                        SwitchItem("Preview panel", "Wide windows only", DexIcons.Preview, vm.previewVisible) { vm.setPreviewVisible(it) }
                        SwitchItem("Two panes", "Wide windows only", DexIcons.DualPane, vm.dual) { vm.setDual(it) }
                        Caption("Files")
                        SwitchItem("Use Trash", "Deleted items can be restored", DexIcons.Trash, vm.useTrash) { vm.setUseTrash(it) }
                        Text(
                            "DexFiles 0.1.0", fontSize = 12.sp, color = dim().copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CircleBtn(icon: ImageVector, label: String, iconSize: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(btnBg()).pressScale(0.92f, onTap = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, label, Modifier.size(iconSize), tint = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun Caption(text: String, top: androidx.compose.ui.unit.Dp = 20.dp) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = dim(), modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = top, bottom = 8.dp))
}

/** One settings row, every row alike: 36 icon tile (radius 12), 15/500 title, 12 dim hint, anything at the right. */
@Composable
private fun Item(title: String, hint: String?, icon: ImageVector? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().heightIn(min = 62.dp).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(start = 20.dp, end = 20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (icon != null) Box(Modifier.size(36.dp).clip(Radius.m).background(if (dark()) Color(0xFF26262B) else cs.surfaceContainerHigh), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(20.dp), tint = AmberText)
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
            if (hint != null) Text(hint, fontSize = 12.sp, color = dim(), modifier = Modifier.padding(top = 2.dp))
        }
        trailing()
    }
}

@Composable
private fun NavItem(title: String, hint: String?, icon: ImageVector, onClick: () -> Unit) =
    Item(title, hint, icon, onClick) { Icon(DexIcons.ChevronRight, null, Modifier.size(16.dp), tint = dim()) }

@Composable
private fun SwitchItem(title: String, hint: String?, icon: ImageVector, checked: Boolean, onChange: (Boolean) -> Unit) =
    Item(title, hint, icon, { onChange(!checked) }) { DexSwitch(checked) }

/** Mock switch: 42 x 24, amber track with a dark 18 thumb when on, #3A3A42 with a grey thumb when off. */
@Composable
fun DexSwitch(on: Boolean) {
    val cs = MaterialTheme.colorScheme
    val x by animateDpAsState(if (on) 21.dp else 3.dp, Motion.glide(220), label = "swX")
    val track by animateColorAsState(if (on) cs.primary else (if (dark()) Color(0xFF3A3A42) else cs.outlineVariant), Motion.glide(220), label = "swT")
    val thumb by animateColorAsState(if (on) cs.onPrimary else (if (dark()) Color(0xFF8E8E96) else cs.onSurfaceVariant), Motion.glide(220), label = "swK")
    Box(Modifier.size(42.dp, 24.dp).clip(CircleShape).background(track)) {
        Box(Modifier.offset(x = x, y = 3.dp).size(18.dp).clip(CircleShape).background(thumb))
    }
}

/** Option tile (mock .opt): radius 18, 2dp border amber when chosen, dashed grey for empty slots reserved for later. */
@Composable
private fun RowScope.Opt(label: String, on: Boolean, ph: Boolean = false, onClick: (() -> Unit)? = null, preview: @Composable BoxScope.() -> Unit = {}, previewHeight: androidx.compose.ui.unit.Dp = 44.dp) {
    val cs = MaterialTheme.colorScheme
    val border by animateColorAsState(if (on) cs.primary else Color.Transparent, Motion.glide(200), label = "optB")
    val dash = if (dark()) Color(0xFF3A3A42) else cs.outlineVariant
    Column(
        Modifier.weight(1f).clip(Radius.l)
            .then(if (ph) Modifier.drawBehind { drawRoundRect(dash, cornerRadius = CornerRadius(18.dp.toPx()), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx())))) }
                else Modifier.background(if (dark()) Color(0xFF17171A) else cs.surfaceContainer).border(2.dp, border, Radius.l))
            .then(if (onClick != null) Modifier.pressScale(0.96f, onTap = onClick) else Modifier)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(previewHeight).clip(Radius.m), contentAlignment = Alignment.Center, content = preview)
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, color = if (on) AmberText else if (ph) (if (dark()) Color(0xFF6E6E76) else dim()) else (if (dark()) Color(0xFFC4C4CC) else cs.onSurface))
    }
}

@Composable
private fun OptRow(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun AppearancePage(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Caption("Mode", top = 6.dp)
    OptRow {
        Opt("System", vm.themeMode == 0, onClick = { vm.setThemeMode(0) }, preview = {
            Row(Modifier.fillMaxSize()) { Box(Modifier.weight(1f).fillMaxSize().background(Color.Black)); Box(Modifier.weight(1f).fillMaxSize().background(Color.White)) }
        })
        Opt("Light", vm.themeMode == 1, onClick = { vm.setThemeMode(1) }, preview = { Box(Modifier.fillMaxSize().background(Color.White)) })
        Opt("Dark", vm.themeMode == 2, onClick = { vm.setThemeMode(2) }, preview = { Box(Modifier.fillMaxSize().background(Color.Black).border(1.dp, Color(0xFF2A2A30), Radius.m)) })
    }
    Caption("Theme")
    OptRow {
        Opt("Default", true, preview = { Box(Modifier.fillMaxSize().background(Color.Black).border(1.dp, Color(0xFF2A2A30), Radius.m)) })
        for (i in 1..3) Opt("Theme $i", false, ph = true, preview = { Box(Modifier.fillMaxSize().drawBehind { drawRoundRect(Color(0xFF3A3A42), cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx())))) }) })
    }
    Caption("Accent colour")
    OptRow {
        Opt("Default", true, previewHeight = 30.dp, preview = { Box(Modifier.size(26.dp).clip(CircleShape).background(Amber)) })
        for (i in 1..3) Opt("Colour $i", false, ph = true, previewHeight = 30.dp, preview = { Box(Modifier.size(26.dp).drawBehind { drawCircle(Color(0xFF4A4A52), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx())))) }) })
    }
    Caption("Folder style")
    OptRow {
        Opt("Default", true, previewHeight = 52.dp, preview = { FolderIcon(Modifier.size(52.dp, 44.dp), null, true) })
        for (i in 1..3) Opt("Style $i", false, ph = true, previewHeight = 52.dp, preview = { Box(Modifier.fillMaxSize().drawBehind { drawRoundRect(Color(0xFF3A3A42), cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx())))) }) })
    }
    Caption("Selection")
    OptRow {
        Opt("Whisper + edge", vm.selStyle == 0, onClick = { vm.setSelStyle(0) }, previewHeight = 34.dp, preview = {
            Box(Modifier.size(width = 64.dp, height = 28.dp).clip(Radius.s).background(Amber.copy(alpha = 0.10f)).border(1.dp, Amber.copy(alpha = 0.30f), Radius.s))
        })
        Opt("Whisper", vm.selStyle == 1, onClick = { vm.setSelStyle(1) }, previewHeight = 34.dp, preview = {
            Box(Modifier.size(width = 64.dp, height = 28.dp).clip(Radius.s).background(Amber.copy(alpha = 0.13f)))
        })
        for (i in 1..2) Opt("Style $i", false, ph = true, previewHeight = 34.dp, preview = { Box(Modifier.fillMaxSize().drawBehind { drawRoundRect(Color(0xFF3A3A42), cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx())))) }) })
    }
    Caption("Font")
    OptRow {
        Opt("Figtree", vm.fontMode == 0, onClick = { vm.setFontMode(0) }, previewHeight = 34.dp, preview = { Text("Aa", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, fontFamily = app.dexfiles.ui.FigtreeFamily) })
        Opt("System", vm.fontMode == 1, onClick = { vm.setFontMode(1) }, previewHeight = 34.dp, preview = { Text("Aa", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, fontFamily = androidx.compose.ui.text.font.FontFamily.Default) })
        Opt("Inter", vm.fontMode == 2, onClick = { vm.setFontMode(2) }, previewHeight = 34.dp, preview = { Text("Aa", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, fontFamily = app.dexfiles.ui2.design.InterFamily) })
        Opt("Onest", vm.fontMode == 3, onClick = { vm.setFontMode(3) }, previewHeight = 34.dp, preview = { Text("Aa", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, fontFamily = app.dexfiles.ui.OnestFamily) })
    }
    Spacer(Modifier.height(6.dp))
    SteppedSlider(
        label = "Text size", value = vm.textSize, min = 12, max = 20, default = 16,
        valueText = { it.toString() }, onChange = { vm.setTextSize(it) },
    )
    val lv = ExplorerViewModel.GRID_LEVELS
    val idx = lv.indices.minByOrNull { Math.abs(lv[it] - vm.gridSize) } ?: 0
    SteppedSlider(
        label = "Icon size", value = idx, min = 0, max = lv.lastIndex, default = 3,
        valueText = { "Level ${it + 1}" }, onChange = { vm.setGridSize(lv[it.coerceIn(0, lv.lastIndex)]) },
    )
}

/**
 * Stepped slider (mock): reset circle, title with a "16 · default" hint, and a 232 wide track at the right. Whole steps only,
 * a white value bubble above the thumb while dragging (hides a moment after letting go), a light tick per step.
 */
@Composable
fun SteppedSlider(
    label: String,
    value: Int,
    min: Int,
    max: Int,
    default: Int,
    valueText: (Int) -> String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    var dragging by remember { mutableStateOf(false) }
    var bubble by remember { mutableStateOf(false) }
    var ping by remember { mutableIntStateOf(0) }
    var widthPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val padPx = with(density) { 10.dp.toPx() }
    val n = (max - min).coerceAtLeast(1)
    val cur by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    fun valueAt(x: Float): Int {
        val span = (widthPx - 2 * padPx).coerceAtLeast(1f)
        return min + (((x - padPx) / span).coerceIn(0f, 1f) * n).roundToInt()
    }
    fun set(v: Int) { if (v != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); change(v) } }
    LaunchedEffect(dragging, ping) { if (dragging) bubble = true else if (ping > 0 || bubble) { bubble = true; delay(800); bubble = false } }
    val frac by animateFloatAsState((value - min).toFloat() / n, Motion.spatialFast(), label = "thumb")
    val grow by animateFloatAsState(if (dragging) 1f else 0f, Motion.spatialFast(), label = "grow")
    val bubbleAlpha by animateFloatAsState(if (bubble) 1f else 0f, Motion.effects(), label = "bubble")
    val changed = value != default
    val trackColor = if (dark()) Color(0xFF34343A) else cs.outlineVariant
    val tickOn = Color(0xFF1A1A1E)
    val tickOff = Color(0xFF1A1A1E).copy(alpha = 0f)
    Row(
        modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 26.dp, bottom = 6.dp).heightIn(min = 58.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(32.dp).clip(CircleShape)
                .background(if (changed) Amber.copy(alpha = 0.18f) else (if (dark()) Color(0xFF222227) else cs.surfaceContainerHighest))
                .clickable(enabled = changed) { set(default) },
            contentAlignment = Alignment.Center,
        ) { Icon(DexIcons.Reset, "Reset to default", Modifier.size(16.dp), tint = if (changed) AmberText else (if (dark()) Color(0xFF5A5A64) else cs.onSurfaceVariant.copy(alpha = 0.5f))) }
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(if (changed) "${valueText(value)} · default is ${valueText(default)}" else "${valueText(value)} · default", fontSize = 12.sp, color = dim(), modifier = Modifier.padding(top = 2.dp))
        }
        Box(
            Modifier.width(232.dp).height(44.dp).onSizeChanged { widthPx = it.width }
                .pointerInput(min, max) { detectTapGestures { off -> ping++; set(valueAt(off.x)) } }
                .pointerInput(min, max) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true; set(valueAt(it.x)) },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change2, _ -> change2.consume(); set(valueAt(change2.position.x)) }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2f
                val x0 = padPx
                val x1 = size.width - padPx
                val tx = x0 + (x1 - x0) * frac
                drawLine(trackColor, Offset(x0, y), Offset(x1, y), strokeWidth = 6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                drawLine(Amber, Offset(x0, y), Offset(tx, y), strokeWidth = 6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                for (i in 0..n) {
                    val x = x0 + (x1 - x0) * i / n
                    if (x <= tx + 1f) drawCircle(tickOn, 2.dp.toPx(), Offset(x, y))
                }
                if (grow > 0f) drawCircle(Amber.copy(alpha = 0.22f * grow), 16.dp.toPx() * grow, Offset(tx, y))
                drawCircle(Amber, 10.dp.toPx() + 2.dp.toPx() * grow, Offset(tx, y))
            }
            Box(
                Modifier
                    .offset { IntOffset((padPx + (widthPx - 2 * padPx) * frac - 24.dp.toPx()).roundToInt(), -40.dp.toPx().roundToInt()) }
                    .graphicsLayer { alpha = bubbleAlpha; translationY = (1f - bubbleAlpha) * 6.dp.toPx() }
                    .size(48.dp, 30.dp).clip(CircleShape).background(if (dark()) Color(0xFFF2F2F4) else Color(0xFF1A1A1E)),
                contentAlignment = Alignment.Center,
            ) { Text(valueText(value), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (dark()) Color(0xFF1A1200) else Color(0xFFFFE7A0), maxLines = 1, softWrap = false) }
        }
    }
}
