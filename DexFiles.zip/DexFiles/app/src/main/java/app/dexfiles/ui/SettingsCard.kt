package app.dexfiles.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Motion
import app.dexfiles.ui2.design.Radius
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Settings as one floating card: a main list, and pages (Appearance, Browsing, Files) that slide in inside the same card. */
@Composable
fun SettingsCard(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val page = vm.settingsPage
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (page != 0) {
                IconBtn(Icons.Filled.ArrowBack, "Back", size = 44.dp) { vm.settingsPage = 0 }
            } else Spacer(Modifier.width(12.dp))
            Text(
                when (page) { 1 -> "Appearance"; 2 -> "Browsing"; 3 -> "Files"; else -> "Settings" },
                style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(start = 4.dp),
            )
            IconBtn(Icons.Filled.Close, "Close", size = 44.dp) { vm.settingsOpen = false }
        }
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(Motion.glide(360)) { it / 6 * dir } + fadeIn(Motion.glide(300))) togetherWith
                    (slideOutHorizontally(Motion.glide(300)) { -it / 8 * dir } + fadeOut(Motion.glide(200)))
            },
            modifier = Modifier.weight(1f),
            label = "settingsPage",
        ) { p ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
                when (p) {
                    1 -> AppearancePage(vm)
                    2 -> BrowsingPage(vm)
                    3 -> FilesPage(vm)
                    else -> {
                        NavRow(Icons.Filled.Palette, "Appearance", "Theme, text size, icon size, folders") { vm.settingsPage = 1 }
                        NavRow(Icons.Filled.Tune, "Browsing", "Hidden files, sorting, clicks, layout") { vm.settingsPage = 2 }
                        NavRow(Icons.Filled.Folder, "Files", "Trash and deleting") { vm.settingsPage = 3 }
                        Spacer(Modifier.height(18.dp))
                        Text("DexFiles", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 6.dp))
                        Text("A desktop-class file manager for touch, mouse and keyboard.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp, top = 2.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun NavRow(icon: ImageVector, title: String, summary: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(Radius.m).background(cs.surfaceContainer).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(22.dp), tint = cs.primary)
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = cs.onSurfaceVariant)
    }
}

@Composable
private fun Block(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(Radius.m).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp)) { content() }
}

@Composable
private fun AppearancePage(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Block {
        Text("Mode", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(10.dp))
        Segmented(listOf("System", "Light", "Dark"), vm.themeMode) { vm.setThemeMode(it) }
    }
    Block {
        SteppedSlider(
            label = "Text size", value = vm.textSize, min = 12, max = 20, default = 16,
            valueText = { it.toString() }, onChange = { vm.setTextSize(it) },
        )
    }
    Block {
        val lv = ExplorerViewModel.GRID_LEVELS
        val idx = lv.indices.minByOrNull { Math.abs(lv[it] - vm.gridSize) } ?: 0
        SteppedSlider(
            label = "Icon size", value = idx, min = 0, max = lv.lastIndex, default = 3,
            valueText = { "Level ${it + 1}" }, onChange = { vm.setGridSize(lv[it.coerceIn(0, lv.lastIndex)]) },
        )
    }
    Block { Text("Theme", style = MaterialTheme.typography.bodyLarge); Spacer(Modifier.height(10.dp)); Placeholders(listOf("Default", "Theme 1", "Theme 2")) }
    Block { Text("Accent colour", style = MaterialTheme.typography.bodyLarge); Spacer(Modifier.height(10.dp)); Placeholders(listOf("Default", "Colour 1", "Colour 2")) }
    Block { Text("Folder style", style = MaterialTheme.typography.bodyLarge); Spacer(Modifier.height(10.dp)); Placeholders(listOf("Default", "Style 1", "Style 2")) }
    Block { Text("Font", style = MaterialTheme.typography.bodyLarge); Spacer(Modifier.height(10.dp)); Placeholders(listOf("Default", "Font 1", "Font 2")) }
    Text("Empty slots are reserved for themes, colours, styles and fonts that come later.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(6.dp))
}

@Composable
private fun BrowsingPage(vm: ExplorerViewModel) {
    Block {
        Toggle("Show hidden files", null, vm.showHidden) { vm.setShowHidden(it) }
        Toggle("Folders first", null, vm.foldersFirst) { vm.setFoldersFirst(it) }
        Toggle("Single tap to open", "Off: tap selects, double-tap opens", vm.singleClick) { vm.setSingleClick(it) }
    }
    Block {
        Toggle("Sidebar", null, vm.sidebarVisible) { vm.setSidebarVisible(it) }
        Toggle("Preview panel", "Wide windows only", vm.previewVisible) { vm.setPreviewVisible(it) }
        Toggle("Two panes", "Wide windows only", vm.dual) { vm.setDual(it) }
    }
}

@Composable
private fun FilesPage(vm: ExplorerViewModel) {
    Block { Toggle("Use Trash", "Deleted items can be restored", vm.useTrash) { vm.setUseTrash(it) } }
}

@Composable
private fun Toggle(label: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(Radius.s).clickable { onChange(!checked) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(CircleShape).background(cs.outlineVariant).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(CircleShape).background(if (on) cs.primary else Color.Transparent).clickable { onPick(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = MaterialTheme.typography.labelLarge, color = if (on) cs.onPrimary else cs.onSurfaceVariant, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium)
            }
        }
    }
}

/** First chip is the real "Default"; the dashed ones are empty slots that are filled in later. */
@Composable
private fun Placeholders(names: List<String>) {
    val cs = MaterialTheme.colorScheme
    val dash = cs.onSurfaceVariant.copy(alpha = 0.45f)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n ->
            if (i == 0) {
                Box(Modifier.clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)).padding(horizontal = 16.dp, vertical = 9.dp)) {
                    Text(n, style = MaterialTheme.typography.labelLarge, color = cs.primary, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Box(
                    Modifier.clip(CircleShape).drawBehind {
                        drawRoundRect(dash, cornerRadius = CornerRadius(size.height / 2), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx()))))
                    }.padding(horizontal = 16.dp, vertical = 9.dp),
                ) { Text(n, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant.copy(alpha = 0.6f)) }
            }
        }
    }
}

/**
 * Obsidian-style stepped slider: whole steps only, a reset button first, the value in a bubble above the thumb while dragging
 * (it hides a moment after letting go), and a light tick per step. Reuse it for any bounded number.
 */
@Composable
fun SteppedSlider(
    label: String,
    value: Int,
    min: Int,
    max: Int,
    default: Int,
    valueText: (Int) -> String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    var dragging by remember { mutableStateOf(false) }
    var bubble by remember { mutableStateOf(false) }
    var ping by remember { mutableIntStateOf(0) }
    var widthPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val padPx = with(density) { 16.dp.toPx() }
    val n = (max - min).coerceAtLeast(1)
    val cur by rememberUpdatedState(value)
    val change by rememberUpdatedState(onChange)
    fun valueAt(x: Float): Int {
        val span = (widthPx - 2 * padPx).coerceAtLeast(1f)
        return min + (((x - padPx) / span).coerceIn(0f, 1f) * n).roundToInt()
    }
    fun set(v: Int) { if (v != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); change(v) } }
    LaunchedEffect(dragging, ping) { if (dragging) bubble = true else if (ping > 0 || bubble) { bubble = true; delay(800); bubble = false } }
    val frac by animateFloatAsState((value - min).toFloat() / n, Motion.spatialFast(), label = "thumb")
    val grow by animateFloatAsState(if (dragging) 1f else 0f, Motion.spatialFast(), label = "grow")
    val bubbleAlpha by animateFloatAsState(if (bubble) 1f else 0f, Motion.effects(), label = "bubble")
    val changed = value != default
    val trackColor = cs.outlineVariant
    val accent = cs.primary
    val tickOn = cs.onPrimary.copy(alpha = 0.55f)
    val tickOff = cs.onSurfaceVariant.copy(alpha = 0.45f)
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Box(
            Modifier.padding(bottom = 6.dp).size(36.dp).clip(CircleShape)
                .background(if (changed) accent.copy(alpha = 0.18f) else cs.surfaceContainerHighest)
                .clickable(enabled = changed) { set(default) },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Refresh, "Reset to default", Modifier.size(18.dp), tint = if (changed) accent else cs.onSurfaceVariant.copy(alpha = 0.5f)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Text(
                    if (changed) "${valueText(value)} · default is ${valueText(default)}" else valueText(value),
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                )
            }
            Box(
                Modifier.fillMaxWidth().height(58.dp).onSizeChanged { widthPx = it.width }
                    .pointerInput(min, max) { detectTapGestures { off -> ping++; set(valueAt(off.x)) } }
                    .pointerInput(min, max) {
                        detectHorizontalDragGestures(
                            onDragStart = { dragging = true; set(valueAt(it.x)) },
                            onDragEnd = { dragging = false },
                            onDragCancel = { dragging = false },
                        ) { change2, _ -> change2.consume(); set(valueAt(change2.position.x)) }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val y = size.height - 16.dp.toPx()
                    val x0 = padPx
                    val x1 = size.width - padPx
                    val tx = x0 + (x1 - x0) * frac
                    drawLine(trackColor, Offset(x0, y), Offset(x1, y), strokeWidth = 5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawLine(accent, Offset(x0, y), Offset(tx, y), strokeWidth = 5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    for (i in 0..n) {
                        val x = x0 + (x1 - x0) * i / n
                        drawCircle(if (x <= tx + 1f) tickOn else tickOff, 1.6.dp.toPx(), Offset(x, y))
                    }
                    if (grow > 0f) drawCircle(accent.copy(alpha = 0.22f * grow), 18.dp.toPx() * grow, Offset(tx, y))
                    drawCircle(accent, (9.dp.toPx() + 3.dp.toPx() * grow), Offset(tx, y))
                }
                Box(
                    Modifier
                        .offset { IntOffset((padPx + (widthPx - 2 * padPx) * frac - 20.dp.toPx()).roundToInt(), 0) }
                        .graphicsLayer { alpha = bubbleAlpha; translationY = (1f - bubbleAlpha) * 6.dp.toPx() }
                        .size(40.dp, 26.dp).clip(Radius.s).background(accent),
                    contentAlignment = Alignment.Center,
                ) { Text(valueText(value), style = MaterialTheme.typography.labelMedium, color = cs.onPrimary, fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}
