package app.dexfiles.ui2.design

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Everything a theme may change that is NOT a colour: sizes, density and motion speed.
 * Screens read these through [LocalSpec] instead of hard-coding numbers, so a future theme is one more
 * [ThemeSpec] value (plus a palette and, if it wants, an icon pack) and no screen has to change.
 * The default, [Ember], reproduces the app exactly as it looks today.
 */
data class ThemeSpec(
    val id: String,
    val name: String,
    /** Row heights (dp) for the tall list rows and the Details rows. */
    val rowList: Dp = 64.dp,
    val rowDetails: Dp = 54.dp,
    val rowSearch: Dp = 64.dp,
    /** Thumbnail size inside list rows. */
    val rowIcon: Dp = 36.dp,
    /** Hairline width used for borders and rules. */
    val hairline: Dp = 1.dp,
    /** Scales every animation duration (1 = as designed, 0.5 = twice as fast). */
    val motionScale: Float = 1f,
)

/** The shipped look: amber on AMOLED black. */
val Ember = ThemeSpec(id = "ember", name = "Ember")

val LocalSpec = staticCompositionLocalOf { Ember }
