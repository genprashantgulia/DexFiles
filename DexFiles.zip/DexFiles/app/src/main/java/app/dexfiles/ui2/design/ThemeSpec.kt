package app.dexfiles.ui2.design

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Everything a theme may change that is NOT a colour: sizes and density. Screens read these through [LocalSpec]
 * instead of hard-coding numbers.
 */
data class ThemeSpec(
    val id: String,
    val name: String,
    /** Row heights (dp) for the Details rows and the search results. */
    val rowDetails: Dp = 44.dp,
    val rowSearch: Dp = 56.dp,
)

/**
 * One whole look: its sizes plus a dark and a light palette. Adding a theme is adding one more value here and
 * passing it to DexTheme; DexTheme and every screen pick it up through the locals, no screen changes.
 */
class DexThemeDef(val spec: ThemeSpec, val dark: Palette, val light: Palette)

/** The shipped look: amber on AMOLED black. */
val EmberTheme = DexThemeDef(ThemeSpec(id = "ember", name = "Ember"), DarkPalette, LightPalette)

val LocalSpec = staticCompositionLocalOf { EmberTheme.spec }
