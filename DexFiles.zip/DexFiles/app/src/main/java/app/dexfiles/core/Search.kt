package app.dexfiles.core

import java.io.File
import java.util.Locale

/**
 * Finder/Explorer style smart search. Plain words must all appear in the name (use * and ? as wildcards).
 * Extra filters: kind:image  ext:pdf  size>10mb  size<1gb  newer:7d (h, d, w, m, y)
 */
data class SearchQuery(
    val terms: List<String> = emptyList(),
    val kinds: Set<FileKind> = emptySet(),
    val exts: Set<String> = emptySet(),
    val minSize: Long = 0L,
    val maxSize: Long = Long.MAX_VALUE,
    val newerThan: Long = 0L,
    val includeHidden: Boolean = false,
) {
    val isEmpty: Boolean
        get() = terms.isEmpty() && kinds.isEmpty() && exts.isEmpty() && minSize == 0L && maxSize == Long.MAX_VALUE && newerThan == 0L

    private val matchers: List<(String) -> Boolean> by lazy {
        terms.map { t ->
            if (t.contains('*') || t.contains('?')) {
                val sb = StringBuilder()
                for (c in t) {
                    when (c) {
                        '*' -> sb.append(".*")
                        '?' -> sb.append('.')
                        else -> sb.append(Regex.escape(c.toString()))
                    }
                }
                val re = Regex(sb.toString(), RegexOption.IGNORE_CASE)
                val m: (String) -> Boolean = { name -> re.matches(name) }
                m
            } else {
                val m: (String) -> Boolean = { name -> name.contains(t, ignoreCase = true) }
                m
            }
        }
    }

    fun matches(e: FileEntry): Boolean {
        if (kinds.isNotEmpty() && e.kind !in kinds) return false
        if (exts.isNotEmpty() && e.ext !in exts) return false
        if (!e.isDir) {
            if (e.size < minSize || e.size > maxSize) return false
        } else if (minSize > 0L) {
            return false
        }
        if (newerThan > 0L && e.modified < newerThan) return false
        for (m in matchers) if (!m(e.name)) return false
        return true
    }

    companion object {
        private val sizeRe = Regex("^size([<>])(\\d+(?:\\.\\d+)?)(b|kb|mb|gb|tb)?$", RegexOption.IGNORE_CASE)
        private val ageRe = Regex("^(\\d+)([hdwmy])$", RegexOption.IGNORE_CASE)

        private fun kindFor(word: String): FileKind? = when (word.lowercase(Locale.ROOT)) {
            "image", "images", "photo", "photos", "picture" -> FileKind.IMAGE
            "video", "videos", "movie" -> FileKind.VIDEO
            "audio", "music", "sound" -> FileKind.AUDIO
            "pdf" -> FileKind.PDF
            "doc", "docs", "document", "documents" -> FileKind.DOCUMENT
            "sheet", "spreadsheet", "excel" -> FileKind.SHEET
            "slides", "presentation" -> FileKind.SLIDES
            "archive", "archives", "zip" -> FileKind.ARCHIVE
            "apk", "app" -> FileKind.APK
            "code", "source" -> FileKind.CODE
            "text" -> FileKind.TEXT
            "folder", "folders", "dir" -> FileKind.FOLDER
            else -> null
        }

        fun parse(input: String, now: Long = System.currentTimeMillis()): SearchQuery {
            val terms = ArrayList<String>()
            val kinds = HashSet<FileKind>()
            val exts = HashSet<String>()
            var min = 0L
            var max = Long.MAX_VALUE
            var newer = 0L
            for (tok in input.trim().split(Regex("\\s+"))) {
                if (tok.isEmpty()) continue
                val lower = tok.lowercase(Locale.ROOT)
                when {
                    lower.startsWith("kind:") -> {
                        val k = kindFor(lower.removePrefix("kind:"))
                        if (k != null) kinds.add(k) else terms.add(tok)
                    }
                    lower.startsWith("ext:") -> exts.add(lower.removePrefix("ext:").removePrefix("."))
                    lower.startsWith("size") && sizeRe.matches(lower) -> {
                        val m = sizeRe.find(lower)!!
                        val num = m.groupValues[2].toDouble()
                        val mult = when (m.groupValues[3]) {
                            "kb" -> 1024L
                            "mb" -> 1024L * 1024
                            "gb" -> 1024L * 1024 * 1024
                            "tb" -> 1024L * 1024 * 1024 * 1024
                            else -> 1L
                        }
                        val bytes = (num * mult).toLong()
                        if (m.groupValues[1] == ">") min = bytes else max = bytes
                    }
                    lower.startsWith("newer:") && ageRe.matches(lower.removePrefix("newer:")) -> {
                        val m = ageRe.find(lower.removePrefix("newer:"))!!
                        val n = m.groupValues[1].toLong()
                        val ms = when (m.groupValues[2]) {
                            "h" -> 3_600_000L
                            "d" -> 86_400_000L
                            "w" -> 7 * 86_400_000L
                            "m" -> 30 * 86_400_000L
                            else -> 365 * 86_400_000L
                        }
                        newer = now - n * ms
                    }
                    else -> terms.add(tok)
                }
            }
            return SearchQuery(terms, kinds, exts, min, max, newer)
        }
    }
}

object Search {
    /** Depth-first walk below [root]; calls [onHit] for each match. Returns the number of hits (stops at [limit]). */
    fun run(root: File, q: SearchQuery, cancel: CancelToken, limit: Int = 10_000, onHit: (FileEntry) -> Unit): Int {
        var hits = 0
        val stack = java.util.ArrayDeque<File>()
        stack.push(root)
        while (stack.isNotEmpty() && hits < limit) {
            cancel.check()
            val dir = stack.pop()
            val kids = dir.listFiles() ?: continue
            for (k in kids) {
                if (!q.includeHidden && k.name.startsWith(".")) continue
                val e = FileEntry.from(k)
                if (q.matches(e)) {
                    onHit(e)
                    hits++
                    if (hits >= limit) break
                }
                if (e.isDir && !FileOps.isSymlink(k)) stack.push(k)
            }
        }
        return hits
    }
}
