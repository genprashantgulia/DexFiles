package app.dexfiles.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ZipItem(val name: String, val size: Long, val compressedSize: Long, val isDir: Boolean)

object Archives {
    private val zipExts = setOf("zip", "jar", "apk", "cbz", "xapk", "apks")

    private enum class Format { ZIP, SEVEN_Z, RAR }

    private fun formatOf(name: String): Format? = when (FileTypes.extensionOf(name)) {
        in zipExts -> Format.ZIP
        "7z" -> Format.SEVEN_Z
        "rar" -> Format.RAR
        else -> null
    }

    /** Zip-family files (what [create] writes). */
    fun isZip(name: String): Boolean = formatOf(name) == Format.ZIP

    /** Anything that can be listed and extracted: zip, 7z or RAR. */
    fun canExtract(name: String): Boolean = formatOf(name) != null

    fun list(archive: File, limit: Int = Int.MAX_VALUE): List<ZipItem> = when (formatOf(archive.name)) {
        Format.SEVEN_Z -> openSevenZ(archive).use { sz ->
            sz.entries.asSequence().take(limit).map { ZipItem(it.name, it.size, it.size, it.isDirectory) }.toList()
        }
        Format.RAR -> openRar(archive).use { rar ->
            rar.fileHeaders.asSequence().take(limit).map { ZipItem(rarName(it), it.fullUnpackSize, it.fullUnpackSize, it.isDirectory) }.toList()
        }
        else -> {
            val out = ArrayList<ZipItem>()
            ZipFile(archive).use { zf ->
                val en = zf.entries()
                while (en.hasMoreElements() && out.size < limit) {
                    val e = en.nextElement()
                    out.add(ZipItem(e.name, e.size, e.compressedSize, e.isDirectory))
                }
            }
            out
        }
    }

    fun totalEntries(archive: File): Int = when (formatOf(archive.name)) {
        Format.SEVEN_Z -> openSevenZ(archive).use { it.entries.count() }
        Format.RAR -> openRar(archive).use { it.fileHeaders.size }
        else -> ZipFile(archive).use { it.size() }
    }

    /** "photos.zip" -> "photos" */
    fun folderNameFor(zip: File): String {
        val n = zip.name
        val dot = n.lastIndexOf('.')
        return if (dot > 0) n.substring(0, dot) else n + " extracted"
    }

    private fun openSevenZ(f: File): org.apache.commons.compress.archivers.sevenz.SevenZFile = try {
        org.apache.commons.compress.archivers.sevenz.SevenZFile.builder().setFile(f).get()
    } catch (e: org.apache.commons.compress.PasswordRequiredException) {
        throw FileOpException("\"${f.name}\" is password protected")
    } catch (e: java.io.IOException) {
        throw FileOpException("Couldn't read \"${f.name}\" (damaged or unsupported)")
    }

    private fun openRar(f: File): com.github.junrar.Archive = try {
        com.github.junrar.Archive(f).also {
            if (it.isEncrypted) { it.close(); throw FileOpException("\"${f.name}\" is password protected") }
        }
    } catch (e: com.github.junrar.exception.RarException) {
        throw FileOpException("Couldn't read \"${f.name}\" (damaged or unsupported)")
    }

    private fun rarName(h: com.github.junrar.rarfile.FileHeader): String = h.fileName.replace('\\', '/')

    /** Writes entries into [destDir], refusing any name that would escape it (zip-slip) and reporting progress. */
    private class Writer(val destDir: File, val total: Long, val cancel: CancelToken, val onProgress: (Progress) -> Unit) {
        private val root = destDir.canonicalPath
        private var done = 0L
        private var lastEmit = 0L
        var written = 0; private set

        private fun target(name: String): File {
            val out = File(destDir, name.replace('\\', '/'))
            val canon = out.canonicalPath
            if (canon != root && !canon.startsWith(root + File.separator)) throw FileOpException("Blocked unsafe path in archive: $name")
            return out
        }

        fun dir(name: String) { target(name).mkdirs() }

        fun file(name: String, mtime: Long, produce: (java.io.OutputStream) -> Unit) {
            val out = target(name)
            out.parentFile?.mkdirs()
            FileOutputStream(out).use { fos ->
                produce(object : java.io.OutputStream() {
                    override fun write(b: Int) { fos.write(b); count(1, name) }
                    override fun write(b: ByteArray, off: Int, len: Int) { cancel.check(); fos.write(b, off, len); count(len, name) }
                })
            }
            if (mtime > 0) out.setLastModified(mtime)
            written++
        }

        private fun count(n: Int, name: String) {
            done += n
            val now = System.nanoTime()
            if (now - lastEmit > 100_000_000L) { lastEmit = now; onProgress(Progress(done, total, name)) }
        }

        fun finish() = onProgress(Progress(total, total, ""))
    }

    /**
     * Extracts a zip, 7z or RAR into [destDir]. Entries that would escape the destination are rejected.
     * Returns the number of files written.
     */
    fun extract(
        zip: File,
        destDir: File,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ): Int {
        if (!destDir.exists() && !destDir.mkdirs()) throw FileOpException("Couldn't create \"${destDir.name}\"")
        when (formatOf(zip.name)) {
            Format.SEVEN_Z -> openSevenZ(zip).use { sz ->
                val w = Writer(destDir, sz.entries.sumOf { maxOf(0L, it.size) }, cancel, onProgress)
                val buf = ByteArray(128 * 1024)
                while (true) {
                    cancel.check()
                    val e = sz.nextEntry ?: break
                    if (e.isDirectory) { w.dir(e.name); continue }
                    w.file(e.name, if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L) { o ->
                        while (true) { val n = sz.read(buf); if (n < 0) break; o.write(buf, 0, n) }
                    }
                }
                w.finish()
                return w.written
            }
            Format.RAR -> openRar(zip).use { rar ->
                val heads = rar.fileHeaders
                val w = Writer(destDir, heads.sumOf { maxOf(0L, it.fullUnpackSize) }, cancel, onProgress)
                for (h in heads) {
                    cancel.check()
                    val name = rarName(h)
                    if (h.isDirectory) { w.dir(name); continue }
                    w.file(name, h.mTime?.time ?: 0L) { o ->
                        try { rar.extractFile(h, o) } catch (e: com.github.junrar.exception.RarException) {
                            cancel.check() // junrar wraps everything, including our cancellation
                            throw FileOpException("Couldn't extract \"$name\" (damaged or unsupported)")
                        }
                    }
                }
                w.finish()
                return w.written
            }
            else -> ZipFile(zip).use { zf ->
                var total = 0L
                val en0 = zf.entries()
                while (en0.hasMoreElements()) total += maxOf(0L, en0.nextElement().size)
                val w = Writer(destDir, total, cancel, onProgress)
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    cancel.check()
                    val e: ZipEntry = en.nextElement()
                    if (e.isDirectory) { w.dir(e.name); continue }
                    w.file(e.name, e.time) { o -> zf.getInputStream(e).use { it.copyTo(o, 128 * 1024) } }
                }
                w.finish()
                return w.written
            }
        }
    }

    /** Creates a zip of [sources]; each source keeps its own name as the top-level entry. */
    fun create(
        sources: List<File>,
        outFile: File,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ) {
        val total = sources.sumOf { FileOps.sizeOf(it, cancel) }
        var done = 0L
        var lastEmit = 0L
        val outCanon = outFile.canonicalPath
        val buf = ByteArray(128 * 1024)
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
                fun add(f: File, entryName: String) {
                    cancel.check()
                    if (f.canonicalPath == outCanon) return
                    if (f.isDirectory) {
                        if (FileOps.isSymlink(f)) return
                        val e = ZipEntry("$entryName/")
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        zos.closeEntry()
                        f.listFiles()?.forEach { add(it, "$entryName/${it.name}") }
                    } else {
                        val e = ZipEntry(entryName)
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        BufferedInputStream(FileInputStream(f)).use { input ->
                            while (true) {
                                cancel.check()
                                val n = input.read(buf)
                                if (n < 0) break
                                zos.write(buf, 0, n)
                                done += n
                                val now = System.nanoTime()
                                if (now - lastEmit > 100_000_000L) {
                                    lastEmit = now
                                    onProgress(Progress(done, total, f.name))
                                }
                            }
                        }
                        zos.closeEntry()
                    }
                }
                for (s in sources) add(s, s.name)
            }
            onProgress(Progress(total, total, ""))
        } catch (t: Throwable) {
            outFile.delete()
            throw t
        }
    }
}
