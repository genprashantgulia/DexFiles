package app.dexfiles.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ZipItem(val name: String, val size: Long, val compressedSize: Long, val isDir: Boolean)

object Archives {
    private val zipExts = setOf("zip", "jar", "apk", "cbz", "xapk", "apks")

    fun isZip(name: String): Boolean = FileTypes.extensionOf(name) in zipExts

    fun list(zip: File, limit: Int = Int.MAX_VALUE): List<ZipItem> {
        val out = ArrayList<ZipItem>()
        ZipFile(zip).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements() && out.size < limit) {
                val e = en.nextElement()
                out.add(ZipItem(e.name, e.size, e.compressedSize, e.isDirectory))
            }
        }
        return out
    }

    fun totalEntries(zip: File): Int = ZipFile(zip).use { it.size() }

    /** "photos.zip" -> "photos" */
    fun folderNameFor(zip: File): String {
        val n = zip.name
        val dot = n.lastIndexOf('.')
        return if (dot > 0) n.substring(0, dot) else n + " extracted"
    }

    /**
     * Extracts into [destDir]. Entries that would escape the destination (zip-slip) are rejected.
     * Returns the number of files written.
     */
    fun extract(
        zip: File,
        destDir: File,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ): Int {
        if (!destDir.exists() && !destDir.mkdirs()) throw FileOpException("Couldn't create \"${destDir.name}\"")
        val root = destDir.canonicalPath
        var written = 0
        ZipFile(zip).use { zf ->
            var total = 0L
            val en0 = zf.entries()
            while (en0.hasMoreElements()) total += maxOf(0L, en0.nextElement().size)
            var done = 0L
            var lastEmit = 0L
            val en = zf.entries()
            val buf = ByteArray(128 * 1024)
            while (en.hasMoreElements()) {
                cancel.check()
                val e: ZipEntry = en.nextElement()
                val out = File(destDir, e.name)
                val canon = out.canonicalPath
                if (canon != root && !canon.startsWith(root + File.separator)) {
                    throw FileOpException("Blocked unsafe path in archive: ${e.name}")
                }
                if (e.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile?.mkdirs()
                zf.getInputStream(e).use { input ->
                    FileOutputStream(out).use { output ->
                        while (true) {
                            cancel.check()
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val now = System.nanoTime()
                            if (now - lastEmit > 100_000_000L) {
                                lastEmit = now
                                onProgress(Progress(done, total, e.name))
                            }
                        }
                    }
                }
                if (e.time > 0) out.setLastModified(e.time)
                written++
            }
            onProgress(Progress(total, total, ""))
        }
        return written
    }

    /** Creates a zip of [sources]; each source keeps its own name as the top-level entry. */
    fun create(
        sources: List<File>,
        outFile: File,
        cancel: CancelToken = CancelToken(),
        onProgress: (Progress) -> Unit = {},
    ) {
        val total = sources.sumOf { FileOps.sizeOf(it, cancel) }
        var done = 0L
        var lastEmit = 0L
        val outCanon = outFile.canonicalPath
        val buf = ByteArray(128 * 1024)
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
                fun add(f: File, entryName: String) {
                    cancel.check()
                    if (f.canonicalPath == outCanon) return
                    if (f.isDirectory) {
                        if (FileOps.isSymlink(f)) return
                        val e = ZipEntry("$entryName/")
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        zos.closeEntry()
                        f.listFiles()?.forEach { add(it, "$entryName/${it.name}") }
                    } else {
                        val e = ZipEntry(entryName)
                        e.time = f.lastModified()
                        zos.putNextEntry(e)
                        BufferedInputStream(FileInputStream(f)).use { input ->
                            while (true) {
                                cancel.check()
                                val n = input.read(buf)
                                if (n < 0) break
                                zos.write(buf, 0, n)
                                done += n
                                val now = System.nanoTime()
                                if (now - lastEmit > 100_000_000L) {
                                    lastEmit = now
                                    onProgress(Progress(done, total, f.name))
                                }
                            }
                        }
                        zos.closeEntry()
                    }
                }
                for (s in sources) add(s, s.name)
            }
            onProgress(Progress(total, total, ""))
        } catch (t: Throwable) {
            outFile.delete()
            throw t
        }
    }
}
