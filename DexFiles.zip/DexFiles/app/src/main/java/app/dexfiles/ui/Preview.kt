package app.dexfiles.ui

import androidx.compose.runtime.mutableStateOf
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.Archives
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.FileOps
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------------------------------------------------------------------------------------------- side panel

@Composable
fun PreviewPanel(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val sel = vm.selectedEntries(tab)
    val target: FileEntry? = sel.singleOrNull() ?: if (sel.isEmpty()) tab.entries.firstOrNull { it.path == tab.focus } else null

    Column(
        modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        when {
            sel.size > 1 -> {
                Text("${sel.size} items selected", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                val files = sel.count { !it.isDir }
                val folders = sel.size - files
                Text("$files files, $folders folders", style = MaterialTheme.typography.bodySmall)
                Text("Total size of files: ${Format.size(sel.filter { !it.isDir }.sumOf { it.size })}", style = MaterialTheme.typography.bodySmall)
                DexButton("Properties") { vm.dialog = DialogState.Properties(sel) }
            }
            target != null -> {
                PreviewContent(target, big = false, modifier = Modifier.fillMaxWidth().then(if (target.kind == FileKind.IMAGE && !target.isDir) Modifier else Modifier.height(220.dp).clip(Radius.l)))
                Text(target.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                InfoLine("Type", FileTypes.typeLabel(target.name, target.isDir))
                if (!target.isDir) InfoLine("Size", Format.size(target.size))
                if (target.isDir && !Loc.isVirtual(target.path)) {
                    val count by produceState(-1, target.path) { value = withContext(Dispatchers.IO) { FileOps.childCount(File(target.path)) } }
                    if (count >= 0) InfoLine("Contains", Format.items(count))
                    // The total is only worked out when asked: it can mean walking a whole tree.
                    var total by remember(target.path) { androidx.compose.runtime.mutableStateOf<Long?>(null) }
                    var asked by remember(target.path) { androidx.compose.runtime.mutableStateOf(false) }
                    LaunchedEffect(asked, target.path) { if (asked) total = withContext(Dispatchers.IO) { FileOps.sizeOf(File(target.path)) } }
                    val t = total
                    if (t != null) InfoLine("Size", Format.size(t))
                    else if (asked) InfoLine("Size", "Calculating\u2026")
                    else DexButton("Calculate size") { asked = true }
                }
                if (target.kind == FileKind.IMAGE && !target.isDir) {
                    val dims by produceState<Pair<Int, Int>?>(null, target.path) { value = withContext(Dispatchers.IO) { imageSize(target.path) } }
                    dims?.let { InfoLine("Dimensions", "${it.first} \u00D7 ${it.second}") }
                }
                if (Archives.canExtract(target.name) && !target.isDir) {
                    val sum by produceState<String?>(null, target.path, target.modified) {
                        value = withContext(Dispatchers.IO) {
                            runCatching {
                                val items = Archives.list(File(target.path), 20000)
                                val files = items.filter { !it.isDir }
                                "${Format.items(files.size)} \u00B7 ${Format.size(files.sumOf { it.compressedSize })} compressed \u00B7 ${Format.size(files.sumOf { it.size })} unpacked"
                            }.getOrNull()
                        }
                    }
                    sum?.let { InfoLine("Contents", it) }
                }
                InfoLine("Modified", Fmt.dateTime(target.modified))
                target.parentPath?.let { InfoLine("Location", it) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DexButton("Open", DexBtn.Primary) { vm.open(tab, target) }
                    if (!target.isDir && Archives.canExtract(target.name)) DexButton("Extract\u2026") { vm.dialog = DialogState.Archive(target) }
                    DexButton("Properties") { vm.dialog = DialogState.Properties(listOf(target)) }
                }
            }
            else -> {
                val label = Loc.title(tab.path, vm.rootLabelMap())
                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    Format.items(tab.entries.size) + if (tab.selection.isEmpty()) "" else ", ${tab.selection.size} selected",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("Select a file to preview it. Press Space for a full-size look.", style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        Text(value, style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
    }
}

// ---------------------------------------------------------------------------------------------- Quick Look (Space)

@Composable
fun QuickLook(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val e = tab.entries.firstOrNull { it.path == tab.focus } ?: vm.selectedEntries(tab).firstOrNull()
    if (e == null) {
        LaunchedEffect(Unit) { vm.quickLook = false }
        return
    }
    // The card eases in; moving to the next file slides the content 24 dp and cross-fades.
    var shown by remember { androidx.compose.runtime.mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val appear by androidx.compose.animation.core.animateFloatAsState(if (shown) 1f else 0f, androidx.compose.animation.core.tween(240), label = "qlAppear")
    val compact = LocalCompact.current
    val slide = with(androidx.compose.ui.platform.LocalDensity.current) { 24.dp.roundToPx() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f * appear))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.quickLook = false },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .fillMaxWidth(if (compact) 0.94f else 0.82f)
                .fillMaxHeight(if (compact) 0.88f else 0.84f)
                .graphicsLayer { alpha = appear; scaleX = 0.96f + 0.04f * appear; scaleY = 0.96f + 0.04f * appear }
                .clip(Radius.l)
                .background(dialogSurface())
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = e,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                transitionSpec = {
                    val from = tab.entries.indexOfFirst { it.path == initialState.path }
                    val to = tab.entries.indexOfFirst { it.path == targetState.path }
                    val dir = if (to >= from) 1 else -1
                    (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(260)) { dir * slide } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260))) togetherWith
                        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(260)) { -dir * slide } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)))
                },
                label = "qlContent",
            ) { f ->
                val dims by produceState<Pair<Int, Int>?>(null, f.path) { value = if (f.kind == FileKind.IMAGE && !f.isDir) withContext(Dispatchers.IO) { imageSize(f.path) } else null }
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FileThumb(f, 28.dp, crop = false)
                        Spacer(Modifier.size(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                listOfNotNull(
                                    FileTypes.typeLabel(f.name, f.isDir),
                                    dims?.let { "${it.first} \u00D7 ${it.second}" },
                                    if (f.isDir) null else Format.size(f.size),
                                    Fmt.dateTime(f.modified),
                                ).joinToString(" \u00B7 "),
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (!f.isDir) IconBtn(DexIcons.Share, "Share") { vm.share(listOf(f)) }
                        if (!f.isDir) IconBtn(DexIcons.OpenIn, "Open with default app") { vm.quickLook = false; vm.open(tab, f) }
                        IconBtn(DexIcons.Close, "Close (Space or Esc)") { vm.quickLook = false }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp, end = 12.dp).clip(Radius.m).background(cs.surfaceContainer).padding(12.dp), contentAlignment = Alignment.Center) {
                        PreviewContent(f, big = true, modifier = Modifier.fillMaxSize())
                    }
                }
            }
            Text(
                if (compact) "Esc: close" else "Left / Right: previous or next item        Enter: open        Space or Esc: close",
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(10.dp).align(Alignment.CenterHorizontally),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- the preview itself

@Composable
fun PreviewContent(e: FileEntry, big: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val kind = e.kind
    when {
        e.isDir -> Box(modifier, contentAlignment = Alignment.Center) { FileThumb(e, if (big) 120.dp else 88.dp) }
        kind == FileKind.IMAGE -> {
            val ctx = LocalContext.current
            val req = remember(e.path, e.modified, big) {
                ImageRequest.Builder(ctx).data(File(e.path)).size(if (big) 2000 else 700).memoryCacheKey("pv|${e.path}|${e.modified}|$big").build()
            }
            if (big) {
                Box(modifier) {
                    FileThumb(e, 64.dp, Modifier.align(Alignment.Center))
                    AsyncImage(model = req, contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().clip(Radius.xs))
                }
            } else {
                // Side panel: the card takes the picture's own proportions (portrait, wide, square), capped in height, with the corners on the picture itself.
                val ar by produceState(0f, e.path, e.modified) { value = withContext(Dispatchers.IO) { imageAspect(e.path) } }
                androidx.compose.foundation.layout.BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
                    val a = if (ar > 0f) ar else 1.4f
                    val h = (maxWidth / a).coerceIn(120.dp, 380.dp)
                    val w = minOf(maxWidth, h * a)
                    Box(Modifier.size(w, h).clip(Radius.l).background(cs.surfaceContainerHigh)) {
                        AsyncImage(model = req, contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }
        kind == FileKind.VIDEO -> Box(modifier, contentAlignment = Alignment.Center) {
            FileThumb(e, if (big) 360.dp else 200.dp, crop = false)
            Box(Modifier.size(54.dp).clip(Radius.xl).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        kind == FileKind.PDF -> {
            val bmp by produceState<Bitmap?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) { renderPdfFirstPage(e.path, if (big) 1100 else 520) }
            }
            val b = bmp
            Box(modifier, contentAlignment = Alignment.Center) {
                if (b != null) Image(b.asImageBitmap(), contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                else FileThumb(e, if (big) 96.dp else 72.dp)
            }
        }
        FileTypes.isTextual(e.name) -> {
            val text by produceState<String?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) { readTextHead(File(e.path), if (big) 64 * 1024 else 4 * 1024) }
            }
            val t = text
            Box(modifier.clip(Radius.xs).background(cs.surface)) {
                if (t == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { FileThumb(e, 64.dp) }
                else Text(
                    t,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = if (big) 13.sp else 10.sp),
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp),
                )
            }
        }
        Archives.canExtract(e.name) -> {
            val items by produceState<List<String>?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) {
                    runCatching { Archives.list(File(e.path), 200).map { it.name } }.getOrNull()
                }
            }
            val list = items
            Column(modifier.verticalScroll(rememberScrollState())) {
                if (list == null) Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) { FileThumb(e, 56.dp) }
                else {
                    Text("Contents (first ${list.size})", style = MaterialTheme.typography.labelMedium, color = cs.onSurface.copy(alpha = 0.6f))
                    for (n in list) Text(n, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        else -> Box(modifier, contentAlignment = Alignment.Center) { FileThumb(e, if (big) 120.dp else 80.dp) }
    }
}

private fun readTextHead(f: File, limit: Int): String? = try {
    f.inputStream().use { input ->
        val buf = ByteArray(limit)
        val n = input.read(buf)
        if (n <= 0) ""
        else {
            val head = buf.copyOf(n)
            if (head.any { it == 0.toByte() }) null else String(head, Charsets.UTF_8)
        }
    }
} catch (_: Exception) {
    null
}

private fun renderPdfFirstPage(path: String, widthPx: Int): Bitmap? {
    var result: Bitmap? = null
    try {
        ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                if (renderer.pageCount > 0) {
                    renderer.openPage(0).use { page ->
                        val scale = widthPx.toFloat() / page.width
                        val bmp = Bitmap.createBitmap(widthPx, (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        result = bmp
                    }
                }
            }
        }
    } catch (_: Exception) {
        result = null
    }
    return result
}

/** Width and height of the picture as it is displayed (EXIF rotation applied), or null when unknown. Reads only the header. */
internal fun imageSize(path: String): Pair<Int, Int>? = try {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    android.graphics.BitmapFactory.decodeFile(path, o)
    if (o.outWidth <= 0 || o.outHeight <= 0) null else {
        val rot = when (android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90, android.media.ExifInterface.ORIENTATION_ROTATE_270,
            android.media.ExifInterface.ORIENTATION_TRANSPOSE, android.media.ExifInterface.ORIENTATION_TRANSVERSE -> true
            else -> false
        }
        if (rot) o.outHeight to o.outWidth else o.outWidth to o.outHeight
    }
} catch (_: Throwable) { null }

/** Width / height as displayed, or 0 when unknown. */
private fun imageAspect(path: String): Float = imageSize(path)?.let { it.first.toFloat() / it.second } ?: 0f
