package app.dexfiles.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.Archives
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.FileOps
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------------------------------------------------------------------------------------------- side panel

@Composable
fun PreviewPanel(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val sel = vm.selectedEntries(tab)
    val target: FileEntry? = sel.singleOrNull() ?: if (sel.isEmpty()) tab.entries.firstOrNull { it.path == tab.focus } else null

    Column(
        modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        when {
            sel.size > 1 -> {
                Text("${sel.size} items selected", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                val files = sel.count { !it.isDir }
                val folders = sel.size - files
                Text("$files files, $folders folders", style = MaterialTheme.typography.bodySmall)
                Text("Total size of files: ${Format.size(sel.filter { !it.isDir }.sumOf { it.size })}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { vm.dialog = DialogState.Properties(sel) }) { Text("Properties") }
            }
            target != null -> {
                PreviewContent(target, big = false, modifier = Modifier.fillMaxWidth().height(220.dp))
                Text(target.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                InfoLine("Type", FileTypes.typeLabel(target.name, target.isDir))
                if (!target.isDir) InfoLine("Size", Format.size(target.size))
                if (target.isDir && !Loc.isVirtual(target.path)) {
                    val count by produceState(-1, target.path) { value = withContext(Dispatchers.IO) { FileOps.childCount(File(target.path)) } }
                    if (count >= 0) InfoLine("Contains", Format.items(count))
                }
                InfoLine("Modified", Fmt.dateTime(target.modified))
                target.parentPath?.let { InfoLine("Location", it) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { vm.open(tab, target) }) { Text("Open") }
                    TextButton(onClick = { vm.dialog = DialogState.Properties(listOf(target)) }) { Text("Properties") }
                }
            }
            else -> {
                val label = Loc.title(tab.path, vm.rootLabelMap())
                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    Format.items(tab.entries.size) + if (tab.selection.isEmpty()) "" else ", ${tab.selection.size} selected",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("Select a file to preview it. Press Space for a full-size look.", style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        Text(value, style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
    }
}

// ---------------------------------------------------------------------------------------------- Quick Look (Space)

@Composable
fun QuickLook(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val e = tab.entries.firstOrNull { it.path == tab.focus } ?: vm.selectedEntries(tab).firstOrNull()
    if (e == null) {
        LaunchedEffect(Unit) { vm.quickLook = false }
        return
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.quickLook = false },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.82f)
                .fillMaxHeight(0.84f)
                .clip(RoundedCornerShape(16.dp))
                .background(cs.surface)
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                FileThumb(e, 28.dp, crop = false)
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        FileTypes.typeLabel(e.name, e.isDir) + (if (e.isDir) "" else "  -  " + Format.size(e.size)) + "  -  " + Fmt.dateTime(e.modified),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurface.copy(alpha = 0.65f),
                        maxLines = 1,
                    )
                }
                if (!e.isDir) IconBtn(Icons.Filled.OpenInNew, "Open with default app") { vm.quickLook = false; vm.open(tab, e) }
                IconBtn(Icons.Filled.Close, "Close (Space or Esc)") { vm.quickLook = false }
            }
            Box(Modifier.weight(1f).fillMaxWidth().background(cs.surfaceContainerLow).padding(12.dp), contentAlignment = Alignment.Center) {
                PreviewContent(e, big = true, modifier = Modifier.fillMaxSize())
            }
            Text(
                "Left / Right: previous or next item        Enter: open        Space or Esc: close",
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurface.copy(alpha = 0.55f),
                modifier = Modifier.padding(10.dp).align(Alignment.CenterHorizontally),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- the preview itself

@Composable
fun PreviewContent(e: FileEntry, big: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val kind = e.kind
    when {
        e.isDir -> Box(modifier, contentAlignment = Alignment.Center) { FileThumb(e, if (big) 120.dp else 88.dp) }
        kind == FileKind.IMAGE -> {
            val ctx = LocalContext.current
            val req = remember(e.path, e.modified, big) {
                ImageRequest.Builder(ctx).data(File(e.path)).size(if (big) 2000 else 700).memoryCacheKey("pv|${e.path}|${e.modified}|$big").build()
            }
            Box(modifier) {
                FileThumb(e, 64.dp, Modifier.align(Alignment.Center))
                AsyncImage(model = req, contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)))
            }
        }
        kind == FileKind.VIDEO -> Box(modifier, contentAlignment = Alignment.Center) {
            FileThumb(e, if (big) 360.dp else 200.dp, crop = false)
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(27.dp)).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        kind == FileKind.PDF -> {
            val bmp by produceState<Bitmap?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) { renderPdfFirstPage(e.path, if (big) 1100 else 520) }
            }
            val b = bmp
            Box(modifier, contentAlignment = Alignment.Center) {
                if (b != null) Image(b.asImageBitmap(), contentDescription = e.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                else FileThumb(e, if (big) 96.dp else 72.dp)
            }
        }
        FileTypes.isTextual(e.name) -> {
            val text by produceState<String?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) { readTextHead(File(e.path), if (big) 64 * 1024 else 4 * 1024) }
            }
            val t = text
            Box(modifier.clip(RoundedCornerShape(8.dp)).background(cs.surface)) {
                if (t == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { FileThumb(e, 64.dp) }
                else Text(
                    t,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = if (big) 13.sp else 10.sp),
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp),
                )
            }
        }
        Archives.isZip(e.name) -> {
            val items by produceState<List<String>?>(null, e.path, e.modified) {
                value = withContext(Dispatchers.IO) {
                    runCatching { Archives.list(File(e.path), 200).map { it.name } }.getOrNull()
                }
            }
            val list = items
            Column(modifier.verticalScroll(rememberScrollState())) {
                if (list == null) Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) { FileThumb(e, 56.dp) }
                else {
                    Text("Contents (first ${list.size})", style = MaterialTheme.typography.labelMedium, color = cs.onSurface.copy(alpha = 0.6f))
                    for (n in list) Text(n, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        else -> Box(modifier, contentAlignment = Alignment.Center) { FileThumb(e, if (big) 120.dp else 80.dp) }
    }
}

private fun readTextHead(f: File, limit: Int): String? = try {
    f.inputStream().use { input ->
        val buf = ByteArray(limit)
        val n = input.read(buf)
        if (n <= 0) ""
        else {
            val head = buf.copyOf(n)
            if (head.any { it == 0.toByte() }) null else String(head, Charsets.UTF_8)
        }
    }
} catch (_: Exception) {
    null
}

private fun renderPdfFirstPage(path: String, widthPx: Int): Bitmap? {
    var result: Bitmap? = null
    try {
        ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                if (renderer.pageCount > 0) {
                    renderer.openPage(0).use { page ->
                        val scale = widthPx.toFloat() / page.width
                        val bmp = Bitmap.createBitmap(widthPx, (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        result = bmp
                    }
                }
            }
        }
    } catch (_: Exception) {
        result = null
    }
    return result
}
