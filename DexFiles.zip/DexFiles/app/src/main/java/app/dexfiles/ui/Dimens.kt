package app.dexfiles.ui

import androidx.compose.ui.unit.dp

/** List row height from the mock kit (F12): 54 with a pointer, 56 on touch widths. */
@androidx.compose.runtime.Composable
fun rowHeight(): androidx.compose.ui.unit.Dp = if (LocalCompact.current) 56.dp else 54.dp

/**
 * Gap above and below a row's plate. Rows keep their pitch; the plate is drawn this far inside it, so two selected
 * neighbours read as two items: a 4 dp gap with a pointer, 6 dp on touch widths.
 */
@androidx.compose.runtime.Composable
fun rowInset(): androidx.compose.ui.unit.Dp = if (LocalCompact.current) 3.dp else 2.dp

/** Shared sizes. */
object Dimens {
    val radiusRow = 12.dp
    /** The big page title above each list. Off for now; the heading code is kept for later. */
    val showHeadings = false

    val touch = app.dexfiles.ui2.design.Size.touch
    val barHeight = app.dexfiles.ui2.design.Size.pill
}
