package app.dexfiles.ui

import androidx.compose.ui.unit.dp

/** Design tokens from the design bible (UX_SPEC section 4). Use these instead of ad-hoc numbers. */
object Dimens {
    val s4 = 4.dp
    val s8 = 8.dp
    val s12 = 12.dp
    val s16 = 16.dp
    val s24 = 24.dp
    val s32 = 32.dp

    val radiusRow = 12.dp
    val radiusCard = 16.dp
    val radiusSheet = 24.dp

    val touch = 48.dp
    val barHeight = 44.dp
    val pillHeight = 44.dp
    val stripHeight = 44.dp
    val rowList = 64.dp
    val rowDetails = 52.dp
    val rowDetailsCompact = 40.dp
    val iconBtn = 44.dp
}
