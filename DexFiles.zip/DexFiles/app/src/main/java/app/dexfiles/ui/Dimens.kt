package app.dexfiles.ui

import androidx.compose.ui.unit.dp

/** List row height from the mock kit (F12): 54 with a pointer, 56 on touch widths. */
@androidx.compose.runtime.Composable
fun rowHeight(): androidx.compose.ui.unit.Dp = if (LocalCompact.current) 56.dp else 54.dp

/** Shared sizes. */
object Dimens {
    val radiusRow = 12.dp
    /** The big page title above each list. Off for now; the heading code is kept for later. */
    val showHeadings = false

    val touch = 48.dp
    val barHeight = 40.dp
}
