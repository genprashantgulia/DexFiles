package app.dexfiles.ui

import androidx.compose.ui.unit.dp

/** Design tokens from the design bible (UX_SPEC section 4). Use these instead of ad-hoc numbers. */
/** 1 = comfortable rows, 0.8 = compact (Settings > Density). */
val LocalRowScale = androidx.compose.runtime.compositionLocalOf { 1f }

/** True when the desktop (Compact) density is in effect: wide window with a pointer, or chosen in Settings. */
val LocalDesk = androidx.compose.runtime.staticCompositionLocalOf { false }

/** List row height from the mock kit (F12): 54 with a pointer, 56 on touch widths. Compact density scales it. */
@androidx.compose.runtime.Composable
fun rowHeight(): androidx.compose.ui.unit.Dp = (if (LocalCompact.current) 56.dp else 54.dp) * LocalRowScale.current

object Dimens {
    val s4 = 4.dp
    val s8 = 8.dp
    val s12 = 12.dp
    val s16 = 16.dp
    val s24 = 24.dp
    val s32 = 32.dp

    val radiusRow = 12.dp
    val radiusCard = 16.dp
    val radiusSheet = 24.dp
    /** The big page title above each list. Off for now; the heading code is kept for later. */
    val showHeadings = false

    val touch = 48.dp
    val barHeight = 40.dp
    val pillHeight = 44.dp
    val stripHeight = 44.dp
    val rowList = 54.dp
    val rowDetails = 52.dp
    val rowDetailsCompact = 40.dp
    val iconBtn = 40.dp
}
