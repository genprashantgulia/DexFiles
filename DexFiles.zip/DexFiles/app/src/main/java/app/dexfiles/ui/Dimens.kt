package app.dexfiles.ui

import androidx.compose.ui.unit.dp

/**
 * List row height (spec B01.6, B14.4): 56 on every window, and it grows with the text size (the user's size setting
 * and the system font scale are both inside the density's fontScale) so a larger text never clips a name or a date.
 * The 32 dp desktop row comes with Desktop mode.
 */
@androidx.compose.runtime.Composable
fun rowHeight(): androidx.compose.ui.unit.Dp = 56.dp * androidx.compose.ui.platform.LocalDensity.current.fontScale.coerceIn(1f, 1.6f)

/**
 * Gap above and below a row's plate. Rows keep their pitch; the plate is drawn this far inside it, so two selected
 * neighbours read as two items: a 6 dp gap between plates (3 dp each side).
 */
@androidx.compose.runtime.Composable
fun rowInset(): androidx.compose.ui.unit.Dp = 3.dp

/** Shared sizes. */
object Dimens {
    val radiusRow = 12.dp
    /** The big page title above each list. Off for now; the heading code is kept for later. */
    val showHeadings = false

    val touch = app.dexfiles.ui2.design.Size.touch
    val barHeight = app.dexfiles.ui2.design.Size.pill
}
