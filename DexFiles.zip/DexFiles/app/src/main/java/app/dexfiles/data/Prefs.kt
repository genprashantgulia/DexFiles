package app.dexfiles.data

import android.content.Context
import android.content.SharedPreferences
import app.dexfiles.core.SortKey
import app.dexfiles.state.ViewMode

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("dexfiles", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()

    var showHidden: Boolean
        get() = bool("showHidden", false)
        set(v) = putBool("showHidden", v)

    var foldersFirst: Boolean
        get() = bool("foldersFirst", true)
        set(v) = putBool("foldersFirst", v)

    var sidebarVisible: Boolean
        get() = bool("sidebar", true)
        set(v) = putBool("sidebar", v)

    var previewVisible: Boolean
        get() = bool("preview", false)
        set(v) = putBool("preview", v)

    var dualPane: Boolean
        get() = bool("dual", false)
        set(v) = putBool("dual", v)

    var useTrash: Boolean
        get() = bool("useTrash", true)
        set(v) = putBool("useTrash", v)

    var singleClick: Boolean
        get() = bool("singleClick", false)
        set(v) = putBool("singleClick", v)

    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** Interface text size in points, 12..20 (16 = default). */
    var fontMode: Int
        get() = sp.getInt("fontMode", 0)
        set(v) = sp.edit().putInt("fontMode", v).apply()

    var textSize: Int
        get() = sp.getInt("textSize", 16)
        set(v) = sp.edit().putInt("textSize", v).apply()

    var detailsColumns: Boolean
        get() = bool("detailsCols", false)
        set(v) = putBool("detailsCols", v)

    var gridSize: Int
        get() = sp.getInt("gridSize", 148)
        set(v) = sp.edit().putInt("gridSize", v).apply()

    var viewMode: ViewMode
        get() = runCatching { ViewMode.valueOf(sp.getString("viewMode", "DETAILS") ?: "DETAILS") }.getOrDefault(ViewMode.LIST).let { if (it == ViewMode.DETAILS) ViewMode.LIST else it }
        set(v) = sp.edit().putString("viewMode", v.name).apply()

    var sortKey: SortKey
        get() = runCatching { SortKey.valueOf(sp.getString("sortKey", "NAME") ?: "NAME") }.getOrDefault(SortKey.NAME)
        set(v) = sp.edit().putString("sortKey", v.name).apply()

    var sortAscending: Boolean
        get() = bool("sortAsc", true)
        set(v) = putBool("sortAsc", v)

    val hasFavorites: Boolean get() = sp.contains("favorites")

    var favorites: List<String>
        get() = (sp.getString("favorites", null) ?: "").split('\n').filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("favorites", v.joinToString("\n")).apply()

    fun savedTabs(pane: Int): List<String> =
        (sp.getString("tabs$pane", null) ?: "").split('\n').filter { it.isNotEmpty() }

    fun savedActiveTab(pane: Int): Int = sp.getInt("activeTab$pane", 0)

    fun saveTabs(pane: Int, paths: List<String>, active: Int) {
        sp.edit().putString("tabs$pane", paths.joinToString("\n")).putInt("activeTab$pane", active).apply()
    }
}
