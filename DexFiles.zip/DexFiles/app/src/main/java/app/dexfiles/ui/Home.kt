package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.Format
import app.dexfiles.data.Volume
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import java.io.File

/** Top of the Home page (Samsung My Files): round category buttons, storage cards, pinned folders, then "Recent files". */
@Composable
fun HomeTop(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Cat(Icons.Filled.Image, Color(0xFFEC5B8E), "Images") { vm.navigate(tab, Loc.IMAGES) }
            Cat(Icons.Filled.Movie, Color(0xFF8E6CEF), "Videos") { vm.navigate(tab, Loc.VIDEOS) }
            Cat(Icons.Filled.MusicNote, Color(0xFFF29B38), "Audio") { vm.navigate(tab, Loc.AUDIO) }
            Cat(Icons.Filled.Description, Color(0xFF2BB5A8), "Documents") { vm.navigate(tab, Loc.DOCS) }
            Cat(Icons.Filled.Download, Color(0xFF3D8BFF), "Downloads") { vm.navigate(tab, File(vm.primaryRoot, "Download").path) }
            Cat(Icons.Filled.Android, Color(0xFF4CAF50), "Installs") { vm.navigate(tab, Loc.APKS) }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            for (v in vm.volumes) StorageCard(v) { vm.navigate(tab, v.path) }
        }
        if (vm.favorites.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (fav in vm.favorites) {
                    val name = File(fav).name.ifEmpty { fav }
                    Row(
                        Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainer).clickable { vm.navigate(tab, fav) }.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Filled.Folder, null, Modifier.size(18.dp), tint = kindColor(app.dexfiles.core.FileKind.FOLDER))
                        Text(name, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                    }
                }
            }
        }
        Text(
            "Recent files",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 0.dp),
        )
    }
}

@Composable
private fun Cat(icon: ImageVector, color: Color, label: String, onClick: () -> Unit) {
    Column(
        Modifier.width(72.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(28.dp))
        }
        Text(label, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun StorageCard(v: Volume, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val icon = if (v.primary) Icons.Filled.PhoneAndroid else Icons.Filled.SdCard
    Column(
        Modifier.width(260.dp).clip(RoundedCornerShape(Dimens.radiusCard)).background(cs.surfaceContainer).clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, Modifier.size(22.dp), tint = cs.primary)
            Text(v.label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (v.total > 0) {
            LinearProgressIndicator(
                progress = { v.usedFraction },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = if (v.usedFraction > 0.9f) cs.error else cs.primary,
                trackColor = cs.onSurface.copy(alpha = 0.12f),
            )
            Text("${Format.size(v.used)} / ${Format.size(v.total)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}
