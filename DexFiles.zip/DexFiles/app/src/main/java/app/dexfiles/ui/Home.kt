package app.dexfiles.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState

/** One Samsung-style page header for every virtual page: big centred title, grey subtitle under it. */
@Composable
fun PageTitle(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val title = Loc.title(tab.path, vm.rootLabelMap())
    val n = tab.entries.size
    val subtitle = if (tab.loading) "Loading\u2026" else if (n == 1) "1 item" else "$n items"
    Column(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp, lineHeight = 40.sp), fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
    }
}

private val HomeChips = listOf("All", "Images", "Videos", "Audio", "Documents", "Other")

/** Rounded filter bar under the title: the same pill look as the top bar, selected chip in the accent colour. */
@Composable
fun HomeChips(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().barPill().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        HomeChips.forEachIndexed { i, label ->
            val on = vm.homeFilter == i
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                color = if (on) cs.primary else cs.onSurfaceVariant,
                modifier = Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).clickable { vm.setHomeFilter(i, tab) }.padding(horizontal = 16.dp)
                    .wrapContentHeight(Alignment.CenterVertically),
            )
        }
    }
}

/** Shrinks the big page title away while the list scrolls (Samsung collapsing header), and brings it back at the top. */
class CollapseState {
    var offset by androidx.compose.runtime.mutableFloatStateOf(0f)
    var max = 0f
}

@Composable
fun rememberCollapse(key: Any): CollapseState = androidx.compose.runtime.remember(key) { CollapseState() }

fun collapseConnection(st: CollapseState) = object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
    override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        val d = available.y
        if (d < 0f && st.offset > -st.max) {
            val n = (st.offset + d).coerceAtLeast(-st.max)
            val used = n - st.offset
            st.offset = n
            return androidx.compose.ui.geometry.Offset(0f, used)
        }
        return androidx.compose.ui.geometry.Offset.Zero
    }

    override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        val d = available.y
        if (d > 0f && st.offset < 0f) {
            val n = (st.offset + d).coerceAtMost(0f)
            val used = n - st.offset
            st.offset = n
            return androidx.compose.ui.geometry.Offset(0f, used)
        }
        return androidx.compose.ui.geometry.Offset.Zero
    }
}

@Composable
fun CollapsingTitle(vm: ExplorerViewModel, tab: TabState, st: CollapseState) {
    Box(
        Modifier
            .layout { m, c ->
                val p = m.measure(c)
                st.max = p.height.toFloat()
                val h = (p.height + st.offset).toInt().coerceAtLeast(0)
                layout(p.width, h) { p.placeRelative(0, st.offset.toInt()) }
            }
            .graphicsLayer { alpha = (1f + st.offset / st.max.coerceAtLeast(1f)).coerceIn(0f, 1f) }
            .clipToBounds(),
    ) { PageTitle(vm, tab) }
}
