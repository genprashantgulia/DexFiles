package app.dexfiles.ui

import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.runtime.remember
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState

/** Page title as in the mock: centred 34/600 inside the content card, 26 above and 14 below. Real folders show their own name. */
@Composable
fun PageTitle(vm: ExplorerViewModel, tab: TabState, bottom: androidx.compose.ui.unit.Dp = 14.dp) {
    val labels = vm.rootLabelMap()
    val title = if (tab.isVirtual) Loc.title(tab.path, labels) else (app.dexfiles.core.PathUtils.crumbs(tab.path, labels).lastOrNull()?.label ?: tab.path)
    Text(
        title,
        modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 26.dp, bottom = bottom),
        fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-0.34).sp, fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
    )
}

private val HomeChipLabels = listOf("All", "Images", "Videos", "Audio", "Documents", "Other")

/** One entry of a [ChipBar]: a label and, optionally, how many items it holds. */
class ChipItem(val label: String, val count: Int? = null)

/**
 * The one horizontal filter bar of the app (Recent's type filter, a category's sources in Columns view). A quiet track with a sliding
 * amber chip. It is only as wide as its chips; when they do not fit it scrolls sideways, keeps the chosen chip in view and fades its edges.
 */
@Composable
fun ChipBar(items: List<ChipItem>, selected: Int, modifier: Modifier = Modifier, onPick: (Int) -> Unit) {
    if (items.isEmpty()) return
    val cs = MaterialTheme.colorScheme
    val track = if (cs.background == androidx.compose.ui.graphics.Color.Black) androidx.compose.ui.graphics.Color(0xFF17171A) else cs.surfaceContainer
    val scroll = rememberScrollState()
    val xs = remember(items.size) { androidx.compose.runtime.mutableStateListOf<Int>().apply { repeat(items.size) { add(0) } } }
    val ws = remember(items.size) { androidx.compose.runtime.mutableStateListOf<Int>().apply { repeat(items.size) { add(0) } } }
    var viewW by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val sel = selected.coerceIn(0, items.lastIndex)
    val glide = app.dexfiles.ui2.design.Motion.glide<Float>(360)
    val ix by androidx.compose.animation.core.animateFloatAsState(xs[sel].toFloat(), glide, label = "chipX")
    val iw by androidx.compose.animation.core.animateFloatAsState(ws[sel].toFloat(), glide, label = "chipW")
    val d = androidx.compose.ui.platform.LocalDensity.current
    LaunchedEffect(sel, ws[sel], viewW) {
        if (ws[sel] > 0 && viewW > 0) scroll.animateScrollTo((xs[sel] + ws[sel] / 2 - viewW / 2).coerceIn(0, scroll.maxValue))
    }
    Box(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.clip(RoundedCornerShape(24.dp)).background(track).onSizeChanged { viewW = it.width }) {
            Box(Modifier.horizontalScroll(scroll).padding(4.dp)) {
                if (ws[sel] > 0) {
                    Box(
                        Modifier.offset { androidx.compose.ui.unit.IntOffset(ix.toInt(), 0) }.width(with(d) { iw.toDp() }).height(38.dp)
                            .clip(RoundedCornerShape(20.dp)).background(cs.primary),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items.forEachIndexed { i, item ->
                        val on = sel == i
                        val ink by androidx.compose.animation.animateColorAsState(
                            if (on) cs.onPrimary else cs.onSurface.copy(alpha = 0.72f), app.dexfiles.ui2.design.Motion.glide(240), label = "chipInk",
                        )
                        Row(
                            Modifier.height(38.dp).clip(RoundedCornerShape(20.dp))
                                .onGloballyPositioned { xs[i] = it.positionInParent().x.toInt(); ws[i] = it.size.width }
                                .clickable { onPick(i) }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(item.label, fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = ink, maxLines = 1, softWrap = false)
                            if (item.count != null) Text(item.count.toString(), fontSize = 12.sp, color = ink.copy(alpha = 0.7f), maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
            if (scroll.canScrollBackward) Box(Modifier.align(Alignment.CenterStart).width(22.dp).height(46.dp).background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(track, androidx.compose.ui.graphics.Color.Transparent))))
            if (scroll.canScrollForward) Box(Modifier.align(Alignment.CenterEnd).width(22.dp).height(46.dp).background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(androidx.compose.ui.graphics.Color.Transparent, track))))
        }
    }
}

/** Recent files: filter by kind. */
@Composable
fun HomeChips(vm: ExplorerViewModel, tab: TabState) {
    val items = remember { HomeChipLabels.map { ChipItem(it) } }
    ChipBar(items, vm.homeFilter) { vm.setHomeFilter(it, tab) }
}

/**
 * The big page title, Samsung-style. It follows the finger with resistance (it moves about half as far as the finger does), the list
 * stays still while it moves, and on release it settles on a soft spring: closed if it was pulled past a third of the way or flicked,
 * otherwise back where it was. [offset] runs from 0 (open) to -[max] (closed).
 */
class CollapseState(startCollapsed: Boolean = false) {
    var offset by androidx.compose.runtime.mutableFloatStateOf(0f)
    var max = 0f
    /** Phone-width windows begin closed; applied on the first measure, when the header's height is known. */
    var pendingFold = startCollapsed
    private var job: kotlinx.coroutines.Job? = null

    fun stop() { job?.cancel() }

    /** Moves the heading by [dy] of finger travel (negative = up) and returns how much of that travel it used. */
    fun drag(dy: Float): Float {
        if (max <= 0f) return 0f
        job?.cancel()
        val next = (offset + dy * RESIST).coerceIn(-max, 0f)
        val used = (next - offset) / RESIST
        offset = next
        return used
    }

    /** Called when the finger lifts: settle open or closed. [velocity] is the release speed in px/s (negative = up). */
    fun settle(scope: kotlinx.coroutines.CoroutineScope, velocity: Float) {
        if (max <= 0f || offset >= 0f || offset <= -max) return
        val close = when {
            velocity < -FLICK -> true
            velocity > FLICK -> false
            else -> offset < -max * THRESHOLD
        }
        job?.cancel()
        job = scope.launch {
            androidx.compose.animation.core.animate(
                offset, if (close) -max else 0f,
                animationSpec = androidx.compose.animation.core.spring(dampingRatio = 1f, stiffness = 170f),
            ) { v, _ -> offset = v.coerceIn(-max, 0f) }
        }
    }

    private companion object {
        const val RESIST = 0.55f
        const val THRESHOLD = 0.35f
        const val FLICK = 450f
    }
}

@Composable
fun rememberCollapse(key: Any, startCollapsed: Boolean = false): CollapseState = androidx.compose.runtime.remember(key) { CollapseState(startCollapsed) }

fun collapseConnection(st: CollapseState, scope: kotlinx.coroutines.CoroutineScope) = object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
    private val finger = androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput

    override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        // Finger moving up: the heading closes first and the list waits; whatever it cannot use goes on to the list.
        if (source != finger || available.y >= 0f) return androidx.compose.ui.geometry.Offset.Zero
        return androidx.compose.ui.geometry.Offset(0f, st.drag(available.y))
    }

    override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        // Finger moving down with the list already at the top: the heading opens.
        if (source != finger || available.y <= 0f) return androidx.compose.ui.geometry.Offset.Zero
        return androidx.compose.ui.geometry.Offset(0f, st.drag(available.y))
    }

    override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
        // The finger lifted: settle the heading, and let the flick carry on into the list with all its speed.
        st.settle(scope, available.y)
        return androidx.compose.ui.unit.Velocity.Zero
    }
}

@Composable
fun CollapsingTitle(vm: ExplorerViewModel, tab: TabState, st: CollapseState) {
    Box(
        Modifier
            .layout { m, c ->
                val p = m.measure(c)
                st.max = p.height.toFloat()
                val h = (p.height + st.offset).toInt().coerceAtLeast(0)
                layout(p.width, h) { p.placeRelative(0, st.offset.toInt()) }
            }
            .graphicsLayer { alpha = (1f + st.offset / st.max.coerceAtLeast(1f)).coerceIn(0f, 1f) }
            .clipToBounds(),
    ) { PageTitle(vm, tab) }
}

/** Slides its content up by the collapse offset (and fades it) while shrinking its own height by the same amount. */
fun Modifier.collapsing(st: CollapseState): Modifier = this
    .layout { m, c ->
        val p = m.measure(c.copy(minHeight = 0, maxHeight = androidx.compose.ui.unit.Constraints.Infinity))
        st.max = p.height.toFloat()
        if (st.pendingFold && p.height > 0) { st.pendingFold = false; st.offset = -st.max }
        val h = (p.height + st.offset).roundToInt().coerceAtLeast(0)
        layout(p.width, h) { p.placeRelative(0, st.offset.roundToInt()) }
    }
    .graphicsLayer { alpha = (1f + st.offset / (st.max.coerceAtLeast(1f) * 0.7f)).coerceIn(0f, 1f); clip = true }
