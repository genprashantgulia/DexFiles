package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState

/** Page title as in the mock: centred 34/600 inside the content card, 26 above and 14 below. Real folders show their own name. */
@Composable
fun PageTitle(vm: ExplorerViewModel, tab: TabState, bottom: androidx.compose.ui.unit.Dp = 14.dp) {
    val labels = vm.rootLabelMap()
    val title = if (tab.isVirtual) Loc.title(tab.path, labels) else (app.dexfiles.core.PathUtils.crumbs(tab.path, labels).lastOrNull()?.label ?: tab.path)
    Text(
        title,
        modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 26.dp, bottom = bottom),
        fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-0.34).sp, fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
    )
}

private val HomeChips = listOf("All", "Images", "Videos", "Audio", "Documents", "Other")

/** Segmented filter under the title (Recent only): #17171A track, 4 padding, amber selected chip, 14 text. */
@Composable
fun HomeChips(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val track = if (cs.background == androidx.compose.ui.graphics.Color.Black) androidx.compose.ui.graphics.Color(0xFF17171A) else cs.surfaceContainer
    Box(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 8.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier.clip(RoundedCornerShape(24.dp)).background(track).horizontalScroll(rememberScrollState()).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            HomeChips.forEachIndexed { i, label ->
                val on = vm.homeFilter == i
                Text(
                    label,
                    fontSize = 14.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (on) cs.onPrimary else cs.onSurface.copy(alpha = 0.72f),
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) cs.primary else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable { vm.setHomeFilter(i, tab) }.padding(horizontal = 18.dp, vertical = 8.dp),
                )
            }
        }
    }
}

/** Shrinks the big page title away while the list scrolls (Samsung collapsing header), and brings it back at the top. */
class CollapseState {
    var offset by androidx.compose.runtime.mutableFloatStateOf(0f)
    var max = 0f
}

@Composable
fun rememberCollapse(key: Any): CollapseState = androidx.compose.runtime.remember(key) { CollapseState() }

fun collapseConnection(st: CollapseState) = object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
    override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        val d = available.y
        if (d < 0f && st.offset > -st.max) {
            val n = (st.offset + d).coerceAtLeast(-st.max)
            val used = n - st.offset
            st.offset = n
            return androidx.compose.ui.geometry.Offset(0f, used)
        }
        return androidx.compose.ui.geometry.Offset.Zero
    }

    override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
        val d = available.y
        if (d > 0f && st.offset < 0f) {
            val n = (st.offset + d).coerceAtMost(0f)
            val used = n - st.offset
            st.offset = n
            return androidx.compose.ui.geometry.Offset(0f, used)
        }
        return androidx.compose.ui.geometry.Offset.Zero
    }
}

@Composable
fun CollapsingTitle(vm: ExplorerViewModel, tab: TabState, st: CollapseState) {
    Box(
        Modifier
            .layout { m, c ->
                val p = m.measure(c)
                st.max = p.height.toFloat()
                val h = (p.height + st.offset).toInt().coerceAtLeast(0)
                layout(p.width, h) { p.placeRelative(0, st.offset.toInt()) }
            }
            .graphicsLayer { alpha = (1f + st.offset / st.max.coerceAtLeast(1f)).coerceIn(0f, 1f) }
            .clipToBounds(),
    ) { PageTitle(vm, tab) }
}
