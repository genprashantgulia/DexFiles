package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Motion

/**
 * Settings as a floating card that grows out of whatever opened it: bottom-left from the sidebar gear,
 * top-right from the ⋮ menu. A soft scrim keeps the page visible behind it.
 */
@Composable
fun SettingsPanel(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val show = vm.settingsOpen
    val left = vm.settingsFromLeft
    val origin = if (left) TransformOrigin(0f, 1f) else TransformOrigin(1f, 0f)
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(show, enter = fadeIn(tween(180)), exit = fadeOut(tween(140))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.30f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.settingsOpen = false },
            )
        }
        AnimatedVisibility(
            visible = show,
            modifier = Modifier.align(if (left) Alignment.BottomStart else Alignment.TopEnd)
                .padding(start = 12.dp, end = 12.dp, top = if (left) 12.dp else 80.dp, bottom = 12.dp),
            enter = scaleIn(initialScale = 0.94f, transformOrigin = origin, animationSpec = dialogSpring()) + fadeIn(tween(160)),
            exit = scaleOut(targetScale = 0.94f, transformOrigin = origin, animationSpec = tween(150)) + fadeOut(tween(120)),
        ) {
            Surface(
                Modifier.width(440.dp).fillMaxHeight(if (left) 0.88f else 0.9f),
                shape = app.dexfiles.ui2.design.Radius.xl,
                color = dialogSurface(),
                shadowElevation = 24.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
            ) {
                SettingsCard(vm)
            }
        }
    }
}
