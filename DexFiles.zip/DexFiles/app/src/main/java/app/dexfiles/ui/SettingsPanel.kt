package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.ui2.design.Motion

/**
 * Settings: full-screen on a phone, otherwise a right-hand panel that mirrors the sidebar. A soft scrim keeps the page visible behind it.
 */
@Composable
fun SettingsPanel(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val show = vm.settingsOpen
    // Phone: Settings is a full page that slides in from the right, like Samsung's.
    if (LocalCompact.current) {
        AnimatedVisibility(
            visible = show,
            enter = androidx.compose.animation.slideInHorizontally(tween(260)) { it },
            exit = androidx.compose.animation.slideOutHorizontally(tween(200)) { it },
        ) {
            Surface(Modifier.fillMaxSize(), color = cs.background, shape = androidx.compose.ui.graphics.RectangleShape) { SettingsCard(vm) }
        }
        return
    }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(show, enter = fadeIn(tween(180)), exit = fadeOut(tween(140))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.30f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.settingsOpen = false },
            )
        }
        // A right-hand panel, the mirror of the sidebar: same inset, same corner radius, as tall as the page, sliding in from the edge.
        AnimatedVisibility(
            visible = show,
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 100.dp, end = 12.dp, bottom = 12.dp),
            enter = slideInHorizontally(tween(300, easing = Motion.Emphasized)) { it } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(220)) { it } + fadeOut(tween(160)),
        ) {
            Surface(
                Modifier.width(400.dp).fillMaxHeight(),
                shape = app.dexfiles.ui2.design.Radius.xl,
                color = dialogSurface(),
                shadowElevation = 24.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
            ) {
                SettingsCard(vm)
            }
        }
    }
}
