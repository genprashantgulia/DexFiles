@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.dexfiles.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.layout.onSizeChanged
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.launch
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.staggeredgrid.items
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.foundation.layout.RowScope
import androidx.compose.animation.animateContentSize
import app.dexfiles.core.PathUtils
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import app.dexfiles.ui2.design.Motion
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import app.dexfiles.ui2.design.Sel
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.Listing
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.Sorting
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.HitTracker
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import app.dexfiles.state.PaneState
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

private class ColW(val date: androidx.compose.ui.unit.Dp, val type: androidx.compose.ui.unit.Dp, val size: androidx.compose.ui.unit.Dp)

@Composable
fun PaneView(vm: ExplorerViewModel, pane: PaneState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val active = vm.activePane == pane.index
    val tab = pane.tab
    Column(
        modifier
            .fillMaxHeight()
            .pointerInput(pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press && vm.activePane != pane.index) vm.activePane = pane.index
                    }
                }
            },
    ) {
        if (vm.dual) Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) cs.primary else Color.Transparent))
        if (vm.dual && !LocalCompact.current) {
            TabStrip(vm, pane)
            // Each pane carries its own path bar, so the two folders are always readable side by side.
            if (!tab.isSearch) {
                var editing by remember(pane.index) { mutableStateOf(false) }
                Box(Modifier.fillMaxWidth().padding(horizontal = 0.dp, vertical = 8.dp)) {
                    if (tab.isVirtual) {
                        Row(Modifier.fillMaxWidth().barPill(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(virtualIcon(tab.path), null, Modifier.padding(start = 14.dp).size(20.dp), tint = cs.primary)
                            Text(Loc.title(tab.path, vm.rootLabelMap()), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1, modifier = Modifier.padding(horizontal = 10.dp))
                        }
                    } else if (editing) PathEditor(vm, tab, Modifier.fillMaxWidth()) { editing = false }
                    else PathPill(vm, tab, Modifier.fillMaxWidth()) { editing = true }
                }
            }
        }
        // The card from the mock: radius 28, title inside it, then (Recent only) the filter chips, the sort strip and the files.
        Box(Modifier.weight(1f).fillMaxWidth().clip(Radius.m).background(cs.surface)) {
            when (tab.path) {
                Loc.ANALYZE -> AnalyzeScreen(vm, tab)
                Loc.HISTORY -> HistoryScreen(vm)
                else -> {
                  // Samsung-style collapsing header: the big title (and the Recent chips) slide up and fade while the list scrolls
                  // up, and come back as soon as you scroll down. The count / sort strip stays put.
                  // Phone: the title starts folded away (more room for files) and a pull-down at the top brings it out; the chips always stay.
                  val phone = LocalCompact.current
                  val collapse = rememberCollapse(tab.path to tab.isSearch, startCollapsed = phone)
                  val collapseScope = androidx.compose.runtime.rememberCoroutineScope()
                  Column(Modifier.nestedScroll(remember(collapse) { collapseConnection(collapse, collapseScope) })) {
                    Column(Modifier.collapsing(collapse)) {
                        // Page headings are parked (Dimens.showHeadings); the code stays so they can come back.
                        if (Dimens.showHeadings && !tab.isSearch) PageTitle(vm, tab, bottom = if (tab.path == Loc.HOME) 14.dp else 6.dp)
                        else Spacer(Modifier.height(8.dp))
                    }
                    if (phone || (tab.path == Loc.HOME && !tab.isSearch)) SortStrip(vm, tab)
                    Box(Modifier.weight(1f).fillMaxWidth().navTransition(tab)) { ListingBody(vm, pane, tab) }
                    StatusLine(vm, tab)
                  }
                }
            }
            androidx.compose.animation.AnimatedVisibility(
                visible = active && tab.selection.isNotEmpty() && vm.renaming == null && dropRegistry(vm).session == null,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = if (vm.tray.isEmpty()) 40.dp else 104.dp),
                enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(220)) { it } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
                exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(160)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
            ) {
                SelectionPill(vm, tab)
            }
            // Nothing floats over the list at rest (calm by default); New folder and Paste live in the More menu and the right-click menu.
        }
    }
}

// ---------------------------------------------------------------------------------------------- tabs

internal fun virtualIcon(path: String): ImageVector = when (path) {
    Loc.HOME -> DexIcons.Home
    Loc.RECENT -> DexIcons.Recent
    Loc.IMAGES -> DexIcons.Images
    Loc.VIDEOS -> DexIcons.Videos
    Loc.AUDIO -> DexIcons.Audio
    Loc.DOCS -> DexIcons.Document
    Loc.APKS -> DexIcons.Apk
    Loc.DOWNLOADS -> DexIcons.Download
    Loc.TRASH -> DexIcons.Trash
    Loc.ANALYZE -> DexIcons.Analyze
    Loc.HISTORY -> DexIcons.Reset
    else -> DexIcons.Folder
}

@Composable
fun TabStrip(vm: ExplorerViewModel, pane: PaneState, search: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    val many = pane.tabs.size > 1
    Row(
        Modifier.fillMaxWidth().height(44.dp).padding(start = 12.dp, end = 12.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.weight(1f, fill = false).horizontalScroll(rememberScrollState()).animateContentSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            pane.tabs.forEachIndexed { i, t ->
              androidx.compose.runtime.key(t.id) {
                val selected = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                val title = if (t.isSearch) "Search" else Loc.title(t.path, labels)
                val vis = remember { androidx.compose.animation.core.MutableTransitionState(false).apply { targetState = true } }
                androidx.compose.animation.AnimatedVisibility(
                    visibleState = vis,
                    enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(240)),
                    exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) + androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)),
                ) {
                TabChip(
                    vm = vm,
                    icon = if (Loc.isVirtual(t.path)) virtualIcon(t.path) else DexIcons.Folder,
                    iconTint = if (Loc.isVirtual(t.path)) Color.Unspecified else kindColor(app.dexfiles.core.FileKind.FOLDER),
                    title = title,
                    selected = selected,
                    closable = many,
                    dropDest = if (t.isVirtual || t.isSearch) null else t.path,
                    onClose = { vm.closeTab(pane, i) },
                    onClick = { if (Mods.tertiaryDown) vm.closeTab(pane, i) else vm.selectTab(pane, i) },
                )
                }
              }
            }
        }
        // The single circled + : opens a new tab on Home.
        Box(
            Modifier.size(34.dp).clip(Radius.s)
                .clickable { vm.addTab(pane, Loc.HOME) },
            contentAlignment = Alignment.Center,
        ) { Icon(DexIcons.Plus, contentDescription = "New tab (Ctrl+T)", modifier = Modifier.size(16.dp), tint = cs.onSurface.copy(alpha = 0.9f)) }
        }
        if (search && !LocalCompact.current) {
            val cur = vm.current
            // One field that grows leftwards when search opens (the tabs make room) and settles back on close; the border warms to amber as it opens.
            val open = vm.searchUi
            val w by animateDpAsState(if (open) 420.dp else 240.dp, Motion.glide(340), label = "searchW")
            val edge by animateColorAsState(if (open) cs.primary.copy(alpha = 0.6f) else cs.outlineVariant, Motion.glide(260), label = "searchEdge")
            Box(
                Modifier.width(w).height(36.dp).clip(androidx.compose.foundation.shape.CircleShape).background(cs.surfaceContainer).border(if (open) 1.5.dp else 1.dp, edge, androidx.compose.foundation.shape.CircleShape)
                    .then(if (open) Modifier else Modifier.clickable { vm.openSearch() }),
                contentAlignment = Alignment.CenterStart,
            ) {
                androidx.compose.animation.Crossfade(open, animationSpec = Motion.glide(220), label = "searchSwap") { o ->
                    if (o) SearchPill(vm, cur, Modifier.requiredHeight(48.dp).fillMaxWidth(), 1) { vm.closeSearch() }
                    else Row(
                        Modifier.fillMaxSize().padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(DexIcons.Search, null, Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                        Text(
                            if (cur.path == Loc.HOME || cur.isSearch) "Search" else "Search ${Loc.title(cur.path, labels)}",
                            fontSize = 13.5.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/** Selection summary on the left, free space on the right; the item count already lives in the sort strip, so it is not said twice. */
@Composable
private fun StatusLine(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val n = tab.selection.size
    val free = remember(tab.path) {
        val f = java.io.File(if (tab.isVirtual || tab.isSearch) vm.primaryRoot.toString() else tab.path)
        app.dexfiles.core.Format.size(f.freeSpace)
    }
    val phone = LocalCompact.current
    Row(Modifier.fillMaxWidth().padding(top = 6.dp).height(32.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        val total = if (tab.path == Loc.HOME && !tab.isSearch) "${tab.entries.size} files \u00B7 last 30 days" else if (tab.entries.size == 1) "1 item" else "${tab.entries.size} items"
        val left = if (n == 0) total else "$total \u00B7 $n selected \u00B7 " + app.dexfiles.core.Format.size(vm.selectedEntries(tab).filter { !it.isDir }.sumOf { it.size })
        Text(left, fontSize = 11.5.sp, color = cs.onSurfaceVariant, maxLines = 1, modifier = Modifier.weight(1f))
        if (!phone) Text("$free free", fontSize = 11.5.sp, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun TabChip(
    vm: ExplorerViewModel,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    selected: Boolean,
    closable: Boolean,
    dropDest: String?,
    onClose: () -> Unit,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    LaunchedEffect(dropHover) { if (dropHover && !selected) { kotlinx.coroutines.delay(SPRING_MS); if (dropHover) onClick() } }
    val shape = Radius.s
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.25f)
        selected -> cs.surfaceContainerHighest
        hovered -> cs.onSurface.copy(alpha = 0.10f)
        else -> cs.surfaceContainer
    }
    Row(
        Modifier
            .height(34.dp)
            .widthIn(max = 180.dp)
            .clip(shape)
            .background(bg)
                        .hoverable(interaction)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = if (closable) 8.dp else 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) cs.onSurface else cs.onSurface.copy(alpha = 0.66f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (closable) {
            Box(
                Modifier.size(22.dp).clip(Radius.xs).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(DexIcons.Close, contentDescription = "Close tab (Ctrl+W)", modifier = Modifier.size(12.dp), tint = cs.onSurface.copy(alpha = if (selected) 0.66f else 0.45f)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- listing

@Composable
internal fun ListingBody(vm: ExplorerViewModel, pane: PaneState, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val hit = remember(tab.id) { HitTracker() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var paneDrop by remember { mutableStateOf(false) }
    val edgeDp = with(androidx.compose.ui.platform.LocalDensity.current) { 90.dp.toPx() }
    val dropDest = if (tab.isVirtual || tab.isSearch) null else tab.path
    val pinchHaptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    // The content follows the fingers at once (a little resisted) and springs home when a step commits or the fingers lift,
    // so a pinch never feels like it is waiting for a threshold.
    val live = remember { androidx.compose.animation.core.Animatable(1f) }
    val liveScope = androidx.compose.runtime.rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
            // Runs before any row sees the press, so a stale row can't leak into the next right-click.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = null
                    }
                }
            }
            // Runs after the rows: right-click opens the context menu for whichever row (or empty space) was hit.
            .pointerInput(tab.id, pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                            val p = ev.changes.first().position
                            vm.showContext(pane.index, origin + p, hit.entry)
                        }
                    }
                }
            }
            // Ctrl + mouse wheel zooms the icon size, like every desktop file manager.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Scroll && Mods.ctrl && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val dy = ev.changes.first().scrollDelta.y
                            if (dy != 0f) {
                                vm.zoomGrid(if (dy < 0f) 1 else -1)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    }
                }
            }
            // Two-finger pinch moves one thumbnail level at a time; the two layouts cross-fade (see GridZoom below).
            .pointerInput(tab.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var acc = 1f
                    var lastStep = 0L
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.size >= 2 && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val now = ev.changes[0].uptimeMillis
                            // One deliberate pinch moves one level: a bigger threshold, and a short pause before the next step can happen.
                            if (now - lastStep < 160L) acc = 1f else acc = (acc * ev.calculateZoom()).coerceIn(0.5f, 2f)
                            val dir = if (acc >= 1f) 1 else -1
                            val possible = vm.canZoomGrid(dir)
                            // Content follows the fingers; at the smallest / largest size it only gives a tiny resisted wobble (no flicker).
                            val shown = if (possible) 1f + (acc - 1f) * 0.5f else 1f + (acc - 1f) * 0.12f
                            if (now - lastStep >= 160L) liveScope.launch { live.snapTo(shown.coerceIn(0.9f, 1.12f)) }
                            if (possible && (acc > 1.2f || acc < 0.83f)) {
                                vm.zoomGrid(dir)
                                acc = 1f
                                lastStep = now
                                liveScope.launch { live.animateTo(1f, app.dexfiles.ui2.design.Motion.spatial()) }
                                pinchHaptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            }
                            ev.changes.forEach { it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                    liveScope.launch { live.animateTo(1f, app.dexfiles.ui2.design.Motion.spatial()) }
                }
            }
            // A tap on empty space lets go of everything: selection and the grey "you were here" marker.
            .pointerInput(tab.id) { detectTapGestures(onTap = { vm.clearSelection(tab); tab.focus = null }) }
            .onGloballyPositioned { vm.setPaneBounds(pane.index, it.boundsInWindow()) }
            .folderDrop(vm, dropDest, onMove = { y -> vm.dragMoved(pane.index, y, edgeDp) }) { paneDrop = it }
            .then(if (paneDrop) Modifier.border(1.dp, Sel.edge(), Radius.l) else Modifier),
    ) {
        var slow by remember(tab.id) { mutableStateOf(false) }
        LaunchedEffect(tab.loading, tab.path) {
            slow = false
            if (tab.loading) { kotlinx.coroutines.delay(700); slow = true }
        }
        if (tab.loading && slow) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
        else Spacer(Modifier.height(2.dp))

        if (tab.path == Loc.TRASH) TrashBanner(vm)
        // The scope and filter chips appear as soon as the search field opens, not only once results exist.
        if (tab.isSearch || (vm.searchUi && tab === vm.current)) SearchFilters(vm, tab)
        if (tab.isSearch) SearchStatus(tab)

        Box(Modifier.weight(1f).fillMaxWidth().graphicsLayer { scaleX = live.value; scaleY = live.value }) {
            val err = tab.error
            when {
                err != null -> ErrorState(vm, tab, err)
                tab.entries.isEmpty() && !tab.loading && !tab.searching -> EmptyState(vm, tab)
                tab.entries.isEmpty() -> LoadingRows()
                else -> androidx.compose.runtime.key(tab.path, tab.isSearch, if (tab.path == Loc.HOME) vm.homeFilter else 0) {
                val enter = remember { androidx.compose.animation.core.Animatable(0f) }
                LaunchedEffect(Unit) { enter.animateTo(1f, app.dexfiles.ui2.design.Motion.glide(480)) }
                // A new place settles in: it rises 24 dp and fades up on a soft spring (a slight overshoot gives it weight).
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = (enter.value * 1.6f).coerceIn(0f, 1f); translationY = (1f - enter.value) * 24.dp.toPx() }) {
                androidx.compose.animation.Crossfade(targetState = tab.viewMode, animationSpec = androidx.compose.animation.core.tween(200), label = "view") { mode ->
                    when (mode) {
                        // One list view: it grows Date / Size / Type columns when the window is wide.
                        ViewMode.DETAILS, ViewMode.LIST -> BoxWithConstraints(Modifier.fillMaxSize()) {
                            if (maxWidth >= 760.dp && vm.detailsColumns) DetailsView(vm, pane, tab, hit) else PlainList(vm, pane, tab, hit)
                        }
                        // Old and new thumbnail sizes are on screen together for a moment and blend, then settle.
                        // Zoom: tiles glide to their new places (no cross-fade of two layouts).
                        ViewMode.GRID -> GridView(vm, pane, tab, hit, vm.gridSize)
                        ViewMode.GALLERY -> GalleryView(vm, pane, tab, hit, vm.gridSize)
                        ViewMode.COLUMNS -> ColumnsView(vm, pane, tab, hit)
                    }
                } } }
            }
        }
    }
}

@Composable
private fun TrashBanner(vm: ExplorerViewModel) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Items you delete in DexFiles stay here for 30 days", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        DexButton("Empty Trash", DexBtn.Danger) { vm.dialog = DialogState.EmptyTrash }
    }
}

@Composable
private fun SearchStatus(tab: TabState) {
    val n = tab.entries.size
    // The item count already sits in the sort strip, so this line only appears when there is something extra to say.
    val text = when {
        tab.searching -> "Searching\u2026 $n found so far"
        n == 0 -> "No matches"
        n >= 10_000 -> "Showing the first 10,000 matches"
        else -> return
    }
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
}

/** Scrolls a list while a drag is held near the top or bottom edge of the pane. */
@Composable
private fun DragAutoScroll(vm: ExplorerViewModel, state: androidx.compose.foundation.gestures.ScrollableState) {
    val dir = vm.dragScrollDir
    LaunchedEffect(dir) {
        while (dir != 0f) {
            state.scrollBy(dir * 26f)
            kotlinx.coroutines.delay(16)
        }
    }
}

/** One shape for every "nothing to show" screen (mock): icon in a soft circle, 19/600 title, 14 dim body, optional pill button. */
@Composable
private fun StateCard(icon: ImageVector, title: String, body: String, action: String? = null, primary: Boolean = false, onAction: () -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, fontSize = 14.sp, lineHeight = 20.sp, color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max = 320.dp))
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.height(42.dp).clip(app.dexfiles.ui2.design.Radius.s).background(if (primary) cs.primary else cs.onSurface.copy(alpha = 0.10f)).clickable(onClick = onAction).padding(horizontal = 22.dp),
                contentAlignment = Alignment.Center,
            ) { Text(action, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (primary) cs.onPrimary else cs.onSurface) }
        }
    }
}

@Composable
private fun ErrorState(vm: ExplorerViewModel, tab: TabState, message: String) {
    StateCard(DexIcons.Info, "Can't open this folder", message, action = "Go back") { if (tab.back.isNotEmpty()) vm.goBack(tab) else vm.navigate(tab, Loc.HOME) }
}

@Composable
private fun EmptyState(vm: ExplorerViewModel, tab: TabState) {
    when {
        tab.isSearch -> StateCard(
            DexIcons.Search, "No results for \u201c${tab.query}\u201d", "Try fewer letters, or search everywhere instead of just this folder.",
            action = if (vm.searchCurrentOnly) "Search everywhere" else null,
        ) { vm.setSearchCurrentOnly(false) }
        tab.path == Loc.TRASH -> StateCard(DexIcons.Trash, "Trash is empty", "Deleted items appear here, and can be restored.")
        tab.isVirtual -> StateCard(DexIcons.Folder, "Nothing here yet", "Matching files will appear here as soon as there are some.")
        else -> StateCard(DexIcons.Folder, "This folder is empty", "Drop files here, or create a folder to start organizing.", action = "New folder", primary = true) { vm.requestNew(folder = true) }
    }
}

/** Placeholder rows while a place loads (only after a short wait, so quick loads never flash it). */
@Composable
private fun LoadingRows() {
    val cs = MaterialTheme.colorScheme
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(250); show = true }
    if (!show) return
    val pulse by androidx.compose.animation.core.rememberInfiniteTransition(label = "skeleton").animateFloat(
        0.45f, 1f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(900), androidx.compose.animation.core.RepeatMode.Reverse), label = "pulse",
    )
    val widths = listOf(0.62f, 0.48f, 0.7f, 0.55f, 0.66f, 0.44f, 0.6f)
    val bar = cs.onSurface.copy(alpha = 0.07f)
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).graphicsLayer { alpha = pulse }) {
        for (w in widths) Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(Radius.s).background(bar))
            Spacer(Modifier.width(14.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth(w).height(14.dp).clip(CircleShape).background(bar))
                Box(Modifier.fillMaxWidth(0.28f).height(10.dp).clip(CircleShape).background(bar))
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- one entry

@Composable
private fun EntryBox(
    vm: ExplorerViewModel,
    pane: PaneState,
    tab: TabState,
    e: FileEntry,
    hit: HitTracker,
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape = Radius.s,
    tileSelect: Boolean = true,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val selected = e.path in tab.selection
    val active = vm.activePane == pane.index
    val focused = tab.focus == e.path && active
    val bgTarget = when {
        dropHover -> cs.primary.copy(alpha = 0.18f)
        selected && tileSelect -> Sel.plate(active)
        focused && tileSelect -> Sel.plate(false)
        selected -> Color.Transparent
        hovered && !tileSelect -> Color.Transparent
        hovered -> Sel.hover()
        else -> Color.Transparent
    }
    val bg by androidx.compose.animation.animateColorAsState(bgTarget, androidx.compose.animation.core.tween(140), label = "row")
    val wobble = remember { androidx.compose.animation.core.Animatable(1f) }
    val wobbleScope = androidx.compose.runtime.rememberCoroutineScope()
    val edgePx = with(androidx.compose.ui.platform.LocalDensity.current) { 90.dp.toPx() }
    val dropMod = if (e.isDir && tab.path != Loc.TRASH) Modifier.folderDrop(
        vm, e.path,
        onMove = { y -> vm.dragMoved(pane.index, y, edgePx) },
        onDropped = { wobbleScope.launch { wobble.animateTo(1.07f, androidx.compose.animation.core.tween(90)); wobble.animateTo(1f, androidx.compose.animation.core.spring(0.35f, 500f)) } },
    ) { dropHover = it } else Modifier
    // Spring-loaded folders: holding a drag over a folder for a moment opens it, so you can keep going deeper.
    LaunchedEffect(dropHover) { if (dropHover && e.isDir) { kotlinx.coroutines.delay(SPRING_MS); if (dropHover) vm.navigate(tab, e.path) } }
    // While this tile is being renamed and the keyboard is up, scroll so the whole tile shows and stops just short of the next one.
    val reveal = remember { androidx.compose.foundation.relocation.BringIntoViewRequester() }
    var tileSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val imeUp = WindowInsets.isImeVisible
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val renamingHere = vm.renaming == e.path
    LaunchedEffect(renamingHere, imeUp) {
        if (renamingHere && imeUp) {
            kotlinx.coroutines.delay(350)
            reveal.bringIntoView(androidx.compose.ui.geometry.Rect(0f, 0f, tileSize.width.toFloat(), tileSize.height + with(dens) { 4.dp.toPx() }))
        }
    }

    Box(
        modifier
            .bringIntoViewRequester(reveal)
            .onSizeChanged { tileSize = it }
            .clip(shape)
            .background(bg)
            .then(if (selected && tileSelect) Modifier.border(1.dp, Sel.edge(active), shape) else Modifier)
            .then(if (focused && !selected && tileSelect) Modifier.border(1.dp, Sel.edge(false), shape) else Modifier)
            .alpha(if (vm.isCut(e.path)) 0.45f else 1f)
            .graphicsLayer { scaleX = wobble.value; scaleY = wobble.value }
            .hoverable(interaction)
            .pointerInput(e) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = e
                    }
                }
            }
            .pointerInput(e) {
                detectTapGestures(
                    onLongPress = { off ->
                        if (!Mods.mouse) { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); vm.longPressSelect(pane, tab, e) }
                    },
                    onTap = { vm.onEntryClick(pane, tab, e) },
                )
            }
            .entryDragSource(vm, tab, e)
            .then(dropMod),
    ) { androidx.compose.runtime.CompositionLocalProvider(LocalTileHover provides hovered) { content() } }
}

/** True while the pointer (mouse or S Pen) is over the tile being drawn; lets tiles reveal their circle or name. */
private val LocalTileHover = androidx.compose.runtime.compositionLocalOf { false }

private fun mutedAlpha() = 0.72f

// ---------------------------------------------------------------------------------------------- details view

@Composable
private fun DetailsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val measurer = androidx.compose.ui.text.rememberTextMeasurer()
        val style = MaterialTheme.typography.bodyMedium
        val density = androidx.compose.ui.platform.LocalDensity.current
        val loc = tab.isVirtual && !tab.isSearch
        // Each column is as wide as its widest value (plus a little air), never wider.
        val colW = remember(tab.entries, tab.path, tab.isSearch, density) {
            fun widest(texts: List<String>, min: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp {
                val px = texts.take(300).maxOfOrNull { measurer.measure(it, style, maxLines = 1).size.width } ?: 0
                return (with(density) { px.toDp() } + 28.dp).coerceAtLeast(min)
            }
            ColW(
                date = widest(tab.entries.map { Fmt.dateTime(it.modified) }, 140.dp),
                type = widest(tab.entries.map { if (loc) (if (tab.path == Loc.TRASH) "" else File(it.path).parentFile?.name.orEmpty()) else FileTypes.typeLabel(it.name, it.isDir) }, 96.dp),
                size = widest(tab.entries.filter { !it.isDir }.map { Format.size(it.size) }, 84.dp),
            )
        }
        val nameMin = 300.dp
        val showDate = maxWidth >= nameMin + colW.size + colW.date + 90.dp
        val showType = showDate && maxWidth >= nameMin + colW.size + colW.date + colW.type + 90.dp
        val state = rememberLazyListState()
        DragAutoScroll(vm, state)
        val gs = glideSpec(tab)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        Column(Modifier.fillMaxSize()) {
            DetailsHeader(vm, tab, showDate, showType, tab.selection.isNotEmpty(), colW)
            val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
            val heads = rememberHeads(tab)
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().scrollIndicator(state), flingBehavior = dexFling(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                itemsIndexed(tree.rows, key = { _, r -> r.e.path }, contentType = { _, r -> if (r.e.isDir) 0 else 1 }) { idx, row ->
                    val e = row.e
                    Column(Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null)) {
                    heads[e.path]?.let { DateHeader(it) }
                    EntryBox(vm, pane, tab, e, hit, Modifier.resultIn(tab.isSearch, e.path, idx).fillMaxWidth().height((if (tab.isSearch) app.dexfiles.ui2.design.LocalSpec.current.rowSearch else app.dexfiles.ui2.design.LocalSpec.current.rowDetails) * LocalRowScale.current)) {
                        Row(Modifier.fillMaxSize().rowDivider((if (tab.selection.isNotEmpty()) 120.dp else 88.dp) - (if (tree.enabled) 0.dp else 32.dp)).padding(start = 10.dp + 22.dp * row.depth, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
                            ExpandLead(vm, tree, e)
                            FileThumb(e, 36.dp, crop = false)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                EntryName(vm, tab, e, MaterialTheme.typography.bodyLarge, middle = true)
                                if (tab.isSearch) SearchPath(vm, tab, e)
                            }
                            if (showDate) Cell(Fmt.dateTime(e.modified), colW.date)
                            if (showType) Cell(if (tab.isVirtual && !tab.isSearch) (if (tab.path == Loc.TRASH) "" else File(e.path).parentFile?.name.orEmpty()) else FileTypes.typeLabel(e.name, e.isDir), colW.type)
                            Cell(if (e.isDir) "" else Format.size(e.size), colW.size, TextAlign.End)
                        }
                    }
                    }
                }
            }
        }
    }
}

@Composable
private fun Cell(text: String, width: androidx.compose.ui.unit.Dp, align: TextAlign = TextAlign.Start) {
    Text(
        text,
        modifier = Modifier.width(width).padding(start = 8.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = mutedAlpha()),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}

@Composable
private fun DetailsHeader(vm: ExplorerViewModel, tab: TabState, showDate: Boolean, showType: Boolean, selecting: Boolean, colW: ColW) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    val dateLabel = if (tab.path == Loc.TRASH) "Date deleted" else "Date modified"
    Column {
        Row(
            Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HeaderCell(vm, tab, "Name", SortKey.NAME, spec, Modifier.weight(1f).padding(start = if (selecting) 122.dp else 90.dp))
            if (showDate) HeaderCell(vm, tab, dateLabel, SortKey.MODIFIED, spec, Modifier.width(colW.date))
            if (showType) {
                if (tab.isVirtual && !tab.isSearch) HeaderCell(vm, tab, "Location", null, spec, Modifier.width(colW.type))
                else HeaderCell(vm, tab, "Type", SortKey.TYPE, spec, Modifier.width(colW.type))
            }
            HeaderCell(vm, tab, "Size", SortKey.SIZE, spec, Modifier.width(colW.size), end = true)
        }
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
    }
}

@Composable
private fun HeaderCell(vm: ExplorerViewModel, tab: TabState, label: String, key: SortKey?, spec: SortSpec, modifier: Modifier, end: Boolean = false) {
    Row(
        modifier.fillMaxHeight().clickable(enabled = key != null) { if (key != null) vm.setSort(tab, key) }.padding(start = if (end) 0.dp else 8.dp, end = if (end) 4.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (end) Arrangement.End else Arrangement.Start,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.primary, maxLines = 1)
        if (spec.key == key) {
            Icon(
                if (spec.ascending) DexIcons.ArrowUp else DexIcons.ArrowDown,
                contentDescription = null,
                modifier = Modifier.padding(start = 4.dp).size(14.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- compact list / columns

@Composable
private fun CompactList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, modifier: Modifier, items: List<FileEntry> = tab.entries) {
    val state = rememberLazyListState()
    DragAutoScroll(vm, state)
    val gs = glideSpec(tab)
    LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    LazyColumn(state = state, modifier = modifier.scrollIndicator(state), flingBehavior = dexFling(), contentPadding = PaddingValues(8.dp)) {
        itemsIndexed(items, key = { _, x -> x.path }, contentType = { _, x -> if (x.isDir) 0 else 1 }) { idx, e ->
            EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).resultIn(tab.isSearch, e.path, idx).fillMaxWidth().padding(vertical = 1.dp).height(rowHeight())) {
                ColumnRowContent(vm, tab, e)
            }
        }
    }
}

/** One anatomy for every column: lead, icon, name with date underneath, count or size at the right, hairline below. No arrows. */
@Composable
private fun ColumnRowContent(vm: ExplorerViewModel, tab: TabState, e: FileEntry) {
    Row(Modifier.fillMaxSize().rowDivider(if (tab.selection.isNotEmpty()) 84.dp else 56.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
        FileThumb(e, 38.dp, crop = true)
        Spacer(Modifier.width(12.dp))
        EntryLines(vm, tab, e, compact = true)
    }
}

/** Samsung / Finder columns: every ancestor gets its own column (as many as fit, scroll sideways for the rest); the last one is the open folder. */
@Composable
private fun ColumnsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        if (tab.isVirtual && !tab.isSearch && tab.path != Loc.TRASH) {
            // Categories have no folder tree, so the first column groups the items (by folder, or by day in Recent) and the second shows the chosen group.
            val groups = remember(tab.entries, tab.path) { buildGroups(tab.path, tab.entries) }
            var picked by remember(tab.id, tab.path) { mutableStateOf("") }
            val live = if (picked == "" || groups.any { it.key == picked }) picked else ""
            val shown = remember(tab.entries, live, tab.path) { if (live == "") tab.entries else tab.entries.filter { groupKey(tab.path, it) == live } }
            if (maxWidth >= GROUP_SIDE_MIN) {
                Row(Modifier.fillMaxSize()) {
                    GroupColumn(groups, tab.entries.size, live, { picked = it }, Modifier.width(196.dp).fillMaxHeight())
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                    CompactList(vm, pane, tab, hit, Modifier.weight(1f).fillMaxHeight(), items = shown)
                }
            } else {
                // Too narrow for two columns: the same groups become a chip bar above the one list.
                val chips = remember(groups, tab.entries.size) { listOf(ChipItem("All", tab.entries.size)) + groups.map { ChipItem(it.label, it.count) } }
                val at = if (live == "") 0 else 1 + groups.indexOfFirst { it.key == live }
                Column(Modifier.fillMaxSize()) {
                    ChipBar(chips, at) { picked = if (it == 0) "" else groups[it - 1].key }
                    CompactList(vm, pane, tab, hit, Modifier.weight(1f).fillMaxWidth(), items = shown)
                }
            }
            return@BoxWithConstraints
        }
        val total = maxWidth
        val colW = 320.dp
        // Ancestor columns only appear when at least two columns fit; on a narrow window the open folder takes the whole width
        // (the path bar already shows the way back).
        val chain = if (tab.isVirtual || tab.isSearch || total < colW * 2) emptyList()
        else PathUtils.crumbs(tab.path, vm.rootLabelMap()).dropLast(1).map { it.path }
        val scroll = rememberScrollState()
        Row(Modifier.fillMaxSize().horizontalScroll(scroll)) {
            chain.forEachIndexed { i, dir ->
                val child = if (i + 1 < chain.size) chain[i + 1] else tab.path
                AncestorColumn(vm, pane, tab, dir, child, Modifier.width(colW).fillMaxHeight())
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            }
            // Mock F4: the last column previews the highlighted file (a big tile, its size and kind), once there is room for it.
            val focusE = if (total >= 880.dp && !tab.isVirtual) tab.entries.firstOrNull { it.path == tab.focus && !it.isDir } else null
            val prevW = if (focusE != null) 240.dp else 0.dp
            CompactList(vm, pane, tab, hit, Modifier.width(maxOf(colW, total - colW * chain.size - prevW)).fillMaxHeight())
            if (focusE != null) {
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                androidx.compose.foundation.layout.Column(Modifier.width(prevW).fillMaxHeight().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    PreviewContent(focusE, big = false, modifier = Modifier.fillMaxWidth().height(180.dp))
                    Text(focusE.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 12.dp))
                    Text(Format.size(focusE.size) + " \u00b7 " + FileTypes.typeLabel(focusE.name, false), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    }
}

/** Columns view shows groups beside the list from this width up; below it they fold into a chip bar above it. */
private val GROUP_SIDE_MIN = 600.dp

private class Grp(val key: String, val label: String, val count: Int)

private fun groupKey(path: String, e: FileEntry): String {
    if (path == Loc.DOWNLOADS) return app.dexfiles.data.MediaQueries.sources[e.path] ?: "Unknown"
    if (path != Loc.RECENT && path != Loc.HOME) return File(e.path).parentFile?.name ?: "/"
    val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }
    val today = cal.timeInMillis
    val day = 86_400_000L
    return when {
        e.modified >= today -> "Today"
        e.modified >= today - day -> "Yesterday"
        e.modified >= today - 6 * day -> "Earlier this week"
        else -> "Older"
    }
}

private fun buildGroups(path: String, entries: List<FileEntry>): List<Grp> {
    val counts = LinkedHashMap<String, Int>()
    for (e in entries) counts.merge(groupKey(path, e), 1, Int::plus)
    val list = counts.map { Grp(it.key, it.key, it.value) }
    return if (path == Loc.RECENT || path == Loc.HOME) list else list.sortedByDescending { it.count }
}

/** First column of a category in Columns view: "All" plus one row per group; same row anatomy and selection recipe as everywhere. */
@Composable
private fun GroupColumn(groups: List<Grp>, total: Int, picked: String, onPick: (String) -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    LazyColumn(modifier, flingBehavior = dexFling(), contentPadding = PaddingValues(8.dp)) {
        item(key = "all") { GroupRow("All", total, picked == "", cs) { onPick("") } }
        items(groups, key = { it.key }) { g -> GroupRow(g.label, g.count, picked == g.key, cs) { onPick(g.key) } }
    }
}

@Composable
private fun GroupRow(label: String, count: Int, on: Boolean, cs: androidx.compose.material3.ColorScheme, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    Row(
        Modifier.fillMaxWidth().padding(vertical = 1.dp).height(40.dp * LocalRowScale.current).clip(Radius.m)
            .background(if (on) cs.surfaceContainerHighest else if (hovered) Sel.hover() else Color.Transparent)
            .hoverable(src).clickable(interactionSource = src, indication = null, onClick = onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Chosen = grey plate, the same as the sidebar (amber is kept for what you select); the rest recedes so the files stay the point.
        Text(label, fontSize = 13.5.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, color = if (on) cs.onSurface else cs.onSurface.copy(alpha = 0.78f), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(count.toString(), fontSize = 11.sp, color = cs.onSurface.copy(alpha = 0.40f))
    }
}

@Composable
private fun AncestorColumn(vm: ExplorerViewModel, pane: PaneState, tab: TabState, dir: String, child: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val items by produceState(initialValue = emptyList<FileEntry>(), dir, vm.showHidden, tab.effectiveSort) {
        value = withContext(Dispatchers.IO) {
            runCatching { Sorting.sort(Listing.list(File(dir), vm.showHidden), tab.effectiveSort) }.getOrDefault(emptyList())
        }
    }
    val state = rememberLazyListState()
    DragAutoScroll(vm, state)
    val gs = glideSpec(tab)
    LaunchedEffect(items, child) {
        val i = items.indexOfFirst { it.path == child }
        if (i > 2) state.scrollToItem(i - 2)
    }
    LazyColumn(modifier, state = state, flingBehavior = dexFling(), contentPadding = PaddingValues(8.dp)) {
        items(items, key = { it.path }) { d ->
            val on = d.path == child
            val picked = d.path in tab.selection
            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
            Row(
                Modifier.fillMaxWidth().padding(vertical = 1.dp).height(rowHeight()).clip(Radius.m)
                    .background(if (picked) Sel.plate() else if (on) cs.onSurface.copy(alpha = 0.08f) else Color.Transparent)
                    .then(if (picked) Modifier.border(1.dp, Sel.edge(), Radius.m) else Modifier)
                    .combinedClickable(
                        onClick = {
                            vm.treeEntries[d.path] = d
                            if (tab.selection.isNotEmpty()) vm.toggleSelect(tab, d)
                            else if (d.isDir) vm.navigate(tab, d.path) else vm.open(tab, d)
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            vm.treeEntries[d.path] = d
                            vm.longPressSelect(pane, tab, d)
                        },
                    )
            ) {
                ColumnRowContent(vm, tab, d)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- shared bits

/** "12 items" for folders (counted off the UI thread), size for files, with the date in front. */
@Composable
private fun rememberSubtitle(e: FileEntry, withDate: Boolean): String {
    val key = e.path + "|" + e.modified
    val count by produceState(initialValue = SubtitleCache.get(key) ?: "", key) {
        value = if (e.isDir) SubtitleCache.get(key) ?: withContext(Dispatchers.IO) {
            runCatching { Format.items(File(e.path).list()?.size ?: 0) }.getOrDefault("")
        }.also { SubtitleCache.put(key, it) } else Format.size(e.size)
    }
    val date = if (withDate) Fmt.date(e.modified) else ""
    return listOf(date, count).filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
}


/** The tick circle on a tile (Icons, Gallery): a 40 dp target that toggles this item, for touch, mouse and S Pen alike. */
@Composable
private fun TileCircle(vm: ExplorerViewModel, tab: TabState, e: FileEntry, selected: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(44.dp).clip(CircleShape).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.toggleSelect(tab, e) },
        contentAlignment = Alignment.Center,
    ) { SelectCircle(selected, scrim = true) }
}

@Composable
private fun SelectCircle(selected: Boolean, modifier: Modifier = Modifier, scrim: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    // The fill eases in and the tick pops with a little spring, so ticking a row feels physical instead of flipping.
    val fill by androidx.compose.animation.animateColorAsState(if (selected) cs.primary else if (scrim) Color.Black.copy(alpha = 0.22f) else Color.Transparent, androidx.compose.animation.core.tween(160), label = "selFill")
    val line by androidx.compose.animation.animateColorAsState(if (selected) cs.primary else cs.outline, androidx.compose.animation.core.tween(160), label = "selLine")
    val pop by androidx.compose.animation.core.animateFloatAsState(
        if (selected) 1f else 0f,
        androidx.compose.animation.core.spring(dampingRatio = 0.5f, stiffness = androidx.compose.animation.core.Spring.StiffnessMedium),
        label = "selPop",
    )
    Box(
        modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, line, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            DexIcons.Check, contentDescription = null, tint = cs.onPrimary,
            modifier = Modifier.size(14.dp).graphicsLayer { scaleX = pop; scaleY = pop; alpha = pop.coerceIn(0f, 1f) },
        )
    }
}

/** Picture or video at its own proportions inside a square slot: no grey card, the picture itself carries the rounded corners and a hairline. */
@Composable
private fun RealRatioThumb(e: FileEntry, box: androidx.compose.ui.unit.Dp, selected: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val media = e.kind == app.dexfiles.core.FileKind.IMAGE || e.kind == app.dexfiles.core.FileKind.VIDEO
    val ratio by produceState(ratioCache[e.path + "|" + e.modified] ?: 0f, e.path, e.modified) {
        if (media && value == 0f) value = withContext(Dispatchers.IO) { probeRatio(e) }
    }
    // Pictures sit on the bottom edge of the slot, so the name is always right under the picture whatever its shape.
    Box(Modifier.fillMaxWidth().height(box), contentAlignment = Alignment.BottomCenter) {
        if (!media) FileThumb(e, box * 0.84f, crop = false)
        else if (ratio > 0f) {
            // The picture is the largest rectangle of its own proportions that fits the slot (aspectRatio picks whichever side fits).
            val r = ratio.coerceIn(0.4f, 2.5f)
            Box(
                Modifier.aspectRatio(r).clip(Radius.m).border(1.dp, cs.onSurface.copy(alpha = 0.08f), Radius.m),
            ) { FileThumb(e, box, Modifier.fillMaxSize(), crop = true) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- icon grid (iPad style)

@Composable
private fun GridView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, level: Int) {
    val gallery = false
    val cs = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val phone = LocalCompact.current
        val gap = if (phone) 8.dp else 12.dp
        // Phones: the size steps still change the count, but the default is 3 to a row (like iPadOS), 4 at the smallest step, 2 at the largest.
        val cell = (level.dp + 32.dp).coerceAtLeast(104.dp)
        val settledW = settledWidth(maxWidth)
        val side = if (phone) 12.dp else 16.dp
        val ts = vm.textSize / 16f
        val cols = if (phone) {
            // One scale drives it: icon size picks 3 / 2 / 1 to a row (never more than 3), text size can only reduce the count if names would not fit.
            var c = when { level <= 148 -> 3; level <= 188 -> 2; else -> 1 }
            while (c > 1 && (settledW - side * 2 - gap * (c - 1)) / c < 92.dp * ts) c--
            c
        } else (((settledW - side * 2 + gap) / (cell + gap)).toInt()).coerceAtLeast(1)
        val colW = (settledW - side * 2 - gap * (cols - 1)) / cols
        val thumb = if (phone) minOf(maxOf(level, 148).dp, colW - 16.dp).coerceAtLeast(48.dp) else level.dp
        SideEffect { tab.columns = cols }
        // Tiles only glide to new spots for sort/delete/rename; when the column count changes they must not slide around.
        val gs = glideSpec(tab)
        val state = rememberLazyGridState(initialFirstVisibleItemIndex = tab.zoomAnchor)
        DragAutoScroll(vm, state)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { if (tab.zoomAnchor == 0) state.scrollToItem(0) }
        LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.collect { tab.zoomAnchor = it } }
        ScrollToFocus(tab, state)
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize().scrollIndicator(state),
            flingBehavior = dexFling(), contentPadding = PaddingValues(start = side, end = side, top = 8.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            val heads = if (tab.isSearch) emptyMap() else app.dexfiles.core.Grouping.heads(tab.entries, if (tab.path == Loc.HOME) app.dexfiles.core.GroupBy.DATE else tab.groupBy)
            tab.entries.forEachIndexed { idx, e ->
              heads[e.path]?.let { h -> item(key = "head:$h", span = { GridItemSpan(maxLineSpan) }, contentType = 2) { DateHeader(h) } }
              item(key = e.path, contentType = if (e.isDir) 0 else 1) {
                val selected = e.path in tab.selection
                val subtitle = rememberSubtitle(e, withDate = !e.isDir)
                // While something is selected the rest recede a little, so the chosen pictures read first without any loud colour.
                val dimA by androidx.compose.animation.core.animateFloatAsState(if (tab.selection.isNotEmpty() && !selected) 0.55f else 1f, androidx.compose.animation.core.tween(180), label = "dim")
                EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).resultIn(tab.isSearch, e.path, idx).graphicsLayer { alpha = dimA }.fillMaxWidth(), shape = Radius.l) {
                    // iPad-style tile, identical for every kind: 8 side padding, a square slot with the picture sitting on its bottom edge,
                    // a centred name on up to two lines (shortened in the middle, extension kept), a dim detail line. The tick is always
                    // 8 from the plate's top-left corner, so it is the same distance whatever the picture's shape.
                    Box(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 10.dp, bottom = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (e.isDir) Box(Modifier.fillMaxWidth().height(thumb), contentAlignment = Alignment.BottomCenter) { FolderCover(e, thumb * 0.84f) }
                            else RealRatioThumb(e, thumb)
                            EntryName(vm, tab, e, MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, fontWeight = if (e.isDir) FontWeight.SemiBold else FontWeight.Medium, lineHeight = 17.sp, fontFeatureSettings = null), maxLines = 2, textAlign = TextAlign.Center, color = cs.onSurface, modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp), middle = true)
                            if (subtitle.isNotEmpty()) Text(subtitle, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        }
                        if (selected || tab.selection.isNotEmpty() || LocalTileHover.current) TileCircle(vm, tab, e, selected, Modifier.align(Alignment.TopStart))
                    }
                }
              }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- list (Samsung / iPad style)

@Composable
private fun PlainList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    val cs = MaterialTheme.colorScheme
    val compact = LocalCompact.current
    val state = rememberLazyListState()
    DragAutoScroll(vm, state)
    val gs = glideSpec(tab)
    LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
    val heads = rememberHeads(tab)
    LazyColumn(state = state, modifier = Modifier.fillMaxSize().scrollIndicator(state), flingBehavior = dexFling(), contentPadding = PaddingValues(horizontal = if (compact) 4.dp else 12.dp, vertical = 2.dp)) {
        items(tree.rows, key = { it.e.path }, contentType = { if (it.e.isDir) 0 else 1 }) { row ->
            val e = row.e
            val selected = e.path in tab.selection
            Column(Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null)) {
                heads[e.path]?.let { DateHeader(it) }
                // Mock row: 68 high, 16 padding, tile 48, 16 gap, a 1 px rule under the text column only.
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth().padding(vertical = 1.dp).height(if (compact) 60.dp else 68.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxSize().padding(start = (if (compact) 12.dp else 16.dp) + (if (compact) 16.dp else 22.dp) * row.depth, end = if (compact) 12.dp else 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        SelectLead(tab.selection.isNotEmpty(), selected)
                        // Same leading slot as Details: the arrow lives where the indent grows, and only on folders that have something inside.
                        if (!compact) ExpandLead(vm, tree, e)
                        FileThumb(e, if (compact) 36.dp else 38.dp, crop = true)
                        Spacer(Modifier.width(if (compact) 12.dp else 16.dp))
                        EntryLines(vm, tab, e, compact = compact)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- keep keyboard focus on screen

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyListState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx <= first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyGridState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx < first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

/** Folder item counts survive scrolling, so rows never pop in a second time. */
private object SubtitleCache {
    private val map = object : java.util.LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 2000
    }
    @Synchronized fun get(k: String): String? = map[k]
    @Synchronized fun put(k: String, v: String) { map[k] = v }
}

/** Section titles for the listing: Recent files is always by date, other places follow the Group by choice. */
@Composable
private fun rememberHeads(tab: TabState): Map<String, String> {
    val g = if (tab.isSearch) app.dexfiles.core.GroupBy.NONE else if (tab.path == Loc.HOME) app.dexfiles.core.GroupBy.DATE else tab.groupBy
    return remember(tab.entries, g) { app.dexfiles.core.Grouping.heads(tab.entries, g) }
}

/** Section label ("Today", "Yesterday"): small, quiet, no rule, like the other section captions. */
@Composable
private fun DateHeader(text: String) {
    val cs = MaterialTheme.colorScheme
    val side = if (LocalCompact.current) 12.dp else 16.dp
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant, letterSpacing = 0.4.sp,
        modifier = Modifier.fillMaxWidth().padding(start = side, end = side, top = 14.dp, bottom = 4.dp),
    )
}

@Composable
private fun RowScope.SelectLead(visible: Boolean, selected: Boolean) {
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
        exit = androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SelectCircle(selected)
            Spacer(Modifier.width(14.dp))
        }
    }
}

/** Samsung-style "digital blink": chrome stays put, the content goes dark for a split second, then the new list appears. */
@Composable
private fun Modifier.navTransition(tab: TabState): Modifier {
    val p = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(tab.id, tab.path) {
        p.snapTo(0.35f)
        kotlinx.coroutines.withTimeoutOrNull(250) { androidx.compose.runtime.snapshotFlow { tab.loading }.first { !it } }
        p.animateTo(1f, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = p.value }
}

private val ratioCache = java.util.concurrent.ConcurrentHashMap<String, Float>()

private fun probeRatio(e: FileEntry): Float {
    val key = e.path + "|" + e.modified
    ratioCache[key]?.let { return it }
    val r = when (e.kind) {
        app.dexfiles.core.FileKind.IMAGE -> runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(e.path, o)
            var w = o.outWidth.toFloat(); var h = o.outHeight.toFloat()
            val rot = android.media.ExifInterface(e.path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)
            if (rot == 6 || rot == 8) { val t = w; w = h; h = t }
            if (w > 0 && h > 0) (w / h).coerceIn(0.4f, 2.5f) else 1f
        }.getOrDefault(1f)
        app.dexfiles.core.FileKind.VIDEO -> 16f / 9f
        else -> 1.25f
    }
    ratioCache[key] = r
    return r
}

/** Photo-wall: images keep their real shape in a masonry layout, folders sit in a strip on top, names on each tile. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun GalleryView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, level: Int) {
    val cs = MaterialTheme.colorScheme
    val folders = tab.entries.filter { it.isDir }
    val files = tab.entries.filter { !it.isDir }
    val ready by produceState(files.all { ratioCache.containsKey(it.path + "|" + it.modified) }, files) {
        value = files.all { ratioCache.containsKey(it.path + "|" + it.modified) }
        if (!value) {
            withContext(Dispatchers.IO) {
                kotlinx.coroutines.coroutineScope {
                    files.chunked(48).map { part -> async { part.forEach { probeRatio(it) } } }.forEach { it.await() }
                }
            }
            value = true
        }
    }
    if (!ready) return
    val r = files.associate { it.path to probeRatio(it) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cell = (level * 1.7f).dp
        val cols = ((settledWidth(maxWidth) / cell).toInt()).coerceAtLeast(2)
        val gs = glideSpec(tab)
        val state = androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState(initialFirstVisibleItemIndex = tab.zoomAnchor)
        DragAutoScroll(vm, state)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { if (tab.zoomAnchor == 0) state.scrollToItem(0) }
        LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.collect { tab.zoomAnchor = it } }
        androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid(
            columns = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize().scrollIndicator(state),
            flingBehavior = dexFling(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalItemSpacing = 14.dp,
        ) {
            if (folders.isNotEmpty()) item(span = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan.FullLine) {
                // Equal-width folder cards on the same column grid as the photos below, so everything lines up.
                val perRow = (cols + 1).coerceAtMost(6)
                Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (row in folders.chunked(perRow)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (f in row) EntryBox(vm, pane, tab, f, hit, Modifier.weight(1f).background(cs.surfaceContainerHigh, Radius.m), Radius.m) {
                                Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { FileThumb(f, 34.dp) }
                                    Spacer(Modifier.width(10.dp))
                                    Text(f.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            items(files, key = { it.path }) { e ->
                val selected = e.path in tab.selection
                val dimA by androidx.compose.animation.core.animateFloatAsState(if (tab.selection.isNotEmpty() && !selected) 0.55f else 1f, androidx.compose.animation.core.tween(180), label = "dimG")
                EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).graphicsLayer { alpha = dimA }.fillMaxWidth(), Radius.l) {
                    // Selected pictures shrink a little on a spring inside their plate: unmistakable, yet quiet (no thick border, no tint).
                    val shrink by androidx.compose.animation.core.animateFloatAsState(if (selected) 0.88f else 1f, androidx.compose.animation.core.spring(dampingRatio = 0.72f, stiffness = 380f), label = "gallerySelect")
                    val media = e.kind == app.dexfiles.core.FileKind.IMAGE || e.kind == app.dexfiles.core.FileKind.VIDEO
                    if (!media) Box(Modifier.fillMaxWidth().graphicsLayer { scaleX = shrink; scaleY = shrink }.aspectRatio(1.25f).clip(Radius.m).background(kindColor(e.kind).copy(alpha = 0.13f))) {
                        Column(Modifier.align(Alignment.Center).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(56.dp).clip(Radius.m).background(kindColor(e.kind).copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                                Icon(kindIcon(e.kind), null, Modifier.size(30.dp), tint = kindColor(e.kind))
                            }
                            Spacer(Modifier.height(8.dp))
                            EntryName(vm, tab, e, MaterialTheme.typography.bodySmall, maxLines = 2, textAlign = TextAlign.Center, middle = true)
                        }
                        if (selected || tab.selection.isNotEmpty() || LocalTileHover.current) TileCircle(vm, tab, e, selected, Modifier.align(Alignment.TopStart))
                    } else Box(
                        Modifier.fillMaxWidth().graphicsLayer { scaleX = shrink; scaleY = shrink }.aspectRatio(r[e.path] ?: 1f).clip(Radius.l).background(cs.surfaceContainerHigh)
                            .border(1.dp, cs.onSurface.copy(alpha = 0.08f), Radius.l),
                    ) {
                        // Clean at rest. While the pointer is over a picture, a soft scrim and its name fade in at the bottom, and fade out a moment after it leaves.
                        FileThumb(e, cell, Modifier.fillMaxSize(), crop = true)
                        val hov = LocalTileHover.current
                        val nameA by androidx.compose.animation.core.animateFloatAsState(
                            if (hov) 1f else 0f,
                            androidx.compose.animation.core.tween(if (hov) 120 else 180, delayMillis = if (hov) 0 else 150),
                            label = "galleryName",
                        )
                        if (nameA > 0.01f) Box(
                            Modifier.align(Alignment.BottomStart).fillMaxWidth().graphicsLayer { alpha = nameA }
                                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f))))
                                .padding(start = 12.dp, end = 12.dp, top = 28.dp, bottom = 10.dp),
                        ) { Text(e.name, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        if (selected || tab.selection.isNotEmpty() || hov) {
                            TileCircle(vm, tab, e, selected, Modifier.align(Alignment.TopStart))
                        }
                    }
                }
            }
        }
    }
}

/** Spring for tiles/rows moving to new spots. Off for the first moments in a new place so the cached-then-fresh listing swap never shuffles in front of the eye. */
@Composable
private fun glideSpec(tab: TabState): androidx.compose.animation.core.FiniteAnimationSpec<androidx.compose.ui.unit.IntOffset>? {
    var on by remember(tab.path) { mutableStateOf(false) }
    LaunchedEffect(tab.path) { kotlinx.coroutines.delay(700); on = true }
    return if (on) app.dexfiles.ui2.design.Motion.glide<androidx.compose.ui.unit.IntOffset>(440) else null
}

/** Width that only updates after the layout has stopped changing, so tiles stretch smoothly during sidebar animations and re-flow once. */
@Composable
private fun settledWidth(w: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp {
    var s by remember { mutableStateOf(w) }
    // A big jump is the sidebar/preview opening or closing: the pane already dims for that, so re-flow at once (one shift, hidden by the dim).
    // Small steady changes are a window being dragged: wait until it stops so tiles don't dance.
    LaunchedEffect(w) {
        if (kotlin.math.abs((w - s).value) >= 150f) s = w else { kotlinx.coroutines.delay(180); s = w }
    }
    return s
}

/** Two quiet lines like One UI: the name, then the date in a dim tone on the left and the size in a bolder one on the right. */
@Composable
private fun RowScope.EntryLines(vm: ExplorerViewModel, tab: TabState, e: FileEntry, compact: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val right = rememberSubtitle(e, withDate = false)
    val rule = cs.outlineVariant
    Column(
        Modifier.weight(1f).fillMaxHeight().drawBehind { drawLine(rule, Offset(0f, size.height - 0.5f), Offset(size.width, size.height - 0.5f), 1.dp.toPx()) },
        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
    ) {
        EntryName(vm, tab, e, MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Normal, fontSize = if (compact) 15.sp else MaterialTheme.typography.bodyLarge.fontSize), middle = true)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (tab.isSearch) Box(Modifier.weight(1f)) { SearchPath(vm, tab, e) }
            else Text(Fmt.stamp(e.modified), style = MaterialTheme.typography.bodySmall.copy(fontSize = if (compact) 12.sp else MaterialTheme.typography.bodySmall.fontSize), color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (tab.isSearch) Text((if (right.isNotEmpty()) "$right \u00b7 " else "") + Fmt.date(e.modified), style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.82f), maxLines = 1, modifier = Modifier.padding(start = 8.dp))
            else if (right.isNotEmpty()) Text(right, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = cs.onSurface.copy(alpha = 0.82f), maxLines = 1, modifier = Modifier.padding(start = 8.dp))
        }
    }
}


/** Where a search result lives, as small tappable path chips (each one jumps to that folder). The same in every view. */
@Composable
fun SearchPath(vm: ExplorerViewModel, tab: TabState, e: FileEntry) {
    val cs = MaterialTheme.colorScheme
    val parent = java.io.File(e.path).parent ?: return
    val all = PathUtils.crumbs(parent, vm.rootLabelMap())
    val shown = all.takeLast(3)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        if (all.size > shown.size) Text("\u2026", style = MaterialTheme.typography.labelSmall, color = cs.onSurface.copy(alpha = 0.5f))
        shown.forEachIndexed { i, c ->
            if (i > 0) Text("\u203a", style = MaterialTheme.typography.labelSmall, color = cs.onSurface.copy(alpha = 0.4f))
            Text(
                c.label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.clip(Radius.xs).clickable { vm.navigate(tab, c.path) }.padding(horizontal = 2.dp, vertical = 1.dp),
            )
        }
    }
}
