package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.Listing
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.Sorting
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.HitTracker
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import app.dexfiles.state.PaneState
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val DATE_W = 150.dp
private val TYPE_W = 130.dp
private val SIZE_W = 84.dp

@Composable
fun PaneView(vm: ExplorerViewModel, pane: PaneState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val active = vm.activePane == pane.index
    val tab = pane.tab
    Column(
        modifier
            .fillMaxHeight()
            .background(cs.surface)
            .pointerInput(pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press && vm.activePane != pane.index) vm.activePane = pane.index
                    }
                }
            },
    ) {
        if (vm.dual) Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) cs.primary else Color.Transparent))
        if (pane.tabs.size > 1) {
            TabStrip(vm, pane)
            HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab.path) {
                Loc.HOME -> HomeScreen(vm, tab)
                Loc.ANALYZE -> AnalyzeScreen(vm, tab)
                else -> ListingBody(vm, pane, tab)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- tabs

private fun virtualIcon(path: String): ImageVector = when (path) {
    Loc.HOME -> Icons.Filled.Home
    Loc.RECENT -> Icons.Filled.History
    Loc.IMAGES -> Icons.Filled.Image
    Loc.VIDEOS -> Icons.Filled.Movie
    Loc.AUDIO -> Icons.Filled.MusicNote
    Loc.DOCS -> Icons.Filled.Description
    Loc.APKS -> Icons.Filled.Download
    Loc.TRASH -> Icons.Filled.Delete
    Loc.ANALYZE -> Icons.Filled.PieChart
    else -> Icons.Filled.Folder
}

@Composable
private fun TabStrip(vm: ExplorerViewModel, pane: PaneState) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    Row(
        Modifier.fillMaxWidth().height(36.dp).background(cs.surfaceContainer).padding(start = 6.dp, top = 4.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Row(Modifier.weight(1f, fill = false).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.Bottom) {
            pane.tabs.forEachIndexed { i, t ->
                val selected = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                val title = if (t.isSearch) "Search" else Loc.title(t.path, labels)
                TabChip(
                    vm = vm,
                    icon = if (Loc.isVirtual(t.path)) virtualIcon(t.path) else Icons.Filled.Folder,
                    iconTint = if (Loc.isVirtual(t.path)) Color.Unspecified else kindColor(app.dexfiles.core.FileKind.FOLDER),
                    title = title,
                    selected = selected,
                    closable = pane.tabs.size > 1 || pane.index == 1,
                    dropDest = if (t.isVirtual || t.isSearch) null else t.path,
                    onClose = { vm.closeTab(pane, i) },
                    onClick = { if (Mods.tertiaryDown && pane.tabs.size > 1) vm.closeTab(pane, i) else vm.selectTab(pane, i) },
                )
            }
        }
        Box(Modifier.padding(start = 2.dp, bottom = 2.dp)) {
            IconBtn(Icons.Filled.Add, "New tab (Ctrl+T)") {
                val cur = pane.tab
                vm.addTab(pane, if (cur.isVirtual) Loc.HOME else cur.path)
            }
        }
    }
}

@Composable
private fun TabChip(
    vm: ExplorerViewModel,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    selected: Boolean,
    closable: Boolean,
    dropDest: String?,
    onClose: () -> Unit,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.25f)
        selected -> cs.surface
        hovered -> cs.onSurface.copy(alpha = 0.07f)
        else -> Color.Transparent
    }
    Row(
        Modifier
            .padding(end = 2.dp)
            .height(32.dp)
            .width(176.dp)
            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
            .background(bg)
            .hoverable(interaction)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(start = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (iconTint == Color.Unspecified) cs.onSurface.copy(alpha = 0.8f) else iconTint)
        Text(
            title,
            style = MaterialTheme.typography.bodyMedium,
            color = if (selected) cs.onSurface else cs.onSurface.copy(alpha = 0.7f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (closable && (selected || hovered)) {
            Box(
                Modifier.size(22.dp).clip(RoundedCornerShape(11.dp)).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Close, contentDescription = "Close tab (Ctrl+W)", modifier = Modifier.size(13.dp)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- listing

@Composable
private fun ListingBody(vm: ExplorerViewModel, pane: PaneState, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val hit = remember(tab.id) { HitTracker() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var paneDrop by remember { mutableStateOf(false) }
    val dropDest = if (tab.isVirtual || tab.isSearch) null else tab.path

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
            // Runs before any row sees the press, so a stale row can't leak into the next right-click.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = null
                    }
                }
            }
            // Runs after the rows: right-click opens the context menu for whichever row (or empty space) was hit.
            .pointerInput(tab.id, pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                            val p = ev.changes.first().position
                            vm.showContext(pane.index, origin + p, hit.entry)
                        }
                    }
                }
            }
            // Ctrl + mouse wheel zooms the icon size, like every desktop file manager.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Scroll && Mods.ctrl && tab.viewMode == ViewMode.GRID) {
                            val dy = ev.changes.first().scrollDelta.y
                            if (dy != 0f) {
                                vm.zoomGrid(if (dy < 0f) 1 else -1)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    }
                }
            }
            .folderDrop(vm, dropDest) { paneDrop = it }
            .then(if (paneDrop) Modifier.border(2.dp, cs.primary) else Modifier),
    ) {
        if (tab.loading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
        else Spacer(Modifier.height(2.dp))

        if (tab.path == Loc.TRASH) TrashBanner(vm)
        if (tab.isSearch) SearchStatus(tab)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val err = tab.error
            when {
                err != null -> ErrorState(vm, tab, err)
                tab.entries.isEmpty() && !tab.loading && !tab.searching -> EmptyState(tab)
                tab.entries.isEmpty() -> Unit
                else -> when (tab.viewMode) {
                    ViewMode.DETAILS -> DetailsView(vm, pane, tab, hit)
                    ViewMode.LIST -> CompactList(vm, pane, tab, hit, Modifier.fillMaxSize())
                    ViewMode.GRID -> GridView(vm, pane, tab, hit)
                    ViewMode.COLUMNS -> ColumnsView(vm, pane, tab, hit)
                }
            }
        }
    }
}

@Composable
private fun TrashBanner(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.secondaryContainer.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(16.dp))
        Text("  Items in Trash are deleted automatically after 30 days.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        TextButton(onClick = { vm.dialog = DialogState.EmptyTrash }) { Text("Empty Trash") }
    }
}

@Composable
private fun SearchStatus(tab: TabState) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val n = tab.entries.size
        val text = when {
            tab.searching -> "Searching... $n found so far"
            n == 0 -> "No matches"
            n >= 10_000 -> "10,000+ matches (showing the first 10,000)"
            else -> "$n match" + (if (n == 1) "" else "es")
        }
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ErrorState(vm: ExplorerViewModel, tab: TabState, message: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(10.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.refresh(tab) }) { Text("Try again") }
            Button(onClick = { vm.navigate(tab, Loc.HOME) }) { Text("Go to Home") }
        }
    }
}

@Composable
private fun EmptyState(tab: TabState) {
    val text = when {
        tab.isSearch -> "No files match your search"
        tab.path == Loc.TRASH -> "Trash is empty"
        tab.isVirtual -> "Nothing here yet"
        else -> "This folder is empty"
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

// ---------------------------------------------------------------------------------------------- one entry

@Composable
private fun EntryBox(
    vm: ExplorerViewModel,
    pane: PaneState,
    tab: TabState,
    e: FileEntry,
    hit: HitTracker,
    modifier: Modifier,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val selected = e.path in tab.selection
    val active = vm.activePane == pane.index
    val focused = tab.focus == e.path && active
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.30f)
        selected -> if (active) cs.primary.copy(alpha = 0.20f) else cs.onSurface.copy(alpha = 0.10f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val shape = RoundedCornerShape(6.dp)
    val dropMod = if (e.isDir && tab.path != Loc.TRASH) Modifier.folderDrop(vm, e.path) { dropHover = it } else Modifier

    Box(
        modifier
            .clip(shape)
            .background(bg)
            .then(if (focused && !selected) Modifier.border(1.dp, cs.primary.copy(alpha = 0.6f), shape) else Modifier)
            .alpha(if (vm.isCut(e.path)) 0.45f else 1f)
            .hoverable(interaction)
            .onGloballyPositioned { coords = it }
            .pointerInput(e) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = e
                    }
                }
            }
            .pointerInput(e) {
                detectTapGestures(
                    onLongPress = { off ->
                        if (!Mods.mouse) coords?.let { vm.showContext(pane.index, it.localToRoot(off), e) }
                    },
                    onTap = { vm.onEntryClick(pane, tab, e) },
                )
            }
            .entryDragSource(vm, tab, e)
            .then(dropMod),
    ) { content() }
}

private fun mutedAlpha() = 0.72f

// ---------------------------------------------------------------------------------------------- details view

@Composable
private fun DetailsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val showDate = maxWidth >= 430.dp
        val showType = maxWidth >= 660.dp
        val state = rememberLazyListState()
        LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        Column(Modifier.fillMaxSize()) {
            DetailsHeader(vm, tab, showDate, showType)
            LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) {
                items(tab.entries, key = { it.path }) { e ->
                    EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth().height(if (tab.isSearch) 40.dp else 30.dp)) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            FileThumb(e, 20.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (tab.isSearch) {
                                    Text(
                                        vm.relativeParent(e, tab.searchRoot),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            if (showDate) Cell(Fmt.dateTime(e.modified), DATE_W)
                            if (showType) Cell(FileTypes.typeLabel(e.name, e.isDir), TYPE_W)
                            Cell(if (e.isDir) "" else Format.size(e.size), SIZE_W, TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Cell(text: String, width: androidx.compose.ui.unit.Dp, align: TextAlign = TextAlign.Start) {
    Text(
        text,
        modifier = Modifier.width(width).padding(start = 8.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = mutedAlpha()),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}

@Composable
private fun DetailsHeader(vm: ExplorerViewModel, tab: TabState, showDate: Boolean, showType: Boolean) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    val dateLabel = if (tab.path == Loc.TRASH) "Date deleted" else "Date modified"
    Column {
        Row(
            Modifier.fillMaxWidth().height(28.dp).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HeaderCell(vm, tab, "Name", SortKey.NAME, spec, Modifier.weight(1f).padding(start = 38.dp))
            if (showDate) HeaderCell(vm, tab, dateLabel, SortKey.MODIFIED, spec, Modifier.width(DATE_W))
            if (showType) HeaderCell(vm, tab, "Type", SortKey.TYPE, spec, Modifier.width(TYPE_W))
            HeaderCell(vm, tab, "Size", SortKey.SIZE, spec, Modifier.width(SIZE_W), end = true)
        }
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
    }
}

@Composable
private fun HeaderCell(vm: ExplorerViewModel, tab: TabState, label: String, key: SortKey, spec: SortSpec, modifier: Modifier, end: Boolean = false) {
    Row(
        modifier.fillMaxHeight().clickable { vm.setSort(tab, key) }.padding(start = if (end) 0.dp else 8.dp, end = if (end) 4.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (end) Arrangement.End else Arrangement.Start,
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), maxLines = 1)
        if (spec.key == key) {
            Icon(
                if (spec.ascending) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- compact list / columns

@Composable
private fun CompactList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, modifier: Modifier) {
    val state = rememberLazyListState()
    LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    LazyColumn(state = state, modifier = modifier, contentPadding = PaddingValues(6.dp)) {
        items(tab.entries, key = { it.path }) { e ->
            EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth().height(28.dp)) {
                Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FileThumb(e, 18.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(e.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (!e.isDir) Text(Format.size(e.size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                }
            }
        }
    }
}

/** Finder-style: the parent folder's folders on the left, this folder in the middle, preview on the right. */
@Composable
private fun ColumnsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    Row(Modifier.fillMaxSize()) {
        ParentColumn(vm, tab, Modifier.width(210.dp).fillMaxHeight())
        VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        CompactList(vm, pane, tab, hit, Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun ParentColumn(vm: ExplorerViewModel, tab: TabState, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val parent = if (tab.isVirtual || tab.isSearch) null else File(tab.path).parent
    if (parent == null) {
        Box(modifier)
        return
    }
    val siblings by produceState(initialValue = emptyList<FileEntry>(), parent, vm.showHidden, tab.entries.size) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                Sorting.sort(Listing.list(File(parent), vm.showHidden).filter { it.isDir }, tab.sort)
            }.getOrDefault(emptyList())
        }
    }
    LazyColumn(modifier.background(cs.surfaceContainerLow), contentPadding = PaddingValues(6.dp)) {
        items(siblings, key = { it.path }) { d ->
            val isCurrent = d.path == tab.path
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isCurrent) cs.primary.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable { vm.navigate(tab, d.path) }
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FileThumb(d, 18.dp)
                Spacer(Modifier.width(8.dp))
                Text(d.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- icon grid

@Composable
private fun GridView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val thumb = vm.gridSize.dp
        val cell = thumb + 20.dp
        val cols = (((maxWidth - 16.dp + 4.dp) / (cell + 4.dp)).toInt()).coerceAtLeast(1)
        SideEffect { tab.columns = cols }
        val state = rememberLazyGridState()
        LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(cell),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(tab.entries, key = { it.path }) { e ->
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        FileThumb(e, thumb)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            e.name,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- keep keyboard focus on screen

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyListState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx <= first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyGridState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx < first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}
