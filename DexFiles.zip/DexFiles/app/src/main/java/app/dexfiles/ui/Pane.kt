@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.staggeredgrid.items
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.RowScope
import androidx.compose.animation.animateContentSize
import app.dexfiles.core.PathUtils
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.Listing
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.Sorting
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.HitTracker
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import app.dexfiles.state.PaneState
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val DATE_W = 190.dp
private val TYPE_W = 150.dp
private val SIZE_W = 104.dp

@Composable
fun PaneView(vm: ExplorerViewModel, pane: PaneState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val active = vm.activePane == pane.index
    val tab = pane.tab
    val collapse = rememberCollapse(tab.path)
    Column(
        modifier
            .fillMaxHeight()
            .pointerInput(pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press && vm.activePane != pane.index) vm.activePane = pane.index
                    }
                }
            },
    ) {
        if (vm.dual) Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) cs.primary else Color.Transparent))
        TabStrip(vm, pane)
        val virtualPage = tab.isVirtual && !tab.isSearch && tab.path != Loc.ANALYZE
        Column(Modifier.weight(1f).fillMaxWidth().nestedScroll(remember(collapse) { collapseConnection(collapse) })) {
            if (virtualPage) {
                // Samsung: the big title floats on the page background, not inside a panel.
                CollapsingTitle(vm, tab, collapse)
                if (tab.path == Loc.HOME) { HomeChips(vm, tab); Spacer(Modifier.height(10.dp)) }
            }
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(Dimens.radiusSheet)).background(cs.surface)) {
                when (tab.path) {
                    Loc.ANALYZE -> AnalyzeScreen(vm, tab)
                    else -> Column {
                        if (!virtualPage) SortStrip(vm, tab)
                        Box(Modifier.weight(1f).fillMaxWidth().navTransition(tab)) { ListingBody(vm, pane, tab) }
                    }
                }
                androidx.compose.animation.AnimatedVisibility(
                    visible = active && tab.selection.isNotEmpty(),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp),
                    enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(220)) { it } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
                    exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(160)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
                ) {
                    SelectionPill(vm, tab)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- tabs

private fun virtualIcon(path: String): ImageVector = when (path) {
    Loc.HOME -> Icons.Filled.Home
    Loc.RECENT -> Icons.Filled.History
    Loc.IMAGES -> Icons.Filled.Image
    Loc.VIDEOS -> Icons.Filled.Movie
    Loc.AUDIO -> Icons.Filled.MusicNote
    Loc.DOCS -> Icons.Filled.Description
    Loc.APKS -> Icons.Filled.Download
    Loc.TRASH -> Icons.Filled.Delete
    Loc.ANALYZE -> Icons.Filled.PieChart
    else -> Icons.Filled.Folder
}

@Composable
private fun TabStrip(vm: ExplorerViewModel, pane: PaneState) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    val many = pane.tabs.size > 1
    Row(
        Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            Modifier.weight(1f, fill = false).horizontalScroll(rememberScrollState()).animateContentSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            pane.tabs.forEachIndexed { i, t ->
              androidx.compose.runtime.key(t.id) {
                val selected = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                val title = if (t.isSearch) "Search" else Loc.title(t.path, labels)
                val vis = remember { androidx.compose.animation.core.MutableTransitionState(false).apply { targetState = true } }
                androidx.compose.animation.AnimatedVisibility(
                    visibleState = vis,
                    enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(240)),
                    exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) + androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)),
                ) {
                TabChip(
                    vm = vm,
                    icon = if (Loc.isVirtual(t.path)) virtualIcon(t.path) else Icons.Filled.Folder,
                    iconTint = if (Loc.isVirtual(t.path)) Color.Unspecified else kindColor(app.dexfiles.core.FileKind.FOLDER),
                    title = title,
                    selected = selected,
                    closable = many,
                    dropDest = if (t.isVirtual || t.isSearch) null else t.path,
                    onClose = { vm.closeTab(pane, i) },
                    onClick = { if (Mods.tertiaryDown) vm.closeTab(pane, i) else vm.selectTab(pane, i) },
                )
                }
              }
            }
        }
        // The single circled + : opens a new tab on Home.
        Box(
            Modifier.size(32.dp).clip(CircleShape)
                .border(1.dp, cs.outlineVariant, CircleShape)
                .clickable { vm.addTab(pane, Loc.HOME) },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Add, contentDescription = "New tab (Ctrl+T)", modifier = Modifier.size(18.dp), tint = cs.onSurfaceVariant) }
    }
}

@Composable
private fun TabChip(
    vm: ExplorerViewModel,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    selected: Boolean,
    closable: Boolean,
    dropDest: String?,
    onClose: () -> Unit,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.25f)
        selected -> cs.primaryContainer
        hovered -> cs.onSurface.copy(alpha = 0.07f)
        else -> Color.Transparent
    }
    Row(
        Modifier
            .height(32.dp)
            .widthIn(max = 180.dp)
            .clip(shape)
            .background(bg)
            .then(if (selected) Modifier else Modifier.border(1.dp, cs.outlineVariant, shape))
            .hoverable(interaction)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(start = 12.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (iconTint == Color.Unspecified) cs.onSurface.copy(alpha = 0.8f) else iconTint)
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface.copy(alpha = 0.8f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (closable && (selected || hovered)) {
            Box(
                Modifier.size(20.dp).clip(CircleShape).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Close, contentDescription = "Close tab (Ctrl+W)", modifier = Modifier.size(13.dp)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- listing

@Composable
internal fun ListingBody(vm: ExplorerViewModel, pane: PaneState, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val hit = remember(tab.id) { HitTracker() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var paneDrop by remember { mutableStateOf(false) }
    val dropDest = if (tab.isVirtual || tab.isSearch) null else tab.path

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
            // Runs before any row sees the press, so a stale row can't leak into the next right-click.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = null
                    }
                }
            }
            // Runs after the rows: right-click opens the context menu for whichever row (or empty space) was hit.
            .pointerInput(tab.id, pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                            val p = ev.changes.first().position
                            vm.showContext(pane.index, origin + p, hit.entry)
                        }
                    }
                }
            }
            // Ctrl + mouse wheel zooms the icon size, like every desktop file manager.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Scroll && Mods.ctrl && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val dy = ev.changes.first().scrollDelta.y
                            if (dy != 0f) {
                                vm.zoomGrid(if (dy < 0f) 1 else -1)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    }
                }
            }
            // Two-finger pinch zooms the thumbnail size in Grid and Gallery.
            .pointerInput(tab.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.size >= 2 && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val z = ev.calculateZoom()
                            if (z != 1f) { vm.pinchGrid(z); ev.changes.forEach { it.consume() } }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .folderDrop(vm, dropDest) { paneDrop = it }
            .then(if (paneDrop) Modifier.border(2.dp, cs.primary) else Modifier),
    ) {
        var slow by remember(tab.id) { mutableStateOf(false) }
        LaunchedEffect(tab.loading, tab.path) {
            slow = false
            if (tab.loading) { kotlinx.coroutines.delay(700); slow = true }
        }
        if (tab.loading && slow) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
        else Spacer(Modifier.height(2.dp))

        if (tab.path == Loc.TRASH) TrashBanner(vm)
        if (tab.isSearch) SearchStatus(tab)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val err = tab.error
            when {
                err != null -> ErrorState(vm, tab, err)
                tab.entries.isEmpty() && !tab.loading && !tab.searching -> EmptyState(tab)
                tab.entries.isEmpty() -> Unit
                else -> androidx.compose.animation.Crossfade(targetState = tab.viewMode, animationSpec = androidx.compose.animation.core.tween(200), label = "view") { mode ->
                    when (mode) {
                        // One list view: it grows Date / Size / Type columns when the window is wide.
                        ViewMode.DETAILS, ViewMode.LIST -> BoxWithConstraints(Modifier.fillMaxSize()) {
                            if (maxWidth >= 760.dp && !tab.isVirtual) DetailsView(vm, pane, tab, hit) else PlainList(vm, pane, tab, hit)
                        }
                        ViewMode.GRID -> GridView(vm, pane, tab, hit, gallery = false)
                        ViewMode.GALLERY -> GalleryView(vm, pane, tab, hit)
                        ViewMode.COLUMNS -> ColumnsView(vm, pane, tab, hit)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrashBanner(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.secondaryContainer.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(16.dp))
        Text("  Items in Trash are deleted automatically after 30 days.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        TextButton(onClick = { vm.dialog = DialogState.EmptyTrash }) { Text("Empty Trash") }
    }
}

@Composable
private fun SearchStatus(tab: TabState) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val n = tab.entries.size
        val text = when {
            tab.searching -> "Searching... $n found so far"
            n == 0 -> "No matches"
            n >= 10_000 -> "10,000+ matches (showing the first 10,000)"
            else -> "$n match" + (if (n == 1) "" else "es")
        }
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ErrorState(vm: ExplorerViewModel, tab: TabState, message: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(10.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.refresh(tab) }) { Text("Try again") }
            Button(onClick = { vm.navigate(tab, Loc.HOME) }) { Text("Go to Home") }
        }
    }
}

@Composable
private fun EmptyState(tab: TabState) {
    val text = when {
        tab.isSearch -> "No files match your search"
        tab.path == Loc.TRASH -> "Trash is empty"
        tab.isVirtual -> "Nothing here yet"
        else -> "This folder is empty"
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

// ---------------------------------------------------------------------------------------------- one entry

@Composable
private fun EntryBox(
    vm: ExplorerViewModel,
    pane: PaneState,
    tab: TabState,
    e: FileEntry,
    hit: HitTracker,
    modifier: Modifier,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val selected = e.path in tab.selection
    val active = vm.activePane == pane.index
    val focused = tab.focus == e.path && active
    val bgTarget = when {
        dropHover -> cs.primary.copy(alpha = 0.30f)
        selected -> if (active) cs.primary.copy(alpha = 0.20f) else cs.onSurface.copy(alpha = 0.10f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val bg by androidx.compose.animation.animateColorAsState(bgTarget, androidx.compose.animation.core.tween(140), label = "row")
    val shape = RoundedCornerShape(12.dp)
    val dropMod = if (e.isDir && tab.path != Loc.TRASH) Modifier.folderDrop(vm, e.path) { dropHover = it } else Modifier

    Box(
        modifier
            .clip(shape)
            .background(bg)
            .then(if (focused && !selected) Modifier.border(1.dp, cs.primary.copy(alpha = 0.6f), shape) else Modifier)
            .alpha(if (vm.isCut(e.path)) 0.45f else 1f)
            .hoverable(interaction)
            .pointerInput(e) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = e
                    }
                }
            }
            .pointerInput(e) {
                detectTapGestures(
                    onLongPress = { off ->
                        if (!Mods.mouse) { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); vm.longPressSelect(pane, tab, e) }
                    },
                    onTap = { vm.onEntryClick(pane, tab, e) },
                )
            }
            .entryDragSource(vm, tab, e)
            .then(dropMod),
    ) { content() }
}

private fun mutedAlpha() = 0.72f

// ---------------------------------------------------------------------------------------------- details view

@Composable
private fun DetailsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val showDate = maxWidth >= 430.dp
        val showType = maxWidth >= 660.dp
        val state = rememberLazyListState()
        LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        Column(Modifier.fillMaxSize()) {
            DetailsHeader(vm, tab, showDate, showType, tab.selection.isNotEmpty())
            val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
            LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                items(tree.rows, key = { it.e.path }, contentType = { if (it.e.isDir) 0 else 1 }) { row ->
                    val e = row.e
                    EntryBox(vm, pane, tab, e, hit, Modifier.animateItem().fillMaxWidth().height(if (tab.isSearch) 64.dp else 54.dp)) {
                        Row(Modifier.fillMaxSize().rowDivider(if (tab.selection.isNotEmpty()) 120.dp else 88.dp).padding(start = 10.dp + 22.dp * row.depth, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
                            if (tree.enabled) { if (e.isDir) TreeChevron(tree.isOpen(e.path)) { tree.toggle(e.path) } else Spacer(Modifier.width(32.dp)) }
                    FileThumb(e, 36.dp, crop = false)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (tab.isSearch) {
                                    Text(
                                        vm.relativeParent(e, tab.searchRoot),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            if (showDate) Cell(Fmt.dateTime(e.modified), DATE_W)
                            if (showType) Cell(FileTypes.typeLabel(e.name, e.isDir), TYPE_W)
                            Cell(if (e.isDir) "" else Format.size(e.size), SIZE_W, TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Cell(text: String, width: androidx.compose.ui.unit.Dp, align: TextAlign = TextAlign.Start) {
    Text(
        text,
        modifier = Modifier.width(width).padding(start = 8.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = mutedAlpha()),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}

@Composable
private fun DetailsHeader(vm: ExplorerViewModel, tab: TabState, showDate: Boolean, showType: Boolean, selecting: Boolean) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    val dateLabel = if (tab.path == Loc.TRASH) "Date deleted" else "Date modified"
    Column {
        Row(
            Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HeaderCell(vm, tab, "Name", SortKey.NAME, spec, Modifier.weight(1f).padding(start = if (selecting) 122.dp else 90.dp))
            if (showDate) HeaderCell(vm, tab, dateLabel, SortKey.MODIFIED, spec, Modifier.width(DATE_W))
            if (showType) HeaderCell(vm, tab, "Type", SortKey.TYPE, spec, Modifier.width(TYPE_W))
            HeaderCell(vm, tab, "Size", SortKey.SIZE, spec, Modifier.width(SIZE_W), end = true)
        }
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
    }
}

@Composable
private fun HeaderCell(vm: ExplorerViewModel, tab: TabState, label: String, key: SortKey, spec: SortSpec, modifier: Modifier, end: Boolean = false) {
    Row(
        modifier.fillMaxHeight().clickable { vm.setSort(tab, key) }.padding(start = if (end) 0.dp else 8.dp, end = if (end) 4.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (end) Arrangement.End else Arrangement.Start,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.primary, maxLines = 1)
        if (spec.key == key) {
            Icon(
                if (spec.ascending) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- compact list / columns

@Composable
private fun CompactList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, modifier: Modifier) {
    val state = rememberLazyListState()
    LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    LazyColumn(state = state, modifier = modifier, contentPadding = PaddingValues(8.dp)) {
        items(tab.entries, key = { it.path }, contentType = { if (it.isDir) 0 else 1 }) { e ->
            EntryBox(vm, pane, tab, e, hit, Modifier.animateItem().fillMaxWidth().height(52.dp)) {
                Row(Modifier.fillMaxSize().rowDivider(if (tab.selection.isNotEmpty()) 84.dp else 56.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
                    FileThumb(e, 34.dp, crop = false)
                    Spacer(Modifier.width(12.dp))
                    Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (e.isDir) Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    else Text(Format.size(e.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp))
                }
            }
        }
    }
}

/** Samsung / Finder columns: every ancestor gets its own column (as many as fit, scroll sideways for the rest); the last one is the open folder. */
@Composable
private fun ColumnsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val total = maxWidth
        val colW = 320.dp
        val chain = if (tab.isVirtual || tab.isSearch) emptyList()
        else PathUtils.crumbs(tab.path, vm.rootLabelMap()).dropLast(1).map { it.path }
        val scroll = rememberScrollState()
        Row(Modifier.fillMaxSize().horizontalScroll(scroll)) {
            chain.forEachIndexed { i, dir ->
                val child = if (i + 1 < chain.size) chain[i + 1] else tab.path
                AncestorColumn(vm, pane, tab, dir, child, Modifier.width(colW).fillMaxHeight())
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            }
            CompactList(vm, pane, tab, hit, Modifier.width(maxOf(colW, total - colW * chain.size)).fillMaxHeight())
        }
        LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    }
}

@Composable
private fun AncestorColumn(vm: ExplorerViewModel, pane: PaneState, tab: TabState, dir: String, child: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val items by produceState(initialValue = emptyList<FileEntry>(), dir, vm.showHidden, tab.effectiveSort) {
        value = withContext(Dispatchers.IO) {
            runCatching { Sorting.sort(Listing.list(File(dir), vm.showHidden), tab.effectiveSort) }.getOrDefault(emptyList())
        }
    }
    val state = rememberLazyListState()
    LaunchedEffect(items, child) {
        val i = items.indexOfFirst { it.path == child }
        if (i > 2) state.scrollToItem(i - 2)
    }
    LazyColumn(modifier, state = state, contentPadding = PaddingValues(8.dp)) {
        items(items, key = { it.path }) { d ->
            val on = d.path == child
            val picked = d.path in tab.selection
            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
            Row(
                Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (picked) cs.primary.copy(alpha = 0.20f) else if (on) cs.onSurface.copy(alpha = 0.12f) else Color.Transparent)
                    .combinedClickable(
                        onClick = {
                            vm.treeEntries[d.path] = d
                            if (tab.selection.isNotEmpty()) vm.toggleSelect(tab, d)
                            else if (d.isDir) vm.navigate(tab, d.path) else vm.open(tab, d)
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            vm.treeEntries[d.path] = d
                            vm.longPressSelect(pane, tab, d)
                        },
                    )
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SelectLead(tab.selection.isNotEmpty(), picked)
                FileThumb(d, 34.dp, crop = false)
                Spacer(Modifier.width(12.dp))
                Text(d.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (d.isDir) Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = cs.onSurfaceVariant)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- shared bits

/** "12 items" for folders (counted off the UI thread), size for files, with the date in front. */
@Composable
private fun rememberSubtitle(e: FileEntry, withDate: Boolean): String {
    val key = e.path + "|" + e.modified
    val count by produceState(initialValue = SubtitleCache.get(key) ?: "", key) {
        value = if (e.isDir) SubtitleCache.get(key) ?: withContext(Dispatchers.IO) {
            runCatching { Format.items(File(e.path).list()?.size ?: 0) }.getOrDefault("")
        }.also { SubtitleCache.put(key, it) } else Format.size(e.size)
    }
    val date = if (withDate) Fmt.date(e.modified) else ""
    return listOf(date, count).filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
}

@Composable
private fun SelectCircle(selected: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(if (selected) cs.primary else cs.surface.copy(alpha = 0.85f))
            .border(1.5.dp, if (selected) cs.primary else cs.outline, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Filled.Check, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(15.dp))
    }
}

// ---------------------------------------------------------------------------------------------- icon grid (iPad style)

@Composable
private fun GridView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, gallery: Boolean) {
    val cs = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val thumb = if (gallery) (vm.gridSize * 1.9f).dp else vm.gridSize.dp
        val cell = if (gallery) thumb else (thumb + 28.dp).coerceAtLeast(96.dp)
        val gap = if (gallery) 3.dp else 8.dp
        val cols = (((maxWidth - 24.dp + gap) / (cell + gap)).toInt()).coerceAtLeast(1)
        SideEffect { tab.columns = cols }
        val state = rememberLazyGridState()
        LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(cell),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(if (gallery) 3.dp else 12.dp),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            items(tab.entries, key = { it.path }, contentType = { if (it.isDir) 0 else 1 }) { e ->
                val selected = e.path in tab.selection
                val subtitle = rememberSubtitle(e, withDate = true)
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth()) {
                    if (gallery) Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(6.dp))) {
                        FileThumb(e, thumb, Modifier.fillMaxSize(), crop = true)
                        if (selected || tab.selection.isNotEmpty()) {
                            SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp))
                        }
                    } else Box(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            // fixed-height stage; pictures keep their real aspect ratio inside it
                            FileThumb(e, thumb, crop = false)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                e.name,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                            )
                            if (subtitle.isNotEmpty()) {
                                Text(
                                    subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                )
                            }
                        }
                        if (selected || tab.selection.isNotEmpty()) {
                            SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(6.dp))
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- list (Samsung / iPad style)

@Composable
private fun PlainList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    val cs = MaterialTheme.colorScheme
    val state = rememberLazyListState()
    LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
    val heads = if (tab.path == Loc.HOME) remember(tab.entries) { dateHeads(tab.entries) } else emptyMap()
    LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
        items(tree.rows, key = { it.e.path }, contentType = { if (it.e.isDir) 0 else 1 }) { row ->
            val e = row.e
            val selected = e.path in tab.selection
            val subtitle = rememberSubtitle(e, withDate = true)
            Column(Modifier.animateItem()) {
                heads[e.path]?.let { DateHeader(it) }
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth().height(64.dp)) {
                    Row(Modifier.fillMaxSize().padding(start = 6.dp + 22.dp * row.depth, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        SelectLead(tab.selection.isNotEmpty(), selected)
                        if (tree.enabled) {
                            if (e.isDir) TreeChevron(tree.isOpen(e.path)) { tree.toggle(e.path) } else Spacer(Modifier.width(32.dp))
                        } else Spacer(Modifier.width(4.dp))
                        FileThumb(e, 44.dp, crop = false)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (subtitle.isNotEmpty()) {
                                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                HorizontalDivider(Modifier.padding(start = 84.dp + 22.dp * row.depth), color = cs.outlineVariant.copy(alpha = 0.5f))
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- keep keyboard focus on screen

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyListState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx <= first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyGridState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx < first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

/** Folder item counts survive scrolling, so rows never pop in a second time. */
private object SubtitleCache {
    private val map = object : java.util.LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 2000
    }
    @Synchronized fun get(k: String): String? = map[k]
    @Synchronized fun put(k: String, v: String) { map[k] = v }
}

private fun dateHeads(list: List<FileEntry>): Map<String, String> {
    val out = HashMap<String, String>()
    val zone = java.time.ZoneId.systemDefault()
    val today = java.time.LocalDate.now(zone)
    var last = ""
    for (e in list) {
        val d = java.time.Instant.ofEpochMilli(e.modified).atZone(zone).toLocalDate()
        val days = java.time.temporal.ChronoUnit.DAYS.between(d, today)
        val label = when {
            days <= 0 -> "Today"
            days == 1L -> "Yesterday"
            days < 7 -> "This week"
            days < 31 -> "This month"
            else -> "Earlier"
        }
        if (label != last) { out[e.path] = label; last = label }
    }
    return out
}

/** "Today ········" heading with a dotted rule, like Samsung's recent files. */
@Composable
private fun DateHeader(text: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        DottedLine(Modifier.weight(1f).padding(start = 12.dp))
    }
}

@Composable
private fun RowScope.SelectLead(visible: Boolean, selected: Boolean) {
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
        exit = androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SelectCircle(selected)
            Spacer(Modifier.width(12.dp))
        }
    }
}

/** Samsung-style "digital blink": chrome stays put, the content goes dark for a split second, then the new list appears. */
@Composable
private fun Modifier.navTransition(tab: TabState): Modifier {
    val p = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(tab.id, tab.path) {
        p.snapTo(0.35f)
        kotlinx.coroutines.withTimeoutOrNull(250) { androidx.compose.runtime.snapshotFlow { tab.loading }.first { !it } }
        p.animateTo(1f, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = p.value }
}

private val ratioCache = java.util.concurrent.ConcurrentHashMap<String, Float>()

private fun probeRatio(e: FileEntry): Float {
    val key = e.path + "|" + e.modified
    ratioCache[key]?.let { return it }
    val r = when (e.kind) {
        app.dexfiles.core.FileKind.IMAGE -> runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(e.path, o)
            var w = o.outWidth.toFloat(); var h = o.outHeight.toFloat()
            val rot = android.media.ExifInterface(e.path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)
            if (rot == 6 || rot == 8) { val t = w; w = h; h = t }
            if (w > 0 && h > 0) (w / h).coerceIn(0.4f, 2.5f) else 1f
        }.getOrDefault(1f)
        app.dexfiles.core.FileKind.VIDEO -> 16f / 9f
        else -> 1.25f
    }
    ratioCache[key] = r
    return r
}

/** Photo-wall: images keep their real shape in a masonry layout, folders sit in a strip on top, names on each tile. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun GalleryView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    val cs = MaterialTheme.colorScheme
    val folders = tab.entries.filter { it.isDir }
    val files = tab.entries.filter { !it.isDir }
    val ready by produceState(files.all { ratioCache.containsKey(it.path + "|" + it.modified) }, files) {
        value = files.all { ratioCache.containsKey(it.path + "|" + it.modified) }
        if (!value) {
            withContext(Dispatchers.IO) {
                kotlinx.coroutines.coroutineScope {
                    files.chunked(48).map { part -> kotlinx.coroutines.async { part.forEach { probeRatio(it) } } }.forEach { it.await() }
                }
            }
            value = true
        }
    }
    if (!ready) return
    val r = files.associate { it.path to probeRatio(it) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cell = (vm.gridSize * 1.7f).dp
        val cols = ((maxWidth / cell).toInt()).coerceAtLeast(2)
        val state = androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState()
        LaunchedEffect(tab.id, tab.path, tab.isSearch) { state.scrollToItem(0) }
        androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid(
            columns = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalItemSpacing = 8.dp,
        ) {
            if (folders.isNotEmpty()) item(span = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan.FullLine) {
                FlowRow(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (f in folders) EntryBox(vm, pane, tab, f, hit, Modifier.clip(RoundedCornerShape(16.dp)).background(cs.surfaceContainerHigh)) {
                        Row(Modifier.height(52.dp).padding(start = 12.dp, end = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { FileThumb(f, 34.dp) }
                            Spacer(Modifier.width(10.dp))
                            Text(f.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp))
                        }
                    }
                }
            }
            items(files, key = { it.path }) { e ->
                val selected = e.path in tab.selection
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth()) {
                    val media = e.kind == app.dexfiles.core.FileKind.IMAGE || e.kind == app.dexfiles.core.FileKind.VIDEO
                    if (!media) Box(Modifier.fillMaxWidth().aspectRatio(1.25f).clip(RoundedCornerShape(14.dp)).background(kindColor(e.kind).copy(alpha = 0.13f))) {
                        Column(Modifier.align(Alignment.Center).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(kindColor(e.kind).copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                                Icon(kindIcon(e.kind), null, Modifier.size(30.dp), tint = kindColor(e.kind))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(e.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        }
                        if (selected || tab.selection.isNotEmpty()) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp))
                    } else Box(Modifier.fillMaxWidth().aspectRatio(r[e.path] ?: 1f).clip(RoundedCornerShape(14.dp)).background(cs.surfaceContainerHigh)) {
                        FileThumb(e, cell, Modifier.fillMaxSize(), crop = true)
                        Box(
                            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))))
                                .padding(start = 10.dp, end = 10.dp, top = 18.dp, bottom = 8.dp),
                        ) {
                            Text(e.name, style = MaterialTheme.typography.bodySmall, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (selected || tab.selection.isNotEmpty()) {
                            SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp))
                        }
                    }
                }
            }
        }
    }
}
