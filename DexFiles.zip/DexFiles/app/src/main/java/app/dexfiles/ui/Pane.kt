@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.dexfiles.ui

import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.layout.onSizeChanged
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.material.icons.filled.Settings
import androidx.compose.foundation.background
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.staggeredgrid.items
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.RowScope
import androidx.compose.animation.animateContentSize
import app.dexfiles.core.PathUtils
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileTypes
import app.dexfiles.core.Format
import app.dexfiles.core.Listing
import app.dexfiles.core.SortKey
import app.dexfiles.core.SortSpec
import app.dexfiles.core.Sorting
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.HitTracker
import app.dexfiles.state.Loc
import app.dexfiles.state.Mods
import app.dexfiles.state.PaneState
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import java.io.File

private class ColW(val date: androidx.compose.ui.unit.Dp, val type: androidx.compose.ui.unit.Dp, val size: androidx.compose.ui.unit.Dp)

@Composable
fun PaneView(vm: ExplorerViewModel, pane: PaneState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val active = vm.activePane == pane.index
    val tab = pane.tab
    Column(
        modifier
            .fillMaxHeight()
            .pointerInput(pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press && vm.activePane != pane.index) vm.activePane = pane.index
                    }
                }
            },
    ) {
        if (vm.dual) Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) cs.primary else Color.Transparent))
        if (vm.dual) TabStrip(vm, pane)
        // The card from the mock: radius 28, title inside it, then (Recent only) the filter chips, the sort strip and the files.
        Box(Modifier.weight(1f).fillMaxWidth().clip(Radius.xl).background(cs.surface)) {
            when (tab.path) {
                Loc.ANALYZE -> AnalyzeScreen(vm, tab)
                Loc.SETTINGS -> SettingsScreen(vm)
                else -> {
                  // Samsung-style collapsing header: the big title (and the Recent chips) slide up and fade while the list scrolls
                  // up, and come back as soon as you scroll down. The count / sort strip stays put.
                  val collapse = rememberCollapse(tab.path to tab.isSearch)
                  Column(Modifier.nestedScroll(collapseConnection(collapse))) {
                    Column(Modifier.collapsing(collapse)) {
                        if (!tab.isSearch) PageTitle(vm, tab, bottom = if (tab.path == Loc.HOME) 14.dp else 6.dp)
                        if (tab.path == Loc.HOME) HomeChips(vm, tab)
                    }
                    SortStrip(vm, tab)
                    Box(Modifier.weight(1f).fillMaxWidth().navTransition(tab)) { ListingBody(vm, pane, tab) }
                  }
                }
            }
            androidx.compose.animation.AnimatedVisibility(
                visible = active && tab.selection.isNotEmpty() && vm.renaming == null,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
                enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(220)) { it } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
                exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(160)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
            ) {
                SelectionPill(vm, tab)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- tabs

private fun virtualIcon(path: String): ImageVector = when (path) {
    Loc.HOME -> Icons.Filled.Home
    Loc.RECENT -> Icons.Filled.History
    Loc.IMAGES -> Icons.Filled.Image
    Loc.VIDEOS -> Icons.Filled.Movie
    Loc.AUDIO -> Icons.Filled.MusicNote
    Loc.DOCS -> Icons.Filled.Description
    Loc.APKS -> Icons.Filled.Download
    Loc.TRASH -> DexIcons.Trash
    Loc.ANALYZE -> Icons.Filled.PieChart
    Loc.SETTINGS -> DexIcons.Settings
    else -> Icons.Filled.Folder
}

@Composable
fun TabStrip(vm: ExplorerViewModel, pane: PaneState) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    val many = pane.tabs.size > 1
    Row(
        Modifier.fillMaxWidth().height(44.dp).padding(start = 12.dp, end = 12.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            Modifier.weight(1f, fill = false).horizontalScroll(rememberScrollState()).animateContentSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            pane.tabs.forEachIndexed { i, t ->
              androidx.compose.runtime.key(t.id) {
                val selected = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                val title = if (t.isSearch) "Search" else Loc.title(t.path, labels)
                val vis = remember { androidx.compose.animation.core.MutableTransitionState(false).apply { targetState = true } }
                androidx.compose.animation.AnimatedVisibility(
                    visibleState = vis,
                    enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(240)),
                    exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) + androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)),
                ) {
                TabChip(
                    vm = vm,
                    icon = if (Loc.isVirtual(t.path)) virtualIcon(t.path) else Icons.Filled.Folder,
                    iconTint = if (Loc.isVirtual(t.path)) Color.Unspecified else kindColor(app.dexfiles.core.FileKind.FOLDER),
                    title = title,
                    selected = selected,
                    closable = many,
                    dropDest = if (t.isVirtual || t.isSearch) null else t.path,
                    onClose = { vm.closeTab(pane, i) },
                    onClick = { if (Mods.tertiaryDown) vm.closeTab(pane, i) else vm.selectTab(pane, i) },
                )
                }
              }
            }
        }
        // The single circled + : opens a new tab on Home.
        Box(
            Modifier.size(34.dp).clip(CircleShape)
                .background(cs.surfaceContainer)
                .border(1.dp, cs.outlineVariant, CircleShape)
                .clickable { vm.addTab(pane, Loc.HOME) },
            contentAlignment = Alignment.Center,
        ) { Icon(DexIcons.Plus, contentDescription = "New tab (Ctrl+T)", modifier = Modifier.size(16.dp), tint = cs.onSurface.copy(alpha = 0.9f)) }
    }
}

@Composable
private fun TabChip(
    vm: ExplorerViewModel,
    icon: ImageVector,
    iconTint: Color,
    title: String,
    selected: Boolean,
    closable: Boolean,
    dropDest: String?,
    onClose: () -> Unit,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val shape = androidx.compose.foundation.shape.CircleShape
    val bg = when {
        dropHover -> cs.primary.copy(alpha = 0.25f)
        selected -> cs.surfaceContainerHighest
        hovered -> cs.onSurface.copy(alpha = 0.10f)
        else -> cs.surfaceContainer
    }
    Row(
        Modifier
            .height(34.dp)
            .widthIn(max = 180.dp)
            .clip(shape)
            .background(bg)
                        .hoverable(interaction)
            .folderDrop(vm, dropDest) { dropHover = it }
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = if (closable) 8.dp else 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) cs.onSurface else cs.onSurface.copy(alpha = 0.66f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (closable) {
            Box(
                Modifier.size(22.dp).clip(CircleShape).clickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(DexIcons.Close, contentDescription = "Close tab (Ctrl+W)", modifier = Modifier.size(12.dp), tint = cs.onSurface.copy(alpha = if (selected) 0.66f else 0.45f)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- listing

@Composable
internal fun ListingBody(vm: ExplorerViewModel, pane: PaneState, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val hit = remember(tab.id) { HitTracker() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var paneDrop by remember { mutableStateOf(false) }
    val dropDest = if (tab.isVirtual || tab.isSearch) null else tab.path
    val pinchHaptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    // The content follows the fingers at once (a little resisted) and springs home when a step commits or the fingers lift,
    // so a pinch never feels like it is waiting for a threshold.
    val live = remember { androidx.compose.animation.core.Animatable(1f) }
    val liveScope = androidx.compose.runtime.rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
            // Runs before any row sees the press, so a stale row can't leak into the next right-click.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = null
                    }
                }
            }
            // Runs after the rows: right-click opens the context menu for whichever row (or empty space) was hit.
            .pointerInput(tab.id, pane.index) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                            val p = ev.changes.first().position
                            vm.showContext(pane.index, origin + p, hit.entry)
                        }
                    }
                }
            }
            // Ctrl + mouse wheel zooms the icon size, like every desktop file manager.
            .pointerInput(tab.id) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Scroll && Mods.ctrl && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val dy = ev.changes.first().scrollDelta.y
                            if (dy != 0f) {
                                vm.zoomGrid(if (dy < 0f) 1 else -1)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    }
                }
            }
            // Two-finger pinch moves one thumbnail level at a time; the two layouts cross-fade (see GridZoom below).
            .pointerInput(tab.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var acc = 1f
                    var lastStep = 0L
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.size >= 2 && (tab.viewMode == ViewMode.GRID || tab.viewMode == ViewMode.GALLERY)) {
                            val now = ev.changes[0].uptimeMillis
                            // One deliberate pinch moves one level: a bigger threshold, and a short pause before the next step can happen.
                            if (now - lastStep < 160L) acc = 1f else acc = (acc * ev.calculateZoom()).coerceIn(0.5f, 2f)
                            val dir = if (acc >= 1f) 1 else -1
                            val possible = vm.canZoomGrid(dir)
                            // Content follows the fingers; at the smallest / largest size it only gives a tiny resisted wobble (no flicker).
                            val shown = if (possible) 1f + (acc - 1f) * 0.5f else 1f + (acc - 1f) * 0.12f
                            if (now - lastStep >= 160L) liveScope.launch { live.snapTo(shown.coerceIn(0.9f, 1.12f)) }
                            if (possible && (acc > 1.2f || acc < 0.83f)) {
                                vm.zoomGrid(dir)
                                acc = 1f
                                lastStep = now
                                liveScope.launch { live.animateTo(1f, app.dexfiles.ui2.design.Motion.spatial()) }
                                pinchHaptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            }
                            ev.changes.forEach { it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                    liveScope.launch { live.animateTo(1f, app.dexfiles.ui2.design.Motion.spatial()) }
                }
            }
            .folderDrop(vm, dropDest) { paneDrop = it }
            .then(if (paneDrop) Modifier.border(2.dp, cs.primary) else Modifier),
    ) {
        var slow by remember(tab.id) { mutableStateOf(false) }
        LaunchedEffect(tab.loading, tab.path) {
            slow = false
            if (tab.loading) { kotlinx.coroutines.delay(700); slow = true }
        }
        if (tab.loading && slow) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
        else Spacer(Modifier.height(2.dp))

        if (tab.path == Loc.TRASH) TrashBanner(vm)
        if (tab.isSearch) SearchStatus(tab)

        Box(Modifier.weight(1f).fillMaxWidth().graphicsLayer { scaleX = live.value; scaleY = live.value }) {
            val err = tab.error
            when {
                err != null -> ErrorState(vm, tab, err)
                tab.entries.isEmpty() && !tab.loading && !tab.searching -> EmptyState(tab)
                tab.entries.isEmpty() -> Unit
                else -> androidx.compose.runtime.key(tab.path, tab.isSearch, if (tab.path == Loc.HOME) vm.homeFilter else 0) {
                val enter = remember { androidx.compose.animation.core.Animatable(0f) }
                LaunchedEffect(Unit) { enter.animateTo(1f, app.dexfiles.ui2.design.Motion.glide(480)) }
                // A new place settles in: it rises 24 dp and fades up on a soft spring (a slight overshoot gives it weight).
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = (enter.value * 1.6f).coerceIn(0f, 1f); translationY = (1f - enter.value) * 24.dp.toPx() }) {
                androidx.compose.animation.Crossfade(targetState = tab.viewMode, animationSpec = androidx.compose.animation.core.tween(200), label = "view") { mode ->
                    when (mode) {
                        // One list view: it grows Date / Size / Type columns when the window is wide.
                        ViewMode.DETAILS, ViewMode.LIST -> BoxWithConstraints(Modifier.fillMaxSize()) {
                            if (maxWidth >= 760.dp && vm.detailsColumns) DetailsView(vm, pane, tab, hit) else PlainList(vm, pane, tab, hit)
                        }
                        // Old and new thumbnail sizes are on screen together for a moment and blend, then settle.
                        // Zoom: tiles glide to their new places (no cross-fade of two layouts).
                        ViewMode.GRID -> GridView(vm, pane, tab, hit, vm.gridSize)
                        ViewMode.GALLERY -> GalleryView(vm, pane, tab, hit, vm.gridSize)
                        ViewMode.COLUMNS -> ColumnsView(vm, pane, tab, hit)
                    }
                } } }
            }
        }
    }
}

@Composable
private fun TrashBanner(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.secondaryContainer.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(DexIcons.Info, contentDescription = null, modifier = Modifier.size(16.dp))
        Text("  Items in Trash are deleted automatically after 30 days.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        TextButton(onClick = { vm.dialog = DialogState.EmptyTrash }) { Text("Empty Trash") }
    }
}

@Composable
private fun SearchStatus(tab: TabState) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val n = tab.entries.size
        val text = when {
            tab.searching -> "Searching... $n found so far"
            n == 0 -> "No matches"
            n >= 10_000 -> "10,000+ matches (showing the first 10,000)"
            else -> "$n match" + (if (n == 1) "" else "es")
        }
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ErrorState(vm: ExplorerViewModel, tab: TabState, message: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(DexIcons.Info, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(10.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.refresh(tab) }) { Text("Try again") }
            Button(onClick = { vm.navigate(tab, Loc.HOME) }) { Text("Go to Home") }
        }
    }
}

@Composable
private fun EmptyState(tab: TabState) {
    val text = when {
        tab.isSearch -> "No files match your search"
        tab.path == Loc.TRASH -> "Trash is empty"
        tab.isVirtual -> "Nothing here yet"
        else -> "This folder is empty"
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

// ---------------------------------------------------------------------------------------------- one entry

@Composable
private fun EntryBox(
    vm: ExplorerViewModel,
    pane: PaneState,
    tab: TabState,
    e: FileEntry,
    hit: HitTracker,
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape = Radius.s,
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var dropHover by remember { mutableStateOf(false) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val selected = e.path in tab.selection
    val active = vm.activePane == pane.index
    val focused = tab.focus == e.path && active
    val bgTarget = when {
        dropHover -> cs.primary.copy(alpha = 0.30f)
        selected -> if (active) cs.primary.copy(alpha = 0.13f) else cs.onSurface.copy(alpha = 0.10f)
        hovered -> cs.onSurface.copy(alpha = 0.06f)
        else -> Color.Transparent
    }
    val bg by androidx.compose.animation.animateColorAsState(bgTarget, androidx.compose.animation.core.tween(140), label = "row")
    val dropMod = if (e.isDir && tab.path != Loc.TRASH) Modifier.folderDrop(vm, e.path) { dropHover = it } else Modifier
    // While this tile is being renamed and the keyboard is up, scroll so the whole tile shows and stops just short of the next one.
    val reveal = remember { androidx.compose.foundation.relocation.BringIntoViewRequester() }
    var tileSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val imeUp = androidx.compose.foundation.layout.WindowInsets.isImeVisible
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val renamingHere = vm.renaming == e.path
    LaunchedEffect(renamingHere, imeUp) {
        if (renamingHere && imeUp) {
            kotlinx.coroutines.delay(350)
            reveal.bringIntoView(androidx.compose.ui.geometry.Rect(0f, 0f, tileSize.width.toFloat(), tileSize.height + with(dens) { 4.dp.toPx() }))
        }
    }

    Box(
        modifier
            .bringIntoViewRequester(reveal)
            .onSizeChanged { tileSize = it }
            .clip(shape)
            .background(bg)
            .then(if (focused && !selected) Modifier.border(1.dp, cs.primary.copy(alpha = 0.6f), shape) else Modifier)
            .alpha(if (vm.isCut(e.path)) 0.45f else 1f)
            .hoverable(interaction)
            .pointerInput(e) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.type == PointerEventType.Press) hit.entry = e
                    }
                }
            }
            .pointerInput(e) {
                detectTapGestures(
                    onLongPress = { off ->
                        if (!Mods.mouse) { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress); vm.longPressSelect(pane, tab, e) }
                    },
                    onTap = { vm.onEntryClick(pane, tab, e) },
                )
            }
            .entryDragSource(vm, tab, e)
            .then(dropMod),
    ) { content() }
}

private fun mutedAlpha() = 0.72f

// ---------------------------------------------------------------------------------------------- details view

@Composable
private fun DetailsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val measurer = androidx.compose.ui.text.rememberTextMeasurer()
        val style = MaterialTheme.typography.bodyMedium
        val density = androidx.compose.ui.platform.LocalDensity.current
        val loc = tab.isVirtual && !tab.isSearch
        // Each column is as wide as its widest value (plus a little air), never wider.
        val colW = remember(tab.entries, tab.path, tab.isSearch, density) {
            fun widest(texts: List<String>, min: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp {
                val px = texts.take(300).maxOfOrNull { measurer.measure(it, style, maxLines = 1).size.width } ?: 0
                return (with(density) { px.toDp() } + 28.dp).coerceAtLeast(min)
            }
            ColW(
                date = widest(tab.entries.map { Fmt.dateTime(it.modified) }, 140.dp),
                type = widest(tab.entries.map { if (loc) (if (tab.path == Loc.TRASH) "" else File(it.path).parentFile?.name.orEmpty()) else FileTypes.typeLabel(it.name, it.isDir) }, 96.dp),
                size = widest(tab.entries.filter { !it.isDir }.map { Format.size(it.size) }, 84.dp),
            )
        }
        val nameMin = 300.dp
        val showDate = maxWidth >= nameMin + colW.size + colW.date + 90.dp
        val showType = showDate && maxWidth >= nameMin + colW.size + colW.date + colW.type + 90.dp
        val state = rememberLazyListState()
        val gs = glideSpec(tab)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
        ScrollToFocus(tab, state)
        Column(Modifier.fillMaxSize()) {
            DetailsHeader(vm, tab, showDate, showType, tab.selection.isNotEmpty(), colW)
            val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
            LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                itemsIndexed(tree.rows, key = { _, r -> r.e.path }, contentType = { _, r -> if (r.e.isDir) 0 else 1 }) { idx, row ->
                    val e = row.e
                    EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).resultIn(tab.isSearch, e.path, idx).fillMaxWidth().height(if (tab.isSearch) 64.dp else 54.dp)) {
                        Row(Modifier.fillMaxSize().rowDivider(if (tab.selection.isNotEmpty()) 120.dp else 88.dp).padding(start = 10.dp + 22.dp * row.depth, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
                            if (tree.enabled) { if (e.isDir) TreeChevron(tree.isOpen(e.path)) { tree.toggle(e.path) } else Spacer(Modifier.width(32.dp)) }
                    FileThumb(e, 36.dp, crop = false)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                EntryName(vm, tab, e, MaterialTheme.typography.bodyLarge)
                                if (tab.isSearch) {
                                    Text(
                                        vm.relativeParent(e, tab.searchRoot),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            if (showDate) Cell(Fmt.dateTime(e.modified), colW.date)
                            if (showType) Cell(if (tab.isVirtual && !tab.isSearch) (if (tab.path == Loc.TRASH) "" else File(e.path).parentFile?.name.orEmpty()) else FileTypes.typeLabel(e.name, e.isDir), colW.type)
                            Cell(if (e.isDir) "" else Format.size(e.size), colW.size, TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Cell(text: String, width: androidx.compose.ui.unit.Dp, align: TextAlign = TextAlign.Start) {
    Text(
        text,
        modifier = Modifier.width(width).padding(start = 8.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = mutedAlpha()),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
    )
}

@Composable
private fun DetailsHeader(vm: ExplorerViewModel, tab: TabState, showDate: Boolean, showType: Boolean, selecting: Boolean, colW: ColW) {
    val cs = MaterialTheme.colorScheme
    val spec = tab.effectiveSort
    val dateLabel = if (tab.path == Loc.TRASH) "Date deleted" else "Date modified"
    Column {
        Row(
            Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HeaderCell(vm, tab, "Name", SortKey.NAME, spec, Modifier.weight(1f).padding(start = if (selecting) 122.dp else 90.dp))
            if (showDate) HeaderCell(vm, tab, dateLabel, SortKey.MODIFIED, spec, Modifier.width(colW.date))
            if (showType) {
                if (tab.isVirtual && !tab.isSearch) HeaderCell(vm, tab, "Location", null, spec, Modifier.width(colW.type))
                else HeaderCell(vm, tab, "Type", SortKey.TYPE, spec, Modifier.width(colW.type))
            }
            HeaderCell(vm, tab, "Size", SortKey.SIZE, spec, Modifier.width(colW.size), end = true)
        }
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
    }
}

@Composable
private fun HeaderCell(vm: ExplorerViewModel, tab: TabState, label: String, key: SortKey?, spec: SortSpec, modifier: Modifier, end: Boolean = false) {
    Row(
        modifier.fillMaxHeight().clickable(enabled = key != null) { if (key != null) vm.setSort(tab, key) }.padding(start = if (end) 0.dp else 8.dp, end = if (end) 4.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (end) Arrangement.End else Arrangement.Start,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.primary, maxLines = 1)
        if (spec.key == key) {
            Icon(
                if (spec.ascending) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- compact list / columns

@Composable
private fun CompactList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, modifier: Modifier) {
    val state = rememberLazyListState()
    val gs = glideSpec(tab)
    LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    LazyColumn(state = state, modifier = modifier, contentPadding = PaddingValues(8.dp)) {
        itemsIndexed(tab.entries, key = { _, x -> x.path }, contentType = { _, x -> if (x.isDir) 0 else 1 }) { idx, e ->
            EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).resultIn(tab.isSearch, e.path, idx).fillMaxWidth().height(62.dp)) {
                ColumnRowContent(vm, tab, e)
            }
        }
    }
}

/** One anatomy for every column: lead, icon, name with date underneath, count or size at the right, hairline below. No arrows. */
@Composable
private fun ColumnRowContent(vm: ExplorerViewModel, tab: TabState, e: FileEntry) {
    Row(Modifier.fillMaxSize().rowDivider(if (tab.selection.isNotEmpty()) 84.dp else 56.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        SelectLead(tab.selection.isNotEmpty(), e.path in tab.selection)
        FileThumb(e, 38.dp, crop = false)
        Spacer(Modifier.width(12.dp))
        EntryLines(vm, tab, e)
    }
}

/** Samsung / Finder columns: every ancestor gets its own column (as many as fit, scroll sideways for the rest); the last one is the open folder. */
@Composable
private fun ColumnsView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val total = maxWidth
        val colW = 320.dp
        val chain = if (tab.isVirtual || tab.isSearch) emptyList()
        else PathUtils.crumbs(tab.path, vm.rootLabelMap()).dropLast(1).map { it.path }
        val scroll = rememberScrollState()
        Row(Modifier.fillMaxSize().horizontalScroll(scroll)) {
            chain.forEachIndexed { i, dir ->
                val child = if (i + 1 < chain.size) chain[i + 1] else tab.path
                AncestorColumn(vm, pane, tab, dir, child, Modifier.width(colW).fillMaxHeight())
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            }
            CompactList(vm, pane, tab, hit, Modifier.width(maxOf(colW, total - colW * chain.size)).fillMaxHeight())
        }
        LaunchedEffect(tab.path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    }
}

@Composable
private fun AncestorColumn(vm: ExplorerViewModel, pane: PaneState, tab: TabState, dir: String, child: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val items by produceState(initialValue = emptyList<FileEntry>(), dir, vm.showHidden, tab.effectiveSort) {
        value = withContext(Dispatchers.IO) {
            runCatching { Sorting.sort(Listing.list(File(dir), vm.showHidden), tab.effectiveSort) }.getOrDefault(emptyList())
        }
    }
    val state = rememberLazyListState()
    val gs = glideSpec(tab)
    LaunchedEffect(items, child) {
        val i = items.indexOfFirst { it.path == child }
        if (i > 2) state.scrollToItem(i - 2)
    }
    LazyColumn(modifier, state = state, contentPadding = PaddingValues(8.dp)) {
        items(items, key = { it.path }) { d ->
            val on = d.path == child
            val picked = d.path in tab.selection
            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
            Row(
                Modifier.fillMaxWidth().height(62.dp).clip(Radius.m)
                    .background(if (picked) cs.primary.copy(alpha = 0.20f) else if (on) cs.primary.copy(alpha = 0.16f) else Color.Transparent)
                    .combinedClickable(
                        onClick = {
                            vm.treeEntries[d.path] = d
                            if (tab.selection.isNotEmpty()) vm.toggleSelect(tab, d)
                            else if (d.isDir) vm.navigate(tab, d.path) else vm.open(tab, d)
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            vm.treeEntries[d.path] = d
                            vm.longPressSelect(pane, tab, d)
                        },
                    )
            ) {
                ColumnRowContent(vm, tab, d)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- shared bits

/** "12 items" for folders (counted off the UI thread), size for files, with the date in front. */
@Composable
private fun rememberSubtitle(e: FileEntry, withDate: Boolean): String {
    val key = e.path + "|" + e.modified
    val count by produceState(initialValue = SubtitleCache.get(key) ?: "", key) {
        value = if (e.isDir) SubtitleCache.get(key) ?: withContext(Dispatchers.IO) {
            runCatching { Format.items(File(e.path).list()?.size ?: 0) }.getOrDefault("")
        }.also { SubtitleCache.put(key, it) } else Format.size(e.size)
    }
    val date = if (withDate) Fmt.date(e.modified) else ""
    return listOf(date, count).filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
}

@Composable
private fun SelectCircle(selected: Boolean, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    // The fill eases in and the tick pops with a little spring, so ticking a row feels physical instead of flipping.
    val fill by androidx.compose.animation.animateColorAsState(if (selected) cs.primary else Color.Transparent, androidx.compose.animation.core.tween(160), label = "selFill")
    val line by androidx.compose.animation.animateColorAsState(if (selected) cs.primary else (if (cs.background == Color.Black) Color(0xFF4A4A52) else cs.outline), androidx.compose.animation.core.tween(160), label = "selLine")
    val pop by androidx.compose.animation.core.animateFloatAsState(
        if (selected) 1f else 0f,
        androidx.compose.animation.core.spring(dampingRatio = 0.5f, stiffness = androidx.compose.animation.core.Spring.StiffnessMedium),
        label = "selPop",
    )
    Box(
        modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, line, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            DexIcons.Check, contentDescription = null, tint = cs.onPrimary,
            modifier = Modifier.size(14.dp).graphicsLayer { scaleX = pop; scaleY = pop; alpha = pop.coerceIn(0f, 1f) },
        )
    }
}

/** Picture or video at its own proportions inside a square slot: no grey card, the picture itself carries the rounded corners and a hairline. */
@Composable
private fun RealRatioThumb(e: FileEntry, box: androidx.compose.ui.unit.Dp) {
    val cs = MaterialTheme.colorScheme
    val media = e.kind == app.dexfiles.core.FileKind.IMAGE || e.kind == app.dexfiles.core.FileKind.VIDEO
    val ratio by produceState(ratioCache[e.path + "|" + e.modified] ?: 0f, e.path, e.modified) {
        if (media && value == 0f) value = withContext(Dispatchers.IO) { probeRatio(e) }
    }
    Box(Modifier.fillMaxWidth().height(box), contentAlignment = Alignment.Center) {
        if (!media) FileThumb(e, box, Modifier.fillMaxSize(), crop = false)
        else if (ratio > 0f) {
            // The picture is the largest rectangle of its own proportions that fits the slot (aspectRatio picks whichever side fits).
            val r = ratio.coerceIn(0.4f, 2.5f)
            Box(
                Modifier.aspectRatio(r).clip(Radius.m).border(1.dp, cs.onSurface.copy(alpha = 0.08f), Radius.m),
            ) { FileThumb(e, box, Modifier.fillMaxSize(), crop = true) }
        }
    }
}

// ---------------------------------------------------------------------------------------------- icon grid (iPad style)

@Composable
private fun GridView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, level: Int) {
    val gallery = false
    val cs = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val thumb = level.dp
        val cell = if (gallery) thumb else (thumb + 24.dp).coerceAtLeast(96.dp)
        val gap = if (gallery) 3.dp else 12.dp
        val settledW = settledWidth(maxWidth)
        val cols = (((settledW - 40.dp + gap) / (cell + gap)).toInt()).coerceAtLeast(1)
        SideEffect { tab.columns = cols }
        // Tiles only glide to new spots for sort/delete/rename; when the column count changes they must not slide around.
        val gs = glideSpec(tab)
        val state = rememberLazyGridState(initialFirstVisibleItemIndex = tab.zoomAnchor)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { if (tab.zoomAnchor == 0) state.scrollToItem(0) }
        LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.collect { tab.zoomAnchor = it } }
        ScrollToFocus(tab, state)
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = if (gallery) PaddingValues(3.dp) else PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            itemsIndexed(tab.entries, key = { _, x -> x.path }, contentType = { _, x -> if (x.isDir) 0 else 1 }) { idx, e ->
                val selected = e.path in tab.selection
                val subtitle = rememberSubtitle(e, withDate = !e.isDir)
                EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).resultIn(tab.isSearch, e.path, idx).fillMaxWidth(), shape = if (gallery) Radius.xs else Radius.m) {
                    if (gallery) Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(Radius.xs)) {
                        FileThumb(e, thumb, Modifier.fillMaxSize(), crop = true)
                        if (selected || tab.selection.isNotEmpty()) {
                            SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp))
                        }
                    } else if (e.isDir) Box(Modifier.fillMaxWidth()) {
                        // Mock folder cell: icon (about 70% of the thumbnail), 13/600 name, 12 dim count, all centred.
                        Column(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            FileThumb(e, thumb * 0.72f, crop = false)
                            Spacer(Modifier.height(6.dp))
                            EntryName(vm, tab, e, MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFeatureSettings = null), maxLines = 1, textAlign = TextAlign.Center, color = cs.onSurface)
                            if (subtitle.isNotEmpty()) Text(subtitle, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        }
                        if (selected || tab.selection.isNotEmpty()) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(6.dp))
                    } else Box(Modifier.fillMaxWidth()) {
                        // Mock photo cell: thumbnail fills the cell width at a fixed height (radius 16, cropped), 13/500 name and 12 dim date, left aligned.
                        Column(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            RealRatioThumb(e, thumb)
                            Spacer(Modifier.height(6.dp))
                            EntryName(vm, tab, e, MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium, fontFeatureSettings = null), maxLines = 1, color = cs.onSurface, modifier = Modifier.padding(horizontal = 4.dp))
                            if (subtitle.isNotEmpty()) Text(subtitle, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp))
                        }
                        if (selected || tab.selection.isNotEmpty()) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(10.dp))
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- list (Samsung / iPad style)

@Composable
private fun PlainList(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker) {
    val cs = MaterialTheme.colorScheme
    val state = rememberLazyListState()
    val gs = glideSpec(tab)
    LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { state.scrollToItem(0) }
    ScrollToFocus(tab, state)
    val tree = rememberTree(vm, tab, enabled = !tab.isVirtual && !tab.isSearch)
    val heads = if (tab.path == Loc.HOME) remember(tab.entries) { dateHeads(tab.entries) } else emptyMap()
    LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
        items(tree.rows, key = { it.e.path }, contentType = { if (it.e.isDir) 0 else 1 }) { row ->
            val e = row.e
            val selected = e.path in tab.selection
            Column(Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null)) {
                heads[e.path]?.let { DateHeader(it) }
                // Mock row: 68 high, 16 padding, tile 48, 16 gap, a 1 px rule under the text column only.
                EntryBox(vm, pane, tab, e, hit, Modifier.fillMaxWidth().padding(vertical = 1.dp).height(68.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxSize().padding(start = 16.dp + 22.dp * row.depth, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        SelectLead(tab.selection.isNotEmpty(), selected)
                        FileThumb(e, 48.dp, crop = true)
                        Spacer(Modifier.width(16.dp))
                        EntryLines(vm, tab, e)
                        // Folder expand arrow sits at the far right so tiles and text stay aligned exactly as in the mock.
                        if (tree.enabled && e.isDir) TreeChevron(tree.isOpen(e.path)) { tree.toggle(e.path) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------- keep keyboard focus on screen

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyListState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx <= first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

@Composable
private fun ScrollToFocus(tab: TabState, state: LazyGridState) {
    LaunchedEffect(tab.scrollTick) {
        if (tab.scrollTick == 0) return@LaunchedEffect
        val idx = tab.entries.indexOfFirst { it.path == tab.focus }
        if (idx < 0) return@LaunchedEffect
        val vis = state.layoutInfo.visibleItemsInfo
        val first = vis.firstOrNull()?.index ?: 0
        val last = vis.lastOrNull()?.index ?: 0
        when {
            idx < first -> state.scrollToItem(idx)
            idx >= last -> state.scrollToItem((idx - (last - first - 1)).coerceAtLeast(0))
        }
    }
}

/** Folder item counts survive scrolling, so rows never pop in a second time. */
private object SubtitleCache {
    private val map = object : java.util.LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 2000
    }
    @Synchronized fun get(k: String): String? = map[k]
    @Synchronized fun put(k: String, v: String) { map[k] = v }
}

private fun dateHeads(list: List<FileEntry>): Map<String, String> {
    val out = HashMap<String, String>()
    val zone = java.time.ZoneId.systemDefault()
    val today = java.time.LocalDate.now(zone)
    var last = ""
    for (e in list) {
        val d = java.time.Instant.ofEpochMilli(e.modified).atZone(zone).toLocalDate()
        val days = java.time.temporal.ChronoUnit.DAYS.between(d, today)
        val label = when {
            days <= 0 -> "Today"
            days == 1L -> "Yesterday"
            days < 7 -> "This week"
            days < 31 -> "This month"
            else -> "Earlier"
        }
        if (label != last) { out[e.path] = label; last = label }
    }
    return out
}

/** "Today ········" heading with a dotted rule, like Samsung's recent files. */
@Composable
private fun DateHeader(text: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurfaceVariant)
        DottedLine(Modifier.weight(1f).padding(start = 14.dp))
    }
}

@Composable
private fun RowScope.SelectLead(visible: Boolean, selected: Boolean) {
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.expandHorizontally(androidx.compose.animation.core.tween(200)) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)),
        exit = androidx.compose.animation.shrinkHorizontally(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SelectCircle(selected)
            Spacer(Modifier.width(14.dp))
        }
    }
}

/** Samsung-style "digital blink": chrome stays put, the content goes dark for a split second, then the new list appears. */
@Composable
private fun Modifier.navTransition(tab: TabState): Modifier {
    val p = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(tab.id, tab.path) {
        p.snapTo(0.35f)
        kotlinx.coroutines.withTimeoutOrNull(250) { androidx.compose.runtime.snapshotFlow { tab.loading }.first { !it } }
        p.animateTo(1f, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = p.value }
}

private val ratioCache = java.util.concurrent.ConcurrentHashMap<String, Float>()

private fun probeRatio(e: FileEntry): Float {
    val key = e.path + "|" + e.modified
    ratioCache[key]?.let { return it }
    val r = when (e.kind) {
        app.dexfiles.core.FileKind.IMAGE -> runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(e.path, o)
            var w = o.outWidth.toFloat(); var h = o.outHeight.toFloat()
            val rot = android.media.ExifInterface(e.path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)
            if (rot == 6 || rot == 8) { val t = w; w = h; h = t }
            if (w > 0 && h > 0) (w / h).coerceIn(0.4f, 2.5f) else 1f
        }.getOrDefault(1f)
        app.dexfiles.core.FileKind.VIDEO -> 16f / 9f
        else -> 1.25f
    }
    ratioCache[key] = r
    return r
}

/** Photo-wall: images keep their real shape in a masonry layout, folders sit in a strip on top, names on each tile. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun GalleryView(vm: ExplorerViewModel, pane: PaneState, tab: TabState, hit: HitTracker, level: Int) {
    val cs = MaterialTheme.colorScheme
    val folders = tab.entries.filter { it.isDir }
    val files = tab.entries.filter { !it.isDir }
    val ready by produceState(files.all { ratioCache.containsKey(it.path + "|" + it.modified) }, files) {
        value = files.all { ratioCache.containsKey(it.path + "|" + it.modified) }
        if (!value) {
            withContext(Dispatchers.IO) {
                kotlinx.coroutines.coroutineScope {
                    files.chunked(48).map { part -> async { part.forEach { probeRatio(it) } } }.forEach { it.await() }
                }
            }
            value = true
        }
    }
    if (!ready) return
    val r = files.associate { it.path to probeRatio(it) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cell = (level * 1.7f).dp
        val cols = ((settledWidth(maxWidth) / cell).toInt()).coerceAtLeast(2)
        val gs = glideSpec(tab)
        val state = androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState(initialFirstVisibleItemIndex = tab.zoomAnchor)
        LaunchedEffect(tab.id, tab.path, tab.isSearch, tab.query) { if (tab.zoomAnchor == 0) state.scrollToItem(0) }
        LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.collect { tab.zoomAnchor = it } }
        androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid(
            columns = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalItemSpacing = 14.dp,
        ) {
            if (folders.isNotEmpty()) item(span = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan.FullLine) {
                // Equal-width folder cards on the same column grid as the photos below, so everything lines up.
                val perRow = (cols + 1).coerceAtMost(6)
                Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (row in folders.chunked(perRow)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (f in row) EntryBox(vm, pane, tab, f, hit, Modifier.weight(1f).background(cs.surfaceContainerHigh, Radius.m), Radius.m) {
                                Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { FileThumb(f, 34.dp) }
                                    Spacer(Modifier.width(10.dp))
                                    Text(f.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            items(files, key = { it.path }) { e ->
                val selected = e.path in tab.selection
                EntryBox(vm, pane, tab, e, hit, Modifier.animateItem(fadeInSpec = null, placementSpec = gs, fadeOutSpec = null).fillMaxWidth(), Radius.m) {
                    val media = e.kind == app.dexfiles.core.FileKind.IMAGE || e.kind == app.dexfiles.core.FileKind.VIDEO
                    if (!media) Box(Modifier.fillMaxWidth().aspectRatio(1.25f).clip(Radius.m).background(kindColor(e.kind).copy(alpha = 0.13f))) {
                        Column(Modifier.align(Alignment.Center).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(56.dp).clip(Radius.m).background(kindColor(e.kind).copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                                Icon(kindIcon(e.kind), null, Modifier.size(30.dp), tint = kindColor(e.kind))
                            }
                            Spacer(Modifier.height(8.dp))
                            EntryName(vm, tab, e, MaterialTheme.typography.bodySmall, maxLines = 2, textAlign = TextAlign.Center)
                        }
                        if (selected || tab.selection.isNotEmpty()) SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(8.dp))
                    } else Box(
                        Modifier.fillMaxWidth().aspectRatio(r[e.path] ?: 1f).clip(Radius.l).background(cs.surfaceContainerHigh)
                            .border(1.dp, cs.onSurface.copy(alpha = 0.08f), Radius.l),
                    ) {
                        // Photos only, nothing on top of them: no labels. A hairline ring keeps very dark or very light pictures from melting into the page.
                        FileThumb(e, cell, Modifier.fillMaxSize(), crop = true)
                        if (selected || tab.selection.isNotEmpty()) {
                            SelectCircle(selected, Modifier.align(Alignment.TopStart).padding(10.dp))
                        }
                    }
                }
            }
        }
    }
}

/** Spring for tiles/rows moving to new spots. Off for the first moments in a new place so the cached-then-fresh listing swap never shuffles in front of the eye. */
@Composable
private fun glideSpec(tab: TabState): androidx.compose.animation.core.FiniteAnimationSpec<androidx.compose.ui.unit.IntOffset>? {
    var on by remember(tab.path) { mutableStateOf(false) }
    LaunchedEffect(tab.path) { kotlinx.coroutines.delay(700); on = true }
    return if (on) app.dexfiles.ui2.design.Motion.glide<androidx.compose.ui.unit.IntOffset>(440) else null
}

/** Width that only updates after the layout has stopped changing, so tiles stretch smoothly during sidebar animations and re-flow once. */
@Composable
private fun settledWidth(w: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp {
    var s by remember { mutableStateOf(w) }
    // A big jump is the sidebar/preview opening or closing: the pane already dims for that, so re-flow at once (one shift, hidden by the dim).
    // Small steady changes are a window being dragged: wait until it stops so tiles don't dance.
    LaunchedEffect(w) {
        if (kotlin.math.abs((w - s).value) >= 150f) s = w else { kotlinx.coroutines.delay(180); s = w }
    }
    return s
}

/** Two quiet lines like One UI: the name, then the date in a dim tone on the left and the size in a bolder one on the right. */
@Composable
private fun RowScope.EntryLines(vm: ExplorerViewModel, tab: TabState, e: FileEntry) {
    val cs = MaterialTheme.colorScheme
    val right = rememberSubtitle(e, withDate = false)
    val rule = cs.outlineVariant
    Column(
        Modifier.weight(1f).fillMaxHeight().drawBehind { drawLine(rule, Offset(0f, size.height - 0.5f), Offset(size.width, size.height - 0.5f), 1.dp.toPx()) },
        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
    ) {
        EntryName(vm, tab, e, MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Normal))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(Fmt.stamp(e.modified), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (right.isNotEmpty()) Text(right, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = cs.onSurface.copy(alpha = 0.82f), maxLines = 1, modifier = Modifier.padding(start = 8.dp))
        }
    }
}
