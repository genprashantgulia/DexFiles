package app.dexfiles.ui

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.ui2.design.DexIcons
import java.io.File

/**
 * The one list of things you can do to the selected items. The right-click / long-press menu and the selection pill's "More" are both
 * drawn from it, so they always offer the same actions, in the same groups and the same order. A new action is written here once.
 * An action that does not apply is left out, not greyed out.
 */
internal enum class ActGroup { Primary, Open, Edit, Info, Select }

internal class Act(
    val label: String,
    val icon: ImageVector,
    val group: ActGroup,
    val danger: Boolean = false,
    /** Keyboard shortcut shown beside the item, so the menu teaches it. */
    val hint: String? = null,
    /** Shorter label for the pill, where space is tight. */
    val short: String = label,
    val run: () -> Unit,
)

/** [sel] is what every action will apply to; [pane] is where "Open in new tab" puts the tab. */
internal fun fileActions(vm: ExplorerViewModel, tab: TabState, sel: List<FileEntry>, pane: app.dexfiles.state.PaneState): List<Act> {
    if (sel.isEmpty()) return emptyList()
    val single = sel.size == 1
    val one = sel.first()
    val out = ArrayList<Act>()

    if (tab.path == Loc.TRASH) {
        out += Act("Restore", DexIcons.Reset, ActGroup.Primary) { vm.restoreSelected(tab) }
        out += Act("Delete forever", DexIcons.Trash, ActGroup.Primary, danger = true, short = "Delete") { vm.requestDelete(permanent = true, tab = tab) }
        return out
    }

    // Primary: the four things done most. Move and Copy ask for a destination.
    out += Act("Move", DexIcons.Move, ActGroup.Primary) { vm.destination = tab to true }
    out += Act("Copy", DexIcons.Copy, ActGroup.Primary) { vm.destination = tab to false }
    out += Act("Share", DexIcons.Share, ActGroup.Primary) { vm.share(sel.filter { !it.isDir }.ifEmpty { sel }) }
    out += Act("Delete", DexIcons.Trash, ActGroup.Primary, danger = true, hint = "Del") { vm.requestDelete(tab = tab) }

    // Open
    out += Act("Open", DexIcons.OpenIn, ActGroup.Open) { vm.open(tab, one) }
    if (single) out += Act("Quick look", DexIcons.Eye, ActGroup.Open, hint = "Space") { tab.focus = one.path; vm.quickLook = true }
    if (single && one.isDir) out += Act("Open in new tab", DexIcons.NewTab, ActGroup.Open) { vm.openInNewTab(one.path, pane) }
    if (single && !one.isDir) out += Act("Open with…", DexIcons.OpenIn, ActGroup.Open) { vm.openExternally(one, chooser = true) }
    if (single && (tab.isSearch || tab.isVirtual)) out += Act("Show in folder", DexIcons.Folder, ActGroup.Open, hint = "Ctrl ↵") { vm.reveal(one.path) }

    // Edit
    if (single && Rules.canRename(tab)) out += Act("Rename", DexIcons.Rename, ActGroup.Edit, hint = "F2") { vm.requestRename(tab) }
    if (!tab.isVirtual && !tab.isSearch) out += Act("Duplicate", DexIcons.Duplicate, ActGroup.Edit, hint = "Ctrl D") { vm.duplicate(tab) }
    out += Act("Cut", DexIcons.Cut, ActGroup.Edit, hint = "Ctrl X") { vm.copySelection(cut = true, tab = tab) }
    out += Act("Copy to clipboard", DexIcons.Copy, ActGroup.Edit, hint = "Ctrl C") { vm.copySelection(cut = false, tab = tab) }
    if (single && one.isDir && vm.clip != null) out += Act("Paste into folder", DexIcons.Paste, ActGroup.Edit) { vm.paste(into = one.path) }
    out += Act("Add to tray", DexIcons.Tray, ActGroup.Edit) { vm.addToTray(sel, tab) }
    out += Act("Compress to zip", DexIcons.Compress, ActGroup.Edit) { vm.dialog = DialogState.Compress(sel, File(one.path).parent ?: tab.path) }
    if (single && one.kind == FileKind.ARCHIVE) out += Act("Extract…", DexIcons.Extract, ActGroup.Edit) { vm.dialog = DialogState.Archive(one) }
    if (single && one.isDir) {
        val fav = one.path in vm.favorites
        out += Act(if (fav) "Remove from sidebar" else "Add to sidebar", DexIcons.Star, ActGroup.Edit) { vm.toggleFavorite(one.path) }
        out += Act("Customize folder", DexIcons.Info, ActGroup.Edit) { vm.dialog = DialogState.CustomizeFolder(one) }
    }

    // Info
    out += Act("Copy path", DexIcons.Link, ActGroup.Info) { vm.copyPath(sel) }
    out += Act("Properties", DexIcons.Info, ActGroup.Info, hint = "Ctrl I") { vm.dialog = DialogState.Properties(sel) }

    // Select
    out += Act("Select all", DexIcons.SelectAll, ActGroup.Select, hint = "Ctrl A") { vm.selectAll(tab) }
    out += Act("Invert selection", DexIcons.SelectAll, ActGroup.Select) { vm.invertSelection(tab) }
    return out
}

/**
 * The menu body (mock F10): one flat list in a fixed order, groups divided by a hairline, Delete last and red.
 * Open, Quick look / Move to, Copy to, Add to tray / Rename, Compress, Share, Properties / Select / Move to Trash.
 * [primary] false leaves out the four actions the command bar already shows.
 */
@Composable
internal fun ColumnScope.ActionMenuItems(acts: List<Act>, primary: Boolean, close: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    // The right-click / long-press menu is the short one (F10); clipboard verbs, selection helpers and Customize live under More.
    val longOnly = setOf("Cut", "Copy to clipboard", "Customize folder", "Open with…")
    val pool = acts.filter { (primary || it.group != ActGroup.Primary) && !(primary && (it.label in longOnly || it.group == ActGroup.Select)) }
    val used = HashSet<Act>()
    fun pick(vararg labels: String): List<Act> {
        val r = ArrayList<Act>()
        for (l in labels) pool.firstOrNull { it.label == l && it !in used }?.let { used += it; r += it }
        return r
    }
    val trash = acts.firstOrNull { it.group == ActGroup.Primary && it.danger }
    val groups = ArrayList<List<Act>>()
    groups += pick("Open", "Quick look", "Open in new tab", "Open with…", "Show in folder", "Restore")
    groups += pick("Move", "Copy", "Add to tray")
    groups += pick("Rename", "Duplicate", "Compress to zip", "Extract…", "Share", "Cut", "Copy to clipboard", "Paste into folder", "Add to sidebar", "Remove from sidebar", "Customize folder", "Copy path", "Properties")
    groups += pool.filter { it.group == ActGroup.Select && it !in used }.also { used += it }
    groups += pool.filter { it !in used && it !== trash }.also { used += it }
    if (trash != null && trash in pool) groups += listOf(trash)
    var first = true
    for (items in groups) {
        if (items.isEmpty()) continue
        if (!first) HorizontalDivider(Modifier.padding(vertical = 4.dp))
        first = false
        for (a in items) {
            val tint = if (a.danger) cs.error else cs.onSurface
            val hint = a.hint
            val shown = when (a.label) { "Move" -> "Move to…"; "Copy" -> "Copy to…"; "Delete" -> "Move to Trash"; else -> a.label }
            DropdownMenuItem(
                text = { Text(shown, color = tint) },
                leadingIcon = { Icon(a.icon, null, Modifier.size(20.dp), tint = tint) },
                trailingIcon = if (hint != null) ({ Text(hint, fontSize = 11.sp, color = cs.onSurfaceVariant) }) else null,
                onClick = { close(); a.run() },
            )
        }
    }
}
