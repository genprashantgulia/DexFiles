package app.dexfiles.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.ui2.design.DexIcons
import java.io.File

/**
 * The one list of things you can do to the selected items. The right-click / long-press menu and the selection pill's "More" are both
 * drawn from it, so they always offer the same actions, in the same groups and the same order. A new action is written here once.
 * An action that does not apply is left out, not greyed out.
 */
internal enum class ActGroup { Primary, Open, Edit, Info, Select }

internal class Act(
    val label: String,
    val icon: ImageVector,
    val group: ActGroup,
    val danger: Boolean = false,
    /** Keyboard shortcut shown beside the item, so the menu teaches it. */
    val hint: String? = null,
    /** Shorter label for the pill, where space is tight. */
    val short: String = label,
    val run: () -> Unit,
)

/** [sel] is what every action will apply to; [pane] is where "Open in new tab" puts the tab. */
internal fun fileActions(vm: ExplorerViewModel, tab: TabState, sel: List<FileEntry>, pane: app.dexfiles.state.PaneState): List<Act> {
    if (sel.isEmpty()) return emptyList()
    val single = sel.size == 1
    val one = sel.first()
    val out = ArrayList<Act>()

    if (tab.path == Loc.TRASH) {
        out += Act("Restore", DexIcons.Reset, ActGroup.Primary) { vm.restoreSelected(tab) }
        out += Act("Delete forever", DexIcons.Trash, ActGroup.Primary, danger = true, short = "Delete") { vm.requestDelete(permanent = true, tab = tab) }
        return out
    }

    // Primary: the four things done most. Move and Copy ask for a destination.
    out += Act("Move", DexIcons.Move, ActGroup.Primary) { vm.destination = tab to true }
    out += Act("Copy", DexIcons.Copy, ActGroup.Primary) { vm.destination = tab to false }
    out += Act("Share", DexIcons.Share, ActGroup.Primary) { vm.share(sel.filter { !it.isDir }.ifEmpty { sel }) }
    out += Act("Delete", DexIcons.Trash, ActGroup.Primary, danger = true, hint = "Del") { vm.requestDelete(tab = tab) }

    // Open
    out += Act("Open", DexIcons.OpenIn, ActGroup.Open) { vm.open(tab, one) }
    if (single && one.isDir) out += Act("Open in new tab", DexIcons.NewTab, ActGroup.Open) { vm.openInNewTab(one.path, pane) }
    if (single && !one.isDir) out += Act("Open with…", DexIcons.OpenIn, ActGroup.Open) { vm.openExternally(one, chooser = true) }
    if (single && (tab.isSearch || tab.isVirtual)) out += Act("Show in folder", DexIcons.Folder, ActGroup.Open, hint = "Ctrl ↵") { vm.reveal(one.path) }

    // Edit
    if (single && Rules.canRename(tab)) out += Act("Rename", DexIcons.Rename, ActGroup.Edit, hint = "F2") { vm.requestRename(tab) }
    if (!tab.isVirtual && !tab.isSearch) out += Act("Duplicate", DexIcons.Copy, ActGroup.Edit, hint = "Ctrl D") { vm.duplicate(tab) }
    out += Act("Cut", DexIcons.Cut, ActGroup.Edit, hint = "Ctrl X") { vm.copySelection(cut = true, tab = tab) }
    out += Act("Copy to clipboard", DexIcons.Copy, ActGroup.Edit, hint = "Ctrl C") { vm.copySelection(cut = false, tab = tab) }
    if (single && one.isDir && vm.clip != null) out += Act("Paste into folder", DexIcons.Paste, ActGroup.Edit) { vm.paste(into = one.path) }
    out += Act("Compress to zip", DexIcons.Compress, ActGroup.Edit) { vm.dialog = DialogState.Compress(sel, File(one.path).parent ?: tab.path) }
    if (single && one.kind == FileKind.ARCHIVE) out += Act("Extract…", DexIcons.Compress, ActGroup.Edit) { vm.dialog = DialogState.Archive(one) }
    if (single && one.isDir) {
        val fav = one.path in vm.favorites
        out += Act(if (fav) "Remove from sidebar" else "Add to sidebar", DexIcons.Star, ActGroup.Edit) { vm.toggleFavorite(one.path) }
        out += Act("Customize folder", DexIcons.Info, ActGroup.Edit) { vm.dialog = DialogState.CustomizeFolder(one) }
    }

    // Info
    out += Act("Copy path", DexIcons.Link, ActGroup.Info) { vm.copyPath(sel) }
    out += Act("Properties", DexIcons.Info, ActGroup.Info, hint = "Ctrl I") { vm.dialog = DialogState.Properties(sel) }

    // Select
    out += Act("Select all", DexIcons.SelectAll, ActGroup.Select, hint = "Ctrl A") { vm.selectAll(tab) }
    out += Act("Invert selection", DexIcons.SelectAll, ActGroup.Select) { vm.invertSelection(tab) }
    return out
}

/**
 * The menu body: the primary actions as one row of large targets, then the other groups divided by a hairline.
 * [primary] false leaves the row out (the selection pill already shows it).
 */
@Composable
internal fun ColumnScope.ActionMenuItems(acts: List<Act>, primary: Boolean, close: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val prim = acts.filter { it.group == ActGroup.Primary }
    if (primary && prim.isNotEmpty()) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for (a in prim) {
                val c = if (a.danger) cs.error else cs.onSurface
                Column(
                    Modifier.width(68.dp).clip(RoundedCornerShape(14.dp)).clickable { close(); a.run() }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(a.icon, null, Modifier.size(22.dp), tint = c)
                    Text(a.short, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c, maxLines = 1)
                }
            }
        }
    }
    var first = !(primary && prim.isNotEmpty())
    for (g in ActGroup.values()) {
        if (g == ActGroup.Primary) continue
        val items = acts.filter { it.group == g }
        if (items.isEmpty()) continue
        if (!first || (primary && prim.isNotEmpty())) HorizontalDivider(Modifier.padding(vertical = 4.dp))
        first = false
        for (a in items) {
            val tint = if (a.danger) cs.error else cs.onSurface
            DropdownMenuItem(
                text = { Text(a.label, color = tint) },
                leadingIcon = { Icon(a.icon, null, Modifier.size(20.dp), tint = tint) },
                trailingIcon = a.hint?.let { h -> { Text(h, fontSize = 11.sp, color = cs.onSurfaceVariant) } },
                onClick = { close(); a.run() },
            )
        }
    }
}
