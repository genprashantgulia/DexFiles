package app.dexfiles.ui

import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.ui.layout.onSizeChanged
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/** The whole window: toolbar, sidebar, one or two panes, preview, progress strip and toasts. */
@Composable
fun DexFilesApp(vm: ExplorerViewModel, activity: Activity) {
    CompositionLocalProvider(LocalVm provides vm, LocalHostActivity provides activity) {
        DexFilesContent(vm)
    }
}

@Composable
private fun DexFilesContent(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm) {
        for (ev in vm.events) {
            val result = snackbar.showSnackbar(
                message = ev.message,
                actionLabel = ev.actionLabel,
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) ev.onAction?.invoke()
        }
    }

    var drawerOpen by remember { mutableStateOf(false) }

    var dockedSettings by remember { mutableStateOf(false) }
    val curTab = vm.current
    val canStepBack = vm.tabSheet || vm.settingsOpen || vm.viewer != null || vm.quickLook || vm.searchUi || curTab.selection.isNotEmpty() || drawerOpen ||
        curTab.isSearch || curTab.back.isNotEmpty() || curTab.path != app.dexfiles.state.Loc.HOME
    // Back retraces your steps, then lands on Recent files, and only then leaves the app.
    androidx.activity.compose.BackHandler(enabled = canStepBack) {
        when {
            vm.tabSheet -> vm.tabSheet = false
            vm.settingsOpen -> if (vm.settingsPage != 0) vm.settingsPage = 0 else vm.settingsOpen = false
            vm.viewer != null -> vm.viewer = null
            vm.quickLook -> vm.quickLook = false
            vm.searchUi -> vm.closeSearch()
            curTab.selection.isNotEmpty() -> vm.clearSelection(curTab)
            drawerOpen -> drawerOpen = false
            curTab.isSearch || curTab.back.isNotEmpty() -> vm.goBack(curTab)
            else -> vm.navigate(curTab, app.dexfiles.state.Loc.HOME, push = false)
        }
    }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .dropRoot(vm)
            .background(cs.background)
            .windowInsetsPadding(WindowInsets.systemBars)
            .windowInsetsPadding(WindowInsets.ime),
    ) {
        val wc = rememberWindowClass(maxWidth)
        val compact = wc == WindowClass.Compact
        val expanded = wc == WindowClass.Expanded
        androidx.compose.runtime.LaunchedEffect(compact) { if (compact && vm.dual) vm.setDual(false) }
        androidx.compose.runtime.SideEffect { if (vm.phoneGrid != compact) vm.phoneGrid = compact }
        androidx.compose.runtime.CompositionLocalProvider(LocalCompact provides compact) {
        Column(Modifier.fillMaxSize()) {
            // Tabs sit on the very top across the whole window, then the top bar (as in the approved mock).
            if (!compact && !vm.dual) TabStrip(vm, vm.panes[0], search = true)
            AdaptiveTopBar(vm, wc, onMenu = { drawerOpen = !drawerOpen })
            var rowW by remember { mutableIntStateOf(0) }
            val rowDp = with(LocalDensity.current) { rowW.toDp() }
            // Where the page will end up once the sidebar animation is done; the page is laid out at THAT width
            // right away and only revealed gradually, so nothing re-flows (or flickers) while the sidebar moves.
            // The layout only changes while the page is dimmed: dim first (90 ms), then flip the layout, then fade back up.
            // So the one-off re-flow of tiles happens out of sight, and nothing re-flows while the sidebar moves.
            // The sidebar starts sliding on the very first frame; the page re-flows a beat later, while it is already moving,
            // so the heavy layout work can't steal the first frames of the animation (which read as an abrupt start).
            var shownSidebar by remember { mutableStateOf(vm.sidebarVisible) }
            var shownPreview by remember { mutableStateOf(vm.previewVisible) }
            LaunchedEffect(vm.sidebarVisible, vm.previewVisible) {
                kotlinx.coroutines.delay(90)
                shownSidebar = vm.sidebarVisible
                shownPreview = vm.previewVisible
            }
            // Where the page will end up once the animation is done; it is laid out at THAT width right away and only revealed gradually.
            // Settings is a panel docked on the right, mirroring the sidebar, whenever the page keeps a comfortable width beside it.
            // Narrower windows show it over the page instead.
            val leftW = if (expanded) (if (vm.sidebarVisible) 256.dp else 68.dp) else if (wc == WindowClass.Medium) 68.dp else 0.dp
            val dockSettings = !compact && rowDp - 24.dp - leftW - 330.dp >= 480.dp
            androidx.compose.runtime.SideEffect { dockedSettings = dockSettings }
            val settingsW by androidx.compose.animation.core.animateDpAsState(if (dockSettings && vm.settingsOpen) 330.dp else 0.dp, app.dexfiles.ui2.design.Motion.glide(420), label = "settingsW")
            val paneFinal = (rowDp - (if (compact) 16.dp else 24.dp) - (if (expanded) (if (shownSidebar) 256.dp else 68.dp) else if (wc == WindowClass.Medium) 68.dp else 0.dp) - (if (shownPreview && expanded) 282.dp else 0.dp) - (if (dockSettings && vm.settingsOpen) 342.dp else 0.dp)).coerceAtLeast(320.dp)
            Row(
                Modifier.weight(1f).fillMaxWidth().onSizeChanged { rowW = it.width }.padding(start = if (compact) 8.dp else 12.dp, end = if (compact) 8.dp else 12.dp, bottom = if (compact) 8.dp else 12.dp),
            ) {
                // Samsung: the sidebar never disappears, it folds down to an icon rail. Both versions share one clipped box whose width glides;
                // the full list stays laid out at its final width and is revealed by the clip, the rail fades in as the labels fade out.
                // One box for both forms, so crossing a breakpoint glides too: nothing, the rail, or the full list, by width.
                val sbTarget = if (expanded) (if (vm.sidebarVisible) 256.dp else 68.dp) else if (wc == WindowClass.Medium) 68.dp else 0.dp
                val sbW by androidx.compose.animation.core.animateDpAsState(sbTarget, app.dexfiles.ui2.design.Motion.glide(420), label = "sidebarW")
                if (sbW > 0.dp) {
                    val p = ((sbW.value - 68f) / (252f - 68f)).coerceIn(0f, 1f)
                    Box(Modifier.width(sbW).fillMaxHeight().clipToBounds()) {
                        if (p > 0f) Sidebar(vm, Modifier.requiredWidth(256.dp).fillMaxHeight().graphicsLayer { alpha = ((p - 0.15f) / 0.85f).coerceIn(0f, 1f) }, startPad = 0.dp)
                        if (p < 0.98f) SidebarRail(vm, Modifier.width(60.dp).fillMaxHeight().graphicsLayer { alpha = ((0.7f - p) / 0.7f).coerceIn(0f, 1f) })
                    }
                }
                if (vm.dual && !compact) { PaneView(vm, vm.panes[0], Modifier.weight(1f)) }
                else Box(Modifier.weight(1f).fillMaxHeight().clipToBounds()) {
                    PaneView(
                        vm, vm.panes[0],
                        if (rowW > 0) Modifier.wrapContentWidth(Alignment.Start, unbounded = true).width(paneFinal).fillMaxHeight() else Modifier.fillMaxSize(),
                    )
                }
                if (vm.dual && !compact) {
                    TransferRail(vm)
                    PaneView(vm, vm.panes[1], Modifier.weight(1f))
                }
                if (settingsW > 0.dp) Box(Modifier.width(settingsW).fillMaxHeight().clipToBounds()) {
                    Box(Modifier.requiredWidth(342.dp).fillMaxHeight().padding(start = 12.dp)) { SettingsCard(vm) }
                }
                if (shownPreview && expanded) {
                    Spacer(Modifier.width(12.dp))
                    PreviewPanel(vm, Modifier.width(270.dp).fillMaxHeight().clip(app.dexfiles.ui2.design.Radius.m).background(cs.surface))
                }
            }
        }
        // Edge swipe (mock F2): a drag in from the left edge opens the drawer; a drag back across the scrim closes it.
        if (!expanded) {
            var dragged by remember { mutableStateOf(0f) }
            Box(
                Modifier.align(Alignment.CenterStart).width(if (drawerOpen) 0.dp else 22.dp).fillMaxHeight()
                    .pointerInput(drawerOpen) {
                        detectHorizontalDragGestures(
                            onDragStart = { dragged = 0f },
                            onDragEnd = { if (dragged > 40f) drawerOpen = true },
                        ) { _, dx -> dragged += dx }
                    },
            )
            if (drawerOpen) Box(
                Modifier.align(Alignment.CenterEnd).fillMaxWidth(0.16f).fillMaxHeight()
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragStart = { dragged = 0f },
                            onDragEnd = { if (dragged < -40f) drawerOpen = false },
                        ) { _, dx -> dragged += dx }
                    },
            )
        }
        // Phone and small windows: the sidebar slides over the content instead of squeezing it.
        androidx.compose.animation.AnimatedVisibility(
            visible = !expanded && drawerOpen,
            enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)),
            exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { drawerOpen = false },
            )
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = !expanded && drawerOpen,
            enter = androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(260)) { -it },
            exit = androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(200)) { -it },
        ) {
            Sidebar(
                vm,
                // The drawer sits over the status bar, so it keeps its own list clear of the system bars.
                (if (compact) Modifier.fillMaxWidth(0.84f).widthIn(max = 280.dp).fillMaxHeight() else Modifier.width(250.dp).fillMaxHeight()).background(cs.surface).windowInsetsPadding(WindowInsets.systemBars),
                onNavigated = { drawerOpen = false },
                onClose = { drawerOpen = false },
            )
        }
        vm.viewer?.let { ImageViewer(vm, it) }
        if (vm.quickLook) QuickLook(vm)
        SettingsPanel(vm, docked = dockedSettings)
        HoldStackOverlay(vm)
        TrayBar(vm, Modifier.align(Alignment.BottomCenter))
        TabSheet(vm)
        TraySheet(vm)
        ContextMenuHost(vm)
        vm.destination?.let { (t, move) -> DestinationSheet(vm, t, move) { vm.destination = null } }
        DialogHost(vm)
        JobCards(vm, Modifier.align(Alignment.BottomEnd).padding(16.dp))
        DropLabel(vm, Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp))
        CancelDropPill(vm, Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp))
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(16.dp)) { data -> DexToast(data.visuals.message, data.visuals.actionLabel) { data.performAction() } }
        }
    }
}

/** Copy / move / zip jobs as floating cards. A card only appears if the job is still running after a third of a second, so quick jobs never flash one. */
@Composable
private fun JobCards(vm: ExplorerViewModel, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.End) {
        for (job in vm.jobs) androidx.compose.runtime.key(job) { JobCard(job) }
    }
}

@Composable
private fun JobCard(job: app.dexfiles.state.TransferJob) {
    val cs = MaterialTheme.colorScheme
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(350); show = true }
    androidx.compose.animation.AnimatedVisibility(
        visible = show,
        enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.scaleIn(initialScale = 0.94f, animationSpec = dialogSpring()),
        exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        androidx.compose.material3.Surface(
            modifier = Modifier.width(340.dp),
            shape = app.dexfiles.ui2.design.Radius.l,
            color = dialogSurface(),
            shadowElevation = 16.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
        ) {
            Column(Modifier.padding(start = 18.dp, top = 14.dp, end = 8.dp, bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(job.title, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, color = cs.onSurface)
                        // "name · about 12 s left" once there is enough progress to make a fair guess.
                        val elapsed = System.currentTimeMillis() - job.startedAt
                        val left = if (job.fraction > 0.05f && elapsed > 2000L) (elapsed * (1f - job.fraction) / job.fraction / 1000f).toInt() else -1
                        val eta = when { left < 0 -> null; left < 5 -> "a few seconds left"; left < 90 -> "about $left s left"; else -> "about ${left / 60} min left" }
                        val sub = listOfNotNull(job.detail.takeIf { it.isNotEmpty() }, "${(job.fraction * 100).toInt()}%").joinToString(" \u00B7 ")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            if (eta != null) Text(eta, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    Box(Modifier.size(36.dp).clip(app.dexfiles.ui2.design.Radius.xs).clickable { job.token.cancel() }, contentAlignment = Alignment.Center) {
                        Icon(app.dexfiles.ui2.design.DexIcons.Close, "Cancel", Modifier.size(15.dp), tint = cs.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { job.fraction }, modifier = Modifier.fillMaxWidth().padding(end = 10.dp).height(4.dp).clip(androidx.compose.foundation.shape.CircleShape), color = cs.primary, trackColor = cs.onSurface.copy(alpha = 0.10f), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {})
            }
        }
    }
}

/** Shown until the user grants "All files access" in system settings. */
@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.width(420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(app.dexfiles.ui2.design.DexIcons.Folder, contentDescription = null, modifier = Modifier.size(64.dp), tint = cs.primary)
            Text("DexFiles needs access to your files", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Text(
                "To browse, copy and move files like a desktop file manager, Android needs you to switch on " +
                    "\"All files access\" for DexFiles. Nothing leaves your device.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onGrant) { Text("Open settings") }
            Text(
                "Turn the switch on, then come back to this app.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Shown on the launch after a crash, so the error can be copied and sent for fixing. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("DexFiles crashed last time", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copy error") }
            TextButton(onClick = onContinue) { Text("Try again") }
        }
        SelectionContainer(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}
