package app.dexfiles.ui

import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.animation.animateContentSize
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.ui.layout.onSizeChanged
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel

/** The whole window: toolbar, sidebar, one or two panes, preview, progress strip and toasts. */
@Composable
fun DexFilesApp(vm: ExplorerViewModel, activity: Activity) {
    CompositionLocalProvider(LocalVm provides vm, LocalHostActivity provides activity) {
        DexFilesContent(vm)
    }
}

@Composable
private fun DexFilesContent(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm) {
        for (ev in vm.events) {
            val result = snackbar.showSnackbar(
                message = ev.message,
                actionLabel = ev.actionLabel,
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) ev.onAction?.invoke()
        }
    }

    var drawerOpen by remember { mutableStateOf(false) }
    val curTab = vm.current
    val canStepBack = vm.settingsOpen || vm.viewer != null || vm.quickLook || vm.searchUi || curTab.selection.isNotEmpty() || drawerOpen ||
        curTab.isSearch || curTab.back.isNotEmpty() || curTab.path != app.dexfiles.state.Loc.HOME
    // Back retraces your steps, then lands on Recent files, and only then leaves the app.
    androidx.activity.compose.BackHandler(enabled = canStepBack) {
        when {
            vm.settingsOpen -> if (vm.settingsPage != 0) vm.settingsPage = 0 else vm.settingsOpen = false
            vm.viewer != null -> vm.viewer = null
            vm.quickLook -> vm.quickLook = false
            vm.searchUi -> vm.closeSearch()
            curTab.selection.isNotEmpty() -> vm.clearSelection(curTab)
            drawerOpen -> drawerOpen = false
            curTab.isSearch || curTab.back.isNotEmpty() -> vm.goBack(curTab)
            else -> vm.navigate(curTab, app.dexfiles.state.Loc.HOME, push = false)
        }
    }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .dropRoot(vm)
            .background(cs.background)
            .windowInsetsPadding(WindowInsets.systemBars)
            .windowInsetsPadding(WindowInsets.ime),
    ) {
        val wc = windowClassFor(maxWidth)
        val compact = wc == WindowClass.Compact
        val expanded = wc == WindowClass.Expanded
        androidx.compose.runtime.CompositionLocalProvider(LocalCompact provides compact) {
        Column(Modifier.fillMaxSize()) {
            // Tabs sit on the very top across the whole window, then the top bar (as in the approved mock).
            if (!(vm.dual && !compact)) TabStrip(vm, vm.panes[0])
            AdaptiveTopBar(vm, wc, onMenu = { drawerOpen = !drawerOpen })
            var rowW by remember { mutableIntStateOf(0) }
            val rowDp = with(LocalDensity.current) { rowW.toDp() }
            // Where the page will end up once the sidebar animation is done; the page is laid out at THAT width
            // right away and only revealed gradually, so nothing re-flows (or flickers) while the sidebar moves.
            // The layout only changes while the page is dimmed: dim first (90 ms), then flip the layout, then fade back up.
            // So the one-off re-flow of tiles happens out of sight, and nothing re-flows while the sidebar moves.
            // The sidebar starts sliding on the very first frame; the page re-flows a beat later, while it is already moving,
            // so the heavy layout work can't steal the first frames of the animation (which read as an abrupt start).
            var shownSidebar by remember { mutableStateOf(vm.sidebarVisible) }
            var shownPreview by remember { mutableStateOf(vm.previewVisible) }
            LaunchedEffect(vm.sidebarVisible, vm.previewVisible) {
                kotlinx.coroutines.delay(90)
                shownSidebar = vm.sidebarVisible
                shownPreview = vm.previewVisible
            }
            // Where the page will end up once the animation is done; it is laid out at THAT width right away and only revealed gradually.
            val paneFinal = (rowDp - (if (compact) 16.dp else 24.dp) - (if (expanded) (if (shownSidebar) 252.dp else 68.dp) else 0.dp) - (if (shownPreview && expanded) 312.dp else 0.dp)).coerceAtLeast(320.dp)
            Row(
                Modifier.weight(1f).fillMaxWidth().onSizeChanged { rowW = it.width }.padding(start = if (compact) 8.dp else 12.dp, end = if (compact) 8.dp else 12.dp, bottom = if (compact) 8.dp else 12.dp),
            ) {
                // Samsung: the sidebar never disappears, it folds down to an icon rail. Both versions share one clipped box whose width glides;
                // the full list stays laid out at its final width and is revealed by the clip, the rail fades in as the labels fade out.
                if (expanded) {
                    val sbW by androidx.compose.animation.core.animateDpAsState(if (vm.sidebarVisible) 252.dp else 68.dp, app.dexfiles.ui2.design.Motion.glide(420), label = "sidebarW")
                    val p = ((sbW.value - 68f) / (252f - 68f)).coerceIn(0f, 1f)
                    Box(Modifier.width(sbW).fillMaxHeight().clipToBounds()) {
                        Sidebar(vm, Modifier.requiredWidth(252.dp).fillMaxHeight().graphicsLayer { alpha = ((p - 0.15f) / 0.85f).coerceIn(0f, 1f) }, startPad = 0.dp)
                        if (p < 0.98f) SidebarRail(vm, Modifier.width(60.dp).fillMaxHeight().graphicsLayer { alpha = ((0.7f - p) / 0.7f).coerceIn(0f, 1f) })
                    }
                }
                if (vm.dual && !compact) { PaneView(vm, vm.panes[0], Modifier.weight(1f)) }
                else Box(Modifier.weight(1f).fillMaxHeight().clipToBounds()) {
                    PaneView(
                        vm, vm.panes[0],
                        if (rowW > 0) Modifier.wrapContentWidth(Alignment.Start, unbounded = true).width(paneFinal).fillMaxHeight() else Modifier.fillMaxSize(),
                    )
                }
                if (vm.dual && !compact) {
                    Spacer(Modifier.width(12.dp))
                    PaneView(vm, vm.panes[1], Modifier.weight(1f))
                }
                if (shownPreview && expanded) {
                    Spacer(Modifier.width(12.dp))
                    PreviewPanel(vm, Modifier.width(300.dp).fillMaxHeight().clip(RoundedCornerShape(Dimens.radiusSheet)).background(cs.surface))
                }
            }
        }
        // Phone and small windows: the sidebar slides over the content instead of squeezing it.
        androidx.compose.animation.AnimatedVisibility(
            visible = !expanded && drawerOpen,
            enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)),
            exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { drawerOpen = false },
            )
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = !expanded && drawerOpen,
            enter = androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(260)) { -it },
            exit = androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(200)) { -it },
        ) {
            Sidebar(
                vm,
                Modifier.width(300.dp).fillMaxHeight().background(cs.surface),
                onNavigated = { drawerOpen = false },
            )
        }
        vm.viewer?.let { ImageViewer(vm, it) }
        if (vm.quickLook) QuickLook(vm)
        SettingsPanel(vm)
        ContextMenuHost(vm)
        DialogHost(vm)
        JobCards(vm, Modifier.align(Alignment.BottomEnd).padding(16.dp))
        CancelDropPill(vm, Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp))
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(16.dp)) { data -> DexToast(data.visuals.message, data.visuals.actionLabel) { data.performAction() } }
        }
    }
}

/** Copy / move / zip jobs as floating cards. A card only appears if the job is still running after a third of a second, so quick jobs never flash one. */
@Composable
private fun JobCards(vm: ExplorerViewModel, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.End) {
        for (job in vm.jobs) androidx.compose.runtime.key(job) { JobCard(job) }
    }
}

@Composable
private fun JobCard(job: app.dexfiles.state.TransferJob) {
    val cs = MaterialTheme.colorScheme
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(350); show = true }
    androidx.compose.animation.AnimatedVisibility(
        visible = show,
        enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(160)) + androidx.compose.animation.scaleIn(initialScale = 0.94f, animationSpec = dialogSpring()),
        exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)),
    ) {
        androidx.compose.material3.Surface(
            modifier = Modifier.width(340.dp),
            shape = app.dexfiles.ui2.design.Radius.l,
            color = dialogSurface(),
            shadowElevation = 16.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
        ) {
            Column(Modifier.padding(start = 18.dp, top = 14.dp, end = 8.dp, bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(job.title, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, color = cs.onSurface)
                        if (job.detail.isNotEmpty()) Text(job.detail, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    }
                    Text("${(job.fraction * 100).toInt()}%", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    DexButton("Cancel") { job.token.cancel() }
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { job.fraction }, modifier = Modifier.fillMaxWidth().padding(end = 10.dp).height(4.dp).clip(androidx.compose.foundation.shape.CircleShape), color = cs.primary, trackColor = cs.onSurface.copy(alpha = 0.10f), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {})
            }
        }
    }
}

/** Shown until the user grants "All files access" in system settings. */
@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.width(420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(app.dexfiles.ui2.design.DexIcons.Folder, contentDescription = null, modifier = Modifier.size(64.dp), tint = cs.primary)
            Text("DexFiles needs access to your files", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Text(
                "To browse, copy and move files like a desktop file manager, Android needs you to switch on " +
                    "\"All files access\" for DexFiles. Nothing leaves your device.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onGrant) { Text("Open settings") }
            Text(
                "Turn the switch on, then come back to this app.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Shown on the launch after a crash, so the error can be copied and sent for fixing. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("DexFiles crashed last time", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copy error") }
            TextButton(onClick = onContinue) { Text("Try again") }
        }
        SelectionContainer(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}
