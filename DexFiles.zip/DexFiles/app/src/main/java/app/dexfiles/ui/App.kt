package app.dexfiles.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel

/** The whole window: toolbar, sidebar, one or two panes, preview, progress strip and toasts. */
@Composable
fun DexFilesApp(vm: ExplorerViewModel, activity: Activity) {
    CompositionLocalProvider(LocalVm provides vm, LocalHostActivity provides activity) {
        DexFilesContent(vm)
    }
}

@Composable
private fun DexFilesContent(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm) {
        for (ev in vm.events) {
            val result = snackbar.showSnackbar(
                message = ev.message,
                actionLabel = ev.actionLabel,
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) ev.onAction?.invoke()
        }
    }

    var drawerOpen by remember { mutableStateOf(false) }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .windowInsetsPadding(WindowInsets.systemBars),
    ) {
        val wc = windowClassFor(maxWidth)
        val compact = wc == WindowClass.Compact
        val expanded = wc == WindowClass.Expanded
        Column(Modifier.fillMaxSize()) {
            AdaptiveTopBar(vm, wc, onMenu = { drawerOpen = !drawerOpen })
            Row(
                Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (expanded && vm.sidebarVisible) {
                    Sidebar(vm, Modifier.width(264.dp).fillMaxHeight().clip(RoundedCornerShape(Dimens.radiusSheet)).background(cs.surface))
                }
                PaneView(vm, vm.panes[0], Modifier.weight(1f))
                if (vm.dual && !compact) {
                    PaneView(vm, vm.panes[1], Modifier.weight(1f))
                }
                if (vm.previewVisible && expanded) {
                    PreviewPanel(vm, Modifier.width(300.dp).fillMaxHeight().clip(RoundedCornerShape(Dimens.radiusSheet)).background(cs.surface))
                }
            }
            JobStrip(vm)
        }
        if (!expanded && drawerOpen) {
            // Phone and small windows: the sidebar slides over the content instead of squeezing it.
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { drawerOpen = false },
            )
            Sidebar(
                vm,
                Modifier.width(300.dp).fillMaxHeight().background(cs.surface),
                onNavigated = { drawerOpen = false },
            )
        }
        if (vm.quickLook) QuickLook(vm)
        ContextMenuHost(vm)
        DialogHost(vm)
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(16.dp))
    }
}

/** Thin progress strip shown while copy / move / zip jobs run. */
@Composable
private fun JobStrip(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    for (job in vm.jobs) {
        HorizontalDivider(color = cs.outlineVariant)
        Row(
            Modifier.fillMaxWidth().background(cs.surfaceVariant).padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(job.title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                if (job.detail.isNotEmpty()) {
                    Text(job.detail, style = MaterialTheme.typography.bodySmall, maxLines = 1, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(progress = { job.fraction }, modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = { job.token.cancel() }) { Text("Cancel") }
        }
    }
}

/** Shown until the user grants "All files access" in system settings. */
@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.width(420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(Icons.Filled.Folder, contentDescription = null, modifier = Modifier.size(64.dp), tint = cs.primary)
            Text("DexFiles needs access to your files", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Text(
                "To browse, copy and move files like a desktop file manager, Android needs you to switch on " +
                    "\"All files access\" for DexFiles. Nothing leaves your device.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onGrant) { Text("Open settings") }
            Text(
                "Turn the switch on, then come back to this app.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Shown on the launch after a crash, so the error can be copied and sent for fixing. */
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().background(cs.background).windowInsetsPadding(WindowInsets.systemBars).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("DexFiles crashed last time", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copy error") }
            TextButton(onClick = onContinue) { Text("Try again") }
        }
        SelectionContainer(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}
