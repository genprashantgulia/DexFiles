package app.dexfiles.ui

import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

/** How much further a flick glides than the Android default (1 = unchanged). One number, used by every scrolling list, grid and tree. */
private const val FLING_BOOST = 1.3f

/** The system fling with a slightly faster release, so a flick travels further (as in One UI). Touching the list still stops it at once. */
@Composable
fun dexFling(): FlingBehavior {
    val base = ScrollableDefaults.flingBehavior()
    return remember(base) {
        object : FlingBehavior {
            override suspend fun ScrollScope.performFling(initialVelocity: Float): Float =
                with(base) { performFling(initialVelocity * FLING_BOOST) } / FLING_BOOST
        }
    }
}
