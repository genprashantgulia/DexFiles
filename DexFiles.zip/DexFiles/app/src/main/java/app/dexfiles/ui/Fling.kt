package app.dexfiles.ui

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import kotlin.math.abs

/**
 * How quickly a flick loses speed (1 = the stock exponential rate). Lower glides longer. The speed falls off smoothly all the way to a
 * stop, with no abrupt end, like a well-oiled wheel. One number, used by every scrolling list, grid and tree.
 */
private const val FLING_FRICTION = 0.65f

/** A flick starts this much faster than the finger left the glass (1 = the same). */
private const val FLING_SPEED = 1.15f

/** Speed (px/s) under which the glide is considered finished. */
private const val FLING_REST = 30f

/** The flick: starts at the speed of the finger and decays exponentially. Touching the list still stops it at once. */
@Composable
fun dexFling(): FlingBehavior = remember {
    val spec = exponentialDecay<Float>(frictionMultiplier = FLING_FRICTION, absVelocityThreshold = FLING_REST)
    object : FlingBehavior {
        override suspend fun ScrollScope.performFling(initialVelocity: Float): Float {
            if (abs(initialVelocity) <= FLING_REST) return initialVelocity
            var last = 0f
            var left = initialVelocity * FLING_SPEED
            AnimationState(0f, initialVelocity * FLING_SPEED).animateDecay(spec) {
                val delta = value - last
                val used = scrollBy(delta)
                last = value
                left = velocity
                // Hit the end of the list: nothing more to give, so stop instead of grinding on.
                if (abs(delta - used) > 0.5f) cancelAnimation()
            }
            return left
        }
    }
}
