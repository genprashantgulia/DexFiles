package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState
import app.dexfiles.ui2.design.DexIcons

/** One filter: a label, the query prefix(es) it owns, and the choices (label to query token, or null for "any"). */
private class Filter(val title: String, val prefixes: List<String>, val choices: List<Pair<String, String?>>)

private val Filters = listOf(
    Filter(
        "Type", listOf("kind:"),
        listOf("Any type" to null, "Images" to "kind:image", "Videos" to "kind:video", "Audio" to "kind:audio", "Documents" to "kind:doc", "PDF" to "kind:pdf", "Archives" to "kind:archive", "Apps" to "kind:apk", "Folders" to "kind:folder"),
    ),
    Filter("Date", listOf("newer:"), listOf("Any date" to null, "Past day" to "newer:1d", "Past week" to "newer:1w", "Past month" to "newer:1m", "Past year" to "newer:1y")),
    Filter("Size", listOf("size>", "size<"), listOf("Any size" to null, "Over 1 MB" to "size>1mb", "Over 10 MB" to "size>10mb", "Over 100 MB" to "size>100mb", "Over 1 GB" to "size>1gb")),
)

private fun tokens(q: String) = q.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

/** The token this filter currently has in [q], or null. */
private fun current(q: String, f: Filter): String? =
    tokens(q).firstOrNull { t -> f.prefixes.any { t.startsWith(it, ignoreCase = true) } }?.lowercase()

/** [q] with this filter's token replaced by [token] (or removed when null). Free text is left exactly as typed. */
private fun withToken(q: String, f: Filter, token: String?): String =
    (tokens(q).filterNot { t -> f.prefixes.any { t.startsWith(it, ignoreCase = true) } } + listOfNotNull(token)).joinToString(" ")

/** Type / Date / Size chips shown above search results. They write ordinary search tokens, so typing the same tokens works too. */
@Composable
fun SearchFilters(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    // One row at every width: it scrolls sideways when the window is too narrow for all of it.
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
    ) {
        // Scope: where to look. In Recent / category lists there is no "this folder", so the choice is hidden.
        if (!tab.isVirtual) {
            DexChip("This folder", vm.searchCurrentOnly) { vm.setSearchCurrentOnly(true) }
            DexChip("Everywhere", !vm.searchCurrentOnly) { vm.setSearchCurrentOnly(false) }
            Box(Modifier.width(1.dp).height(18.dp).background(cs.onSurface.copy(alpha = 0.14f)))
        }
        for (f in Filters) {
            var open by remember { mutableStateOf(false) }
            val cur = current(tab.query, f)
            val label = f.choices.firstOrNull { it.second == cur }?.first ?: f.title
            Box {
                DexChip(label + " ▾", cur != null) { open = true }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    for ((text, token) in f.choices) {
                        DropdownMenuItem(
                            text = { Text(text) },
                            trailingIcon = { if (token == cur) Icon(DexIcons.Check, null, Modifier.padding(start = 8.dp), tint = cs.primary) },
                            onClick = { open = false; vm.setQuery(tab, withToken(tab.query, f, token)) },
                        )
                    }
                }
            }
        }
    }
}
