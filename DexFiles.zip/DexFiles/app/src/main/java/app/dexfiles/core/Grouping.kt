package app.dexfiles.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/** How a listing is split into headed sections. Sorting still decides the order inside each section. */
enum class GroupBy(val label: String) { NONE("None"), TYPE("Type"), DATE("Date modified"), SIZE("Size") }

object Grouping {
    private class Bucket(val rank: Int, val label: String)

    private val DATE = listOf("Today", "Yesterday", "This week", "This month", "Earlier").mapIndexed { i, l -> Bucket(i, l) }
    private val TYPE = listOf("Folders", "Images", "Videos", "Audio", "Documents", "Archives", "Apps", "Other").mapIndexed { i, l -> Bucket(i, l) }
    private val SIZE = listOf("Folders", "Over 1 GB", "100 MB to 1 GB", "10 to 100 MB", "1 to 10 MB", "Under 1 MB").mapIndexed { i, l -> Bucket(i, l) }

    private const val MB = 1024L * 1024L

    private fun bucket(e: FileEntry, g: GroupBy, today: LocalDate, zone: ZoneId): Bucket = when (g) {
        GroupBy.NONE -> DATE[0]
        GroupBy.DATE -> {
            val days = ChronoUnit.DAYS.between(Instant.ofEpochMilli(e.modified).atZone(zone).toLocalDate(), today)
            DATE[when { days <= 0 -> 0; days == 1L -> 1; days < 7 -> 2; days < 31 -> 3; else -> 4 }]
        }
        GroupBy.TYPE -> TYPE[
            if (e.isDir) 0 else when (e.kind) {
                FileKind.IMAGE -> 1
                FileKind.VIDEO -> 2
                FileKind.AUDIO -> 3
                FileKind.PDF, FileKind.DOCUMENT, FileKind.SHEET, FileKind.SLIDES, FileKind.TEXT -> 4
                FileKind.ARCHIVE -> 5
                FileKind.APK -> 6
                else -> 7
            },
        ]
        GroupBy.SIZE -> SIZE[
            if (e.isDir) 0 else when {
                e.size >= 1024 * MB -> 1
                e.size >= 100 * MB -> 2
                e.size >= 10 * MB -> 3
                e.size >= MB -> 4
                else -> 5
            },
        ]
    }

    /** Moves each section's items together (stable, so the chosen sort order survives inside a section). */
    fun arrange(list: List<FileEntry>, g: GroupBy): List<FileEntry> {
        if (g == GroupBy.NONE) return list
        val today = LocalDate.now(); val zone = ZoneId.systemDefault()
        return list.sortedBy { bucket(it, g, today, zone).rank }
    }

    /** Section title for the first item of each section, keyed by that item's path. */
    fun heads(list: List<FileEntry>, g: GroupBy): Map<String, String> {
        if (g == GroupBy.NONE) return emptyMap()
        val today = LocalDate.now(); val zone = ZoneId.systemDefault()
        val out = HashMap<String, String>()
        var last: String? = null
        for (e in list) {
            val label = bucket(e, g, today, zone).label
            if (label != last) { out[e.path] = label; last = label }
        }
        return out
    }
}
