package app.dexfiles.ui2.design

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

/** Motion spec: springs for physical things, one emphasized curve for page-level changes. */
object Motion {
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    fun <T> page() = tween<T>(280, easing = Emphasized)
    fun <T> quick() = tween<T>(160, easing = Emphasized)
    fun <T> press() = spring<T>(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium)
    // Spring tokens from DESIGN_SPEC: spatial = things that move or resize, effects = fades and colour (never bounce).
    fun <T> spatialFast() = spring<T>(dampingRatio = 0.9f, stiffness = 1400f)
    fun <T> spatial() = spring<T>(dampingRatio = 0.9f, stiffness = 700f)
    fun <T> spatialSlow() = spring<T>(dampingRatio = 0.9f, stiffness = 300f)
    fun <T> effectsFast() = spring<T>(dampingRatio = 1f, stiffness = 3800f)
    fun <T> effects() = spring<T>(dampingRatio = 1f, stiffness = 1600f)
    fun <T> effectsSlow() = spring<T>(dampingRatio = 1f, stiffness = 800f)
    fun <T> expand() = spring<T>(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
}

/** Press feedback: shrinks slightly with a spring while held. Wrap tappable surfaces. */
@Composable
fun Modifier.pressScale(scaleDown: Float = 0.97f, onTap: (() -> Unit)? = null, onLong: (() -> Unit)? = null): Modifier {
    var down by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (down) scaleDown else 1f, Motion.press(), label = "press")
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .pointerInput(onTap, onLong) {
            detectTapGestures(
                onPress = { down = true; tryAwaitRelease(); down = false },
                onTap = { onTap?.invoke() },
                onLongPress = { onLong?.invoke() },
            )
        }
}
