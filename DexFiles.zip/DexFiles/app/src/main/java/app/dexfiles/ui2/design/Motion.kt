package app.dexfiles.ui2.design

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/** Motion spec: springs for physical things, one emphasized curve for page-level changes. */
object Motion {
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    fun <T> page() = tween<T>(280, easing = Emphasized)
    fun <T> press() = spring<T>(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium)
    // Spring tokens from DESIGN_SPEC: spatial = things that move or resize, effects = fades and colour (never bounce).
    fun <T> spatialFast() = spring<T>(dampingRatio = 0.9f, stiffness = 1400f)
    fun <T> spatial() = spring<T>(dampingRatio = 0.9f, stiffness = 700f)
    fun <T> effects() = spring<T>(dampingRatio = 1f, stiffness = 1600f)
    // Ease-in-out with a gentle start and a long soft tail: used where something big moves, so it begins as smoothly as it ends.
    val Glide = CubicBezierEasing(0.4f, 0f, 0.1f, 1f)
    fun <T> glide(ms: Int = 420) = tween<T>(ms, easing = Glide)
}

/** Press feedback: shrinks slightly with a spring while held. Wrap tappable surfaces. */
@Composable
fun Modifier.pressScale(scaleDown: Float = 0.97f, onTap: (() -> Unit)? = null, onLong: (() -> Unit)? = null): Modifier {
    var down by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (down) scaleDown else 1f, Motion.press(), label = "press")
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .pointerInput(onTap, onLong) {
            detectTapGestures(
                onPress = { down = true; tryAwaitRelease(); down = false },
                onTap = { onTap?.invoke() },
                onLongPress = { onLong?.invoke() },
            )
        }
}
