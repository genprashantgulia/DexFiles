package app.dexfiles.ui2.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import app.dexfiles.R

/** Onest (SIL Open Font License, see assets/licenses): the app's one typeface, bundled as a variable font so weights 400 to 700 are exact. */
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
val OnestFamily: FontFamily = FontFamily(
    *listOf(400 to FontWeight.Normal, 500 to FontWeight.Medium, 600 to FontWeight.SemiBold, 700 to FontWeight.Bold).map { (w, fw) ->
        Font(R.font.onest, fw, variationSettings = androidx.compose.ui.text.font.FontVariation.Settings(androidx.compose.ui.text.font.FontVariation.weight(w)))
    }.toTypedArray(),
)

val LocalType = staticCompositionLocalOf { DexType(OnestFamily) }

/** Access tokens: Dex.colors.card, Dex.type.body. */
object Dex {
    val colors: Palette @Composable get() = LocalPalette.current
    val type: DexType @Composable get() = LocalType.current
}

@Composable
fun DexTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val p = if (dark) DarkPalette else LightPalette
    // Material scheme only feeds stock components (menus, switches); screens read Dex.* tokens.
    val m = if (dark) darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.canvas, surface = p.card,
        onSurface = p.text, surfaceContainer = p.raised, surfaceContainerHigh = p.overlay,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.canvas, surface = p.card,
        onSurface = p.text, surfaceContainer = p.raised, surfaceContainerHigh = p.overlay,
    )
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = m, content = content)
    }
}
