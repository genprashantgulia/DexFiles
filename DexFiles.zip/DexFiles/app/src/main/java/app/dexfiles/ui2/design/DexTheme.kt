package app.dexfiles.ui2.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import app.dexfiles.R

val InterFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

val LocalType = staticCompositionLocalOf { DexType(InterFamily) }

/** Access tokens: Dex.colors.card, Dex.type.body. */
object Dex {
    val colors: Palette @Composable get() = LocalPalette.current
    val type: DexType @Composable get() = LocalType.current
}

@Composable
fun DexTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val p = if (dark) DarkPalette else LightPalette
    // Material scheme only feeds stock components (menus, switches); screens read Dex.* tokens.
    val m = if (dark) darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.canvas, surface = p.card,
        onSurface = p.text, surfaceContainer = p.raised, surfaceContainerHigh = p.overlay,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, background = p.canvas, surface = p.card,
        onSurface = p.text, surfaceContainer = p.raised, surfaceContainerHigh = p.overlay,
    )
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = m, content = content)
    }
}
