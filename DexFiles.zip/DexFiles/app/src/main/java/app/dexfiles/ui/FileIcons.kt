package app.dexfiles.ui

import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.lerp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import java.io.File

fun kindIcon(kind: FileKind): ImageVector = when (kind) {
    FileKind.FOLDER -> Icons.Filled.Folder
    FileKind.IMAGE -> Icons.Filled.Image
    FileKind.VIDEO -> Icons.Filled.Movie
    FileKind.AUDIO -> Icons.Filled.MusicNote
    FileKind.PDF -> Icons.Filled.PictureAsPdf
    FileKind.DOCUMENT -> Icons.Filled.Description
    FileKind.SHEET -> Icons.Filled.TableChart
    FileKind.SLIDES -> Icons.Filled.Slideshow
    FileKind.ARCHIVE -> Icons.Filled.FolderZip
    FileKind.APK -> Icons.Filled.Android
    FileKind.CODE -> Icons.Filled.Code
    FileKind.TEXT -> Icons.Filled.Notes
    FileKind.OTHER -> Icons.Filled.InsertDriveFile
}

fun kindColor(kind: FileKind): Color = when (kind) {
    FileKind.FOLDER -> Color(0xFFF2B33D)
    FileKind.IMAGE -> Color(0xFF2E9E6B)
    FileKind.VIDEO -> Color(0xFF8E5CD9)
    FileKind.AUDIO -> Color(0xFFE0558F)
    FileKind.PDF -> Color(0xFFE0493E)
    FileKind.DOCUMENT -> Color(0xFF3D7BE0)
    FileKind.SHEET -> Color(0xFF1F9D55)
    FileKind.SLIDES -> Color(0xFFE8803A)
    FileKind.ARCHIVE -> Color(0xFFB07A3F)
    FileKind.APK -> Color(0xFF3DDC84)
    FileKind.CODE -> Color(0xFF1AA7A0)
    FileKind.TEXT -> Color(0xFF7A8794)
    FileKind.OTHER -> Color(0xFF8A94A0)
}

internal fun tileColor(kind: FileKind): Color = when (kind) {
    FileKind.PDF -> Color(0xFFC8472F)
    FileKind.DOCUMENT -> Color(0xFF2E62B8)
    FileKind.SHEET -> Color(0xFF238A55)
    FileKind.SLIDES -> Color(0xFFC8703A)
    FileKind.AUDIO -> Color(0xFF2F9B6B)
    FileKind.VIDEO -> Color(0xFF6A4FD0)
    FileKind.ARCHIVE -> Color(0xFFA9742E)
    FileKind.APK -> Color(0xFF3DA45F)
    FileKind.CODE -> Color(0xFF1E8E8A)
    FileKind.TEXT -> Color(0xFF5B6577)
    else -> Color(0xFF4A4F5A)
}

/** The mock's file tile: a solid colour square (radius 12) with the extension in white, 11/700 with a little tracking. */
@Composable
fun ExtTile(e: FileEntry, size: Dp) {
    val ext = e.name.substringAfterLast('.', "").uppercase().take(4).ifEmpty { "FILE" }
    val big = size >= 100.dp
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(if (big) 16.dp else 12.dp)).background(tileColor(e.kind)),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Text(
            ext, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            fontSize = if (big) 24.sp else 11.sp, letterSpacing = 0.03.em, maxLines = 1,
        )
    }
}

/**
 * Kind icon, replaced by a real thumbnail for photos and videos once it has loaded.
 * crop=false keeps the picture's ORIGINAL aspect ratio (fitted inside the square box, like iPadOS Files).
 */
@Composable
fun FileThumb(e: FileEntry, size: Dp, modifier: Modifier = Modifier, crop: Boolean = true) {
    val kind = e.kind
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }.coerceAtLeast(16)
    var loaded by remember(e.path, e.modified) { mutableStateOf(false) }
    Box(if (modifier == Modifier) Modifier.size(size) else modifier, contentAlignment = Alignment.Center) {
        if (e.isDir) {
            val (fc, fg) = FolderStyles.parse(LocalVm.current.folderStyles[e.path])
            val has = rememberFolderHasFiles(e)
            FolderIcon(Modifier.size(size), fc, hasFiles = has)
            FolderStyles.glyph(fg)?.let { g ->
                Icon(g, null, Modifier.size(size * 0.30f).offset(y = size * 0.10f), tint = Color.White.copy(alpha = 0.95f))
            }
        } else if (kind != FileKind.IMAGE && kind != FileKind.VIDEO) {
            ExtTile(e, size)
        } else if (!loaded) {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(if (size >= 100.dp) 16.dp else 12.dp)).background(kindColor(kind).copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) { Icon(kindIcon(kind), contentDescription = null, tint = kindColor(kind), modifier = Modifier.size(size * 0.40f)) }
        }
        if (!e.isDir && (kind == FileKind.IMAGE || kind == FileKind.VIDEO)) {
            val req = remember(e.path, e.modified, px) {
                val b = ImageRequest.Builder(ctx)
                    .data(File(e.path))
                    .size(px)
                    .memoryCacheKey("${e.path}|${e.modified}|$px")
                if (kind == FileKind.VIDEO) b.videoFrameMillis(1000)
                b.build()
            }
            AsyncImage(
                model = req,
                contentDescription = null,
                contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
                onSuccess = { loaded = true; (it.result.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap?.let { b -> DragThumbs.put(e.path, b) } },
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(if (size >= 100.dp) 16.dp else 12.dp)),
            )
        }
    }
}

/**
 * Folder with "papers peeking out" (approved mockup, style C). With files: two sheets show above the front panel and the colour is
 * full. Empty: no papers, front panel sits a little higher and the whole icon is muted to 50%, so you can tell what is worth opening.
 * Drawn on a 120x100 grid; the change between the two states animates.
 */
@Composable
fun FolderIcon(modifier: Modifier = Modifier, tint: Color? = null, hasFiles: Boolean = true) {
    val front = tint ?: Color(0xFFFFC93C)
    val back = tint?.let { lerp(it, Color.Black, 0.22f) } ?: Color(0xFFD9A200)
    val amount by androidx.compose.animation.core.animateFloatAsState(
        if (hasFiles) 1f else 0f,
        androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing),
        label = "folderFill",
    )
    Canvas(modifier) {
        val u = minOf(size.width / 120f, size.height / 100f)
        val ox = (size.width - 120f * u) / 2f
        val oy = (size.height - 100f * u) / 2f
        fun x(v: Float) = ox + v * u
        fun y(v: Float) = oy + v * u
        fun Path.q(x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float) = cubicTo(
            x(x0 + 2f / 3f * (cx - x0)), y(y0 + 2f / 3f * (cy - y0)),
            x(x1 + 2f / 3f * (cx - x1)), y(y1 + 2f / 3f * (cy - y1)),
            x(x1), y(y1),
        )
        val whole = 0.5f + 0.5f * amount

        val backPath = Path().apply {
            moveTo(x(10f), y(16f))
            q(10f, 16f, 10f, 8f, 18f, 8f)
            lineTo(x(44f), y(8f))
            q(44f, 8f, 49f, 8f, 52f, 12f)
            lineTo(x(56f), y(17f))
            lineTo(x(102f), y(17f))
            q(102f, 17f, 110f, 17f, 110f, 25f)
            lineTo(x(110f), y(82f))
            q(110f, 82f, 110f, 92f, 100f, 92f)
            lineTo(x(20f), y(92f))
            q(20f, 92f, 10f, 92f, 10f, 82f)
            close()
        }
        drawPath(backPath, back.copy(alpha = whole))

        if (amount > 0.01f) {
            // far sheet, tilted 3 degrees
            rotate(3f, pivot = Offset(x(66f), y(40f))) {
                drawRoundRect(Color(0xFFD6D6DC).copy(alpha = amount), Offset(x(28f), y(14f)), Size(76f * u, 52f * u), CornerRadius(6f * u))
            }
            // near sheet
            drawRoundRect(Color(0xFFF4F4F6).copy(alpha = amount), Offset(x(22f), y(20f)), Size(76f * u, 52f * u), CornerRadius(6f * u))
        }

        val top = 28f + 6f * amount
        val frontPath = Path().apply {
            moveTo(x(10f), y(top + 6f))
            q(10f, top + 6f, 10f, top, 18f, top)
            lineTo(x(102f), y(top))
            q(102f, top, 110f, top, 110f, top + 6f)
            lineTo(x(110f), y(82f))
            q(110f, 82f, 110f, 92f, 100f, 92f)
            lineTo(x(20f), y(92f))
            q(20f, 92f, 10f, 92f, 10f, 82f)
            close()
        }
        drawPath(frontPath, front.copy(alpha = whole))
    }
}

private val hasFilesCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

/** Whether a folder has anything inside; checked off the main thread and remembered so icons don't flicker while scrolling. */
@Composable
fun rememberFolderHasFiles(e: FileEntry): Boolean {
    val key = e.path + "|" + e.modified
    var has by remember(key) { mutableStateOf(hasFilesCache[key] ?: true) }
    LaunchedEffect(key) {
        val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val l = File(e.path).list()
            if (l == null) true else l.isNotEmpty()
        }
        hasFilesCache[key] = r
        has = r
    }
    return has
}

/** The last few thumbnails that were drawn, kept so a drag can show the real pictures in its stack. */
object DragThumbs {
    private val cache = object : android.util.LruCache<String, android.graphics.Bitmap>(64) {}
    fun put(path: String, b: android.graphics.Bitmap) { cache.put(path, b) }
    fun get(path: String): android.graphics.Bitmap? = cache.get(path)
}
