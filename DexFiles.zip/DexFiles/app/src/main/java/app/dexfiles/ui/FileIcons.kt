package app.dexfiles.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import java.io.File

fun kindIcon(kind: FileKind): ImageVector = when (kind) {
    FileKind.FOLDER -> Icons.Filled.Folder
    FileKind.IMAGE -> Icons.Filled.Image
    FileKind.VIDEO -> Icons.Filled.Movie
    FileKind.AUDIO -> Icons.Filled.MusicNote
    FileKind.PDF -> Icons.Filled.PictureAsPdf
    FileKind.DOCUMENT -> Icons.Filled.Description
    FileKind.SHEET -> Icons.Filled.TableChart
    FileKind.SLIDES -> Icons.Filled.Slideshow
    FileKind.ARCHIVE -> Icons.Filled.FolderZip
    FileKind.APK -> Icons.Filled.Android
    FileKind.CODE -> Icons.Filled.Code
    FileKind.TEXT -> Icons.Filled.Notes
    FileKind.OTHER -> Icons.Filled.InsertDriveFile
}

fun kindColor(kind: FileKind): Color = when (kind) {
    FileKind.FOLDER -> Color(0xFFF2B33D)
    FileKind.IMAGE -> Color(0xFF2E9E6B)
    FileKind.VIDEO -> Color(0xFF8E5CD9)
    FileKind.AUDIO -> Color(0xFFE0558F)
    FileKind.PDF -> Color(0xFFE0493E)
    FileKind.DOCUMENT -> Color(0xFF3D7BE0)
    FileKind.SHEET -> Color(0xFF1F9D55)
    FileKind.SLIDES -> Color(0xFFE8803A)
    FileKind.ARCHIVE -> Color(0xFFB07A3F)
    FileKind.APK -> Color(0xFF3DDC84)
    FileKind.CODE -> Color(0xFF1AA7A0)
    FileKind.TEXT -> Color(0xFF7A8794)
    FileKind.OTHER -> Color(0xFF8A94A0)
}

/**
 * Kind icon, replaced by a real thumbnail for photos and videos once it has loaded.
 * crop=false keeps the picture's ORIGINAL aspect ratio (fitted inside the square box, like iPadOS Files).
 */
@Composable
fun FileThumb(e: FileEntry, size: Dp, modifier: Modifier = Modifier, crop: Boolean = true) {
    val kind = e.kind
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }.coerceAtLeast(16)
    var loaded by remember(e.path, e.modified) { mutableStateOf(false) }
    Box(if (modifier == Modifier) Modifier.size(size) else modifier, contentAlignment = Alignment.Center) {
        if (e.isDir) {
            FolderIcon(Modifier.size(size))
        } else if (!loaded) {
            Box(
                Modifier.size(size * 0.92f).clip(RoundedCornerShape(size * 0.28f)).background(kindColor(kind).copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) { Icon(kindIcon(kind), contentDescription = null, tint = kindColor(kind), modifier = Modifier.size(size * 0.52f)) }
        }
        if (!e.isDir && (kind == FileKind.IMAGE || kind == FileKind.VIDEO)) {
            val req = remember(e.path, e.modified, px) {
                val b = ImageRequest.Builder(ctx)
                    .data(File(e.path))
                    .size(px)
                    .memoryCacheKey("${e.path}|${e.modified}|$px")
                if (kind == FileKind.VIDEO) b.videoFrameMillis(1000)
                b.build()
            }
            AsyncImage(
                model = req,
                contentDescription = null,
                contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
                onSuccess = { loaded = true },
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(if (size > 48.dp) 8.dp else 3.dp)),
            )
        }
    }
}

/**
 * Rich yellow folder in the style of One UI / iPadOS: deeper amber back panel with a tab, a cream "paper" strip,
 * a front panel fading from bright yellow to gold, and a soft gloss line. Drawn from a 100x80 design grid so it stays
 * sharp at every size (prototyped as SVG and checked at 200, 110, 64 and 32 px on light and dark backgrounds).
 */
@Composable
fun FolderIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = minOf(size.width / 100f, size.height / 80f)
        val ox = (size.width - 100f * u) / 2f
        val oy = (size.height - 80f * u) / 2f
        fun x(v: Float) = ox + v * u
        fun y(v: Float) = oy + v * u

        // quadratic curve helper built on cubicTo, which exists in every Compose version
        fun Path.q(x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float) = cubicTo(
            x(x0 + 2f / 3f * (cx - x0)), y(y0 + 2f / 3f * (cy - y0)),
            x(x1 + 2f / 3f * (cx - x1)), y(y1 + 2f / 3f * (cy - y1)),
            x(x1), y(y1),
        )

        // ground shadow
        drawOval(Color.Black.copy(alpha = 0.14f), topLeft = Offset(x(10f), y(72.9f)), size = Size(80f * u, 5.2f * u))

        // back panel with tab
        val back = Path().apply {
            moveTo(x(10f), y(8f))
            lineTo(x(36f), y(8f))
            q(36f, 8f, 40f, 8f, 42.5f, 11f)
            lineTo(x(46f), y(15.5f))
            lineTo(x(90f), y(15.5f))
            q(90f, 15.5f, 96f, 15.5f, 96f, 21.5f)
            lineTo(x(96f), y(66f))
            q(96f, 66f, 96f, 72f, 90f, 72f)
            lineTo(x(10f), y(72f))
            q(10f, 72f, 4f, 72f, 4f, 66f)
            lineTo(x(4f), y(14f))
            q(4f, 14f, 4f, 8f, 10f, 8f)
            close()
        }
        drawPath(back, Brush.verticalGradient(listOf(Color(0xFFF7B500), Color(0xFFE89C00)), startY = y(8f), endY = y(72f)))

        // cream paper strip peeking out above the front panel
        drawRoundRect(Color(0xFFFFF1C2), topLeft = Offset(x(9f), y(19f)), size = Size(82f * u, 14f * u), cornerRadius = CornerRadius(3.5f * u))

        // front panel
        val front = Path().apply {
            moveTo(x(4f), y(32f))
            q(4f, 32f, 4f, 26f, 10f, 26f)
            lineTo(x(90f), y(26f))
            q(90f, 26f, 96f, 26f, 96f, 32f)
            lineTo(x(96f), y(66f))
            q(96f, 66f, 96f, 72f, 90f, 72f)
            lineTo(x(10f), y(72f))
            q(10f, 72f, 4f, 72f, 4f, 66f)
            close()
        }
        drawPath(front, Brush.verticalGradient(listOf(Color(0xFFFFD84D), Color(0xFFFFB400)), startY = y(26f), endY = y(72f)))

        // soft gloss along the top edge of the front panel
        drawRoundRect(
            Color.White.copy(alpha = 0.45f),
            topLeft = Offset(x(9f), y(26.8f)),
            size = Size(82f * u, 1.6f * u),
            cornerRadius = CornerRadius(0.8f * u),
        )
    }
}
