package app.dexfiles.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import java.io.File

fun kindIcon(kind: FileKind): ImageVector = when (kind) {
    FileKind.FOLDER -> Icons.Filled.Folder
    FileKind.IMAGE -> Icons.Filled.Image
    FileKind.VIDEO -> Icons.Filled.Movie
    FileKind.AUDIO -> Icons.Filled.MusicNote
    FileKind.PDF -> Icons.Filled.PictureAsPdf
    FileKind.DOCUMENT -> Icons.Filled.Description
    FileKind.SHEET -> Icons.Filled.TableChart
    FileKind.SLIDES -> Icons.Filled.Slideshow
    FileKind.ARCHIVE -> Icons.Filled.FolderZip
    FileKind.APK -> Icons.Filled.Android
    FileKind.CODE -> Icons.Filled.Code
    FileKind.TEXT -> Icons.Filled.Notes
    FileKind.OTHER -> Icons.Filled.InsertDriveFile
}

fun kindColor(kind: FileKind): Color = when (kind) {
    FileKind.FOLDER -> Color(0xFFF2B33D)
    FileKind.IMAGE -> Color(0xFF2E9E6B)
    FileKind.VIDEO -> Color(0xFF8E5CD9)
    FileKind.AUDIO -> Color(0xFFE0558F)
    FileKind.PDF -> Color(0xFFE0493E)
    FileKind.DOCUMENT -> Color(0xFF3D7BE0)
    FileKind.SHEET -> Color(0xFF1F9D55)
    FileKind.SLIDES -> Color(0xFFE8803A)
    FileKind.ARCHIVE -> Color(0xFFB07A3F)
    FileKind.APK -> Color(0xFF3DDC84)
    FileKind.CODE -> Color(0xFF1AA7A0)
    FileKind.TEXT -> Color(0xFF7A8794)
    FileKind.OTHER -> Color(0xFF8A94A0)
}

/** Kind icon, replaced by a real thumbnail for photos and videos once it has loaded. */
@Composable
fun FileThumb(e: FileEntry, size: Dp, modifier: Modifier = Modifier, crop: Boolean = true) {
    val kind = e.kind
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }.coerceAtLeast(16)
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(kindIcon(kind), contentDescription = null, tint = kindColor(kind), modifier = Modifier.size(size * 0.86f))
        if (!e.isDir && (kind == FileKind.IMAGE || kind == FileKind.VIDEO)) {
            val req = remember(e.path, e.modified, px) {
                val b = ImageRequest.Builder(ctx)
                    .data(File(e.path))
                    .size(px)
                    .memoryCacheKey("${e.path}|${e.modified}|$px")
                if (kind == FileKind.VIDEO) b.videoFrameMillis(1000)
                b.build()
            }
            AsyncImage(
                model = req,
                contentDescription = null,
                contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(if (size > 48.dp) 8.dp else 3.dp)),
            )
        }
    }
}
