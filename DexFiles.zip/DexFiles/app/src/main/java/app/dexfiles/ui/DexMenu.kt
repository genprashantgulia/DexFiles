package app.dexfiles.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.PopupProperties
import app.dexfiles.ui2.design.Radius

// One look for every menu and dialog, from the approved mock: popup #26262C with a hairline ring, radius 20, 8 dp inner padding,
// rows 44 high with radius 12, 14/500 text, soft white hover/press fill. Same-package functions with the Material names,
// so every existing call picks them up (files must not import the Material versions).

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun DropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    offset: DpOffset = DpOffset(0.dp, 0.dp),
    properties: PopupProperties = PopupProperties(focusable = true),
    shape: Shape = Radius.l,
    containerColor: Color = Color.Unspecified,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    // A focusable popup takes focus from a text field, so the keyboard would slide away and back every time a menu opens.
    // While the keyboard is up the menu stays non-focusable (taps outside still close it), so the keyboard never moves.
    val imeUp = WindowInsets.isImeVisible
    val props = if (imeUp) PopupProperties(focusable = false, dismissOnClickOutside = true, dismissOnBackPress = true) else properties
    androidx.compose.material3.DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = modifier.widthIn(min = 220.dp),
        offset = offset,
        properties = props,
        shape = shape,
        containerColor = cs.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 18.dp,
        border = BorderStroke(1.dp, cs.onSurface.copy(alpha = 0.10f)),
    ) {
        Column(Modifier.padding(8.dp), content = content)
    }
}

@Composable
fun DropdownMenuItem(
    text: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    val pressed by src.collectIsPressedAsState()
    val fill = when {
        !enabled -> Color.Transparent
        pressed -> cs.onSurface.copy(alpha = 0.14f)
        hovered -> cs.onSurface.copy(alpha = 0.08f)
        else -> Color.Transparent
    }
    val ink = if (enabled) cs.onSurface.copy(alpha = 0.92f) else cs.onSurface.copy(alpha = 0.38f)
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 44.dp)
            .clip(Radius.s)
            .background(fill)
            .hoverable(src)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        CompositionLocalProvider(LocalContentColor provides ink) {
            if (leadingIcon != null) leadingIcon()
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium)) {
                Box(Modifier.weight(1f)) { text() }
            }
            if (trailingIcon != null) {
                CompositionLocalProvider(LocalContentColor provides cs.onSurfaceVariant) { trailingIcon() }
            }
        }
    }
}

@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    shape: Shape = Radius.xl,
    containerColor: Color = Color.Unspecified,
) {
    val cs = MaterialTheme.colorScheme
    val styledTitle: (@Composable () -> Unit)? = if (title != null) {
        { ProvideTextStyle(MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp)) { title() } }
    } else null
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = confirmButton,
        modifier = modifier,
        dismissButton = dismissButton,
        title = styledTitle,
        text = text,
        shape = Radius.xl,
        containerColor = dialogSurface(),
        tonalElevation = 0.dp,
    )
}
