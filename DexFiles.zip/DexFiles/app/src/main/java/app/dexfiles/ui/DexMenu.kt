package app.dexfiles.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.PopupProperties
import app.dexfiles.ui2.design.Radius
import androidx.compose.runtime.getValue

// One look for every menu and dialog, from the approved mock: popup with a hairline ring, radius 16, 6 dp inner padding all round,
// rows 48 high on touch (40 with a mouse) with radius 12, 14/500 text, soft white hover/press fill, greyed rows at 45%. Same-package functions with the Material names,
// so every existing call picks them up (files must not import the Material versions).

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun DropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    offset: DpOffset = DpOffset(0.dp, 0.dp),
    properties: PopupProperties = PopupProperties(focusable = true),
    shape: Shape = Radius.m,
    containerColor: Color = Color.Unspecified,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    // A focusable popup takes focus from a text field, so the keyboard would slide away and back every time a menu opens.
    // While the keyboard is up the menu stays non-focusable (taps outside still close it), so the keyboard never moves.
    val imeUp = WindowInsets.isImeVisible
    val props = if (imeUp) PopupProperties(focusable = false, dismissOnClickOutside = true, dismissOnBackPress = true) else properties
    androidx.compose.material3.DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = modifier.widthIn(min = 220.dp),
        offset = offset,
        properties = props,
        shape = shape,
        containerColor = cs.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 18.dp,
        border = BorderStroke(1.dp, cs.onSurface.copy(alpha = 0.10f)),
    ) {
        // Material adds 8 dp above and below the list; the spec padding is 6 all round, so the sides get 6 and the list is pulled 2 dp
        // into Material's own padding at the top and bottom.
        Column(
            Modifier.padding(horizontal = 6.dp).layout { m, c ->
                val p = m.measure(c)
                val cut = 2.dp.roundToPx()
                layout(p.width, (p.height - cut * 2).coerceAtLeast(0)) { p.place(0, -cut) }
            },
            content = content,
        )
    }
}

@Composable
fun DropdownMenuItem(
    text: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
    /** Greyed rows say why, in a few words, on the right ("one item at a time"); a row is never just missing. */
    note: String? = null,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val hovered by src.collectIsHoveredAsState()
    val pressed by src.collectIsPressedAsState()
    val fill = when {
        !enabled -> Color.Transparent
        pressed -> cs.onSurface.copy(alpha = 0.14f)
        hovered -> cs.onSurface.copy(alpha = 0.08f)
        else -> Color.Transparent
    }
    val ink = if (enabled) cs.onSurface.copy(alpha = 0.92f) else cs.onSurface.copy(alpha = 0.45f)
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = if (app.dexfiles.state.Mods.mouse) 40.dp else 48.dp)
            .clip(Radius.s)
            .background(fill)
            .hoverable(src)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        CompositionLocalProvider(LocalContentColor provides ink) {
            if (leadingIcon != null) leadingIcon()
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium)) {
                Box(Modifier.weight(1f)) { text() }
            }
            if (note != null) androidx.compose.material3.Text(note, fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.45f), maxLines = 1)
            if (trailingIcon != null) {
                CompositionLocalProvider(LocalContentColor provides cs.onSurfaceVariant) { trailingIcon() }
            }
        }
    }
}

@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    shape: Shape = Radius.l,
    containerColor: Color = Color.Unspecified,
) {
    val cs = MaterialTheme.colorScheme
    val styledTitle: (@Composable () -> Unit)? = if (title != null) {
        { ProvideTextStyle(MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp)) { title() } }
    } else null
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = confirmButton,
        modifier = modifier,
        dismissButton = dismissButton,
        title = styledTitle,
        text = text,
        shape = Radius.l,
        containerColor = dialogSurface(),
        tonalElevation = 0.dp,
    )
}

/** The hairline between groups in every menu: 1 dp, 5 dp above and below, 6 dp in from each side. */
@Composable
fun MenuDivider() {
    Box(Modifier.padding(horizontal = 6.dp, vertical = 5.dp).fillMaxWidth().height(1.dp).background(app.dexfiles.ui2.design.LocalPalette.current.hairline))
}
