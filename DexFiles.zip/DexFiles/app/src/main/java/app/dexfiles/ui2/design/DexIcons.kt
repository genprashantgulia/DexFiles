package app.dexfiles.ui2.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/**
 * The mock's icon family: 24 grid, round caps and joins, no fill. Paths are copied from the mock's SVGs, so every icon in
 * the app comes from one family and one stroke weight (1.8 for bar and menu icons, 2.2-2.4 for small marks).
 */
object DexIcons {
    private fun line(name: String, w: Float, vararg d: String, fill: Boolean = false): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
            for (p in d) addPath(
                pathData = addPathNodes(p),
                fill = if (fill) SolidColor(Color.Black) else null,
                stroke = if (fill) null else SolidColor(Color.Black),
                strokeLineWidth = w, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
            )
        }.build()

    val Menu = line("menu", 1.8f, "M4 7h16M4 12h16M4 17h16")
    val Back = line("back", 1.8f, "M15 5l-7 7 7 7")
    val Forward = line("forward", 1.8f, "M9 5l7 7-7 7")
    val ChevronRight = line("chevRight", 2.2f, "M9 5l7 7-7 7")
    val ChevronDown = line("chevDown", 2.4f, "M6 9l6 6 6-6")
    val Close = line("close", 2.2f, "M6 6l12 12M18 6L6 18")
    val Plus = line("plus", 2.2f, "M12 5v14M5 12h14")
    val Check = line("check", 2.6f, "M5 12.5l4.5 4.5L19 7.5")
    val Search = line("search", 1.8f, "M17.5 11a6.5 6.5 0 1 1-13 0a6.5 6.5 0 0 1 13 0z", "M16 16l4.5 4.5")
    val Grid = line("grid", 1.8f, "M6 4h2.5a2 2 0 0 1 2 2v2.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z", "M15.5 4H18a2 2 0 0 1 2 2v2.5a2 2 0 0 1-2 2h-2.5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z", "M6 13.5h2.5a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2.5a2 2 0 0 1 2-2z", "M15.5 13.5H18a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2h-2.5a2 2 0 0 1-2-2v-2.5a2 2 0 0 1 2-2z")
    val More = ImageVector.Builder("more", 24.dp, 24.dp, 24f, 24f).apply {
        for (y in listOf(5.5f, 12f, 18.5f)) addPath(addPathNodes("M12 ${y - 1.8f}a1.8 1.8 0 1 1 0 3.6a1.8 1.8 0 1 1 0-3.6z"), fill = SolidColor(Color.Black))
    }.build()
    val ArrowUp = line("arrowUp", 2.4f, "M12 19V5M6 11l6-6 6 6")
    val ArrowDown = line("arrowDown", 2.4f, "M12 5v14M6 13l6 6 6-6")
    val Reset = line("reset", 2.2f, "M4 12a8 8 0 1 0 2.6-5.9", "M4 4v5h5")
    val Appearance = line("appearance", 1.8f, "M21 12a9 9 0 1 1-18 0a9 9 0 0 1 18 0z", "M12 3a9 9 0 0 0 0 18z")
}
