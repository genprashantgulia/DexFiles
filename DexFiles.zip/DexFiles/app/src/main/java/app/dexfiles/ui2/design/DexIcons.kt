package app.dexfiles.ui2.design

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/**
 * The mock's icon family: 24 grid, round caps and joins, no fill. Paths are copied from the mock's SVGs, so every icon in
 * the app comes from one family and one stroke weight (1.8 for bar and menu icons, 2.2-2.4 for small marks).
 */
object DexIcons {
    private fun line(name: String, w: Float, vararg d: String, fill: Boolean = false): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
            for (p in d) addPath(
                pathData = addPathNodes(p),
                fill = if (fill) SolidColor(Color.Black) else null,
                stroke = if (fill) null else SolidColor(Color.Black),
                strokeLineWidth = w, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
            )
        }.build()

    val Menu = line("menu", 1.8f, "M4 7h16M4 12h16M4 17h16")
    val Back = line("back", 1.8f, "M15 5l-7 7 7 7")
    val Forward = line("forward", 1.8f, "M9 5l7 7-7 7")
    val ChevronRight = line("chevRight", 2.2f, "M9 5l7 7-7 7")
    val ChevronDown = line("chevDown", 2.4f, "M6 9l6 6 6-6")
    val Close = line("close", 2.2f, "M6 6l12 12M18 6L6 18")
    val Plus = line("plus", 2.2f, "M12 5v14M5 12h14")
    val Check = line("check", 2.6f, "M5 12.5l4.5 4.5L19 7.5")
    val Search = line("search", 1.8f, "M17.5 11a6.5 6.5 0 1 1-13 0a6.5 6.5 0 0 1 13 0z", "M16 16l4.5 4.5")
    val Grid = line("grid", 1.8f, "M6 4h2.5a2 2 0 0 1 2 2v2.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z", "M15.5 4H18a2 2 0 0 1 2 2v2.5a2 2 0 0 1-2 2h-2.5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z", "M6 13.5h2.5a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2.5a2 2 0 0 1 2-2z", "M15.5 13.5H18a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2h-2.5a2 2 0 0 1-2-2v-2.5a2 2 0 0 1 2-2z")
    val More = ImageVector.Builder("more", 24.dp, 24.dp, 24f, 24f).apply {
        for (y in listOf(5.5f, 12f, 18.5f)) addPath(addPathNodes("M12 ${y - 1.8f}a1.8 1.8 0 1 1 0 3.6a1.8 1.8 0 1 1 0-3.6z"), fill = SolidColor(Color.Black))
    }.build()
    val ArrowUp = line("arrowUp", 2.4f, "M12 19V5M6 11l6-6 6 6")
    val ArrowDown = line("arrowDown", 2.4f, "M12 5v14M6 13l6 6 6-6")
    val Reset = line("reset", 2.2f, "M4 12a8 8 0 1 0 2.6-5.9", "M4 4v5h5")
    val Appearance = line("appearance", 1.8f, "M21 12a9 9 0 1 1-18 0a9 9 0 0 1 18 0z", "M12 3a9 9 0 0 0 0 18z")

    // Sidebar and category set (mock Sidebar board), stroke 1.8.
    val Recent = line("recent", 1.8f, "M21 12a9 9 0 1 1-18 0a9 9 0 0 1 18 0z", "M12 7v5l3 2")
    val Images = line("images", 1.8f, "M6 4h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z", "M10.6 10a1.6 1.6 0 1 1-3.2 0a1.6 1.6 0 0 1 3.2 0z", "M4 18l5-5 4 4 3-3 4 4")
    val Videos = line("videos", 1.8f, "M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z", "M10 9.5v5l4.5-2.5z")
    val Audio = line("audio", 1.8f, "M9 18V6l10-2v12", "M9.5 18a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0z", "M19.5 16a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0z")
    val Document = line("document", 1.8f, "M7 3h7l5 5v13H7z", "M14 3v5h5")
    val Download = line("download", 1.8f, "M12 4v11M8 11l4 4 4-4", "M5 19h14")
    val Apk = line("apk", 1.8f, "M12 3l8 4v10l-8 4-8-4V7z", "M4 7l8 4 8-4M12 11v10")
    val Phone = line("phone", 1.8f, "M8 3h8a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3z", "M10 18h4")
    val SdCard = line("sdcard", 1.8f, "M8 3h8l3 3v15H5V6z", "M9 7v3M12 7v3M15 7v3")
    val Trash = line("trash", 1.8f, "M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13")
    val Analyze = line("analyze", 1.8f, "M4 20V10M10 20V4M16 20v-7M21 20H3")
    val Settings = line("settings", 1.8f, "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z","M15 12a3 3 0 1 1-6 0a3 3 0 0 1 6 0z")
    // Selection pill and menus (mock Select board), stroke 1.8.
    val Move = line("move", 1.8f, "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M10 13h5M13 10.5l2.5 2.5-2.5 2.5")
    val Copy = line("copy", 1.8f, "M11 8h6a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3v-6a3 3 0 0 1 3-3z", "M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2")
    val Share = line("share", 1.8f, "M12 15V4M8 8l4-4 4 4", "M5 12v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6")
    val MoreH = ImageVector.Builder("moreH", 24.dp, 24.dp, 24f, 24f).apply {
        for (x in listOf(5.5f, 12f, 18.5f)) addPath(addPathNodes("M${x - 1.8f} 12a1.8 1.8 0 1 1 3.6 0a1.8 1.8 0 1 1-3.6 0z"), fill = SolidColor(Color.Black))
    }.build()
    val Rename = line("rename", 1.8f, "M4 20h4L19 9l-4-4L4 16z")
    val Compress = line("compress", 1.8f, "M7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z", "M12 4v10M9 11l3 3 3-3")
    val Info = line("info", 1.8f, "M21 12a9 9 0 1 1-18 0a9 9 0 0 1 18 0z", "M12 11v6M12 7.5v.5")
    val Cut = line("cut", 1.8f, "M9 6a3 3 0 1 1-6 0a3 3 0 0 1 6 0z", "M9 18a3 3 0 1 1-6 0a3 3 0 0 1 6 0z", "M20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12")
    val SelectAll = line("selectAll", 1.8f, "M7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z", "M8.5 12.5l2.5 2.5 4.5-5")
    val Folder = line("folder", 1.8f, "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z")
    val List = line("list", 1.8f, "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01")
    val Details = line("details", 1.8f, "M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", "M4 9h16", "M10 9v11")
    val Gallery = line("gallery", 1.8f, "M5 4h4a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", "M15 4h4a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", "M15 13h4a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z", "M5 16h4a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1z")
    val DualPane = line("dualpane", 1.8f, "M4 5a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z", "M13 5a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1z")
    val Columns = line("columns", 2f, "M4 5v14M10 5v14M16 5v14M21 5v14")
    val Paste = line("paste", 1.8f, "M9 4h6v3H9z", "M15 5h2a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2")
    val NewFile = line("newFile", 1.8f, "M7 3h7l5 5v13H7z", "M14 3v5h5M12 12v5M9.5 14.5h5")
    val NewFolder = line("newFolder", 1.8f, "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M12 10v5M9.5 12.5h5")
    val Keyboard = line("keyboard", 1.8f, "M6 6h12a3 3 0 0 1 3 3v6a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3z", "M7 10h.01M11 10h.01M15 10h.01M8 14h8")
    val Sort = line("sort", 1.8f, "M4 7h16M7 12h10M10 17h4")
    val Eye = line("eye", 1.8f, "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z", "M15 12a3 3 0 1 1-6 0a3 3 0 0 1 6 0z")
    val Tap = line("tap", 1.8f, "M12 4v7M9 8l3-4 3 4", "M5 14a7 7 0 0 0 14 0")
    val Sidebar = line("sidebar", 1.8f, "M7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z", "M9.5 4v16")
    val Preview = line("preview", 1.8f, "M7 4h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z", "M14.5 4v16")
    val OpenIn = line("openIn", 1.8f, "M14 4h6v6", "M20 4l-9 9", "M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5")
    val NewTab = line("newTab", 1.8f, "M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z", "M12 10v6M9 13h6")
    val Star = line("star", 1.8f, "M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.6l1-5.8L3.5 9.7l5.9-.9z")
    val Link = line("link", 1.8f, "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1", "M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1")
    val Home = line("home", 1.8f, "M4 11l8-7 8 7", "M6 10v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-9")
}
