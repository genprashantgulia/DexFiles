package app.dexfiles.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.dexfiles.core.QuickIndex
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.ViewMode
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One line in the palette: a folder to jump to or a command to run. */
private class Pick(val title: String, val hint: String, val icon: ImageVector, val run: () -> Unit)

private const val MAX_SHOWN = 12

/**
 * Ctrl+K. One box, two kinds of answer: type a folder name to jump there in the current tab, or a command name to run it.
 * Up/Down move, Enter runs, Esc closes. Results are scored off the UI thread and a newer keystroke cancels the older search.
 */
@Composable
fun Palette(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf(TextFieldValue("")) }
    var index by remember { mutableIntStateOf(0) }
    var folders by remember { mutableStateOf<List<Pick>>(emptyList()) }
    val focus = remember { FocusRequester() }
    val list = rememberLazyListState()
    fun close() { vm.dialog = null }

    val commands = remember(vm) { commandsOf(vm) { close() } }
    val words = QuickIndex.words(query.text)

    LaunchedEffect(query.text, vm.quickFolders) {
        val w = QuickIndex.words(query.text)
        folders = if (w.isEmpty()) emptyList() else withContext(Dispatchers.Default) {
            vm.quickFolders.asSequence()
                .map { p -> p to QuickIndex.score(w, p.substringAfterLast('/'), p) }
                .filter { it.second >= 0 }
                .sortedByDescending { it.second }
                .take(MAX_SHOWN)
                .map { (p, _) ->
                    Pick(p.substringAfterLast('/'), where(p.substringBeforeLast('/', "")), DexIcons.Folder) {
                        close(); vm.navigate(vm.current, p)
                    }
                }
                .toList()
        }
    }

    val shownCommands = if (words.isEmpty()) commands else commands.filter { QuickIndex.score(words, it.title, it.title) >= 0 }
    val picks = (folders + shownCommands).take(MAX_SHOWN)
    val sel = index.coerceIn(0, (picks.size - 1).coerceAtLeast(0))

    LaunchedEffect(query.text) { index = 0 }
    LaunchedEffect(sel) { if (picks.isNotEmpty()) list.animateScrollToItem((sel - 3).coerceAtLeast(0)) }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Dialog(onDismissRequest = ::close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { close() } }.padding(horizontal = 24.dp, vertical = 72.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Surface(
                shape = Radius.xl,
                color = dialogSurface(),
                shadowElevation = 24.dp,
                border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
                modifier = Modifier.widthIn(max = 620.dp).fillMaxWidth().pointerInput(Unit) { detectTapGestures { } },
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DexField(
                        value = query,
                        onChange = { query = it },
                        hint = "Jump to a folder or run a command",
                        imeDone = { picks.getOrNull(sel)?.run?.invoke() },
                        modifier = Modifier.focusRequester(focus).onPreviewKeyEvent { ev ->
                            if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                            when (ev.key) {
                                Key.DirectionDown -> { index = (sel + 1).coerceAtMost(picks.size - 1); true }
                                Key.DirectionUp -> { index = (sel - 1).coerceAtLeast(0); true }
                                Key.Enter, Key.NumPadEnter -> { picks.getOrNull(sel)?.run?.invoke(); true }
                                Key.Escape -> { close(); true }
                                else -> false
                            }
                        },
                    )
                    if (picks.isEmpty()) {
                        Text(
                            if (vm.quickIndexing) "Looking through your folders…" else "Nothing matches “${query.text.trim()}”",
                            fontSize = 14.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                        )
                    } else {
                        LazyColumn(Modifier.heightIn(max = 440.dp), state = list) {
                            itemsIndexed(picks) { i, p -> PickRow(p, i == sel) { p.run() } }
                        }
                        if (vm.quickIndexing) {
                            Text("Still indexing folders…", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PickRow(p: Pick, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(Radius.m).background(if (selected) Sel.plate() else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(p.icon, null, Modifier.size(20.dp), tint = if (selected) cs.primary else cs.onSurfaceVariant)
        Text(p.title, fontSize = 15.sp, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        Text(p.hint, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}

/** "/storage/emulated/0/Documents/Tax" becomes "Internal storage › Documents › Tax". */
private fun where(parent: String): String =
    parent.replace("/storage/emulated/0", "Internal storage").trim('/').replace("/", " › ")

private fun commandsOf(vm: ExplorerViewModel, close: () -> Unit): List<Pick> {
    fun cmd(title: String, hint: String, icon: ImageVector, run: () -> Unit) = Pick(title, hint, icon) { close(); run() }
    val tab = vm.current
    return listOf(
        cmd("New folder", "Ctrl+Shift+N", DexIcons.Folder) { vm.requestNew(true) },
        cmd("New file", "", DexIcons.Plus) { vm.requestNew(false) },
        cmd("New tab", "Ctrl+T", DexIcons.Plus) { vm.newTab() },
        cmd("Go to Home", "", DexIcons.Home) { vm.navigate(tab, Loc.HOME) },
        cmd("Open Trash", "", DexIcons.Trash) { vm.navigate(tab, Loc.TRASH) },
        cmd("Analyze storage", "", DexIcons.Analyze) { vm.navigate(tab, Loc.ANALYZE) },
        cmd("Show hidden files", if (vm.showHidden) "On" else "Off", DexIcons.Eye) { vm.setShowHidden(!vm.showHidden) },
        cmd("Toggle sidebar", "Ctrl+B", DexIcons.Sidebar) { vm.setSidebarVisible(!vm.sidebarVisible) },
        cmd("View as list", "Ctrl+2", DexIcons.List) { vm.setViewMode(tab, ViewMode.LIST) },
        cmd("View as thumbnails", "Ctrl+3", DexIcons.Grid) { vm.setViewMode(tab, ViewMode.GRID) },
        cmd("View as columns", "Ctrl+4", DexIcons.Columns) { vm.setViewMode(tab, ViewMode.COLUMNS) },
        cmd("Settings", "", DexIcons.Settings) { vm.openSettings(false) },
        cmd("Keyboard shortcuts", "F1", DexIcons.Keyboard) { vm.dialog = DialogState.Shortcuts },
        cmd("Recent operations", "", DexIcons.Reset) { vm.navigate(tab, Loc.HISTORY) },
    )
}
