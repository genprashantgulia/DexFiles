package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode

fun viewModeIcon(m: ViewMode): ImageVector = when (m) {
    ViewMode.DETAILS -> DexIcons.Details
    ViewMode.LIST -> DexIcons.List
    ViewMode.GRID -> DexIcons.Grid
    ViewMode.COLUMNS -> DexIcons.Columns
    ViewMode.GALLERY -> DexIcons.Gallery
}



// ---------------------------------------------------------------------------------------------- address bar


@Composable
private fun Crumb(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodyMedium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.clip(Radius.xs).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
    )
}

// ---------------------------------------------------------------------------------------------- search


// ---------------------------------------------------------------------------------------------- command bar


@Composable
fun MenuHint(text: String) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
}


/** The icon of the view the tab is in now: a Details-style List shows the table glyph, and the glyph cross-fades when the view changes. */
@Composable
fun CurrentViewIcon(vm: app.dexfiles.state.ExplorerViewModel, tab: TabState): ImageVector {
    val m = tab.viewMode
    return if (m == ViewMode.LIST && vm.detailsColumns) DexIcons.Details else viewModeIcon(m)
}

/** Switch-style menu row: icon in front (amber while on), shortcut and a tick at the end. */
@Composable
fun ToggleMenuRow(label: String, icon: ImageVector, on: Boolean, shortcut: String? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp), tint = if (on) cs.tertiary else cs.onSurface) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (shortcut != null) MenuHint(shortcut)
                Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) { if (on) Icon(DexIcons.Check, null, Modifier.size(18.dp), tint = cs.tertiary) }
            }
        },
        enabled = enabled,
        onClick = onClick,
    )
}
