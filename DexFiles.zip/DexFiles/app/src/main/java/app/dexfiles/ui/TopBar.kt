package app.dexfiles.ui

import androidx.compose.material.icons.filled.Collections
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.TableRows
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.delay
import java.io.File

fun viewModeIcon(m: ViewMode): ImageVector = when (m) {
    ViewMode.DETAILS -> Icons.Filled.TableRows
    ViewMode.LIST -> Icons.Filled.ViewList
    ViewMode.GRID -> Icons.Filled.GridView
    ViewMode.COLUMNS -> Icons.Filled.ViewColumn
    ViewMode.GALLERY -> Icons.Filled.Collections
}

@Composable
fun CheckItem(label: String, checked: Boolean, shortcut: String? = null, onClick: () -> Unit) {
    val trailing: (@Composable () -> Unit)? = if (shortcut != null) ({ MenuHint(shortcut) }) else null
    DropdownMenuItem(
        text = { Text(label, style = MaterialTheme.typography.bodyMedium) },
        onClick = onClick,
        leadingIcon = {
            if (checked) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            else Spacer(Modifier.size(18.dp))
        },
        trailingIcon = trailing,
    )
}

@Composable
fun TopBar(vm: ExplorerViewModel, compact: Boolean) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    Column(Modifier.fillMaxWidth().background(cs.surface)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            IconBtn(Icons.Filled.Menu, "Sidebar (Ctrl+B)", active = vm.sidebarVisible) { vm.setSidebarVisible(!vm.sidebarVisible) }
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Back (Alt+Left)", enabled = tab.back.isNotEmpty() || tab.isSearch) { vm.goBack(tab) }
            IconBtn(Icons.AutoMirrored.Filled.ArrowForward, "Forward (Alt+Right)", enabled = tab.forward.isNotEmpty()) { vm.goForward(tab) }
            IconBtn(Icons.Filled.ArrowUpward, "Up (Alt+Up)", enabled = vm.canGoUp(tab)) { vm.goUp(tab) }
            IconBtn(Icons.Filled.Refresh, "Refresh (Ctrl+R)") { vm.refresh(tab) }
            Spacer(Modifier.width(4.dp))
            AddressBar(vm, tab, Modifier.weight(1f))
            Spacer(Modifier.width(4.dp))
            SearchField(vm, tab, Modifier.width(if (compact) 150.dp else 260.dp))
        }
        CommandBar(vm, tab, compact)
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
    }
}

// ---------------------------------------------------------------------------------------------- address bar

@Composable
internal fun AddressBar(vm: ExplorerViewModel, tab: TabState, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var editing by remember(tab.id) { mutableStateOf(false) }
    var text by remember { mutableStateOf(TextFieldValue("")) }
    var lastTick by remember { mutableIntStateOf(vm.addressTick) }

    fun startEdit() {
        val t = if (tab.isVirtual) "" else tab.path
        text = TextFieldValue(t, TextRange(0, t.length))
        editing = true
    }

    LaunchedEffect(vm.addressTick) {
        if (vm.addressTick != lastTick) {
            lastTick = vm.addressTick
            startEdit()
        }
    }
    LaunchedEffect(editing) {
        if (editing) {
            delay(30)
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    fun commit() {
        val typed = text.text.trim()
        editing = false
        focusManager.clearFocus()
        vm.typing = false
        if (typed.isEmpty()) return
        val base = if (tab.isVirtual) vm.primaryRoot else tab.path
        val resolved = PathUtils.resolveTyped(base, typed, vm.primaryRoot)
        val f = File(resolved)
        when {
            f.isDirectory -> vm.navigate(tab, resolved)
            f.exists() -> vm.reveal(resolved)
            else -> vm.toast("Can't find \"$typed\"")
        }
    }

    if (editing) {
        DexTextField(
            value = text,
            onValueChange = { text = it },
            modifier = modifier,
            placeholder = "Type a path, for example /storage/emulated/0/Download",
            focusRequester = focus,
            onEnter = { commit() },
            onEscape = { editing = false; focusManager.clearFocus(); vm.typing = false },
            onFocusChange = { f ->
                vm.typing = f
                if (!f && editing) editing = false
            },
        )
        return
    }

    val shape = RoundedCornerShape(8.dp)
    val labels = vm.rootLabelMap()
    val scroll = rememberScrollState()
    val crumbs = if (tab.isVirtual || tab.isSearch) emptyList() else PathUtils.crumbs(tab.path, labels)
    LaunchedEffect(tab.path, crumbs.size) {
        delay(30)
        scroll.scrollTo(scroll.maxValue)
    }
    Row(
        modifier
            .height(36.dp)
            .clip(shape)
            .background(cs.surfaceVariant.copy(alpha = 0.55f))
            .clickable { startEdit() }
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.padding(horizontal = 4.dp).size(16.dp), tint = cs.onSurface.copy(alpha = 0.7f))
        Row(Modifier.weight(1f).horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically) {
            if (tab.isSearch) {
                val where = tab.searchRoot?.let { Loc.title(it, labels) } ?: ""
                Text(
                    if (tab.query.isBlank()) "Search" else "Results for \"${tab.query}\" in $where",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 6.dp),
                    maxLines = 1,
                )
            } else if (tab.isVirtual) {
                Crumb(Loc.title(tab.path, labels), onClick = { startEdit() })
            } else {
                crumbs.forEachIndexed { i, c ->
                    if (i > 0) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, modifier = Modifier.size(16.dp), tint = cs.onSurface.copy(alpha = 0.5f))
                    Crumb(c.label, onClick = { vm.navigate(tab, c.path) })
                }
            }
        }
    }
}

@Composable
private fun Crumb(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodyMedium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.clip(RoundedCornerShape(5.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
    )
}

// ---------------------------------------------------------------------------------------------- search

@Composable
internal fun SearchField(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, autoFocus: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var lastTick by remember { mutableIntStateOf(vm.searchTick) }
    var tv by remember { mutableStateOf(TextFieldValue(tab.query)) }

    LaunchedEffect(vm.searchTick) {
        if (vm.searchTick != lastTick) {
            lastTick = vm.searchTick
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    LaunchedEffect(tab.id, tab.query) {
        if (tab.query != tv.text) tv = TextFieldValue(tab.query)
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    LaunchedEffect(Unit) {
        if (autoFocus) {
            delay(60)
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    val where = Loc.title(if (tab.isVirtual) vm.primaryRoot else tab.path, vm.rootLabelMap())
    DexTextField(
        value = tv,
        onValueChange = { tv = it; vm.setQuery(tab, it.text) },
        modifier = modifier,
        placeholder = "Search $where",
        leading = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(16.dp), tint = cs.onSurface.copy(alpha = 0.6f)) },
        trailing = {
            if (tv.text.isNotEmpty()) {
                Icon(
                    Icons.Filled.Close, contentDescription = "Clear search",
                    modifier = Modifier.size(16.dp).clip(RoundedCornerShape(8.dp)).clickable { tv = TextFieldValue(""); vm.clearSearch(tab) },
                    tint = cs.onSurface.copy(alpha = 0.7f),
                )
            } else {
                Icon(
                    Icons.Filled.Info, contentDescription = "Search tips",
                    modifier = Modifier.size(16.dp).clip(RoundedCornerShape(8.dp)).clickable {
                        vm.dialog = DialogState.Message(
                            "Search tips",
                            listOf(
                                "Type words to match file names. * and ? work as wildcards.",
                                "kind:image  kind:video  kind:audio  kind:pdf  kind:doc  kind:sheet  kind:slides  kind:archive  kind:apk  kind:code  kind:text  kind:folder",
                                "ext:pdf   matches a file extension",
                                "size>10mb   size<500kb   (units: b, kb, mb, gb, tb)",
                                "newer:7d   (h hours, d days, w weeks, m months, y years)",
                                "Combine them, for example:  invoice ext:pdf newer:30d",
                                "Search covers the current folder and everything inside it. From Home it covers all of internal storage.",
                            ),
                        )
                    },
                    tint = cs.onSurface.copy(alpha = 0.45f),
                )
            }
        },
        focusRequester = focus,
        onEnter = { focusManager.clearFocus(); vm.typing = false },
        onEscape = { tv = TextFieldValue(""); vm.clearSearch(tab); focusManager.clearFocus(); vm.typing = false },
        onFocusChange = { vm.typing = it },
    )
}

// ---------------------------------------------------------------------------------------------- command bar

@Composable
private fun CommandBar(vm: ExplorerViewModel, tab: TabState, compact: Boolean) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    val has = sel.isNotEmpty()
    val canWrite = !tab.isVirtual && !tab.isSearch
    val inTrash = tab.path == Loc.TRASH
    var newMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var viewMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        Modifier.weight(1f).horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(1.dp),
      ) {
        if (inTrash) {
            BarBtn("Restore", Icons.Filled.Restore, enabled = has, showLabel = !compact) { vm.restoreSelected(tab) }
            BarBtn("Delete forever", Icons.Filled.DeleteForever, enabled = has, showLabel = !compact) { vm.requestDelete(permanent = true, tab = tab) }
            BarBtn("Empty Trash", Icons.Filled.Delete, showLabel = !compact) { vm.dialog = DialogState.EmptyTrash }
        } else {
            Box {
                BarBtn("New", Icons.Filled.CreateNewFolder, enabled = canWrite, showLabel = !compact) { newMenu = true }
                DropdownMenu(shape = RoundedCornerShape(20.dp), containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = newMenu, onDismissRequest = { newMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Folder") },
                        leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null, Modifier.size(18.dp)) },
                        onClick = { newMenu = false; vm.requestNew(true) },
                    )
                    DropdownMenuItem(
                        text = { Text("Text file") },
                        leadingIcon = { Icon(Icons.Filled.NoteAdd, null, Modifier.size(18.dp)) },
                        onClick = { newMenu = false; vm.requestNew(false) },
                    )
                }
            }
            BarSep()
            IconBtn(Icons.Filled.ContentCut, "Cut (Ctrl+X)", enabled = has) { vm.copySelection(true, tab) }
            IconBtn(Icons.Filled.ContentCopy, "Copy (Ctrl+C)", enabled = has) { vm.copySelection(false, tab) }
            IconBtn(Icons.Filled.ContentPaste, "Paste (Ctrl+V)", enabled = vm.clip != null && canWrite) { vm.paste() }
            IconBtn(Icons.Filled.DriveFileRenameOutline, "Rename (F2)", enabled = has && tab.path != Loc.TRASH) { vm.requestRename(tab) }
            IconBtn(Icons.Filled.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
            IconBtn(Icons.Filled.Delete, "Delete (Del)", enabled = has) { vm.requestDelete(tab = tab) }
            if (vm.dual) {
                BarSep()
                BarBtn("Copy to other pane (F5)", null, enabled = has && !compact) { vm.transferToOtherPane(false) }
                BarBtn("Move to other pane (F6)", null, enabled = has && !compact) { vm.transferToOtherPane(true) }
            }
        }

      }
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        Box {
            BarBtn("Sort", Icons.Filled.Sort, showLabel = !compact) { sortMenu = true }
            DropdownMenu(shape = RoundedCornerShape(20.dp), containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                val spec = tab.effectiveSort
                for (k in SortKey.entries) {
                    CheckItem(k.label, spec.key == k) { vm.setSort(tab, k); sortMenu = false }
                }
                HorizontalDivider()
                CheckItem("Ascending", spec.ascending) { vm.setSortAscending(tab, true); sortMenu = false }
                CheckItem("Descending", !spec.ascending) { vm.setSortAscending(tab, false); sortMenu = false }
                HorizontalDivider()
                CheckItem("Folders first", vm.foldersFirst) { vm.setFoldersFirst(!vm.foldersFirst) }
            }
        }
        Box {
            BarBtn("View", viewModeIcon(tab.viewMode), showLabel = !compact) { viewMenu = true }
            DropdownMenu(shape = RoundedCornerShape(20.dp), containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = viewMenu, onDismissRequest = { viewMenu = false }) {
                val shortcuts = listOf("Ctrl+1", "Ctrl+2", "Ctrl+3", "Ctrl+4")
                ViewMode.entries.filter { it != ViewMode.DETAILS }.forEachIndexed { i, m ->
                    DropdownMenuItem(
                        text = { Text(m.label) },
                        leadingIcon = { Icon(viewModeIcon(m), null, Modifier.size(18.dp), tint = if (tab.viewMode == m) cs.primary else cs.onSurface) },
                        trailingIcon = { Text(shortcuts[i], style = MaterialTheme.typography.labelSmall, color = cs.onSurface.copy(alpha = 0.55f)) },
                        onClick = { vm.setViewMode(tab, m); viewMenu = false },
                    )
                }
            }
        }
        IconBtn(Icons.Filled.VerticalSplit, "Dual pane (F9)", active = vm.dual) { vm.setDual(!vm.dual) }
        Box {
            IconBtn(Icons.Filled.MoreVert, "More") { moreMenu = true }
            DropdownMenu(shape = RoundedCornerShape(20.dp), containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                CheckItem("Show hidden files", vm.showHidden, "Ctrl+H") { vm.setShowHidden(!vm.showHidden); moreMenu = false }
                CheckItem("Preview pane", vm.previewVisible, "Alt+P") { vm.setPreviewVisible(!vm.previewVisible); moreMenu = false }
                CheckItem("Sidebar", vm.sidebarVisible, "Ctrl+B") { vm.setSidebarVisible(!vm.sidebarVisible); moreMenu = false }
                HorizontalDivider()
                DropdownMenuItem(text = { Text("Select all") }, onClick = { moreMenu = false; vm.selectAll(tab) }, trailingIcon = { MenuHint("Ctrl+A") })
                DropdownMenuItem(text = { Text("Invert selection") }, onClick = { moreMenu = false; vm.invertSelection(tab) })
                DropdownMenuItem(
                    text = { Text("New window") },
                    onClick = { moreMenu = false; vm.openInNewWindow(if (tab.isVirtual) null else tab.path) },
                    trailingIcon = { MenuHint("Ctrl+N") },
                )
                HorizontalDivider()
                DropdownMenuItem(text = { Text("Settings") }, onClick = { moreMenu = false; vm.navigate(tab, app.dexfiles.state.Loc.SETTINGS) })
                DropdownMenuItem(text = { Text("Keyboard shortcuts") }, onClick = { moreMenu = false; vm.dialog = DialogState.Shortcuts }, trailingIcon = { MenuHint("F1") })
            }
        }
      }
    }
}

@Composable
fun MenuHint(text: String) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
}

@Composable
private fun BarSep() {
    Box(Modifier.padding(horizontal = 5.dp).width(1.dp).height(20.dp).background(MaterialTheme.colorScheme.outlineVariant))
}
