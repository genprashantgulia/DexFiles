package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.dexfiles.core.FileKind
import app.dexfiles.core.Listing
import app.dexfiles.core.PathUtils
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Samsung My Files floating action pill: Move, Copy, Share, Delete, More. Appears only while items are selected. */
@Composable
fun SelectionPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    var more by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<Boolean?>(null) } // true = move, false = copy
    val canWrite = !tab.isVirtual || tab.path == Loc.TRASH

    Surface(
        modifier,
        shape = RoundedCornerShape(32.dp),
        color = cs.surfaceContainerHigh,
        shadowElevation = 10.dp,
        tonalElevation = 2.dp,
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (inTrash) {
                PillAction(Icons.Filled.Restore, "Restore") { vm.restoreSelected(tab) }
                PillAction(Icons.Filled.DeleteForever, "Delete") { vm.requestDelete(permanent = true, tab = tab) }
            } else {
                PillAction(Icons.Filled.DriveFileMove, "Move") { sheet = true }
                PillAction(Icons.Filled.ContentCopy, "Copy") { sheet = false }
                PillAction(Icons.Filled.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
                PillAction(Icons.Filled.Delete, "Delete") { vm.requestDelete(tab = tab) }
                Box {
                    PillAction(Icons.Filled.MoreHoriz, "More") { more = true }
                    DropdownMenu(
                        shape = RoundedCornerShape(20.dp),
                        containerColor = cs.surfaceContainerHigh,
                        expanded = more,
                        onDismissRequest = { more = false },
                    ) {
                        PillMenuItem("Rename", Icons.Filled.DriveFileRenameOutline, enabled = sel.size == 1 && canWrite) { more = false; vm.requestRename(tab) }
                        PillMenuItem("Cut to clipboard", Icons.Filled.ContentCut) { more = false; vm.copySelection(true, tab) }
                        PillMenuItem("Copy to clipboard", Icons.Filled.ContentCopy) { more = false; vm.copySelection(false, tab) }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        PillMenuItem("Select all", Icons.Filled.SelectAll) { more = false; vm.selectAll(tab) }
                        PillMenuItem("Invert selection", Icons.Filled.SelectAll) { more = false; vm.invertSelection(tab) }
                        PillMenuItem("Copy path", Icons.Filled.ContentCopy) { more = false; vm.copyPath(sel) }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        PillMenuItem("Details", Icons.Filled.Info) { more = false; vm.dialog = DialogState.Properties(sel) }
                    }
                }
            }
        }
    }
    sheet?.let { move -> DestinationSheet(vm, tab, move) { sheet = null } }
}

@Composable
private fun PillMenuItem(label: String, icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
        enabled = enabled,
        onClick = onClick,
    )
}

@Composable
private fun PillAction(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(RoundedCornerShape(22.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Spacer(Modifier.size(2.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = c, maxLines = 1)
    }
}

/** "Move to" / "Copy to": browse to a folder, then confirm. Storage list at the top level, folders below it. */
@Composable
fun DestinationSheet(vm: ExplorerViewModel, tab: TabState, move: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var dir by remember { mutableStateOf<String?>(null) }
    val volumePaths = vm.volumes.map { it.path }
    val folders by produceState(initialValue = emptyList<app.dexfiles.core.FileEntry>(), dir, vm.showHidden) {
        val d = dir
        value = if (d == null) emptyList() else withContext(Dispatchers.IO) {
            runCatching { Listing.list(File(d), vm.showHidden).filter { it.isDir } }.getOrDefault(emptyList())
        }
    }
    val verb = if (move) "Move" else "Copy"
    val here = dir
    val crumbs = if (here == null) emptyList() else PathUtils.crumbs(here, vm.rootLabelMap())

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth(0.94f).widthIn(max = 560.dp).heightIn(max = 640.dp),
            shape = RoundedCornerShape(Dimens.radiusSheet),
            color = cs.surfaceContainerHigh,
        ) {
            Column(Modifier.padding(vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (here != null) {
                        IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Up", size = 44.dp) {
                            dir = if (here in volumePaths) null else File(here).parent
                        }
                    }
                    Text(
                        "$verb to",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f).padding(start = if (here != null) 4.dp else 12.dp),
                    )
                    IconBtn(Icons.Filled.Close, "Cancel", size = 44.dp) { onDismiss() }
                }
                if (here != null) {
                    Text(
                        crumbs.joinToString("  ›  ") { it.label },
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    )
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                LazyColumn(Modifier.weight(1f, fill = false), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
                    if (here == null) {
                        items(vm.volumes, key = { it.path }) { v ->
                            DestRow(v.label, null) { dir = v.path }
                        }
                    } else {
                        items(folders, key = { it.path }) { f -> DestRow(f.name, f) { dir = f.path } }
                        if (folders.isEmpty()) item {
                            Text("No folders here", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(20.dp))
                        }
                    }
                }
                HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (here != null) {
                        TextButton(onClick = { vm.dialog = DialogState.NewItem(true, here) }) { Text("New folder") }
                        Spacer(Modifier.weight(1f))
                    }
                    Button(
                        enabled = here != null,
                        onClick = { onDismiss(); vm.transferSelectionTo(here!!, move, tab) },
                    ) { Text("$verb here") }
                }
            }
        }
    }
}

@Composable
private fun DestRow(name: String, entry: app.dexfiles.core.FileEntry?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().height(Dimens.touch + 8.dp).clip(RoundedCornerShape(Dimens.radiusRow)).clickable(onClick = onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (entry != null) FileThumb(entry, 36.dp) else Icon(Icons.Filled.DriveFileMove, null, Modifier.size(28.dp), tint = cs.primary)
        Text(name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(Icons.Filled.ChevronRight, null, tint = cs.onSurfaceVariant)
    }
}
