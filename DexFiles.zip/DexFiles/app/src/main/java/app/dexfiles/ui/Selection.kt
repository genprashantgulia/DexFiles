package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.DriveFileMove
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.Share
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.pressScale
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.width
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.dexfiles.core.FileKind
import app.dexfiles.core.Listing
import app.dexfiles.core.PathUtils
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Samsung My Files floating action pill: Move, Copy, Share, Delete, More. Appears only while items are selected. */
@Composable
fun SelectionPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    var more by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf<Boolean?>(null) } // true = move, false = copy
    val canWrite = !tab.isVirtual || tab.path == Loc.TRASH

    Surface(
        modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(38.dp),
        color = if (cs.background == Color.Black) Color(0xFF232328) else cs.surfaceContainerHigh,
        shadowElevation = 24.dp,
        tonalElevation = 0.dp,
    ) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (inTrash) {
                PillAction(DexIcons.Reset, "Restore") { vm.restoreSelected(tab) }
                PillAction(DexIcons.Trash, "Delete") { vm.requestDelete(permanent = true, tab = tab) }
            } else {
                PillAction(DexIcons.Move, "Move") { sheet = true }
                PillAction(DexIcons.Copy, "Copy") { sheet = false }
                PillAction(DexIcons.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
                PillAction(DexIcons.Trash, "Delete") { vm.requestDelete(tab = tab) }
                Box {
                    PillAction(DexIcons.MoreH, "More") { more = true }
                    DropdownMenu(
                        shape = Radius.l,
                        containerColor = cs.surfaceContainerHigh,
                        expanded = more,
                        onDismissRequest = { more = false },
                    ) {
                        PillMenuItem("Rename", DexIcons.Rename, enabled = sel.size == 1 && Rules.canRename(tab)) { more = false; vm.requestRename(tab) }
                        PillMenuItem("Cut to clipboard", DexIcons.Cut) { more = false; vm.copySelection(true, tab) }
                        PillMenuItem("Copy to clipboard", DexIcons.Copy) { more = false; vm.copySelection(false, tab) }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        PillMenuItem("Select all", DexIcons.SelectAll) { more = false; vm.selectAll(tab) }
                        PillMenuItem("Invert selection", DexIcons.SelectAll) { more = false; vm.invertSelection(tab) }
                        PillMenuItem("Customize folder", DexIcons.Info, enabled = sel.size == 1 && sel[0].isDir) { more = false; vm.dialog = DialogState.CustomizeFolder(sel[0]) }
                        PillMenuItem("Copy path", DexIcons.Copy) { more = false; vm.copyPath(sel) }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        PillMenuItem("Details", DexIcons.Info) { more = false; vm.dialog = DialogState.Properties(sel) }
                    }
                }
            }
        }
    }
    sheet?.let { move -> DestinationSheet(vm, tab, move) { sheet = null } }
}

@Composable
private fun PillMenuItem(label: String, icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
        enabled = enabled,
        onClick = onClick,
    )
}

@Composable
private fun PillAction(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val danger = label == "Delete"
    val c = if (!enabled) cs.onSurface.copy(alpha = 0.38f) else if (danger) Color(0xFFFF8A80) else cs.onSurface.copy(alpha = 0.92f)
    // Mock: 84 wide, 24 icon, 4 gap, 12/600 label; "More" sits on its own #34343A chip.
    Column(
        Modifier.width(84.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(30.dp))
            .then(if (label == "More") Modifier.background(if (cs.background == Color.Black) Color(0xFF34343A) else cs.surfaceVariant) else Modifier)
            .then(if (enabled) Modifier.pressScale(0.93f, onTap = onClick) else Modifier)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Spacer(Modifier.size(4.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c, maxLines = 1)
    }
}

/** Samsung-style "Select folder" dialog: storage chips, tappable breadcrumb pill, folder list, Cancel / Move here. */
@Composable
fun DestinationSheet(vm: ExplorerViewModel, tab: TabState, move: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val volumePaths = vm.volumes.map { it.path }
    var dir by remember { mutableStateOf(vm.volumes.firstOrNull()?.path ?: vm.primaryRoot) }
    val folders by produceState(initialValue = emptyList<app.dexfiles.core.FileEntry>(), dir, vm.showHidden) {
        val d = dir
        value = withContext(Dispatchers.IO) {
            runCatching { Listing.list(File(d), vm.showHidden).filter { it.isDir }.sortedBy { it.name.lowercase() } }.getOrDefault(emptyList())
        }
    }
    val verb = if (move) "Move" else "Copy"
    val crumbs = PathUtils.crumbs(dir, vm.rootLabelMap())
    val rootOfDir = volumePaths.firstOrNull { dir == it || dir.startsWith(it.trimEnd('/') + "/") }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth(0.94f).widthIn(max = 720.dp).heightIn(max = 700.dp),
            shape = Radius.xl,
            color = cs.surfaceContainerHigh,
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 12.dp)) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Select folder", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconBtn(DexIcons.Folder, "New folder", size = 48.dp) { vm.dialog = DialogState.NewItem(true, dir) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (v in vm.volumes) {
                        val on = v.path == rootOfDir
                        Box(
                            Modifier.height(44.dp).clip(Radius.l)
                                .background(if (on) cs.surfaceContainerHighest else Color.Transparent)
                                .clickable { dir = v.path }.padding(horizontal = 18.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(v.label, style = MaterialTheme.typography.titleMedium, color = if (on) cs.onSurface else cs.onSurfaceVariant) }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp).height(52.dp).clip(Radius.xl)
                        .background(cs.surfaceContainerHighest).horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    crumbs.forEachIndexed { i, c ->
                        val last = i == crumbs.lastIndex
                        Text(
                            c.label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (last) cs.primary else cs.onSurfaceVariant,
                            fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            modifier = Modifier.clip(Radius.xs).clickable { dir = c.path }.padding(horizontal = 4.dp, vertical = 6.dp),
                        )
                        if (!last) Icon(DexIcons.ChevronRight, null, Modifier.size(18.dp).padding(horizontal = 0.dp), tint = cs.onSurfaceVariant)
                    }
                }
                LazyColumn(Modifier.weight(1f, fill = false).heightIn(min = 160.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp)) {
                    items(folders, key = { it.path }) { f -> DestRow(f.name, f) { dir = f.path } }
                    if (folders.isEmpty()) item {
                        Text("No folders here", style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(24.dp))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp).height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("Cancel", style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                    }
                    TextButton(onClick = { onDismiss(); vm.transferSelectionTo(dir, move, tab) }, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text("$verb here", style = MaterialTheme.typography.titleMedium, color = cs.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun DestRow(name: String, entry: app.dexfiles.core.FileEntry?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().height(Dimens.touch + 8.dp).clip(RoundedCornerShape(Dimens.radiusRow)).clickable(onClick = onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (entry != null) FileThumb(entry, 36.dp) else Icon(DexIcons.Move, null, Modifier.size(28.dp), tint = cs.primary)
        Text(name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 14.dp))
        Icon(DexIcons.ChevronRight, null, tint = cs.onSurfaceVariant)
    }
}

