package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.DriveFileMove
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.Share
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.pressScale
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.width
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.dexfiles.core.FileKind
import app.dexfiles.core.Listing
import app.dexfiles.core.PathUtils
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** The command bar: a count chip that clears the selection, then Move, Copy, Share, Delete, More. Floats at the bottom while items are selected, at every width. */
@Composable
fun SelectionPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    var more by remember { mutableStateOf(false) }
    val canWrite = !tab.isVirtual || tab.path == Loc.TRASH

    Surface(
        modifier,
        shape = Radius.m,
        color = dialogSurface(),
        shadowElevation = 24.dp,
        tonalElevation = 0.dp,
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            val acts = fileActions(vm, tab, sel, vm.panes[vm.activePane.coerceIn(0, vm.panes.lastIndex)])
            // The count chip is 52 wide; every button shares what the window leaves over, up to 72, so on a narrow window nothing is pushed out.
            val count = acts.count { it.group == ActGroup.Primary } + if (inTrash) 0 else 1
            val cell = ((androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp - 40 - 12 - 52 - 2 * count) / count).coerceIn(48, 72).dp
            CountChip(sel.size) { vm.clearSelection(tab) }
            // The four primary actions sit on the pill itself; everything else is the same list the right-click menu shows.
            for (a in acts.filter { it.group == ActGroup.Primary }) {
                PillAction(a.icon, a.short, cell, enabled = !(a.label == "Share" && sel.none { !it.isDir })) { a.run() }
            }
            if (!inTrash) Box {
                PillAction(DexIcons.MoreH, "More", cell) { more = true }
                DropdownMenu(
                    shape = Radius.l,
                    containerColor = cs.surfaceContainerHigh,
                    expanded = more,
                    onDismissRequest = { more = false },
                ) { ActionMenuItems(acts, primary = false, close = { more = false }) }
            }
        }
    }
}

/** Amber chip with the number selected; a tap clears the selection (Esc does the same). */
@Composable
private fun CountChip(n: Int, onClear: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.size(width = 52.dp, height = 48.dp).clip(Radius.s).background(cs.primary).pressScale(0.95f, onTap = onClear),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$n", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = cs.onPrimary, maxLines = 1)
        Icon(DexIcons.Close, "Clear selection", Modifier.padding(start = 3.dp).size(14.dp), tint = cs.onPrimary)
    }
}

@Composable
private fun PillMenuItem(label: String, icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
        enabled = enabled,
        onClick = onClick,
    )
}

@Composable
private fun PillAction(icon: ImageVector, label: String, cell: androidx.compose.ui.unit.Dp, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val danger = label == "Delete"
    val c = if (!enabled) cs.onSurface.copy(alpha = 0.38f) else if (danger) cs.error else cs.onSurface.copy(alpha = 0.92f)
    // Mock: 84 wide, 24 icon, 4 gap, 12/600 label; "More" sits on its own #34343A chip.
    Column(
        Modifier.width(cell).clip(Radius.s)
            .then(if (label == "More") Modifier.background(cs.onSurface.copy(alpha = 0.10f)) else Modifier)
            .then(if (enabled) Modifier.pressScale(0.93f, onTap = onClick) else Modifier)
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(22.dp))
        Spacer(Modifier.size(3.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c, maxLines = 1)
    }
}

/** Samsung-style "Select folder" dialog: storage chips, tappable breadcrumb pill, folder list, Cancel / Move here. */
@Composable
fun DestinationSheet(vm: ExplorerViewModel, tab: TabState, move: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val volumePaths = vm.volumes.map { it.path }
    val sel = vm.selectedEntries(tab)
    // Opens where the files already are, so the folders next door are one tap away (as in Samsung's).
    val start = sel.firstOrNull()?.let { File(it.path).parent }?.takeIf { p -> File(p).isDirectory && volumePaths.any { p == it || p.startsWith(it.trimEnd('/') + "/") } }
    var dir by remember { mutableStateOf(start ?: vm.volumes.firstOrNull()?.path ?: vm.primaryRoot) }
    val listing by produceState(initialValue = emptyList<app.dexfiles.core.FileEntry>(), dir, vm.showHidden) {
        val d = dir
        value = withContext(Dispatchers.IO) {
            runCatching { Listing.list(File(d), vm.showHidden).sortedBy { it.name.lowercase() } }.getOrDefault(emptyList())
        }
    }
    // A folder can't be sent into itself, so the selected folders are left out of the choices.
    val folders = listing.filter { f -> f.isDir && sel.none { it.path == f.path } }
    val files = listing.filter { !it.isDir }
    val sameFolder = move && sel.all { File(it.path).parent == dir }
    val insideSelected = sel.any { it.isDir && (dir == it.path || dir.startsWith(it.path.trimEnd('/') + "/")) }
    val verb = if (move) "Move" else "Copy"
    val crumbs = PathUtils.crumbs(dir, vm.rootLabelMap())
    val rootOfDir = volumePaths.firstOrNull { dir == it || dir.startsWith(it.trimEnd('/') + "/") }

    val n = sel.size
    // Built on the same dialog as every other dialog, so surface, title, buttons and width all match.
    DexDialog(
        title = if (n > 1) "$verb $n items to" else "$verb to",
        onDismiss = onDismiss,
        width = 520.dp,
        actions = {
            DexButton("New folder") { vm.dialog = DialogState.NewItem(true, dir) }
            Spacer(Modifier.weight(1f))
            DexButton("Cancel", onClick = onDismiss)
            DexButton("$verb here", DexBtn.Primary, enabled = !sameFolder && !insideSelected) { onDismiss(); vm.transferSelectionTo(dir, move, tab) }
        },
    ) {
        // Several storages: choose one. With a single storage the path bar below already says it, so no second copy.
        if (vm.volumes.size > 1) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (v in vm.volumes) DexChip(v.label, v.path == rootOfDir) { dir = v.path }
        }
        // Path bar, styled like the one at the top of the app: the current folder in bold, the way back in grey.
        Row(
            Modifier.fillMaxWidth().height(44.dp).clip(Radius.s).background(cs.surface).horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            crumbs.forEachIndexed { i, c ->
                val last = i == crumbs.lastIndex
                Text(
                    c.label,
                    fontSize = 14.sp,
                    color = if (last) cs.onSurface else cs.onSurfaceVariant,
                    fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    modifier = Modifier.clip(Radius.xs).clickable { dir = c.path }.padding(horizontal = 4.dp, vertical = 6.dp),
                )
                if (!last) Icon(DexIcons.ChevronRight, null, Modifier.size(16.dp), tint = cs.onSurfaceVariant)
            }
        }
        LazyColumn(Modifier.fillMaxWidth().height(320.dp), flingBehavior = dexFling()) {
            items(folders, key = { it.path }) { f -> DestRow(f.name, f) { dir = f.path } }
            // The files are shown dimmed, only so you can tell you are in the right place.
            items(files, key = { it.path }) { f -> DestRow(f.name, f, dim = true) {} }
            if (listing.isEmpty()) item {
                Text("This folder is empty", fontSize = 14.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(24.dp))
            }
        }
    }
}

@Composable
private fun DestRow(name: String, entry: app.dexfiles.core.FileEntry?, dim: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().height(Dimens.touch + 8.dp).clip(RoundedCornerShape(Dimens.radiusRow))
            .then(if (dim) Modifier else Modifier.clickable(onClick = onClick)).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.graphicsLayer { alpha = if (dim) 0.4f else 1f }) {
            if (entry != null) FileThumb(entry, 36.dp) else Icon(DexIcons.Move, null, Modifier.size(28.dp), tint = cs.primary)
        }
        Text(
            name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (dim) cs.onSurface.copy(alpha = 0.4f) else cs.onSurface,
            modifier = Modifier.weight(1f).padding(start = 14.dp),
        )
        if (!dim) Icon(DexIcons.ChevronRight, null, tint = cs.onSurfaceVariant)
    }
}
