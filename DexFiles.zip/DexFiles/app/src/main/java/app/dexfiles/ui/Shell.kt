package app.dexfiles.ui

import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import app.dexfiles.core.Format
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.delay
import java.io.File

/** Phone, small tablet / narrow window, and large tablet or DeX window. */
enum class WindowClass { Compact, Medium, Expanded }

fun windowClassFor(width: Dp): WindowClass = when {
    width < 600.dp -> WindowClass.Compact
    width < 840.dp -> WindowClass.Medium
    else -> WindowClass.Expanded
}

private val BtnSize = 44.dp

/** One top bar for every screen size: it shows only what fits and tucks the rest into menus. */
@Composable
fun AdaptiveTopBar(vm: ExplorerViewModel, wc: WindowClass, onMenu: () -> Unit) {
    val tab = vm.current
    val sel = vm.selectedEntries(tab)
    androidx.compose.animation.Crossfade(targetState = sel.isNotEmpty(), animationSpec = androidx.compose.animation.core.tween(180), label = "bar") { selecting ->
        if (selecting) SelectionBar(vm, tab, vm.selectedEntries(tab).ifEmpty { sel }, wc) else NavBar(vm, tab, wc, onMenu)
    }
}

/** A round 44 dp button on its own raised disc, as in the approved top bar. */
@Composable
private fun RoundBtn(icon: ImageVector, label: String, enabled: Boolean = true, active: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(BtnSize).clip(androidx.compose.foundation.shape.CircleShape).background(cs.surfaceContainer)) {
        IconBtn(icon, label, enabled = enabled, active = active, size = BtnSize, onClick = onClick)
    }
}

@Composable
private fun PillGroup(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.barPill().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

// ---------------------------------------------------------------------------------------------- navigation bar

@Composable
private fun NavBar(vm: ExplorerViewModel, tab: TabState, wc: WindowClass, onMenu: () -> Unit) {
    val expanded = wc == WindowClass.Expanded
    val roomy = wc != WindowClass.Compact
    val canWrite = !tab.isVirtual && !tab.isSearch
    val searchOpen = false
    var editing by remember(tab.id) { mutableStateOf(false) }
    var searchFocus by remember { mutableIntStateOf(0) }
    var lastSearchTick by remember { mutableIntStateOf(vm.searchTick) }
    var lastAddressTick by remember { mutableIntStateOf(vm.addressTick) }
    var optionsMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    LaunchedEffect(vm.searchTick) {
        if (vm.searchTick != lastSearchTick) {
            lastSearchTick = vm.searchTick
            vm.openSearch()
        }
    }
    LaunchedEffect(vm.addressTick) {
        if (vm.addressTick != lastAddressTick) {
            lastAddressTick = vm.addressTick
            editing = true
        }
    }

    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().height(56.dp)) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        RoundBtn(Icons.Filled.Menu, "Sidebar", active = expanded && vm.sidebarVisible) {
            if (expanded) vm.setSidebarVisible(!vm.sidebarVisible) else onMenu()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RoundBtn(Icons.AutoMirrored.Filled.ArrowBack, "Back", enabled = tab.back.isNotEmpty() || tab.isSearch || vm.searchUi) { if (vm.searchUi) vm.closeSearch() else vm.goBack(tab) }
            if (roomy) {
                RoundBtn(Icons.AutoMirrored.Filled.ArrowForward, "Forward (Alt+Right)", enabled = tab.forward.isNotEmpty()) { vm.goForward(tab) }
            }
        }

        val centre = when {
            editing -> 0
            tab.isSearch -> 2
            tab.isVirtual -> 3
            else -> 4
        }
        androidx.compose.animation.AnimatedContent(
            targetState = centre,
            modifier = Modifier.weight(1f),
            transitionSpec = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) },
            label = "centre",
        ) { c ->
            when (c) {
                0 -> PathEditor(vm, tab, Modifier.fillMaxWidth()) { editing = false }
                1 -> SearchPill(vm, tab, Modifier.fillMaxWidth(), 1) {
                    vm.closeSearch()
                }
                2 -> TitleArea(vm, tab, Modifier.fillMaxWidth()) { editing = true }
                3 -> Spacer(Modifier.fillMaxWidth())
                else -> PathPill(vm, tab, Modifier.fillMaxWidth()) { editing = true }
            }
        }

        run {
            RoundBtn(Icons.Filled.Search, "Search (Ctrl+F)") { vm.openSearch() }
            Box {
                RoundBtn(viewModeIcon(tab.viewMode), "View options") { optionsMenu = true }
                ViewOptionsMenu(vm, tab, optionsMenu) { optionsMenu = false }
            }
            Box {
                RoundBtn(Icons.Filled.MoreVert, "More") { moreMenu = true }
                MoreMenu(vm, tab, roomy, moreMenu) { moreMenu = false }
            }
        }
    }
    // Search grows out of its button towards the left over the bar (laid out once at full width, revealed by a growing pill).
    val grow by androidx.compose.animation.core.animateFloatAsState(if (vm.searchUi) 1f else 0f, app.dexfiles.ui2.design.Motion.glide<Float>(440), label = "searchExpand")
    if (grow > 0.001f) {
        val cs2 = MaterialTheme.colorScheme
        val leftBound = 12.dp + 44.dp + 10.dp + 44.dp + (if (roomy) 50.dp else 0.dp) + 10.dp
        val fullW = maxWidth - 12.dp - leftBound
        val w = 44.dp + (fullW - 44.dp) * grow
        Box(
            Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).width(w).height(44.dp)
                .clip(CircleShape).background(cs2.surfaceContainer)
                .border(1.5.dp, cs2.primary.copy(alpha = grow), CircleShape),
        ) {
            Box(Modifier.requiredWidth(fullW).fillMaxHeight().align(Alignment.CenterEnd).graphicsLayer { alpha = ((grow - 0.45f) / 0.45f).coerceIn(0f, 1f) }) {
                SearchPill(vm, tab, Modifier.fillMaxSize(), 1) { vm.closeSearch() }
            }
        }
    }
    }
}

/** Folder name as a large title with the item count under it; tap it for the path and quick actions. */
@Composable
private fun TitleArea(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onTypePath: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    var menu by remember { mutableStateOf(false) }
    val crumbs = if (tab.isVirtual || tab.isSearch) emptyList() else PathUtils.crumbs(tab.path, labels)
    val title = when {
        tab.isSearch -> "Search"
        tab.isVirtual -> Loc.title(tab.path, labels)
        else -> crumbs.lastOrNull()?.label ?: tab.path
    }
    val subtitle = when {
        tab.isSearch -> if (tab.query.isBlank()) "" else "Results for \"${tab.query}\""
        tab.path == Loc.HOME -> ""
        tab.loading -> "Loading…"
        tab.entries.size == 1 -> "1 item"
        else -> "${tab.entries.size} items"
    }
    Box(modifier) {
        Column(
            Modifier.clip(Radius.s).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 2.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = cs.onSurfaceVariant)
            }
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
        DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = menu, onDismissRequest = { menu = false }) {
            for (c in crumbs.asReversed()) {
                DropdownMenuItem(
                    text = { Text(c.label) },
                    leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(20.dp), tint = kindColor(FileKind.FOLDER)) },
                    onClick = { menu = false; vm.navigate(tab, c.path) },
                )
            }
            if (crumbs.isNotEmpty()) HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Go to path…") },
                leadingIcon = { Icon(Icons.Filled.Edit, null, Modifier.size(20.dp)) },
                onClick = { menu = false; onTypePath() },
            )
            DropdownMenuItem(
                text = { Text("Open in new tab") },
                leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(20.dp)) },
                onClick = { menu = false; vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path) },
            )
        }
    }
}

@Composable
private fun PathEditor(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onDone: () -> Unit) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val start = if (tab.isVirtual) "" else tab.path
    var text by remember { mutableStateOf(TextFieldValue(start, TextRange(0, start.length))) }
    var hadFocus by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(30)
        try { focus.requestFocus() } catch (_: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    fun commit() {
        val typed = text.text.trim()
        onDone()
        focusManager.clearFocus()
        vm.typing = false
        if (typed.isEmpty()) return
        val base = if (tab.isVirtual) vm.primaryRoot else tab.path
        val resolved = PathUtils.resolveTyped(base, typed, vm.primaryRoot)
        val f = File(resolved)
        when {
            f.isDirectory -> vm.navigate(tab, resolved)
            f.exists() -> vm.reveal(resolved)
            else -> vm.toast("Can't find \"$typed\"")
        }
    }

    DexTextField(
        value = text,
        onValueChange = { text = it },
        modifier = modifier.height(Dimens.barHeight),
        placeholder = "Type a path, for example /storage/emulated/0/Download",
        shape = Radius.xl,
        container = MaterialTheme.colorScheme.surfaceContainer,
        borderColor = androidx.compose.ui.graphics.Color.Transparent,
        focusRequester = focus,
        onEnter = { commit() },
        onEscape = { onDone(); focusManager.clearFocus(); vm.typing = false },
        onFocusChange = { f ->
            vm.typing = f
            if (f) hadFocus = true else if (hadFocus) onDone()
        },
    )
}

@Composable
private fun SearchPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, focusSignal: Int, onClose: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var tv by remember { mutableStateOf(TextFieldValue(tab.query)) }

    LaunchedEffect(focusSignal) {
        if (focusSignal > 0) {
            delay(30)
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    LaunchedEffect(tab.id, tab.query) {
        if (tab.query != tv.text) tv = TextFieldValue(tab.query)
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    DexTextField(
        value = tv,
        onValueChange = { tv = it; vm.setQuery(tab, it.text) },
        modifier = modifier.height(Dimens.barHeight),
        placeholder = "Search",
        shape = Radius.xl,
        container = cs.surfaceContainer,
        borderColor = androidx.compose.ui.graphics.Color.Transparent,
        leading = {
            Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(20.dp), tint = cs.onSurfaceVariant)
            val here = vm.searchCurrentOnly && !tab.isVirtual
            Box(
                Modifier.padding(start = 8.dp).height(32.dp).clip(Radius.m).background(cs.surfaceContainerHigh)
                    .clickable(enabled = !tab.isVirtual) { vm.setSearchCurrentOnly(!vm.searchCurrentOnly) }.padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text(if (here) "This folder" else "Everywhere", style = MaterialTheme.typography.labelLarge, color = cs.primary, maxLines = 1) }
        },
        trailing = {
            if (tv.text.isNotEmpty() || onClose != null) {
                Icon(
                    Icons.Filled.Close, contentDescription = "Clear search",
                    modifier = Modifier.size(22.dp).clip(CircleShape).clickable {
                        tv = TextFieldValue("")
                        vm.clearSearch(tab)
                        onClose?.invoke()
                    },
                    tint = cs.onSurfaceVariant,
                )
            }
        },
        focusRequester = focus,
        onEnter = { vm.addRecent(tv.text); focusManager.clearFocus(); vm.typing = false },
        onEscape = {
            tv = TextFieldValue("")
            vm.clearSearch(tab)
            focusManager.clearFocus()
            vm.typing = false
            onClose?.invoke()
        },
        onFocusChange = { vm.typing = it },
    )
    if (vm.searchUi && tv.text.isEmpty() && vm.recentSearches.isNotEmpty()) {
        DropdownMenu(
            expanded = true,
            onDismissRequest = { },
            properties = androidx.compose.ui.window.PopupProperties(focusable = false),
            shape = Radius.l,
            containerColor = cs.surfaceContainerHigh,
        ) {
            Text("Recent searches", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            for (q in vm.recentSearches.take(6)) {
                DropdownMenuItem(
                    text = { Text(q) },
                    trailingIcon = { Icon(Icons.Filled.Close, "Remove", Modifier.size(18.dp).clickable { vm.removeRecent(q) }, tint = cs.onSurfaceVariant) },
                    onClick = { tv = TextFieldValue(q, androidx.compose.ui.text.TextRange(q.length)); vm.setQuery(tab, q) },
                )
            }
            DropdownMenuItem(text = { Text("Clear all", color = cs.primary) }, onClick = { vm.clearRecents() })
        }
    }
}

// ---------------------------------------------------------------------------------------------- menus

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
private fun ViewOptionsMenu(vm: ExplorerViewModel, tab: TabState, expanded: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = expanded, onDismissRequest = onDismiss) {
        SectionLabel("View as")
        for (m in ViewMode.entries.filter { it != ViewMode.DETAILS }) {
            val on = (if (tab.viewMode == ViewMode.DETAILS) ViewMode.LIST else tab.viewMode) == m
            DropdownMenuItem(
                text = { Text(m.label) },
                leadingIcon = { Icon(viewModeIcon(m), null, Modifier.size(20.dp), tint = if (on) cs.primary else cs.onSurface) },
                trailingIcon = {
                    if (m == ViewMode.LIST) {
                        // Simple | Detailed belongs to List, so it sits right beside it. Picking either also switches to List.
                        SimpleDetailed(detailed = vm.detailsColumns) { d ->
                            vm.setViewMode(tab, ViewMode.LIST)
                            vm.setDetailsColumns(d)
                        }
                    } else if (on) Icon(Icons.Filled.Check, null, Modifier.size(18.dp), tint = cs.primary)
                },
                onClick = { vm.setViewMode(tab, m); onDismiss() },
            )
        }
        HorizontalDivider()
        // Switches stay open so the change can be seen behind the menu; choosing a view closes it.
        CheckItem("Show hidden files", vm.showHidden, "Ctrl+H") { vm.setShowHidden(!vm.showHidden) }
    }
}

/** Small two-way switch, same look as Ascending / Descending. */
@Composable
private fun SimpleDetailed(detailed: Boolean, onPick: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(androidx.compose.foundation.shape.CircleShape).background(cs.outlineVariant).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        for ((label, d) in listOf("Simple" to false, "Detailed" to true)) {
            val on = detailed == d
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (on) androidx.compose.ui.text.font.FontWeight.SemiBold else androidx.compose.ui.text.font.FontWeight.Medium,
                color = if (on) cs.onPrimary else cs.onSurfaceVariant,
                modifier = Modifier
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (on) cs.primary else Color.Transparent)
                    .clickable { onPick(d) }
                    .padding(horizontal = 11.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun MenuRow(label: String, icon: ImageVector, enabled: Boolean = true, hint: String? = null, onClick: () -> Unit) {
    if (hint != null) {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            trailingIcon = { MenuHint(hint) },
            enabled = enabled,
            onClick = onClick,
        )
    } else {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            enabled = enabled,
            onClick = onClick,
        )
    }
}

@Composable
private fun MoreMenu(vm: ExplorerViewModel, tab: TabState, roomy: Boolean, expanded: Boolean, onDismiss: () -> Unit) {
    val canWrite = !tab.isVirtual && !tab.isSearch
    DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = expanded, onDismissRequest = onDismiss) {
        if (canWrite) {
            MenuRow("New folder", Icons.Filled.CreateNewFolder, hint = "Ctrl+Shift+N") { onDismiss(); vm.requestNew(true) }
            MenuRow("New text file", Icons.Filled.NoteAdd) { onDismiss(); vm.requestNew(false) }
            MenuRow("Paste", Icons.Filled.ContentPaste, enabled = vm.clip != null, hint = "Ctrl+V") { onDismiss(); vm.paste() }
            HorizontalDivider()
        }
        MenuRow("New tab", Icons.Filled.Add, hint = "Ctrl+T") {
            onDismiss()
            vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path)
        }
        CheckItem("Dual pane", vm.dual, "F9") { vm.setDual(!vm.dual); onDismiss() }
        CheckItem("Preview pane", vm.previewVisible, "Alt+P") { vm.setPreviewVisible(!vm.previewVisible); onDismiss() }
        MenuRow("Refresh", Icons.Filled.Refresh, hint = "Ctrl+R") { onDismiss(); vm.refresh(tab) }
        HorizontalDivider()
        MenuRow("Select all", Icons.Filled.SelectAll, hint = "Ctrl+A") { onDismiss(); vm.selectAll(tab) }
        MenuRow("New window", Icons.Filled.Add, hint = "Ctrl+N") {
            onDismiss()
            vm.openInNewWindow(if (tab.isVirtual) null else tab.path)
        }
        HorizontalDivider()
        MenuRow("Settings", Icons.Filled.Settings) { onDismiss(); vm.openSettings(fromLeft = false) }
        MenuRow("Keyboard shortcuts", Icons.Filled.Keyboard, hint = "F1") { onDismiss(); vm.dialog = DialogState.Shortcuts }
    }
}

// ---------------------------------------------------------------------------------------------- selection

@Composable
private fun SelectionBar(vm: ExplorerViewModel, tab: TabState, sel: List<FileEntry>, wc: WindowClass) {
    val cs = MaterialTheme.colorScheme
    val bytes = sel.filter { !it.isDir }.sumOf { it.size }
    val allSelected = sel.size >= tab.entries.size && tab.entries.isNotEmpty()
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(start = 20.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Tick circle toggles "select all"; "N selected" and the close button on the right, exactly as in the mock.
        Box(
            Modifier.size(26.dp).clip(CircleShape).border(2.dp, cs.primary, CircleShape)
                .clickable { if (allSelected) vm.clearSelection(tab) else vm.selectAll(tab) },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Check, null, Modifier.size(14.dp), tint = cs.primary) }
        Text("${sel.size} selected", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
        RoundBtn(Icons.Filled.Close, "Cancel selection (Esc)") { vm.clearSelection(tab) }
    }
}

/** Phone-style action row along the bottom while items are selected. */
@Composable
fun BottomActionBar(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    Row(
        Modifier.fillMaxWidth().background(cs.surface).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        if (inTrash) {
            ActionItem(Icons.Filled.Restore, "Restore") { vm.restoreSelected(tab) }
            ActionItem(Icons.Filled.DeleteForever, "Delete") { vm.requestDelete(permanent = true, tab = tab) }
        } else {
            ActionItem(Icons.Filled.ContentCopy, "Copy") { vm.copySelection(false, tab) }
            ActionItem(Icons.Filled.ContentCut, "Cut") { vm.copySelection(true, tab) }
            ActionItem(Icons.Filled.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
            ActionItem(Icons.Filled.Delete, "Delete") { vm.requestDelete(tab = tab) }
        }
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(Radius.s).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = c)
    }
}
