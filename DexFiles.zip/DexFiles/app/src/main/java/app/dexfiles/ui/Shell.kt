package app.dexfiles.ui

import androidx.compose.material3.minimumInteractiveComponentSize
import app.dexfiles.ui2.design.DexIcons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.foundation.layout.fillMaxSize
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.background
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import app.dexfiles.core.Format
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.delay
import java.io.File

/** Phone, small tablet / narrow window, and large tablet or DeX window. */
enum class WindowClass { Compact, Medium, Expanded }

/** True on phone-width windows. Screens read this to tighten margins and rows instead of each guessing from its own width. */
val LocalCompact = androidx.compose.runtime.staticCompositionLocalOf { false }

/** The layout contract's breakpoints (docs/LAYOUT_CONTRACT.md): under 600, 600 to 900, 900 and up. */
fun windowClassFor(width: Dp): WindowClass = when {
    width < 600.dp -> WindowClass.Compact
    width < 900.dp -> WindowClass.Medium
    else -> WindowClass.Expanded
}

/**
 * The class for the current width, with 24 dp of slack: once in a class, the width has to be clearly past the line to leave it,
 * so dragging a window edge across a breakpoint never makes the layout flicker between two forms.
 */
@androidx.compose.runtime.Composable
fun rememberWindowClass(width: Dp): WindowClass {
    val held = androidx.compose.runtime.remember { object { var wc: WindowClass? = null } }
    val raw = windowClassFor(width)
    val cur = held.wc
    val next = when {
        cur == null || cur == raw -> raw
        windowClassFor(width + 24.dp) == raw && windowClassFor(width - 24.dp) == raw -> raw
        else -> cur
    }
    held.wc = next
    return next
}

internal val BtnSize = 44.dp

/** One top bar for every screen size: it shows only what fits and tucks the rest into menus. Selecting never replaces it; the command bar floats at the bottom. */
@Composable
fun AdaptiveTopBar(vm: ExplorerViewModel, wc: WindowClass, onMenu: () -> Unit) {
    NavBar(vm, vm.current, wc, onMenu)
}

/** A round 44 dp button on its own raised disc, as in the approved top bar. */
@Composable
private fun RoundBtn(icon: ImageVector, label: String, enabled: Boolean = true, active: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(BtnSize).clip(Radius.s).background(cs.surfaceContainer)) {
        IconBtn(icon, label, enabled = enabled, active = active, size = BtnSize, onClick = onClick)
    }
}

@Composable
private fun PillGroup(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.barPill().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

// ---------------------------------------------------------------------------------------------- navigation bar

@Composable
private fun NavBar(vm: ExplorerViewModel, tab: TabState, wc: WindowClass, onMenu: () -> Unit) {
    val expanded = wc == WindowClass.Expanded
    val roomy = wc != WindowClass.Compact
    val canWrite = !tab.isVirtual && !tab.isSearch
    val searchOpen = false
    var editing by remember(tab.id) { mutableStateOf(false) }
    var searchFocus by remember { mutableIntStateOf(0) }
    var lastSearchTick by remember { mutableIntStateOf(vm.searchTick) }
    var lastAddressTick by remember { mutableIntStateOf(vm.addressTick) }
    var optionsMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    LaunchedEffect(vm.searchTick) {
        if (vm.searchTick != lastSearchTick) {
            lastSearchTick = vm.searchTick
            vm.openSearch()
        }
    }
    LaunchedEffect(vm.addressTick) {
        if (vm.addressTick != lastAddressTick) {
            lastAddressTick = vm.addressTick
            editing = true
        }
    }

    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().height(56.dp)) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(horizontal = if (roomy) 12.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(if (roomy) 10.dp else 6.dp),
    ) {
        RoundBtn(DexIcons.Menu, "Sidebar", active = expanded && vm.sidebarVisible) {
            if (expanded) vm.setSidebarVisible(!vm.sidebarVisible) else onMenu()
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // On a phone the system back gesture retraces steps, so that slot goes to the tab button instead.
            if (roomy) RoundBtn(DexIcons.Back, "Back", enabled = tab.back.isNotEmpty() || tab.isSearch || vm.searchUi) { if (vm.searchUi) vm.closeSearch() else vm.goBack(tab) }
            if (roomy) {
                RoundBtn(DexIcons.Forward, "Forward (Alt+Right)", enabled = tab.forward.isNotEmpty()) { vm.goForward(tab) }
            }
        }

        val centre = when {
            editing -> 0
            tab.isSearch -> 2
            tab.isVirtual -> 3
            else -> 4
        }
        androidx.compose.animation.AnimatedContent(
            targetState = centre,
            modifier = Modifier.weight(1f),
            transitionSpec = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) },
            label = "centre",
        ) { c ->
            when (c) {
                0 -> PathEditor(vm, tab, Modifier.fillMaxWidth()) { editing = false }
                1 -> SearchPill(vm, tab, Modifier.fillMaxWidth(), 1) {
                    vm.closeSearch()
                }
                2 -> TitleArea(vm, tab, Modifier.fillMaxWidth()) { editing = true }
                3 -> Row(Modifier.fillMaxWidth().barPill(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        Loc.title(tab.path, vm.rootLabelMap()), fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
                else -> PathPill(vm, tab, Modifier.fillMaxWidth()) { editing = true }
            }
        }

        run {
            RoundBtn(DexIcons.Search, "Search (Ctrl+F)") { vm.openSearch() }
            if (!roomy) TabCountButton(vm)
            // On a phone the view switch moves down beside Sort, so the path pill keeps room to be readable.
            if (roomy) Box {
                androidx.compose.animation.Crossfade(CurrentViewIcon(vm, tab), animationSpec = androidx.compose.animation.core.tween(180), label = "viewIcon") { ic ->
                    RoundBtn(ic, "View options") { optionsMenu = true }
                }
                ViewOptionsMenu(vm, tab, optionsMenu) { optionsMenu = false }
            }
            Box {
                RoundBtn(DexIcons.More, "More") { moreMenu = true }
                MoreMenu(vm, tab, roomy, moreMenu) { moreMenu = false }
            }
        }
    }
    // Search grows out of its button towards the left over the bar (laid out once at full width, revealed by a growing pill).
    val grow by androidx.compose.animation.core.animateFloatAsState(if (vm.searchUi) 1f else 0f, app.dexfiles.ui2.design.Motion.glide<Float>(440), label = "searchExpand")
    if (grow > 0.001f) {
        val cs2 = MaterialTheme.colorScheme
        val edge = if (roomy) 12.dp else 8.dp
        // The field takes the whole bar: the leading icon closes it, so no separate back button eats into the width.
        val fullW = maxWidth - edge * 2
        val w = 44.dp + (fullW - 44.dp) * grow
        Box(
            Modifier.align(Alignment.CenterEnd).padding(end = edge).width(w).height(48.dp)
                .clip(CircleShape).background(cs2.surfaceContainer)
                .border(1.5.dp, cs2.primary.copy(alpha = 0.55f * grow), CircleShape),
        ) {
            Box(Modifier.requiredWidth(fullW).fillMaxHeight().align(Alignment.CenterEnd).graphicsLayer { alpha = ((grow - 0.45f) / 0.45f).coerceIn(0f, 1f) }) {
                SearchPill(vm, tab, Modifier.fillMaxSize(), 1) { vm.closeSearch() }
            }
        }
    }
    }
}

/** Folder name as a large title with the item count under it; tap it for the path and quick actions. */
@Composable
private fun TitleArea(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onTypePath: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    var menu by remember { mutableStateOf(false) }
    val crumbs = if (tab.isVirtual || tab.isSearch) emptyList() else PathUtils.crumbs(tab.path, labels)
    val title = when {
        tab.isSearch -> "Search"
        tab.isVirtual -> Loc.title(tab.path, labels)
        else -> crumbs.lastOrNull()?.label ?: tab.path
    }
    val subtitle = when {
        tab.isSearch -> if (tab.query.isBlank()) "" else "Results for \"${tab.query}\""
        tab.path == Loc.HOME -> ""
        tab.loading -> "Loading…"
        tab.entries.size == 1 -> "1 item"
        else -> "${tab.entries.size} items"
    }
    Box(modifier) {
        Column(
            Modifier.clip(Radius.s).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 2.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Icon(DexIcons.ChevronDown, contentDescription = null, tint = cs.onSurfaceVariant)
            }
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
        DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = menu, onDismissRequest = { menu = false }) {
            for (c in crumbs.asReversed()) {
                DropdownMenuItem(
                    text = { Text(c.label) },
                    leadingIcon = { Icon(DexIcons.Folder, null, Modifier.size(20.dp), tint = kindColor(FileKind.FOLDER)) },
                    onClick = { menu = false; vm.navigate(tab, c.path) },
                )
            }
            if (crumbs.isNotEmpty()) HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Go to path…") },
                leadingIcon = { Icon(DexIcons.Rename, null, Modifier.size(20.dp)) },
                onClick = { menu = false; onTypePath() },
            )
            DropdownMenuItem(
                text = { Text("Open in new tab") },
                leadingIcon = { Icon(DexIcons.Plus, null, Modifier.size(20.dp)) },
                onClick = { menu = false; vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path) },
            )
        }
    }
}

@Composable
private fun PathEditor(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onDone: () -> Unit) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val start = if (tab.isVirtual) "" else tab.path
    var text by remember { mutableStateOf(TextFieldValue(start, TextRange(0, start.length))) }
    var hadFocus by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(30)
        try { focus.requestFocus() } catch (_: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    fun commit() {
        val typed = text.text.trim()
        onDone()
        focusManager.clearFocus()
        vm.typing = false
        if (typed.isEmpty()) return
        val base = if (tab.isVirtual) vm.primaryRoot else tab.path
        val resolved = PathUtils.resolveTyped(base, typed, vm.primaryRoot)
        val f = File(resolved)
        when {
            f.isDirectory -> vm.navigate(tab, resolved)
            f.exists() -> vm.reveal(resolved)
            else -> vm.toast("Can't find \"$typed\"")
        }
    }

    DexTextField(
        value = text,
        onValueChange = { text = it },
        modifier = modifier.height(Dimens.barHeight),
        placeholder = "Type a path, for example /storage/emulated/0/Download",
        shape = Radius.xl,
        container = MaterialTheme.colorScheme.surfaceContainer,
        borderColor = androidx.compose.ui.graphics.Color.Transparent,
        focusRequester = focus,
        onEnter = { commit() },
        onEscape = { onDone(); focusManager.clearFocus(); vm.typing = false },
        onFocusChange = { f ->
            vm.typing = f
            if (f) hadFocus = true else if (hadFocus) onDone()
        },
    )
}

@Composable
private fun SearchPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, focusSignal: Int, onClose: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var tv by remember { mutableStateOf(TextFieldValue(tab.query)) }

    LaunchedEffect(focusSignal) {
        if (focusSignal > 0) {
            delay(30)
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    LaunchedEffect(tab.id, tab.query) {
        if (tab.query != tv.text) tv = TextFieldValue(tab.query)
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    DexTextField(
        value = tv,
        onValueChange = { tv = it; vm.setQuery(tab, it.text) },
        modifier = modifier.height(48.dp),
        placeholder = if (vm.searchCurrentOnly && !tab.isVirtual) "Search in ${Loc.title(tab.path, vm.rootLabelMap())}" else "Search",
        shape = Radius.xl,
        container = androidx.compose.ui.graphics.Color.Transparent,
        borderColor = androidx.compose.ui.graphics.Color.Transparent,
        leading = {
            // The only fixed control: tapping it closes search (as do Esc and the system back gesture).
            Box(Modifier.minimumInteractiveComponentSize().size(34.dp).clip(CircleShape).clickable { vm.clearSearch(tab); onClose?.invoke() }, contentAlignment = Alignment.Center) {
                Icon(DexIcons.Search, contentDescription = "Close search", modifier = Modifier.size(20.dp), tint = cs.primary)
            }
        },
        trailing = {
            // The same cross as before: clears the text, and closes search when there is nothing left to clear.
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(cs.surfaceContainerHigh)
                    .clickable { if (tv.text.isNotEmpty()) { tv = TextFieldValue(""); vm.clearSearch(tab) } else { vm.clearSearch(tab); onClose?.invoke() } },
                contentAlignment = Alignment.Center,
            ) { Icon(DexIcons.Close, if (tv.text.isNotEmpty()) "Clear search" else "Close search", Modifier.size(14.dp), tint = cs.onSurface) }
        },
        focusRequester = focus,
        onEnter = { vm.addRecent(tv.text); focusManager.clearFocus(); vm.typing = false },
        onEscape = {
            tv = TextFieldValue("")
            vm.clearSearch(tab)
            focusManager.clearFocus()
            vm.typing = false
            onClose?.invoke()
        },
        onFocusChange = { vm.typing = it },
    )
    if (vm.searchUi && tv.text.isEmpty() && vm.recentSearches.isNotEmpty()) {
        DropdownMenu(
            expanded = true,
            onDismissRequest = { },
            properties = androidx.compose.ui.window.PopupProperties(focusable = false),
            shape = Radius.l,
            containerColor = cs.surfaceContainerHigh,
        ) {
            Text("Recent searches", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            for (q in vm.recentSearches.take(6)) {
                DropdownMenuItem(
                    text = { Text(q) },
                    trailingIcon = { Icon(DexIcons.Close, "Remove", Modifier.size(18.dp).clickable { vm.removeRecent(q) }, tint = cs.onSurfaceVariant) },
                    onClick = { tv = TextFieldValue(q, androidx.compose.ui.text.TextRange(q.length)); vm.setQuery(tab, q) },
                )
            }
            DropdownMenuItem(text = { Text("Clear all", color = cs.primary) }, onClick = { vm.clearRecents() })
        }
    }
}

// ---------------------------------------------------------------------------------------------- menus

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
internal fun ViewOptionsMenu(vm: ExplorerViewModel, tab: TabState, expanded: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = expanded, onDismissRequest = onDismiss) {
        SectionLabel("View as")
        for (m in listOf(ViewMode.LIST, ViewMode.GRID, ViewMode.COLUMNS)) {
            val cur = when (tab.viewMode) { ViewMode.DETAILS -> ViewMode.LIST; ViewMode.GALLERY -> ViewMode.GRID; else -> tab.viewMode }
            val on = cur == m
            DropdownMenuItem(
                text = { Text(when (m) { ViewMode.GRID -> "Icons"; else -> m.label }) },
                leadingIcon = { Icon(viewModeIcon(m), null, Modifier.size(20.dp), tint = if (on) cs.primary else cs.onSurface) },
                trailingIcon = {
                    // The small switch belongs to its view, so it sits right beside it; picking either side also switches to that view.
                    if (m == ViewMode.LIST) {
                        TwoWay("Simple", "Detailed", vm.detailsColumns) { d -> vm.setViewMode(tab, ViewMode.LIST); vm.setDetailsColumns(d) }
                    } else if (m == ViewMode.GRID) {
                        TwoWay("Thumbnails", "Gallery", tab.viewMode == ViewMode.GALLERY && on) { g -> vm.setViewMode(tab, if (g) ViewMode.GALLERY else ViewMode.GRID) }
                    } else if (on) Icon(DexIcons.Check, null, Modifier.size(18.dp), tint = cs.primary)
                },
                onClick = { if (!on) vm.setViewMode(tab, m); onDismiss() },
            )
        }
        HorizontalDivider()
        // Switches stay open so the change can be seen behind the menu; choosing a view closes it.
        ToggleMenuRow("Show hidden files", DexIcons.Eye, vm.showHidden, "Ctrl+H") { vm.setShowHidden(!vm.showHidden) }
        ToggleMenuRow("Remember view per folder", DexIcons.Folder, vm.perFolderView) { vm.setPerFolderView(!vm.perFolderView) }
    }
}

/** Small two-way switch, same look as Ascending / Descending. */
@Composable
private fun TwoWay(first: String, second: String, second_on: Boolean, onPick: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(Radius.xs).background(cs.outlineVariant).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        for ((label, d) in listOf(first to false, second to true)) {
            val on = second_on == d
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (on) androidx.compose.ui.text.font.FontWeight.SemiBold else androidx.compose.ui.text.font.FontWeight.Medium,
                color = if (on) cs.onPrimary else cs.onSurfaceVariant,
                modifier = Modifier
                    .clip(Radius.xs)
                    .background(if (on) cs.primary else Color.Transparent)
                    .clickable { onPick(d) }
                    .padding(horizontal = 11.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun MenuRow(label: String, icon: ImageVector, enabled: Boolean = true, hint: String? = null, onClick: () -> Unit) {
    if (hint != null) {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            trailingIcon = { MenuHint(hint) },
            enabled = enabled,
            onClick = onClick,
        )
    } else {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            enabled = enabled,
            onClick = onClick,
        )
    }
}

@Composable
private fun MoreMenu(vm: ExplorerViewModel, tab: TabState, roomy: Boolean, expanded: Boolean, onDismiss: () -> Unit) {
    val canWrite = !tab.isVirtual && !tab.isSearch
    DropdownMenu(shape = Radius.l, containerColor = MaterialTheme.colorScheme.surfaceContainerHigh, expanded = expanded, onDismissRequest = onDismiss) {
        if (canWrite) {
            MenuRow("New folder", DexIcons.NewFolder, hint = "Ctrl+Shift+N") { onDismiss(); vm.requestNew(true) }
            MenuRow("New text file", DexIcons.NewFile) { onDismiss(); vm.requestNew(false) }
            MenuRow("Paste", DexIcons.Paste, enabled = vm.clip != null, hint = "Ctrl+V") { onDismiss(); vm.paste() }
            HorizontalDivider()
        }
        MenuRow("New tab", DexIcons.Plus, hint = "Ctrl+T") {
            onDismiss()
            vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path)
        }
        ToggleMenuRow("Dual pane", DexIcons.DualPane, vm.dual, "F9") { vm.setDual(!vm.dual); onDismiss() }
        ToggleMenuRow("Preview pane", DexIcons.Preview, vm.previewVisible, "Alt+P") { vm.setPreviewVisible(!vm.previewVisible); onDismiss() }
        MenuRow("Refresh", DexIcons.Reset, hint = "Ctrl+R") { onDismiss(); vm.refresh(tab) }
        HorizontalDivider()
        MenuRow("Select all", DexIcons.SelectAll, hint = "Ctrl+A") { onDismiss(); vm.selectAll(tab) }
        MenuRow("New window", DexIcons.Plus, hint = "Ctrl+N") {
            onDismiss()
            vm.openInNewWindow(if (tab.isVirtual) null else tab.path)
        }
        HorizontalDivider()
        MenuRow("Settings", DexIcons.Settings) { onDismiss(); vm.openSettings(fromLeft = false) }
        MenuRow("Keyboard shortcuts", DexIcons.Keyboard, hint = "F1") { onDismiss(); vm.dialog = DialogState.Shortcuts }
    }
}

// ---------------------------------------------------------------------------------------------- selection

/** Phone-style action row along the bottom while items are selected. */
@Composable
fun BottomActionBar(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    Row(
        Modifier.fillMaxWidth().background(cs.surface).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        if (inTrash) {
            ActionItem(DexIcons.Reset, "Restore") { vm.restoreSelected(tab) }
            ActionItem(DexIcons.Trash, "Delete") { vm.requestDelete(permanent = true, tab = tab) }
        } else {
            ActionItem(DexIcons.Copy, "Copy") { vm.copySelection(false, tab) }
            ActionItem(DexIcons.Cut, "Cut") { vm.copySelection(true, tab) }
            ActionItem(DexIcons.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
            ActionItem(DexIcons.Trash, "Delete") { vm.requestDelete(tab = tab) }
        }
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(Radius.s).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = c)
    }
}
