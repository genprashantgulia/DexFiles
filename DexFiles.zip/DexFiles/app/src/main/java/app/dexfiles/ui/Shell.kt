package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.PathUtils
import app.dexfiles.core.SortKey
import app.dexfiles.state.DialogState
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import app.dexfiles.state.ViewMode
import kotlinx.coroutines.delay
import java.io.File

/** Phone, small tablet / narrow window, and large tablet or DeX window. */
enum class WindowClass { Compact, Medium, Expanded }

fun windowClassFor(width: Dp): WindowClass = when {
    width < 600.dp -> WindowClass.Compact
    width < 840.dp -> WindowClass.Medium
    else -> WindowClass.Expanded
}

private val BtnSize = 44.dp

/** One top bar for every screen size: it shows only what fits and tucks the rest into menus. */
@Composable
fun AdaptiveTopBar(vm: ExplorerViewModel, wc: WindowClass, onMenu: () -> Unit) {
    val tab = vm.current
    val sel = vm.selectedEntries(tab)
    if (sel.isNotEmpty()) SelectionBar(vm, tab, sel, wc) else NavBar(vm, tab, wc, onMenu)
}

@Composable
private fun PillGroup(content: @Composable RowScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.clip(shape).background(cs.surface).border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), shape).padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

// ---------------------------------------------------------------------------------------------- navigation bar

@Composable
private fun NavBar(vm: ExplorerViewModel, tab: TabState, wc: WindowClass, onMenu: () -> Unit) {
    val expanded = wc == WindowClass.Expanded
    val roomy = wc != WindowClass.Compact
    val canWrite = !tab.isVirtual && !tab.isSearch
    var searchOpen by remember(tab.id) { mutableStateOf(tab.query.isNotEmpty()) }
    var editing by remember(tab.id) { mutableStateOf(false) }
    var searchFocus by remember { mutableIntStateOf(0) }
    var lastSearchTick by remember { mutableIntStateOf(vm.searchTick) }
    var lastAddressTick by remember { mutableIntStateOf(vm.addressTick) }
    var optionsMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    LaunchedEffect(vm.searchTick) {
        if (vm.searchTick != lastSearchTick) {
            lastSearchTick = vm.searchTick
            searchOpen = true
            searchFocus++
        }
    }
    LaunchedEffect(vm.addressTick) {
        if (vm.addressTick != lastAddressTick) {
            lastAddressTick = vm.addressTick
            editing = true
        }
    }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PillGroup {
            IconBtn(Icons.Filled.Menu, "Sidebar", size = BtnSize, active = expanded && vm.sidebarVisible) {
                if (expanded) vm.setSidebarVisible(!vm.sidebarVisible) else onMenu()
            }
        }
        PillGroup {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Back", enabled = tab.back.isNotEmpty() || tab.isSearch, size = BtnSize) { vm.goBack(tab) }
            if (roomy) {
                IconBtn(Icons.AutoMirrored.Filled.ArrowForward, "Forward", enabled = tab.forward.isNotEmpty(), size = BtnSize) { vm.goForward(tab) }
                IconBtn(Icons.Filled.ArrowUpward, "Up", enabled = vm.canGoUp(tab), size = BtnSize) { vm.goUp(tab) }
            }
        }

        when {
            editing -> PathEditor(vm, tab, Modifier.weight(1f)) { editing = false }
            searchOpen && !expanded -> SearchPill(vm, tab, Modifier.weight(1f), searchFocus) {
                searchOpen = false
                vm.clearSearch(tab)
            }
            else -> TitleArea(vm, tab, Modifier.weight(1f)) { editing = true }
        }

        if (expanded) SearchPill(vm, tab, Modifier.width(260.dp), searchFocus, null)

        if (expanded || !searchOpen) {
            PillGroup {
                if (!expanded) {
                    IconBtn(Icons.Filled.Search, "Search", size = BtnSize) { searchOpen = true; searchFocus++ }
                }
                if (canWrite && roomy) {
                    IconBtn(Icons.Filled.CreateNewFolder, "New folder", size = BtnSize) { vm.requestNew(true) }
                }
                Box {
                    IconBtn(viewModeIcon(tab.viewMode), "View options", size = BtnSize) { optionsMenu = true }
                    ViewOptionsMenu(vm, tab, optionsMenu) { optionsMenu = false }
                }
                Box {
                    IconBtn(Icons.Filled.MoreVert, "More", size = BtnSize) { moreMenu = true }
                    MoreMenu(vm, tab, roomy, moreMenu) { moreMenu = false }
                }
            }
        }
    }
}

/** Folder name as a large title with the item count under it; tap it for the path and quick actions. */
@Composable
private fun TitleArea(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onTypePath: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val labels = vm.rootLabelMap()
    var menu by remember { mutableStateOf(false) }
    val crumbs = if (tab.isVirtual || tab.isSearch) emptyList() else PathUtils.crumbs(tab.path, labels)
    val title = when {
        tab.isSearch -> "Search"
        tab.isVirtual -> Loc.title(tab.path, labels)
        else -> crumbs.lastOrNull()?.label ?: tab.path
    }
    val subtitle = when {
        tab.isSearch -> if (tab.query.isBlank()) "" else "Results for \"${tab.query}\""
        tab.path == Loc.HOME -> ""
        tab.loading -> "Loading…"
        tab.entries.size == 1 -> "1 item"
        else -> "${tab.entries.size} items"
    }
    Box(modifier) {
        Column(
            Modifier.clip(RoundedCornerShape(12.dp)).clickable { menu = true }.padding(horizontal = 10.dp, vertical = 2.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = cs.onSurfaceVariant)
            }
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            for (c in crumbs.asReversed()) {
                DropdownMenuItem(
                    text = { Text(c.label) },
                    leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(20.dp), tint = kindColor(FileKind.FOLDER)) },
                    onClick = { menu = false; vm.navigate(tab, c.path) },
                )
            }
            if (crumbs.isNotEmpty()) HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Go to path…") },
                leadingIcon = { Icon(Icons.Filled.Edit, null, Modifier.size(20.dp)) },
                onClick = { menu = false; onTypePath() },
            )
            DropdownMenuItem(
                text = { Text("Open in new tab") },
                leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(20.dp)) },
                onClick = { menu = false; vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path) },
            )
        }
    }
}

@Composable
private fun PathEditor(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, onDone: () -> Unit) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val start = if (tab.isVirtual) "" else tab.path
    var text by remember { mutableStateOf(TextFieldValue(start, TextRange(0, start.length))) }
    var hadFocus by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(30)
        try { focus.requestFocus() } catch (_: Exception) { }
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    fun commit() {
        val typed = text.text.trim()
        onDone()
        focusManager.clearFocus()
        vm.typing = false
        if (typed.isEmpty()) return
        val base = if (tab.isVirtual) vm.primaryRoot else tab.path
        val resolved = PathUtils.resolveTyped(base, typed, vm.primaryRoot)
        val f = File(resolved)
        when {
            f.isDirectory -> vm.navigate(tab, resolved)
            f.exists() -> vm.reveal(resolved)
            else -> vm.toast("Can't find \"$typed\"")
        }
    }

    DexTextField(
        value = text,
        onValueChange = { text = it },
        modifier = modifier,
        placeholder = "Type a path, for example /storage/emulated/0/Download",
        shape = RoundedCornerShape(24.dp),
        focusRequester = focus,
        onEnter = { commit() },
        onEscape = { onDone(); focusManager.clearFocus(); vm.typing = false },
        onFocusChange = { f ->
            vm.typing = f
            if (f) hadFocus = true else if (hadFocus) onDone()
        },
    )
}

@Composable
private fun SearchPill(vm: ExplorerViewModel, tab: TabState, modifier: Modifier, focusSignal: Int, onClose: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var tv by remember { mutableStateOf(TextFieldValue(tab.query)) }

    LaunchedEffect(focusSignal) {
        if (focusSignal > 0) {
            delay(30)
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    LaunchedEffect(tab.id, tab.query) {
        if (tab.query != tv.text) tv = TextFieldValue(tab.query)
    }
    DisposableEffect(Unit) { onDispose { vm.typing = false } }

    DexTextField(
        value = tv,
        onValueChange = { tv = it; vm.setQuery(tab, it.text) },
        modifier = modifier,
        placeholder = "Search",
        shape = RoundedCornerShape(24.dp),
        leading = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(20.dp), tint = cs.onSurfaceVariant) },
        trailing = {
            if (tv.text.isNotEmpty() || onClose != null) {
                Icon(
                    Icons.Filled.Close, contentDescription = "Clear search",
                    modifier = Modifier.size(22.dp).clip(CircleShape).clickable {
                        tv = TextFieldValue("")
                        vm.clearSearch(tab)
                        onClose?.invoke()
                    },
                    tint = cs.onSurfaceVariant,
                )
            }
        },
        focusRequester = focus,
        onEnter = { focusManager.clearFocus(); vm.typing = false },
        onEscape = {
            tv = TextFieldValue("")
            vm.clearSearch(tab)
            focusManager.clearFocus()
            vm.typing = false
            onClose?.invoke()
        },
        onFocusChange = { vm.typing = it },
    )
}

// ---------------------------------------------------------------------------------------------- menus

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
private fun ViewOptionsMenu(vm: ExplorerViewModel, tab: TabState, expanded: Boolean, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        SectionLabel("View as")
        for (m in ViewMode.entries) {
            val on = tab.viewMode == m
            DropdownMenuItem(
                text = { Text(m.label) },
                leadingIcon = { Icon(viewModeIcon(m), null, Modifier.size(20.dp), tint = if (on) cs.primary else cs.onSurface) },
                trailingIcon = { if (on) Icon(Icons.Filled.Check, null, Modifier.size(18.dp), tint = cs.primary) },
                onClick = { vm.setViewMode(tab, m); onDismiss() },
            )
        }
        HorizontalDivider()
        SectionLabel("Sort by")
        val spec = tab.effectiveSort
        for (k in SortKey.entries) {
            CheckItem(k.label, spec.key == k) { vm.setSort(tab, k); onDismiss() }
        }
        HorizontalDivider()
        CheckItem("Ascending", spec.ascending) { vm.setSortAscending(tab, true); onDismiss() }
        CheckItem("Descending", !spec.ascending) { vm.setSortAscending(tab, false); onDismiss() }
        CheckItem("Folders first", vm.foldersFirst) { vm.setFoldersFirst(!vm.foldersFirst) }
        HorizontalDivider()
        CheckItem("Show hidden files", vm.showHidden, "Ctrl+H") { vm.setShowHidden(!vm.showHidden); onDismiss() }
    }
}

@Composable
private fun MenuRow(label: String, icon: ImageVector, enabled: Boolean = true, hint: String? = null, onClick: () -> Unit) {
    if (hint != null) {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            trailingIcon = { MenuHint(hint) },
            enabled = enabled,
            onClick = onClick,
        )
    } else {
        DropdownMenuItem(
            text = { Text(label) },
            leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
            enabled = enabled,
            onClick = onClick,
        )
    }
}

@Composable
private fun MoreMenu(vm: ExplorerViewModel, tab: TabState, roomy: Boolean, expanded: Boolean, onDismiss: () -> Unit) {
    val canWrite = !tab.isVirtual && !tab.isSearch
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        if (canWrite) {
            if (!roomy) MenuRow("New folder", Icons.Filled.CreateNewFolder) { onDismiss(); vm.requestNew(true) }
            MenuRow("New text file", Icons.Filled.NoteAdd) { onDismiss(); vm.requestNew(false) }
            MenuRow("Paste", Icons.Filled.ContentPaste, enabled = vm.clip != null, hint = "Ctrl+V") { onDismiss(); vm.paste() }
            HorizontalDivider()
        }
        MenuRow("New tab", Icons.Filled.Add, hint = "Ctrl+T") {
            onDismiss()
            vm.addTab(vm.currentPane, if (tab.isVirtual) Loc.HOME else tab.path)
        }
        CheckItem("Dual pane", vm.dual, "F9") { vm.setDual(!vm.dual); onDismiss() }
        CheckItem("Preview pane", vm.previewVisible, "Alt+P") { vm.setPreviewVisible(!vm.previewVisible); onDismiss() }
        MenuRow("Refresh", Icons.Filled.Refresh, hint = "Ctrl+R") { onDismiss(); vm.refresh(tab) }
        HorizontalDivider()
        MenuRow("Select all", Icons.Filled.SelectAll, hint = "Ctrl+A") { onDismiss(); vm.selectAll(tab) }
        MenuRow("New window", Icons.Filled.Add, hint = "Ctrl+N") {
            onDismiss()
            vm.openInNewWindow(if (tab.isVirtual) null else tab.path)
        }
        HorizontalDivider()
        MenuRow("Settings", Icons.Filled.Settings) { onDismiss(); vm.dialog = DialogState.Settings }
        MenuRow("Keyboard shortcuts", Icons.Filled.Keyboard, hint = "F1") { onDismiss(); vm.dialog = DialogState.Shortcuts }
    }
}

// ---------------------------------------------------------------------------------------------- selection

@Composable
private fun SelectionBar(vm: ExplorerViewModel, tab: TabState, sel: List<FileEntry>, wc: WindowClass) {
    val roomy = wc != WindowClass.Compact
    val inTrash = tab.path == Loc.TRASH
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PillGroup {
            IconBtn(Icons.Filled.Close, "Clear selection", size = BtnSize) { vm.clearSelection(tab) }
        }
        Text(
            if (sel.size == 1) "1 selected" else "${sel.size} selected",
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            modifier = Modifier.weight(1f).padding(start = 4.dp),
        )
        PillGroup {
            if (inTrash) {
                IconBtn(Icons.Filled.Restore, "Restore", size = BtnSize) { vm.restoreSelected(tab) }
                IconBtn(Icons.Filled.DeleteForever, "Delete forever", size = BtnSize) { vm.requestDelete(permanent = true, tab = tab) }
            } else if (roomy) {
                IconBtn(Icons.Filled.ContentCopy, "Copy", size = BtnSize) { vm.copySelection(false, tab) }
                IconBtn(Icons.Filled.ContentCut, "Cut", size = BtnSize) { vm.copySelection(true, tab) }
                IconBtn(Icons.Filled.Share, "Share", enabled = sel.any { !it.isDir }, size = BtnSize) { vm.share(sel) }
                IconBtn(Icons.Filled.Delete, "Delete", size = BtnSize) { vm.requestDelete(tab = tab) }
            }
            IconBtn(Icons.Filled.SelectAll, "Select all", size = BtnSize) { vm.selectAll(tab) }
            Box {
                IconBtn(Icons.Filled.MoreVert, "More", size = BtnSize) { more = true }
                DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                    if (!inTrash) {
                        MenuRow("Rename", Icons.Filled.DriveFileRenameOutline, enabled = sel.size == 1, hint = "F2") {
                            more = false
                            vm.requestRename(tab)
                        }
                    }
                    MenuRow("Invert selection", Icons.Filled.SelectAll) { more = false; vm.invertSelection(tab) }
                    MenuRow("Copy path", Icons.Filled.ContentCopy) { more = false; vm.copyPath(sel) }
                    MenuRow("Properties", Icons.Filled.Info) { more = false; vm.dialog = DialogState.Properties(sel) }
                }
            }
        }
    }
}

/** Phone-style action row along the bottom while items are selected. */
@Composable
fun BottomActionBar(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val sel = vm.selectedEntries(tab)
    if (sel.isEmpty()) return
    val inTrash = tab.path == Loc.TRASH
    Row(
        Modifier.fillMaxWidth().background(cs.surface).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        if (inTrash) {
            ActionItem(Icons.Filled.Restore, "Restore") { vm.restoreSelected(tab) }
            ActionItem(Icons.Filled.DeleteForever, "Delete") { vm.requestDelete(permanent = true, tab = tab) }
        } else {
            ActionItem(Icons.Filled.ContentCopy, "Copy") { vm.copySelection(false, tab) }
            ActionItem(Icons.Filled.ContentCut, "Cut") { vm.copySelection(true, tab) }
            ActionItem(Icons.Filled.Share, "Share", enabled = sel.any { !it.isDir }) { vm.share(sel) }
            ActionItem(Icons.Filled.Delete, "Delete") { vm.requestDelete(tab = tab) }
        }
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = c)
    }
}
