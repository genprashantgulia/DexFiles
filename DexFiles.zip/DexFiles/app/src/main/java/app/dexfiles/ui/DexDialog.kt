package app.dexfiles.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel

/**
 * The one dialog shell (mock "Dialogs"): 28dp card, 20/600 title, body, pill buttons at the bottom right.
 * It settles in on a spring (scale 0.94 to 1) and a tap on the scrim dismisses it, everywhere.
 */
@Composable
fun DexDialog(
    title: String,
    onDismiss: () -> Unit,
    width: Dp = 420.dp,
    actions: @Composable RowScope.() -> Unit,
    body: @Composable ColumnScope.() -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, dialogSpring()) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }.padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                shape = Radius.xl,
                color = dialogSurface(),
                tonalElevation = 0.dp,
                shadowElevation = 24.dp,
                border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f)),
                modifier = Modifier
                    .widthIn(max = width).fillMaxWidth()
                    .graphicsLayer { val s = 0.94f + 0.06f * t.value; scaleX = s; scaleY = s; alpha = t.value.coerceIn(0f, 1f) }
                    .pointerInput(Unit) { detectTapGestures { } },
            ) {
                Column(Modifier.padding(start = 24.dp, top = 24.dp, end = 24.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurface)
                    Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) { body() }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End), verticalAlignment = Alignment.CenterVertically) { actions() }
                }
            }
        }
    }
}

@Composable
fun dialogSurface(): Color {
    val cs = MaterialTheme.colorScheme
    return if (cs.background == Color.Black) Color(0xFF1E1E22) else cs.surface
}

/** Body paragraph: 14sp, dim. */
@Composable
fun DexBody(text: String) {
    Text(text, fontSize = 14.sp, lineHeight = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

enum class DexBtn { Plain, Primary, Danger }

@Composable
fun DexButton(label: String, kind: DexBtn = DexBtn.Plain, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background == Color.Black
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val hovered by src.collectIsHoveredAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "btnPress")
    val bg = when (kind) {
        DexBtn.Primary -> cs.primary
        DexBtn.Danger -> if (dark) Color(0xFFFF8A80).copy(alpha = 0.16f) else cs.error.copy(alpha = 0.12f)
        DexBtn.Plain -> if (hovered) Sel.hover() else Color.Transparent
    }
    val fg = when (kind) {
        DexBtn.Primary -> cs.onPrimary
        DexBtn.Danger -> if (dark) Color(0xFFFF9E94) else cs.error
        DexBtn.Plain -> cs.onSurface.copy(alpha = 0.86f)
    }
    Box(
        Modifier.height(40.dp).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).background(bg)
            .hoverable(src).clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (enabled) fg else fg.copy(alpha = 0.38f)) }
}

/** Radio row from the mock's Name-conflict card: 44dp, quiet-amber plate when chosen, spring dot. */
@Composable
fun DexOption(label: String, selected: Boolean, hint: String? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background == Color.Black
    val dot by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "radio")
    val ring = if (selected) cs.primary else if (dark) Color(0xFF5A5A64) else cs.outline
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp).clip(Radius.m).background(if (selected) Sel.plate() else Color.Transparent)
            .clickable(role = Role.RadioButton, onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(20.dp).border(2.dp, ring, CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(10.dp).graphicsLayer { scaleX = dot; scaleY = dot }.background(cs.primary, CircleShape))
        }
        Column {
            Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
            if (hint != null) Text(hint, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
}

/** Mock text field: 48dp, 14dp radius, raised fill, amber 60% outline while focused. */
@Composable
fun DexField(
    value: TextFieldValue,
    onChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    hint: String = "",
    error: Boolean = false,
    imeDone: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val line = when {
        error -> cs.error
        focused -> cs.primary.copy(alpha = 0.6f)
        else -> Color.Transparent
    }
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        interactionSource = src,
        textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp, fontWeight = FontWeight.Medium),
        cursorBrush = SolidColor(cs.primary),
        keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { imeDone?.invoke() }),
        modifier = modifier.fillMaxWidth().height(48.dp).clip(Radius.m).background(cs.surfaceContainer).border(1.5.dp, line, Radius.m).padding(horizontal = 14.dp),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.text.isEmpty() && hint.isNotEmpty()) Text(hint, fontSize = 16.sp, color = cs.onSurfaceVariant.copy(alpha = 0.7f))
                inner()
            }
        },
    )
}

/** Small dim label above a field. */
@Composable
fun DexLabel(text: String) {
    Text(text, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
}

/** Key/value line for Properties and Shortcuts: 92dp dim label, then the value. */
@Composable
fun DexKV(label: String, value: String, labelWidth: Dp = 92.dp, bold: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label, fontSize = 14.sp, color = cs.onSurfaceVariant, modifier = Modifier.widthIn(min = labelWidth, max = labelWidth))
        Text(value, fontSize = 14.sp, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal, color = cs.onSurface, modifier = Modifier.weight(1f))
    }
}

/** The one settle-in spring for every floating card (dialogs, Settings). */
fun dialogSpring(): androidx.compose.animation.core.SpringSpec<Float> = spring(dampingRatio = 0.78f, stiffness = 380f)
