package app.dexfiles.ui2.design

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as GSize
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileKind

/** Per-folder look. Stage 4 stores one of these per path; until then every folder uses Default. */
data class FolderStyle(val color: Color = Color(0xFFFFB63D), val glyph: ImageVector? = null) {
    companion object { val Default = FolderStyle() }
}

/** Hand-drawn two-tone folder (tab + body + soft highlight), optional centred glyph. Scales to any size. */
@Composable
fun FolderGlyph(size: Dp, style: FolderStyle = FolderStyle.Default, modifier: Modifier = Modifier) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val w = this.size.width; val h = this.size.height
            val back = style.color.copy(alpha = 1f)
            val dark = Color(
                (style.color.red * 0.78f), (style.color.green * 0.78f), (style.color.blue * 0.78f), 1f,
            )
            // back panel with tab
            drawRoundRect(dark, Offset(w * 0.04f, h * 0.14f), GSize(w * 0.92f, h * 0.70f), CornerRadius(w * 0.12f))
            drawRoundRect(dark, Offset(w * 0.04f, h * 0.08f), GSize(w * 0.40f, h * 0.22f), CornerRadius(w * 0.09f))
            // front body
            drawRoundRect(
                Brush.verticalGradient(listOf(back.copy(alpha = 1f), Color(back.red * 0.93f, back.green * 0.93f, back.blue * 0.93f, 1f)), startY = h * 0.28f, endY = h * 0.9f),
                Offset(w * 0.04f, h * 0.28f), GSize(w * 0.92f, h * 0.62f), CornerRadius(w * 0.12f),
            )
            // top highlight line
            drawRoundRect(Color.White.copy(alpha = 0.28f), Offset(w * 0.10f, h * 0.30f), GSize(w * 0.80f, h * 0.025f), CornerRadius(h * 0.012f))
        }
        style.glyph?.let { Icon(it, null, Modifier.size(size * 0.34f).graphicsLayer { translationY = size.toPx() * 0.08f }, tint = Color.White.copy(alpha = 0.92f)) }
    }
}

fun kindGlyph(k: FileKind): ImageVector = when (k) {
    FileKind.IMAGE -> Icons.Rounded.Image
    FileKind.VIDEO -> Icons.Rounded.Movie
    FileKind.AUDIO -> Icons.Rounded.MusicNote
    FileKind.PDF -> Icons.Rounded.PictureAsPdf
    FileKind.DOCUMENT -> Icons.Rounded.Description
    FileKind.SHEET -> Icons.Rounded.TableChart
    FileKind.SLIDES -> Icons.Rounded.Slideshow
    FileKind.ARCHIVE -> Icons.Rounded.FolderZip
    FileKind.APK -> Icons.Rounded.Android
    FileKind.CODE -> Icons.Rounded.Code
    FileKind.TEXT -> Icons.Rounded.Notes
    else -> Icons.Rounded.InsertDriveFile
}

fun kindTint(k: FileKind): Color = when (k) {
    FileKind.IMAGE -> Color(0xFF34C48B)
    FileKind.VIDEO -> Color(0xFF9B6BFF)
    FileKind.AUDIO -> Color(0xFFFF5C9D)
    FileKind.PDF -> Color(0xFFFF5B4F)
    FileKind.DOCUMENT -> Color(0xFF4F8DFF)
    FileKind.SHEET -> Color(0xFF2FBF6B)
    FileKind.SLIDES -> Color(0xFFFF9140)
    FileKind.ARCHIVE -> Color(0xFFC98E4A)
    FileKind.APK -> Color(0xFF3DDC84)
    FileKind.CODE -> Color(0xFF22BDB5)
    else -> Color(0xFF8E98A6)
}

/** Non-folder file glyph: tinted rounded tile. */
@Composable
fun KindTile(kind: FileKind, size: Dp, modifier: Modifier = Modifier) {
    val t = kindTint(kind)
    Box(modifier.size(size).clip(RoundedCornerShape(size * 0.26f)).background(t.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        Icon(kindGlyph(kind), null, Modifier.size(size * 0.5f), tint = t)
    }
}
