package app.dexfiles.ui2.design

import androidx.compose.ui.geometry.Size as GSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/** Per-folder look. Stage 4 stores one of these per path; until then every folder uses Default. */
data class FolderStyle(val color: Color = Color(0xFFFFB63D), val glyph: ImageVector? = null) {
    companion object { val Default = FolderStyle() }
}




