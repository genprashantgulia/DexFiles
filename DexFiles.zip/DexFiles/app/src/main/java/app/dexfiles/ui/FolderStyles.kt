package app.dexfiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import app.dexfiles.core.FileEntry
import app.dexfiles.state.ExplorerViewModel

/** Per-folder colour and glyph, iPadOS style. Stored by the view model as "RRGGBB|glyph". */
object FolderStyles {
    val colors = listOf(
        0xFFFFB400, 0xFFFF8A3D, 0xFFFF5B5B, 0xFFFF5C9D, 0xFFB06BFF,
        0xFF5B8CFF, 0xFF22BDB5, 0xFF34C48B, 0xFF9AA3AE, 0xFF8D6E63,
    )
    val glyphs: List<Pair<String, ImageVector>> = listOf(
        "none" to Icons.Filled.Remove, "star" to Icons.Filled.Star, "heart" to Icons.Filled.Favorite,
        "work" to Icons.Filled.Work, "school" to Icons.Filled.School, "music" to Icons.Filled.MusicNote,
        "photo" to Icons.Filled.Image, "video" to Icons.Filled.Movie, "code" to Icons.Filled.Code,
        "home" to Icons.Filled.Home, "download" to Icons.Filled.Download, "game" to Icons.Filled.SportsEsports,
        "lock" to Icons.Filled.Lock, "cloud" to Icons.Filled.Cloud, "camera" to Icons.Filled.CameraAlt,
        "book" to Icons.Filled.MenuBook, "cart" to Icons.Filled.ShoppingCart, "travel" to Icons.Filled.Flight,
        "money" to Icons.Filled.AttachMoney, "idea" to Icons.Filled.Lightbulb,
    )

    fun glyph(key: String?): ImageVector? = if (key == null || key == "none") null else glyphs.firstOrNull { it.first == key }?.second

    fun parse(v: String?): Pair<Color?, String?> {
        if (v == null) return null to null
        val parts = v.split("|")
        val c = parts.getOrNull(0)?.takeIf { it.length == 8 }?.toLongOrNull(16)?.let { Color(it) }
        return c to parts.getOrNull(1)?.takeIf { it.isNotEmpty() }
    }

    fun encode(c: Color?, g: String?): String? {
        if (c == null && (g == null || g == "none")) return null
        val hex = c?.let { String.format("%08X", (it.value shr 32).toLong() and 0xFFFFFFFFL) } ?: ""
        return hex + "|" + (g ?: "")
    }
}

@Composable
fun CustomizeFolderDialog(vm: ExplorerViewModel, entry: FileEntry) {
    val cs = MaterialTheme.colorScheme
    val (curColor, curGlyph) = FolderStyles.parse(vm.folderStyles[entry.path])
    fun apply(c: Color?, g: String?) = vm.setFolderStyle(entry.path, FolderStyles.encode(c, g))

    AlertDialog(
        onDismissRequest = { vm.dialog = null },
        shape = RoundedCornerShape(28.dp),
        containerColor = cs.surfaceContainerHigh,
        title = { Text("Customize folder") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                FileThumb(entry, 96.dp)
                Spacer(Modifier.height(4.dp))
                Text(entry.name, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1)
                Spacer(Modifier.height(16.dp))
                for (row in FolderStyles.colors.chunked(5)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (c in row) {
                            val col = Color(c)
                            val on = curColor == col
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(col)
                                    .then(if (on) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                                    .clickable { apply(col, curGlyph) },
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Spacer(Modifier.height(6.dp))
                for (row in FolderStyles.glyphs.chunked(5)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for ((key, icon) in row) {
                            val on = (curGlyph ?: "none") == key
                            Box(
                                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                                    .background(if (on) cs.primary.copy(alpha = 0.22f) else cs.surfaceContainerHighest)
                                    .clickable { apply(curColor, key) },
                                contentAlignment = Alignment.Center,
                            ) { Icon(icon, key, Modifier.size(22.dp), tint = if (on) cs.primary else cs.onSurface) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.dialog = null }) { Text("Done") } },
        dismissButton = { TextButton(onClick = { vm.setFolderStyle(entry.path, null) }) { Text("Reset") } },
    )
}
