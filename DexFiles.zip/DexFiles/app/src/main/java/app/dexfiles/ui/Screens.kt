@file:OptIn(ExperimentalLayoutApi::class)

package app.dexfiles.ui

import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import app.dexfiles.data.MediaQueries
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.core.DuplicateGroup
import app.dexfiles.core.FileEntry
import app.dexfiles.core.FileKind
import app.dexfiles.core.Format
import app.dexfiles.data.Volume
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.state.TabState
import java.io.File

// ---------------------------------------------------------------------------------------------- home

@Composable
fun HomeScreen(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val recents by produceState<List<FileEntry>?>(initialValue = null, tab.path) {
        value = withContext(Dispatchers.IO) {
            try {
                MediaQueries.query(ctx, Loc.RECENT).take(36)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    val asList = tab.viewMode != app.dexfiles.state.ViewMode.GRID && tab.viewMode != app.dexfiles.state.ViewMode.GALLERY
    if (asList) {
        androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Recent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    DexButton("See all") { vm.navigate(tab, Loc.RECENT) }
                }
            }
            val l = recents.orEmpty()
            if (l.isEmpty()) item { Text(if (recents == null) "Loading\u2026" else "Nothing recent yet.", color = cs.onSurfaceVariant) }
            items(l, key = { it.path }) { e ->
                Row(
                    Modifier.fillMaxWidth().height(64.dp).clip(Radius.s).clickable { vm.open(tab, e) }.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FileThumb(e, 44.dp, crop = false)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(Fmt.date(e.modified), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(136.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                DexButton("See all") { vm.navigate(tab, Loc.RECENT) }
            }
        }
        val list = recents
        when {
            list == null -> item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Loading\u2026", color = cs.onSurfaceVariant)
            }
            list.isEmpty() -> item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Nothing recent yet. Files you add or change will show up here.", color = cs.onSurfaceVariant)
            }
            else -> items(list, key = { it.path }) { e -> RecentCell(vm, tab, e) }
        }
    }
}

@Composable
private fun RecentCell(vm: ExplorerViewModel, tab: TabState, e: FileEntry) {
    val cs = MaterialTheme.colorScheme
    val media = e.kind == FileKind.IMAGE || e.kind == FileKind.VIDEO
    Column(
        Modifier.clip(Radius.m).clickable { vm.open(tab, e) }.padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.size(104.dp).clip(Radius.m).background(cs.surfaceContainer),
            contentAlignment = Alignment.Center,
        ) {
            FileThumb(e, if (media) 104.dp else 52.dp, crop = false)
        }
        Text(e.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text(Fmt.date(e.modified), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
}

// ---------------------------------------------------------------------------------------------- storage analysis

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzeScreen(vm: ExplorerViewModel, tab: TabState) {
    val cs = MaterialTheme.colorScheme
    val a = vm.analyze
    LaunchedEffect(Unit) {
        if (a.volume == null) vm.volumes.firstOrNull()?.let { a.volume = it.path }
    }
    val vol = a.volume
    val busy = a.running || a.dupRunning || a.emptyRunning

    Column(
        Modifier.fillMaxWidth().fillMaxHeight().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Storage analysis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(
            "See what is using your space and find duplicate files. Nothing is deleted unless you choose it.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurface.copy(alpha = 0.65f),
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (v in vm.volumes) {
                DexChip(v.label, vol == v.path) { if (!busy) a.volume = v.path }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            DexButton("Scan usage", DexBtn.Primary, enabled = vol != null && !busy) { vol?.let { vm.startAnalyze(it) } }
            DexButton("Find duplicates", DexBtn.Plain, enabled = vol != null && !busy) { vol?.let { vm.startDuplicates(it) } }
            DexButton("Empty folders", DexBtn.Plain, enabled = vol != null && !busy) { vol?.let { vm.startEmptyFolders(it) } }
            DexButton("Installers", DexBtn.Plain) { vm.navigate(tab, Loc.APKS) }
            if (busy) DexButton("Cancel") { vm.cancelAnalyze() }
        }
        if (busy) {
            LinearProgressIndicator(Modifier.fillMaxWidth().height(4.dp))
            Text("Scanned ${a.scanned} files...", style = MaterialTheme.typography.bodySmall)
        }

        val rep = a.report
        if (rep != null) {
            SectionTitle("${Format.size(rep.totalBytes)} in ${rep.fileCount} files")
            val rows = rep.byKind.entries.sortedByDescending { it.value }
            val max = (rows.firstOrNull()?.value ?: 1L).coerceAtLeast(1L)
            for ((kind, bytes) in rows) {
                if (bytes <= 0L) continue
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(kindIcon(kind), contentDescription = null, tint = kindColor(kind), modifier = Modifier.size(18.dp))
                    Text(kind.label, Modifier.width(120.dp), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    Box(Modifier.weight(1f).height(10.dp).clip(Radius.xs).background(cs.onSurface.copy(alpha = 0.08f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth((bytes.toFloat() / max).coerceIn(0.01f, 1f)).background(kindColor(kind)))
                    }
                    Text(
                        "${Format.size(bytes)}  (${rep.countByKind[kind] ?: 0})",
                        Modifier.width(150.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurface.copy(alpha = 0.75f),
                    )
                }
            }
            if (rep.largest.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                SectionTitle("Largest files")
                for (f in rep.largest) {
                    FileLine(vm, f.path, f.size, onTrash = {
                        vm.moveToTrash(listOf(f))
                        a.report = rep.copy(largest = rep.largest.filter { it.path != f.path })
                    })
                }
            }
        }

        val empties = a.empties
        if (empties != null) {
            SectionTitle(if (empties.isEmpty()) "No empty folders found" else "${empties.size} empty folders")
            if (empties.isNotEmpty()) {
                DexButton("Move all ${empties.size} to Trash", DexBtn.Danger) {
                    vm.moveToTrash(empties.map { FileEntry.from(File(it)) })
                    a.empties = emptyList()
                }
            }
            for (p in empties.take(200)) {
                FileLine(vm, p, null, onTrash = {
                    vm.moveToTrash(listOf(FileEntry.from(File(p))))
                    a.empties = a.empties?.filter { it != p }
                })
            }
        }

        val dups = a.dups
        if (dups != null) {
            val wasted = dups.sumOf { it.wasted }
            SectionTitle(if (dups.isEmpty()) "No duplicate files found" else "${Format.size(wasted)} wasted by ${dups.size} sets of duplicates")
            for (g in dups.sortedByDescending { it.wasted }.take(100)) {
                Column(
                    Modifier.fillMaxWidth().clip(Radius.s).background(cs.surfaceContainer).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        "${g.files.size} copies of ${Format.size(g.sizeEach)}  -  ${Format.size(g.wasted)} wasted",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                    val oldest = g.files.minByOrNull { File(it).lastModified() }
                    for (p in g.files) {
                        FileLine(vm, p, g.sizeEach, note = if (p == oldest) "Oldest, kept by default" else null, onTrash = {
                            vm.moveToTrash(listOf(FileEntry.from(File(p))))
                            a.dups = a.dups?.map { grp -> grp.withoutFile(p) }?.filter { it.files.size > 1 }
                        })
                    }
                    if (oldest != null) {
                        val extras = g.files.filter { it != oldest }
                        DexButton("Keep oldest, trash ${extras.size}", DexBtn.Plain) {
                            vm.moveToTrash(extras.map { FileEntry.from(File(it)) })
                            a.dups = a.dups?.map { grp -> if (grp === g) grp.copy(files = listOf(oldest)) else grp }?.filter { it.files.size > 1 }
                        }
                    }
                }
            }
        }
    }
}

private fun DuplicateGroup.withoutFile(path: String): DuplicateGroup = copy(files = files.filter { it != path })

@Composable
private fun FileLine(vm: ExplorerViewModel, path: String, size: Long?, note: String? = null, onTrash: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val f = File(path)
    Row(
        Modifier.fillMaxWidth().clip(Radius.xs).clickable { vm.reveal(path) }.padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                (f.parent ?: "") + (note?.let { "  \u00b7  $it" } ?: ""),
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurface.copy(alpha = 0.55f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        size?.let { Text(Format.size(it), style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.75f)) }
        IconBtn(DexIcons.Folder, "Show in folder") { vm.reveal(path) }
        IconBtn(DexIcons.Trash, "Move to Trash") { onTrash() }
    }
}
