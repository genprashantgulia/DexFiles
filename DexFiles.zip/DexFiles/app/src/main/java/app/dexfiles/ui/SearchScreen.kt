package app.dexfiles.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.PaneState
import app.dexfiles.state.TabState
import java.io.File
import kotlinx.coroutines.delay

/** Samsung My Files search: Filters, recent searches, and a floating search bar near the thumbs at the bottom. */
@Composable
fun SearchScreen(vm: ExplorerViewModel, pane: PaneState, tab: TabState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var filtersOpen by remember { mutableStateOf(true) }
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var tv by remember { mutableStateOf(TextFieldValue(tab.query)) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(120); runCatching { focus.requestFocus() } }

    Box(modifier.fillMaxSize()) {
        if (tab.query.isBlank()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).clickable { filtersOpen = !filtersOpen }.padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Filters", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(26.dp).rotate(if (filtersOpen) 0f else -90f))
                }
                AnimatedVisibility(filtersOpen) {
                    Column {
                        SwitchRow("Search current folder only", vm.searchCurrentOnly && !tab.isVirtual, enabled = !tab.isVirtual) { vm.setSearchCurrentOnly(it) }
                        SwitchRow("Include hidden files", vm.showHidden) { vm.setShowHidden(it) }
                    }
                }
                Surface(Modifier.fillMaxWidth().padding(top = 20.dp), shape = RoundedCornerShape(28.dp), color = cs.surfaceContainer) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Recent searches", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                            if (vm.recentSearches.isNotEmpty()) TextButton(onClick = { vm.clearRecents() }) { Text("Clear all") }
                        }
                        if (vm.recentSearches.isEmpty()) {
                            Text("Nothing yet", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp))
                        } else {
                            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for (q in vm.recentSearches.toList()) {
                                    Row(
                                        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainerHigh)
                                            .clickable { tv = TextFieldValue(q, androidx.compose.ui.text.TextRange(q.length)); vm.setQuery(tab, q) }
                                            .padding(start = 18.dp, end = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(q, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                                        Box(Modifier.padding(start = 6.dp).size(28.dp).clip(CircleShape).clickable { vm.removeRecent(q) }, contentAlignment = Alignment.Center) {
                                            Icon(Icons.Filled.Close, "Remove", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Box(Modifier.fillMaxSize().padding(bottom = 92.dp).clip(RoundedCornerShape(Dimens.radiusSheet)).background(cs.surface)) {
                ListingBody(vm, pane, tab)
            }
        }

        // The floating search bar sits at the bottom, where a thumb rests on an 11-inch tablet.
        Surface(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp).fillMaxWidth(0.92f).widthIn(max = 680.dp).imePadding(),
            shape = RoundedCornerShape(36.dp),
            color = cs.surfaceContainerHigh,
            shadowElevation = 10.dp,
        ) {
            Row(Modifier.height(64.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Close search", size = 44.dp) { vm.closeSearch() }
                if (vm.searchCurrentOnly && !tab.isVirtual) {
                    Row(
                        Modifier.height(40.dp).clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainer).padding(start = 14.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(File(tab.path).name.ifEmpty { "Storage" }, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
                        Box(Modifier.padding(start = 4.dp).size(26.dp).clip(CircleShape).clickable { vm.setSearchCurrentOnly(false) }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Close, "Search everywhere", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                        }
                    }
                }
                Box(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    if (tv.text.isEmpty()) Text("Search", style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant)
                    BasicTextField(
                        value = tv,
                        onValueChange = { tv = it; vm.setQuery(tab, it.text) },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.titleMedium.copy(color = cs.onSurface),
                        cursorBrush = SolidColor(cs.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { vm.addRecent(tv.text); focusManager.clearFocus() }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    )
                }
                if (tv.text.isNotEmpty()) {
                    IconBtn(Icons.Filled.Close, "Clear", size = 44.dp) { tv = TextFieldValue(""); vm.clearSearch(tab) }
                }
                Box {
                    IconBtn(Icons.Filled.MoreVert, "More", size = 44.dp) { menu = true }
                    DropdownMenu(shape = RoundedCornerShape(20.dp), containerColor = cs.surfaceContainerHigh, expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Clear recent searches") }, onClick = { menu = false; vm.clearRecents() })
                        DropdownMenuItem(text = { Text("Close search") }, onClick = { menu = false; vm.closeSearch() })
                    }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
