package app.dexfiles.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/** True when the selection bar sits at the top of a wide window (setting); the tray is then a band along the bottom of the panel. */
@Composable
fun barOnTop(vm: ExplorerViewModel): Boolean = vm.barTop && !LocalCompact.current

private val Tray_Chip_H = 30.dp

/** What is in the tray: one strip that runs left to right and scrolls sideways, grouped by the folder each file came from, with a cross on every item. */
@Composable
private fun TrayStrip(vm: ExplorerViewModel, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val groups = vm.tray.toList().groupBy { java.io.File(it.path).parentFile?.name ?: "" }
    Row(
        modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        for ((from, items) in groups) {
            Text("FROM ${from.uppercase()}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = cs.onSurfaceVariant, maxLines = 1, modifier = Modifier.padding(start = 6.dp, end = 2.dp))
            for (e in items) {
                Row(
                    Modifier.height(44.dp).clip(Radius.s).background(cs.onSurface.copy(alpha = 0.07f)).padding(start = 8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FileThumb(e, 26.dp)
                    Text(e.name, fontSize = 13.sp, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp))
                    Box(Modifier.size(44.dp).clip(Radius.xs).clickable { vm.removeFromTray(e.path) }, contentAlignment = Alignment.Center) {
                        Icon(DexIcons.Close, "Remove from tray", Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

private fun trayFrom(vm: ExplorerViewModel): String {
    val from = vm.tray.toList().mapNotNull { java.io.File(it.path).parentFile?.name }.distinct()
    return if (from.isEmpty()) "" else "from " + from.take(2).joinToString(", ") + if (from.size > 2) " +${from.size - 2}" else ""
}

/** Whether the tray may show now: it has items and nothing else (a rename, a drag) owns the bottom edge. */
@Composable
private fun trayVisible(vm: ExplorerViewModel): Boolean = vm.tray.isNotEmpty() && vm.renaming == null && dropRegistry(vm).session == null

/**
 * Bottom layout (touch, and every phone): the tray is a small chip above the left end of the selection bar; open, it is a card as wide as the bar,
 * sitting right above it. Chip, card and bar share one column, so their left edges always line up. Lives inside the files panel, so it moves with it.
 */
@Composable
fun PaneDock(vm: ExplorerViewModel, pane: app.dexfiles.state.PaneState, modifier: Modifier = Modifier) {
    val compact = LocalCompact.current
    val tab = pane.tab
    val active = vm.activePane == pane.index
    val quiet = vm.renaming == null && dropRegistry(vm).session == null
    val selecting = active && quiet && tab.selection.isNotEmpty()
    val showTray = active && trayVisible(vm)
    androidx.compose.runtime.LaunchedEffect(vm.tray.size) { if (vm.tray.isEmpty()) vm.traySheet = false }
    // One column for chip, open card and bar, so their left edges always line up. On a tablet it is left aligned and capped at 560 dp, the same corner as on a phone.
    androidx.compose.foundation.layout.BoxWithConstraints(modifier.fillMaxWidth()) {
        val colW = if (compact) maxWidth - 16.dp else 560.dp.coerceAtMost(maxWidth - 24.dp)
        val colStart by androidx.compose.animation.core.animateDpAsState(
            if (compact) 8.dp else 12.dp,
            app.dexfiles.ui2.design.Motion.glide(260), label = "dockStart",
        )
        Column(Modifier.align(Alignment.BottomStart).padding(start = colStart, bottom = 40.dp).width(colW), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AnimatedVisibility(
                visible = showTray && !vm.traySheet,
                enter = slideInVertically(tween(220)) { it / 2 } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(160)) { it / 2 } + fadeOut(tween(120)),
            ) { TrayChip(vm) }
            AnimatedVisibility(
                visible = showTray && vm.traySheet,
                enter = slideInVertically(tween(240)) { it / 3 } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(180)) { it / 3 } + fadeOut(tween(120)),
            ) { TrayCard(vm) }
            AnimatedVisibility(
                visible = selecting,
                enter = slideInVertically(tween(220)) { it } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120)),
            ) { SelectionPill(vm, tab, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
private fun TrayChip(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.height(Tray_Chip_H).clip(Radius.xs).clickable { vm.traySheet = true },
        shape = Radius.xs,
        color = app.dexfiles.ui2.design.LocalPalette.current.accentSoft,
        border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.35f)),
    ) {
        Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(DexIcons.Tray, null, Modifier.size(15.dp), tint = cs.primary)
            Text("Tray \u00B7 ${vm.tray.size}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
            Icon(DexIcons.ChevronDown, null, Modifier.size(12.dp).graphicsLayer { rotationZ = 180f }, tint = cs.onSurfaceVariant)
        }
    }
}

/** The open tray (bottom layout): header, the list by source folder, then Clear / Copy here / Move here. Copy and Move are greyed where nothing can be dropped. */
@Composable
private fun TrayCard(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val canDrop = !tab.isVirtual && !tab.isSearch
    Surface(Modifier.fillMaxWidth(), shape = Radius.m, color = dialogSurface(), shadowElevation = 16.dp, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f))) {
        Column(Modifier.padding(start = 10.dp, end = 10.dp, top = 4.dp, bottom = 10.dp)) {
            Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    Modifier.weight(1f).height(44.dp).clip(Radius.s).clickable { vm.traySheet = false }.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(DexIcons.Tray, null, Modifier.size(20.dp), tint = cs.primary)
                    Text("Tray \u00B7 ${vm.tray.size} ${if (vm.tray.size == 1) "item" else "items"}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
                    Icon(DexIcons.ChevronDown, null, Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                }
                DexButton("Clear") { vm.tray.clear(); vm.traySheet = false }
            }
            TrayStrip(vm)
            if (!canDrop) Text("Open a folder to drop these into it.", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 6.dp))
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DexButton("Copy here", enabled = canDrop, modifier = Modifier.weight(1f).fillMaxWidth()) { vm.traySheet = false; vm.dropTray(move = false) }
                DexButton("Move ${vm.tray.size} here", DexBtn.Primary, enabled = canDrop, modifier = Modifier.weight(1f).fillMaxWidth()) { vm.traySheet = false; vm.dropTray(move = true) }
            }
        }
    }
}

/**
 * Top layout (wide window, selection bar on top): the tray is a neutral band along the bottom of the files panel, edge to edge,
 * sitting above the status line. Tap the title to see what is in it; amber is only on Move.
 */
@Composable
fun TrayBand(vm: ExplorerViewModel, pane: app.dexfiles.state.PaneState) {
    val cs = MaterialTheme.colorScheme
    val tab = pane.tab
    val canDrop = !tab.isVirtual && !tab.isSearch
    val show = vm.activePane == pane.index && trayVisible(vm)
    androidx.compose.runtime.LaunchedEffect(vm.tray.size) { if (vm.tray.isEmpty()) vm.traySheet = false }
    AnimatedVisibility(visible = show, enter = androidx.compose.animation.expandVertically(tween(220)) + fadeIn(tween(180)), exit = androidx.compose.animation.shrinkVertically(tween(160)) + fadeOut(tween(120))) {
        Column(Modifier.fillMaxWidth().background(cs.surfaceContainer)) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(cs.outlineVariant.copy(alpha = 0.6f)))
            if (vm.traySheet) Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                TrayStrip(vm)
                if (!canDrop) Text("Open a folder to drop these into it.", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 4.dp, bottom = 4.dp))
            }
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    Modifier.weight(1f).height(44.dp).clip(Radius.s).clickable { vm.traySheet = !vm.traySheet }.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(DexIcons.Tray, null, Modifier.size(20.dp), tint = cs.primary)
                    Text("Tray \u00B7 ${vm.tray.size} ${if (vm.tray.size == 1) "item" else "items"}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
                    Text(trayFrom(vm), fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(DexIcons.ChevronDown, null, Modifier.size(14.dp).graphicsLayer { rotationZ = if (vm.traySheet) 0f else 180f }, tint = cs.onSurfaceVariant)
                }
                DexButton("Clear") { vm.tray.clear(); vm.traySheet = false }
                DexButton("Copy here", enabled = canDrop) { vm.traySheet = false; vm.dropTray(move = false) }
                DexButton("Move ${vm.tray.size} here", DexBtn.Primary, enabled = canDrop) { vm.traySheet = false; vm.dropTray(move = true) }
            }
        }
    }
}

/** Phone tab button: a rounded square with the number of tabs, the way a browser shows it. Opens the tab sheet. */
@Composable
fun TabCountButton(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(BtnSize).clip(Radius.s).background(cs.surfaceContainer).clickable { vm.tabSheet = true },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(22.dp).border(1.8.dp, cs.onSurface, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            Text("${vm.panes[0].tabs.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1)
        }
    }
}

/** The list of open tabs, as a bottom sheet. Tap a row to switch, the cross closes it. */
@Composable
fun TabSheet(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val pane = vm.panes[0]
    val labels = vm.rootLabelMap()
    AnimatedVisibility(visible = vm.tabSheet, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.tabSheet = false },
        )
    }
    AnimatedVisibility(
        visible = vm.tabSheet,
        enter = slideInVertically(tween(260)) { it },
        exit = slideOutVertically(tween(200)) { it },
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(dialogSurface())
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(cs.onSurface.copy(alpha = 0.25f)))
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (pane.tabs.size == 1) "1 tab" else "${pane.tabs.size} tabs", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    DexButton("New tab") { vm.addTab(pane, Loc.HOME); vm.tabSheet = false }
                    DexButton("Done", DexBtn.Primary) { vm.tabSheet = false }
                }
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    pane.tabs.forEachIndexed { i, t ->
                        androidx.compose.runtime.key(t.id) {
                            val active = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                            Row(
                                Modifier.fillMaxWidth().height(56.dp).clip(Radius.s)
                                    .background(if (active) Sel.plate() else Color.Transparent)
                                    .clickable { vm.selectTab(pane, i); vm.tabSheet = false }
                                    .padding(start = 12.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    if (Loc.isVirtual(t.path)) virtualIcon(t.path) else DexIcons.Folder, null, Modifier.size(22.dp),
                                    tint = if (active) cs.primary else cs.onSurfaceVariant,
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(if (t.isSearch) "Search" else Loc.title(t.path, labels), fontSize = 15.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (!t.isVirtual && !t.isSearch) Text(t.path, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (pane.tabs.size > 1) Box(Modifier.size(48.dp).clip(Radius.xs).clickable { vm.closeTab(pane, i) }, contentAlignment = Alignment.Center) {
                                    Icon(DexIcons.Close, "Close tab", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
