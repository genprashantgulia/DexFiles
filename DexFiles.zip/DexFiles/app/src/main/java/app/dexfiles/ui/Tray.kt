package app.dexfiles.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel

private val Tray_Chip_H = 40.dp

/** What is in the tray: grouped by the folder the files came from ("FROM DOWNLOADS"), one plain row per file with a cross. Scrolls when long. */
@Composable
private fun TrayList(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
        for ((dir, files) in vm.tray.toList().groupBy { java.io.File(it.path).parent.orEmpty() }) {
            Text(
                "FROM ${java.io.File(dir).name.uppercase()}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp, color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 6.dp, top = 8.dp, bottom = 2.dp),
            )
            for (e in files) {
                Row(Modifier.fillMaxWidth().height(44.dp).padding(start = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FileThumb(e, 30.dp)
                    Text(e.name, fontSize = 14.sp, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Box(Modifier.size(44.dp).clip(Radius.xs).clickable { vm.removeFromTray(e.path) }, contentAlignment = Alignment.Center) {
                        Icon(DexIcons.Close, "Remove from tray", Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/** Whether the tray may show now: it has items and nothing else (a rename, a drag) owns the bottom edge. */
@Composable
private fun trayVisible(vm: ExplorerViewModel): Boolean = vm.tray.isNotEmpty() && vm.renaming == null && dropRegistry(vm).session == null

/**
 * The bottom dock, at every width: one centred column, at most 560 dp wide (the whole width on a phone). The selection bar fills it;
 * the tray is a small chip above the bar's left edge and, open, a card as wide as the bar. The chip keeps the same spot with or without
 * a selection, so nothing moves when the bar comes and goes. Lives inside the files panel, so it moves with it.
 */
@Composable
fun PaneDock(vm: ExplorerViewModel, pane: app.dexfiles.state.PaneState, modifier: Modifier = Modifier) {
    val tab = pane.tab
    val active = vm.activePane == pane.index
    val quiet = vm.renaming == null && dropRegistry(vm).session == null
    val selecting = active && quiet && tab.selection.isNotEmpty()
    val showTray = active && trayVisible(vm)
    androidx.compose.runtime.LaunchedEffect(vm.tray.size) { if (vm.tray.isEmpty()) vm.traySheet = false }
    Column(modifier.widthIn(max = 560.dp).fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        AnimatedVisibility(
            visible = showTray,
            enter = slideInVertically(tween(220)) { it / 2 } + fadeIn(tween(180)),
            exit = slideOutVertically(tween(160)) { it / 2 } + fadeOut(tween(120)),
        ) {
            // Chip and open card trade places in one slot, so the old one never sits above the new one while it leaves.
            AnimatedContent(
                targetState = vm.traySheet,
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.BottomStart,
                transitionSpec = {
                    (fadeIn(tween(200, delayMillis = 60)) + slideInVertically(tween(240)) { it / 4 }) togetherWith fadeOut(tween(100)) using SizeTransform(clip = false) { _, _ -> tween(240) }
                },
                label = "tray",
            ) { open -> if (open) TrayCard(vm) else TrayChip(vm) }
        }
        AnimatedVisibility(
            visible = selecting,
            enter = slideInVertically(tween(220)) { it } + fadeIn(tween(180)),
            exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120)),
        ) { SelectionPill(vm, tab, Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun TrayChip(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val soft = app.dexfiles.ui2.design.LocalPalette.current.accentSoft
    Surface(
        modifier = Modifier.height(Tray_Chip_H).clip(Radius.m).clickable { vm.traySheet = true },
        shape = Radius.m,
        color = dialogSurface(),
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.45f)),
    ) {
        Row(Modifier.background(soft).padding(start = 12.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // The newest few items peek out as a small stack, so the chip says what is in it, not only how many.
            Row(horizontalArrangement = Arrangement.spacedBy((-8).dp)) {
                for (e in vm.tray.toList().takeLast(3)) Box(Modifier.size(26.dp).clip(Radius.xs).border(2.dp, dialogSurface(), Radius.xs)) { FileThumb(e, 26.dp) }
            }
            Text("Tray \u00B7 ${vm.tray.size}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
            Icon(DexIcons.ChevronDown, null, Modifier.size(14.dp).graphicsLayer { rotationZ = 180f }, tint = cs.onSurfaceVariant)
        }
    }
}

/** The open tray: header, the list grouped by source folder, then Clear / Copy here / Move here. Copy and Move are greyed where nothing can be dropped. */
@Composable
private fun TrayCard(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val canDrop = !tab.isVirtual && !tab.isSearch
    Surface(Modifier.fillMaxWidth(), shape = Radius.m, color = dialogSurface(), shadowElevation = 16.dp, border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.6f))) {
        Column(Modifier.padding(start = 10.dp, end = 10.dp, top = 4.dp, bottom = 10.dp)) {
            Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    Modifier.weight(1f).height(44.dp).clip(Radius.s).clickable { vm.traySheet = false }.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(DexIcons.Tray, null, Modifier.size(20.dp), tint = cs.primary)
                    Text("Tray \u00B7 ${vm.tray.size} ${if (vm.tray.size == 1) "item" else "items"}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
                    Icon(DexIcons.ChevronDown, null, Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                }
                DexButton("Clear") { vm.tray.clear(); vm.traySheet = false }
            }
            TrayList(vm)
            if (!canDrop) Text("Open a folder to drop these into it.", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 6.dp))
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DexButton("Copy here", enabled = canDrop, modifier = Modifier.weight(1f).fillMaxWidth()) { vm.traySheet = false; vm.dropTray(move = false) }
                DexButton("Move ${vm.tray.size} here", DexBtn.Primary, enabled = canDrop, modifier = Modifier.weight(1f).fillMaxWidth()) { vm.traySheet = false; vm.dropTray(move = true) }
            }
        }
    }
}

/** Phone tab button: a rounded square with the number of tabs, the way a browser shows it. Opens the tab sheet. */
@Composable
fun TabCountButton(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(BtnSize).clip(Radius.s).background(cs.surfaceContainer).clickable { vm.tabSheet = true },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(22.dp).border(1.8.dp, cs.onSurface, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            Text("${vm.panes[0].tabs.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1)
        }
    }
}

/** The list of open tabs, as a bottom sheet. Tap a row to switch, the cross closes it. */
@Composable
fun TabSheet(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val pane = vm.panes[0]
    val labels = vm.rootLabelMap()
    AnimatedVisibility(visible = vm.tabSheet, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.tabSheet = false },
        )
    }
    AnimatedVisibility(
        visible = vm.tabSheet,
        enter = slideInVertically(tween(260)) { it },
        exit = slideOutVertically(tween(200)) { it },
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(dialogSurface())
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(cs.onSurface.copy(alpha = 0.25f)))
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (pane.tabs.size == 1) "1 tab" else "${pane.tabs.size} tabs", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    DexButton("New tab") { vm.addTab(pane, Loc.HOME); vm.tabSheet = false }
                    DexButton("Done", DexBtn.Primary) { vm.tabSheet = false }
                }
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    pane.tabs.forEachIndexed { i, t ->
                        androidx.compose.runtime.key(t.id) {
                            val active = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                            Row(
                                Modifier.fillMaxWidth().height(56.dp).clip(Radius.s)
                                    .background(if (active) Sel.plate() else Color.Transparent)
                                    .clickable { vm.selectTab(pane, i); vm.tabSheet = false }
                                    .padding(start = 12.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    if (Loc.isVirtual(t.path)) virtualIcon(t.path) else DexIcons.Folder, null, Modifier.size(22.dp),
                                    tint = if (active) cs.primary else cs.onSurfaceVariant,
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(if (t.isSearch) "Search" else Loc.title(t.path, labels), fontSize = 15.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (!t.isVirtual && !t.isSearch) Text(t.path, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (pane.tabs.size > 1) Box(Modifier.size(48.dp).clip(Radius.xs).clickable { vm.closeTab(pane, i) }, contentAlignment = Alignment.Center) {
                                    Icon(DexIcons.Close, "Close tab", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
