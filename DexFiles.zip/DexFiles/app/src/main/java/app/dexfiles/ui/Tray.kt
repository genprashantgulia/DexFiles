package app.dexfiles.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dexfiles.state.ExplorerViewModel
import app.dexfiles.state.Loc
import app.dexfiles.ui2.design.DexIcons
import app.dexfiles.ui2.design.Radius
import app.dexfiles.ui2.design.Sel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/** Phone and in-between widths (mock F2): a small "Tray · 5" chip above the thumb zone, bottom left; it opens a sheet. Wide windows keep the strip (F1). */
@Composable
fun TrayBar(vm: ExplorerViewModel, modifier: Modifier) {
    if (!LocalCompact.current) { TrayStrip(vm, modifier); return }
    val cs = MaterialTheme.colorScheme
    val selecting = vm.current.selection.isNotEmpty()
    // Sits just above the selection bar when there is one, otherwise just above the bottom edge.
    val bottom by androidx.compose.animation.core.animateDpAsState(if (selecting) 124.dp else 36.dp, app.dexfiles.ui2.design.Motion.glide(260), label = "trayChipLift")
    AnimatedVisibility(
        visible = vm.tray.isNotEmpty() && vm.renaming == null && dropRegistry(vm).session == null && !vm.traySheet,
        modifier = modifier.fillMaxWidth().padding(bottom = bottom, start = 12.dp, end = 12.dp),
        enter = slideInVertically(tween(220)) { it } + fadeIn(tween(180)),
        exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120)),
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
            Surface(
                modifier = Modifier.height(44.dp).clip(Radius.s).clickable { vm.traySheet = true },
                shape = Radius.s,
                color = app.dexfiles.ui2.design.LocalPalette.current.accentSoft,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.35f)),
            ) {
                Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(DexIcons.Tray, null, Modifier.size(18.dp), tint = cs.primary)
                    Text("Tray \u00B7 ${vm.tray.size}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
                    Icon(DexIcons.ChevronDown, null, Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                }
            }
        }
    }
}

/** What is in the tray, grouped by the folder it came from; every row has a cross. */
@Composable
private fun TrayList(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
        val groups = vm.tray.toList().groupBy { java.io.File(it.path).parentFile?.name ?: "" }
        for ((from, items) in groups) {
            Text("FROM ${from.uppercase()}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 2.dp))
            for (e in items) {
                Row(Modifier.fillMaxWidth().height(44.dp).padding(start = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FileThumb(e, 28.dp)
                    Text(e.name, fontSize = 14.sp, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Box(Modifier.size(44.dp).clip(Radius.xs).clickable { vm.removeFromTray(e.path) }, contentAlignment = Alignment.Center) {
                        Icon(DexIcons.Close, "Remove from tray", Modifier.size(14.dp), tint = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

/** The tray as a bottom sheet (phones): the list, then Clear, Copy here and Move here. Those two are greyed where nothing can be dropped (Recents, search). */
@Composable
fun TraySheet(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val canDrop = !tab.isVirtual && !tab.isSearch
    // Emptying the tray (or moving everything out) closes the sheet by itself.
    androidx.compose.runtime.LaunchedEffect(vm.tray.size) { if (vm.tray.isEmpty()) vm.traySheet = false }
    AnimatedVisibility(visible = vm.traySheet, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.traySheet = false },
        )
    }
    AnimatedVisibility(visible = vm.traySheet, enter = slideInVertically(tween(260)) { it }, exit = slideOutVertically(tween(200)) { it }) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(dialogSurface())
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(cs.onSurface.copy(alpha = 0.25f)))
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(DexIcons.Tray, null, Modifier.size(20.dp), tint = cs.primary)
                    Text("Tray \u00B7 ${vm.tray.size} ${if (vm.tray.size == 1) "item" else "items"}", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    DexButton("Clear") { vm.tray.clear(); vm.traySheet = false }
                }
                TrayList(vm)
                Text(
                    if (canDrop) "Copy or move everything into the folder you are in." else "Open a folder to drop these into it.",
                    fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { DexButton("Copy here", enabled = canDrop) { vm.traySheet = false; vm.dropTray(move = false) } }
                    Box(Modifier.weight(1f)) { DexButton("Move ${vm.tray.size} here", DexBtn.Primary, enabled = canDrop) { vm.traySheet = false; vm.dropTray(move = true) } }
                }
            }
        }
    }
}

/**
 * The Tray: a holding strip for things picked up in one folder and dropped in another. It floats above the command bar,
 * so Move / Copy here are in thumb reach. Tap the label to see what is in it.
 */
@Composable
private fun TrayStrip(vm: ExplorerViewModel, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val tab = vm.current
    val canDrop = !tab.isVirtual && !tab.isSearch
    val compact = LocalCompact.current
    val lift by androidx.compose.animation.core.animateDpAsState(0.dp, app.dexfiles.ui2.design.Motion.glide(260), label = "trayLift")
    var open by remember { mutableStateOf(false) }
    AnimatedVisibility(
        visible = vm.tray.isNotEmpty() && vm.renaming == null && dropRegistry(vm).session == null,
        modifier = modifier.padding(bottom = 28.dp + lift, start = 12.dp, end = 12.dp),
        enter = slideInVertically(tween(220)) { it } + fadeIn(tween(180)),
        exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120)),
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 620.dp).fillMaxWidth(),
            shape = Radius.m,
            color = app.dexfiles.ui2.design.LocalPalette.current.accentSoft,
            shadowElevation = 12.dp,
            border = BorderStroke(1.dp, cs.primary.copy(alpha = 0.35f)),
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (open) {
                    TrayList(vm)
                }
                Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        Modifier.weight(1f).height(44.dp).clip(Radius.s).clickable { open = !open }.padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(DexIcons.Tray, null, Modifier.size(20.dp), tint = cs.primary)
                        Text(if (compact) "Tray \u00B7 ${vm.tray.size}" else "Tray \u00B7 ${vm.tray.size} items", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1)
                        if (!compact) {
                            val from = vm.tray.toList().mapNotNull { java.io.File(it.path).parentFile?.name }.distinct()
                            Text("from " + from.take(3).joinToString(", ") + if (from.size > 3) "\u2026" else "", fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    DexButton(if (open) "Clear tray" else "Clear") { vm.tray.clear(); open = false }
                    DexButton(if (compact) "Copy" else "Copy here", enabled = canDrop) { vm.dropTray(move = false); open = false }
                    DexButton(if (compact) "Move" else "Move ${vm.tray.size} here", DexBtn.Primary, enabled = canDrop) { vm.dropTray(move = true); open = false }
                }
            }
        }
    }
}

/** Phone tab button: a rounded square with the number of tabs, the way a browser shows it. Opens the tab sheet. */
@Composable
fun TabCountButton(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(BtnSize).clip(Radius.s).background(cs.surfaceContainer).clickable { vm.tabSheet = true },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(22.dp).border(1.8.dp, cs.onSurface, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            Text("${vm.panes[0].tabs.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1)
        }
    }
}

/** The list of open tabs, as a bottom sheet. Tap a row to switch, the cross closes it. */
@Composable
fun TabSheet(vm: ExplorerViewModel) {
    val cs = MaterialTheme.colorScheme
    val pane = vm.panes[0]
    val labels = vm.rootLabelMap()
    AnimatedVisibility(visible = vm.tabSheet, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.tabSheet = false },
        )
    }
    AnimatedVisibility(
        visible = vm.tabSheet,
        enter = slideInVertically(tween(260)) { it },
        exit = slideOutVertically(tween(200)) { it },
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.widthIn(max = 560.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(dialogSurface())
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(cs.onSurface.copy(alpha = 0.25f)))
                Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (pane.tabs.size == 1) "1 tab" else "${pane.tabs.size} tabs", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    DexButton("New tab") { vm.addTab(pane, Loc.HOME); vm.tabSheet = false }
                    DexButton("Done", DexBtn.Primary) { vm.tabSheet = false }
                }
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    pane.tabs.forEachIndexed { i, t ->
                        androidx.compose.runtime.key(t.id) {
                            val active = i == pane.active.coerceIn(0, pane.tabs.lastIndex)
                            Row(
                                Modifier.fillMaxWidth().height(56.dp).clip(Radius.s)
                                    .background(if (active) Sel.plate() else Color.Transparent)
                                    .clickable { vm.selectTab(pane, i); vm.tabSheet = false }
                                    .padding(start = 12.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    if (Loc.isVirtual(t.path)) virtualIcon(t.path) else DexIcons.Folder, null, Modifier.size(22.dp),
                                    tint = if (active) cs.primary else cs.onSurfaceVariant,
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(if (t.isSearch) "Search" else Loc.title(t.path, labels), fontSize = 15.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (!t.isVirtual && !t.isSearch) Text(t.path, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (pane.tabs.size > 1) Box(Modifier.size(48.dp).clip(Radius.xs).clickable { vm.closeTab(pane, i) }, contentAlignment = Alignment.Center) {
                                    Icon(DexIcons.Close, "Close tab", Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Between two panes: copy what is selected on one side into the folder shown on the other. */
@Composable
internal fun TransferRail(vm: ExplorerViewModel) {
    val cs = androidx.compose.material3.MaterialTheme.colorScheme
    androidx.compose.foundation.layout.Column(
        Modifier.width(44.dp).fillMaxHeight(),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
    ) {
        fun go(from: Int, to: Int) {
            val src = vm.panes[from].tab
            val dst = vm.panes[to].tab
            val sel = vm.selectedEntries(src).map { it.path }
            if (dst.isVirtual || dst.isSearch) { vm.toast("The other pane is not a folder"); return }
            if (sel.isEmpty()) { vm.toast("Select items in this pane first"); return }
            vm.copyPathsTo(sel, dst.path)
        }
        for ((icon, from) in listOf(app.dexfiles.ui2.design.DexIcons.Forward to 0, app.dexfiles.ui2.design.DexIcons.Back to 1)) {
            val has = vm.selectedEntries(vm.panes[from].tab).isNotEmpty()
            androidx.compose.foundation.layout.Box(
                Modifier.padding(vertical = 4.dp).size(40.dp)
                    .clip(app.dexfiles.ui2.design.Radius.s)
                    .background(if (has) cs.primary else cs.surfaceContainer),
            ) {
                IconBtn(icon, if (from == 0) "Copy to right pane" else "Copy to left pane", size = 40.dp) { go(from, 1 - from) }
            }
        }
    }
}
